import { useCallback, useEffect, useRef } from 'react'
import { useSearchParams } from 'react-router-dom'

import { useMessagingSession } from '@/pages/shared/hooks/use-messaging-session'
import { useSession } from '@/pages/shared/auth/session-store'

export const useMessagesPage = () => {
  const isAuthenticated = useSession((state) => state.isAuthenticated)
  const user = useSession((state) => state.user)
  const messaging = useMessagingSession(isAuthenticated)
  const [searchParams, setSearchParams] = useSearchParams()
  const requestedConversationId = searchParams.get('conversationId') ?? undefined
  const consumedConversationIdRef = useRef<string | undefined>(undefined)
  const {
    conversations,
    selectConversation,
    sendSocketEvent,
  } = messaging

  const handleTypingChange = useCallback((conversationId: string, isTyping: boolean) => {
    sendSocketEvent({
      type: isTyping ? 'typing_started' : 'typing_stopped',
      conversationId,
    })
  }, [sendSocketEvent])

  useEffect(() => {
    if (
      requestedConversationId &&
      consumedConversationIdRef.current !== requestedConversationId &&
      conversations.some((conversation) => conversation.id === requestedConversationId)
    ) {
      consumedConversationIdRef.current = requestedConversationId
      queueMicrotask(() => {
        selectConversation(requestedConversationId)
        setSearchParams({}, { replace: true })
      })
    }
  }, [conversations, requestedConversationId, selectConversation, setSearchParams])

  return {
    handleTypingChange,
    messaging,
    isAuthenticated,
    user,
  }
}
