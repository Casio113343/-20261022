import { MessageCircleMore } from 'lucide-react'

export const EmptyMessagesPanel = () => (
  <div className="flex h-full min-h-0 items-center justify-center px-4 py-4 sm:px-6 lg:px-8">
    <div className="mx-auto flex h-full w-full max-w-3xl flex-col items-center justify-center rounded-[34px] border border-slate-200 bg-white text-center shadow-[0_28px_90px_rgba(15,23,42,0.08)]">
      <MessageCircleMore className="h-10 w-10 text-slate-400" />
      <h1 className="mt-5 text-2xl font-semibold text-slate-950">No messages yet</h1>
      <p className="mt-2 max-w-md text-sm leading-6 text-slate-500">
        Start a conversation from a listing and it will appear here.
      </p>
    </div>
  </div>
)
