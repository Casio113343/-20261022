import { EmptyMessagesPanel } from '@/pages/MessagesPage/components/EmptyMessagesPanel'
import { useMessagesPage } from '@/pages/MessagesPage/hooks/use-messages-page'
import { MessagingSurface } from '@/pages/shared/messaging/MessagingSurface'

export default function MessagesPage() {
  const page = useMessagesPage()

  if (!page.user || !page.isAuthenticated) {
    return null
  }

  const showEmptyMessages =
    page.messaging.conversations.length === 0 &&
    page.messaging.loadState.status === 'ready'

  return (
    <div className="h-[calc(100vh-81px)] min-h-0 overflow-hidden">
      {showEmptyMessages ? (
        <EmptyMessagesPanel />
      ) : (
        <MessagingSurface
          connectionState={page.messaging.connectionState}
          conversations={page.messaging.conversations}
          currentUserId={page.user.id}
          messages={page.messaging.selectedMessages}
          onQueueFiles={page.messaging.queueFiles}
          onSelectConversation={page.messaging.selectConversation}
          onSendMessage={(body, pendingAttachments) =>
            page.messaging.selectedConversationId
              ? page.messaging.sendMessage(page.messaging.selectedConversationId, body, pendingAttachments)
              : Promise.resolve({ ok: false, message: 'Select a conversation first.' })
          }
          onTypingChange={page.handleTypingChange}
          selectedConversationId={page.messaging.selectedConversationId}
          typingUserIds={page.messaging.selectedConversationId ? (page.messaging.typingUserIds[page.messaging.selectedConversationId] ?? []) : []}
          variant="inbox"
        />
      )}
    </div>
  )
}
