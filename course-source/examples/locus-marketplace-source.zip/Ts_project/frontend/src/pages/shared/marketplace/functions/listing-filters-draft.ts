import type {
  ApartmentSubtype,
  HouseSubtype,
  ListingSort,
  PropertyType,
} from '@/objects/listings'
import {
  defaultMarketplaceFilters,
  type MarketplaceFilterValues,
} from '@/pages/shared/marketplace/functions/marketplace-filters'

export type RangeConfig = {
  max: number
  step: number
  unit: 'currency' | 'size'
  label: string
  kind: 'price' | 'floor' | 'land'
}

export type SelectOption<T extends string> = {
  label: string
  value: T
}

export const salePriceConfig: RangeConfig = {
  max: 12_000_000,
  step: 50_000,
  unit: 'currency',
  label: 'Price Range',
  kind: 'price',
}

export const rentPriceConfig: RangeConfig = {
  max: 5_000,
  step: 25,
  unit: 'currency',
  label: 'Weekly Rent',
  kind: 'price',
}

export const floorSizeConfig: RangeConfig = {
  max: 1_500,
  step: 10,
  unit: 'size',
  label: 'Floor Size',
  kind: 'floor',
}

export const landSizeConfig: RangeConfig = {
  max: 3_000,
  step: 10,
  unit: 'size',
  label: 'Land Size',
  kind: 'land',
}

export const propertyTypeOptions: SelectOption<PropertyType>[] = [
  { label: 'House', value: 'house' },
  { label: 'Apartment', value: 'apartment' },
  { label: 'Vacant land', value: 'vacant_land' },
]

export const houseSubtypeOptions: SelectOption<HouseSubtype>[] = [
  { label: 'Free standing', value: 'free_standing' },
  { label: 'Duplex', value: 'duplex' },
  { label: 'Terrace', value: 'terrace' },
  { label: 'Villa', value: 'villa' },
  { label: 'Off the plan', value: 'off_the_plan' },
]

export const apartmentSubtypeOptions: SelectOption<ApartmentSubtype>[] = [
  { label: 'Standard', value: 'standard' },
  { label: 'Unit', value: 'unit' },
  { label: 'Penthouse', value: 'penthouse' },
  { label: 'Studio', value: 'studio' },
  { label: 'Off the plan', value: 'off_the_plan' },
]

export const houseSubtypeValues = houseSubtypeOptions.map(({ value }) => value)
export const apartmentSubtypeValues = apartmentSubtypeOptions.map(({ value }) => value)

export const featureOptions = (max: number) =>
  [
    { label: 'Any', value: '' },
    ...Array.from({ length: max }, (_, index) => {
      const value = String(index + 1)

      return {
        label: `${value}+`,
        value,
      }
    }),
  ] as const

export const sortOptions: SelectOption<ListingSort>[] = [
  { label: 'Newest', value: 'newest' },
  { label: 'Price Low to High', value: 'price_asc' },
  { label: 'Price High to Low', value: 'price_desc' },
]

export const numberLabel = (value: number, unit: RangeConfig['unit']) =>
  unit === 'currency'
    ? new Intl.NumberFormat('en-AU', {
        style: 'currency',
        currency: 'AUD',
        notation: value >= 1_000_000 ? 'compact' : 'standard',
        maximumFractionDigits: value >= 1_000_000 ? 1 : 0,
      }).format(value).replace('M', 'm').replace('K', 'k')
    : `${new Intl.NumberFormat('en-AU').format(value)} m²`

export const parseRangeValue = (value: string, max: number) => {
  const parsed = Number(value)
  return Number.isFinite(parsed) ? Math.min(Math.max(parsed, 0), max) : 0
}

export const toRangeDraft = (minValue: string, maxValue: string, max: number) => {
  const min = minValue === '' ? 0 : parseRangeValue(minValue, max)
  const rawMax = maxValue === '' ? max : parseRangeValue(maxValue, max)

  return {
    min: Math.min(min, rawMax),
    max: Math.max(min, rawMax),
  }
}

export const toStoredRangeValue = (value: number, bound: 'min' | 'max', max: number) =>
  bound === 'min'
    ? value <= 0
      ? ''
      : String(value)
    : value >= max
      ? ''
      : String(value)

export const rangeSummary = (
  minValue: string,
  maxValue: string,
  config: RangeConfig,
) => {
  const hasMin = minValue !== ''
  const hasMax = maxValue !== ''
  const min = hasMin ? parseRangeValue(minValue, config.max) : 0
  const max = hasMax ? parseRangeValue(maxValue, config.max) : config.max

  if (!hasMin && !hasMax) {
    return 'Any'
  }

  if (hasMin && !hasMax) {
    return `Over ${numberLabel(min, config.unit)}`
  }

  if (!hasMin && hasMax) {
    return `Up to ${numberLabel(max, config.unit)}`
  }

  return `${numberLabel(min, config.unit)} - ${numberLabel(max, config.unit)}`
}

export const togglePropertyType = (
  currentValues: PropertyType[],
  nextValue: PropertyType,
): PropertyType[] =>
  currentValues.includes(nextValue)
    ? currentValues.filter((value) => value !== nextValue)
    : [...currentValues, nextValue]

export const toggleHouseSubtype = (
  filters: MarketplaceFilterValues,
  nextValue: HouseSubtype,
): MarketplaceFilterValues => {
  const houseSubtypes = filters.houseSubtypes.includes(nextValue)
    ? filters.houseSubtypes.filter((value) => value !== nextValue)
    : [...filters.houseSubtypes, nextValue]

  return {
    ...filters,
    houseSubtypes,
    propertyTypes:
      houseSubtypes.length > 0
        ? filters.propertyTypes.includes('house')
          ? filters.propertyTypes
          : [...filters.propertyTypes, 'house']
        : filters.propertyTypes.filter((value) => value !== 'house'),
  }
}

export const toggleApartmentSubtype = (
  filters: MarketplaceFilterValues,
  nextValue: ApartmentSubtype,
): MarketplaceFilterValues => {
  const apartmentSubtypes = filters.apartmentSubtypes.includes(nextValue)
    ? filters.apartmentSubtypes.filter((value) => value !== nextValue)
    : [...filters.apartmentSubtypes, nextValue]

  return {
    ...filters,
    apartmentSubtypes,
    propertyTypes:
      apartmentSubtypes.length > 0
        ? filters.propertyTypes.includes('apartment')
          ? filters.propertyTypes
          : [...filters.propertyTypes, 'apartment']
        : filters.propertyTypes.filter((value) => value !== 'apartment'),
  }
}

export const toggleListingPropertyType = (
  filters: MarketplaceFilterValues,
  nextValue: PropertyType,
): MarketplaceFilterValues => {
  const propertyTypes = togglePropertyType(filters.propertyTypes, nextValue)
  const hasHouse = propertyTypes.includes('house')
  const hasApartment = propertyTypes.includes('apartment')

  return {
    ...filters,
    propertyTypes,
    houseSubtypes: hasHouse
      ? nextValue === 'house' || filters.houseSubtypes.length === 0
        ? houseSubtypeValues
        : filters.houseSubtypes
      : [],
    apartmentSubtypes: hasApartment
      ? nextValue === 'apartment' || filters.apartmentSubtypes.length === 0
        ? apartmentSubtypeValues
        : filters.apartmentSubtypes
      : [],
  }
}

export const normalizeDraftFilters = (
  nextDraft: MarketplaceFilterValues,
): MarketplaceFilterValues => ({
  ...nextDraft,
  query: nextDraft.query.trim(),
})

export const clearMarketplaceDraft = (
  draftFilters: MarketplaceFilterValues,
  isHomeVariant: boolean,
): MarketplaceFilterValues => ({
  ...defaultMarketplaceFilters,
  marketMode: isHomeVariant ? draftFilters.marketMode : defaultMarketplaceFilters.marketMode,
})
