import type {
  ListingStatus,
  TransactionType,
} from '@/objects/listings'

type ListingStatusPillProps = {
  listingStatus: ListingStatus
  transactionType: TransactionType
}

type ListingTag = {
  label: string
  className: string
}

const listingTagFor = (
  listingStatus: ListingStatus,
  transactionType: TransactionType,
): ListingTag =>
  listingStatus === 'sold'
    ? {
        label: 'Sold',
        className: 'border border-rose-200/80 bg-rose-50 text-rose-700',
      }
    : listingStatus === 'leased'
      ? {
          label: 'Leased',
          className: 'border border-amber-200/80 bg-amber-50 text-amber-700',
        }
      : listingStatus === 'archived'
        ? {
            label: 'Archived',
            className: 'border border-slate-200/80 bg-slate-100 text-slate-700',
          }
        : transactionType === 'rent'
          ? {
              label: 'For Rent',
              className: 'border border-sky-200/80 bg-sky-50 text-sky-700',
            }
          : {
              label: 'For Sale',
              className: 'border border-emerald-200/80 bg-emerald-50 text-emerald-700',
            }

export const ListingStatusPill = ({
  listingStatus,
  transactionType,
}: ListingStatusPillProps) => {
  const listingTag = listingTagFor(listingStatus, transactionType)

  return (
    <span
      className={[
        'inline-flex items-center rounded-full px-4 py-1.5 text-sm font-semibold tracking-[0.08em] shadow-sm backdrop-blur',
        listingTag.className,
      ].join(' ')}
    >
      {listingTag.label}
    </span>
  )
}
