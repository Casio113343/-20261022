export const headerActionClass =
  'inline-flex h-10 items-center rounded-full border border-white/50 bg-white/60 px-4 text-sm font-medium leading-none text-slate-700 shadow-sm transition hover:text-slate-950'

export const headerActionTextClass = 'text-sm font-medium leading-none'
