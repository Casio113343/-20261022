import {
  Bath,
  BedDouble,
  CarFront,
  SlidersHorizontal,
  Sparkles,
} from 'lucide-react'

import { Button } from '@/components/ui/button'
import type { ListingSort } from '@/objects/listings'
import { ListingFilterPropertyTypesField } from '@/pages/shared/marketplace/components/ListingFilters/ListingFilterPropertyTypesField'
import { ListingFilterRangeSection } from '@/pages/shared/marketplace/components/ListingFilters/ListingFilterRangeSection'
import { ListingFilterSectionCard } from '@/pages/shared/marketplace/components/ListingFilters/ListingFilterSectionCard'
import { ListingFilterSegmentedSection } from '@/pages/shared/marketplace/components/ListingFilters/ListingFilterSegmentedSection'
import type { ListingFiltersController } from '@/pages/shared/marketplace/components/ListingFilters/hooks/use-listing-filters'
import {
  featureOptions,
  sortOptions,
} from '@/pages/shared/marketplace/functions/listing-filters-draft'
import type { MarketplaceFilterValues } from '@/pages/shared/marketplace/functions/marketplace-filters'

type ListingFilterDialogPanelProps = {
  actionLabel: string
  controller: ListingFiltersController
  isHomeVariant: boolean
}

export const ListingFilterDialogPanel = ({
  actionLabel,
  controller,
  isHomeVariant,
}: ListingFilterDialogPanelProps) => {
  const {
    clearAll,
    closeWithoutApplying,
    commitDraft,
    draftFilters,
    handleApartmentSubtypeToggle,
    handleHouseSubtypeToggle,
    handlePropertyTypeToggle,
    isApartmentSubtypeOpen,
    isHouseSubtypeOpen,
    priceConfig,
    setIsApartmentSubtypeOpen,
    setIsHouseSubtypeOpen,
    showDwellingFeatures,
    showFloorSize,
    showLandSize,
    sizeConfigs,
    updateDraft,
  } = controller

  return (
    <div className="flex max-h-[min(74vh,48rem)] flex-col">
      <div className="flex items-center justify-between gap-4 border-b border-slate-200/80 px-6 py-3.5">
        <p className="text-lg font-semibold tracking-tight text-slate-950">Filters</p>
        <button
          className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-100"
          onClick={clearAll}
          type="button"
        >
          Reset All
        </button>
      </div>

      <div className="overflow-y-auto px-6 py-5">
        <div className="space-y-4">
          {!isHomeVariant ? (
            <ListingFilterSectionCard>
              <ListingFilterSegmentedSection
                icon={<Sparkles className="h-4 w-4 text-slate-400" />}
                label="Type"
                onSelect={(value) =>
                  updateDraft({ marketMode: value as MarketplaceFilterValues['marketMode'] })
                }
                options={[
                  { label: 'Buy', value: 'sale' },
                  { label: 'Rent', value: 'rent' },
                  { label: 'Sold', value: 'sold' },
                  { label: 'Leased', value: 'leased' },
                ]}
                value={draftFilters.marketMode}
              />
            </ListingFilterSectionCard>
          ) : null}

          <ListingFilterSectionCard>
            <ListingFilterPropertyTypesField
              apartmentSubtypes={draftFilters.apartmentSubtypes}
              houseSubtypes={draftFilters.houseSubtypes}
              isApartmentSubtypeOpen={isApartmentSubtypeOpen}
              isHouseSubtypeOpen={isHouseSubtypeOpen}
              selected={draftFilters.propertyTypes}
              onApartmentSubtypeToggle={handleApartmentSubtypeToggle}
              onApartmentSubtypeVisibilityChange={() =>
                setIsApartmentSubtypeOpen((current) => !current)
              }
              onHouseSubtypeToggle={handleHouseSubtypeToggle}
              onHouseSubtypeVisibilityChange={() =>
                setIsHouseSubtypeOpen((current) => !current)
              }
              onToggle={handlePropertyTypeToggle}
            />
          </ListingFilterSectionCard>

          <ListingFilterRangeSection
            config={priceConfig}
            maxValue={draftFilters.maxPrice}
            minValue={draftFilters.minPrice}
            onChange={updateDraft}
          />

          {showFloorSize ? (
            <ListingFilterRangeSection
              config={sizeConfigs.floor}
              maxValue={draftFilters.maxFloorSize}
              minValue={draftFilters.minFloorSize}
              onChange={updateDraft}
            />
          ) : null}

          {showLandSize ? (
            <ListingFilterRangeSection
              config={sizeConfigs.land}
              maxValue={draftFilters.maxLandSize}
              minValue={draftFilters.minLandSize}
              onChange={updateDraft}
            />
          ) : null}

          <ListingFilterSectionCard>
            <ListingFilterSegmentedSection
              icon={<SlidersHorizontal className="h-4 w-4 text-slate-400" />}
              label="Sort"
              onSelect={(value) => updateDraft({ sort: value as ListingSort })}
              options={sortOptions}
              value={draftFilters.sort}
            />
          </ListingFilterSectionCard>

          {showDwellingFeatures ? (
            <>
              <ListingFilterSectionCard>
                <ListingFilterSegmentedSection
                  icon={<BedDouble className="h-4 w-4 text-slate-400" />}
                  label="Bedrooms"
                  onSelect={(value) => updateDraft({ bedrooms: value })}
                  options={featureOptions(5)}
                  value={draftFilters.bedrooms}
                />
              </ListingFilterSectionCard>
              <ListingFilterSectionCard>
                <ListingFilterSegmentedSection
                  icon={<Bath className="h-4 w-4 text-slate-400" />}
                  label="Bathrooms"
                  onSelect={(value) => updateDraft({ bathrooms: value })}
                  options={featureOptions(5)}
                  value={draftFilters.bathrooms}
                />
              </ListingFilterSectionCard>
              <ListingFilterSectionCard>
                <ListingFilterSegmentedSection
                  icon={<CarFront className="h-4 w-4 text-slate-400" />}
                  label="Parking"
                  onSelect={(value) => updateDraft({ carSpaces: value })}
                  options={featureOptions(5)}
                  value={draftFilters.carSpaces}
                />
              </ListingFilterSectionCard>
            </>
          ) : null}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 border-t border-slate-200/80 bg-white/90 px-6 py-4 backdrop-blur-xl">
        <Button
          className="h-12 rounded-full border border-slate-200 bg-white text-slate-700 hover:bg-slate-100"
          onClick={closeWithoutApplying}
          type="button"
          variant="outline"
        >
          Cancel
        </Button>
        <Button
          className="h-12 rounded-full bg-slate-950 text-white shadow-[0_12px_24px_rgba(15,23,42,0.16)] hover:bg-slate-800"
          onClick={commitDraft}
          type="button"
        >
          {actionLabel}
        </Button>
      </div>
    </div>
  )
}
