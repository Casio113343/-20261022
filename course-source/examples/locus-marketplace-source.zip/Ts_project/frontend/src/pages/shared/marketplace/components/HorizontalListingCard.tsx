import { ChevronLeft, ChevronRight, Heart } from 'lucide-react'
import type { ReactNode } from 'react'
import { useState } from 'react'
import { Link } from 'react-router-dom'

import { AgentAttribution } from '@/pages/shared/marketplace/components/AgentAttribution'
import { PropertyFacts } from '@/pages/shared/marketplace/components/PropertyFacts'
import { ListingStatusPill } from '@/pages/shared/marketplace/components/ListingStatusPill'
import type { ListingSummary } from '@/objects/listings'
import {
  formatPrice,
  formatPropertyLabel,
} from '@/pages/shared/marketplace/functions/marketplace-format'

type HorizontalListingCardProps = {
  listing: ListingSummary
  isSaved?: boolean
  onToggleSave?: (listingId: string) => void
  onOpenListing?: (listingId: string) => void
  secondaryActionIcon?: ReactNode
  secondaryActionLabel?: string
  secondaryActionTo?: string
  actionState?: unknown
  actionLabel?: string
  actionTo?: string
  showAgentInfo?: boolean
  showSaveButton?: boolean
}

export const HorizontalListingCard = ({
  listing,
  isSaved = false,
  onToggleSave,
  onOpenListing,
  secondaryActionIcon,
  secondaryActionLabel,
  secondaryActionTo,
  actionState,
  actionLabel = 'View',
  actionTo,
  showAgentInfo = true,
  showSaveButton = true,
}: HorizontalListingCardProps) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0)
  const gallery = listing.previewImageUrls.length > 0
    ? listing.previewImageUrls
    : [listing.primaryImageUrl ?? '/fallbacks/property-location.jpg']
  const activeImageUrl = gallery[activeImageIndex] ?? gallery[0] ?? '/fallbacks/property-location.jpg'

  const cycleImage = (direction: -1 | 1) => {
    if (gallery.length <= 1) {
      return
    }

    setActiveImageIndex((current) => (current + direction + gallery.length) % gallery.length)
  }

  return (
    <article className="overflow-hidden rounded-[32px] bg-white/72 shadow-[0_24px_72px_rgba(15,23,42,0.08)] ring-1 ring-white/60 backdrop-blur-2xl">
      <div className="grid gap-0 md:grid-cols-2 md:aspect-[32/10]">
        <div className="p-5 sm:p-6 md:h-full">
          <Link
            className="block w-full md:h-full"
            onClick={() => onOpenListing?.(listing.id)}
            state={actionState}
            to={actionTo ?? `/listings/${listing.id}`}
          >
            <div className="relative aspect-[16/10] w-full overflow-hidden rounded-[28px] bg-slate-100 md:h-full md:aspect-auto">
              <img
                alt={listing.title}
                className="h-full w-full object-cover"
                src={activeImageUrl}
              />
              <div className="absolute right-5 top-5">
                <ListingStatusPill
                  listingStatus={listing.listingStatus}
                  transactionType={listing.transactionType}
                />
              </div>
              {gallery.length > 1 ? (
                <div className="absolute bottom-4 right-4 flex items-center gap-1.5 text-white">
                  <button
                    aria-label="View previous listing photo"
                    className="inline-flex h-7 w-7 items-center justify-center opacity-80 transition hover:opacity-100"
                    onClick={(event) => {
                      event.preventDefault()
                      cycleImage(-1)
                    }}
                    type="button"
                  >
                    <ChevronLeft className="h-4.5 w-4.5" />
                  </button>
                  <button
                    aria-label="View next listing photo"
                    className="inline-flex h-7 w-7 items-center justify-center opacity-80 transition hover:opacity-100"
                    onClick={(event) => {
                      event.preventDefault()
                      cycleImage(1)
                    }}
                    type="button"
                  >
                    <ChevronRight className="h-4.5 w-4.5" />
                  </button>
                </div>
              ) : null}
            </div>
          </Link>
        </div>

        <div className="flex min-w-0 flex-col p-5 sm:p-6 md:h-full">
          <div className="flex min-h-0 flex-1 flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-4 border-b border-slate-200/80 pb-4">
                <p className="text-[2rem] font-semibold tracking-tight text-slate-950 sm:text-[2.15rem]">
                  {formatPrice(listing.price, listing.transactionType)}
                </p>
                {showSaveButton ? (
                  <button
                    className={[
                      'inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full border bg-white shadow-sm transition',
                      isSaved
                        ? 'border-rose-200 text-rose-600'
                        : 'border-slate-200 text-slate-700 hover:border-slate-300 hover:text-slate-950',
                    ].join(' ')}
                    onClick={() => onToggleSave?.(listing.id)}
                    type="button"
                  >
                    <Heart className={`h-5 w-5 ${isSaved ? 'fill-current' : ''}`} />
                  </button>
                ) : null}
              </div>

              <div>
                <div className="space-y-1">
                  <p className="text-[1.55rem] font-semibold leading-tight tracking-tight text-slate-950 sm:text-[1.65rem]">
                    {`${listing.addressLine},`}
                  </p>
                  <p className="text-[1.55rem] font-semibold leading-tight tracking-tight text-slate-950 sm:text-[1.65rem]">
                    {[listing.suburb, listing.state, listing.postcode].filter(Boolean).join(', ')}
                  </p>
                </div>
                <div className="mt-3 border-y border-slate-200/80 py-3.5">
                  <p className="text-[1.55rem] font-semibold leading-tight tracking-tight text-slate-900 sm:text-[1.65rem]">
                    {formatPropertyLabel(listing.propertyType, listing.houseSubtype ?? listing.apartmentSubtype)}
                  </p>
                </div>
              </div>

              <PropertyFacts
                className="gap-4 pb-3 [&_span]:text-[1.05rem] [&_svg]:h-[1.15rem] [&_svg]:w-[1.15rem]"
                propertyType={listing.propertyType}
                bathrooms={listing.bathrooms}
                bedrooms={listing.bedrooms}
                buildingSize={listing.buildingSize}
                carSpaces={listing.carSpaces}
                landSize={listing.landSize}
              />
            </div>

            <div className="mt-4 flex items-center justify-between gap-4 pt-2">
              {showAgentInfo ? (
                <AgentAttribution agent={listing.agent} />
              ) : (
                <div />
              )}
              <div className="flex shrink-0 flex-wrap items-center justify-end gap-2">
                {secondaryActionLabel && secondaryActionTo ? (
                  <Link
                    className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-950"
                    to={secondaryActionTo}
                  >
                    {secondaryActionIcon}
                    {secondaryActionLabel}
                  </Link>
                ) : null}
                <Link
                  className="inline-flex items-center rounded-full border border-slate-200 bg-slate-100 px-5 py-2.5 text-sm font-semibold text-slate-950 transition hover:border-slate-300 hover:bg-slate-200"
                  onClick={() => onOpenListing?.(listing.id)}
                  state={actionState}
                  to={actionTo ?? `/listings/${listing.id}`}
                >
                  {actionLabel}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </article>
  )
}
