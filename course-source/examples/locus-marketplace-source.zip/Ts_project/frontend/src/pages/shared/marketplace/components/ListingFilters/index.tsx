import { Search, SlidersHorizontal } from 'lucide-react'

import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog'
import { ListingFilterDialogPanel } from '@/pages/shared/marketplace/components/ListingFilters/ListingFilterDialogPanel'
import { useListingFilters } from '@/pages/shared/marketplace/components/ListingFilters/hooks/use-listing-filters'
import type { MarketplaceFilterValues } from '@/pages/shared/marketplace/functions/marketplace-filters'

type ListingFiltersProps = {
  filters: MarketplaceFilterValues
  draftVersion: string
  onApply: (nextFilters: MarketplaceFilterValues) => void
  actionLabel?: string
  applyOnAction?: boolean
  onSearchApply?: () => void
  variant?: 'default' | 'home'
}

const homeSearchActionTextClass =
  'font-sans text-sm font-semibold leading-none tracking-normal'

const marketModeOptions = [
  { label: 'Buy', value: 'sale' },
  { label: 'Rent', value: 'rent' },
  { label: 'Sold', value: 'sold' },
  { label: 'Leased', value: 'leased' },
] as const

export const ListingFilters = (props: ListingFiltersProps) => (
  <ListingFiltersPanel key={props.draftVersion} {...props} />
)

const ListingFiltersPanel = ({
  filters,
  onApply,
  actionLabel = 'Apply',
  applyOnAction = true,
  onSearchApply,
  variant = 'default',
}: ListingFiltersProps) => {
  const isHomeVariant = variant === 'home'
  const controller = useListingFilters({
    filters,
    onApply,
    applyOnAction,
    onSearchApply,
    isHomeVariant,
  })
  const {
    applyDraft,
    draftFilters,
    handleOpenChange,
    isOpen,
    updateDraft,
  } = controller

  return (
    <div
      className={[
        'border border-white/75 bg-[rgba(255,255,255,0.78)] shadow-[0_22px_70px_rgba(15,23,42,0.08)] backdrop-blur-2xl',
        isHomeVariant ? 'rounded-[28px] p-1.5' : 'rounded-[32px] p-3',
      ].join(' ')}
    >
      {isHomeVariant ? (
        <div className="px-3.5 pt-1.5">
          <div className="grid grid-cols-4 border-b border-slate-200/80">
            {marketModeOptions.map((option) => {
              const isActive = draftFilters.marketMode === option.value

              return (
                <button
                  className={[
                    'relative flex w-full justify-center pb-2.5 text-sm font-semibold transition after:absolute after:inset-x-0 after:bottom-[-1px] after:h-[1.5px]',
                    isActive
                      ? 'text-slate-950 after:bg-slate-950'
                      : 'text-slate-400 after:bg-transparent hover:text-slate-700',
                  ].join(' ')}
                  key={option.value}
                  onClick={() => updateDraft({ marketMode: option.value })}
                  type="button"
                >
                  {option.label}
                </button>
              )
            })}
          </div>
        </div>
      ) : null}

      <div
        className={
          isHomeVariant
            ? 'flex flex-col gap-2.5 p-2.5 md:flex-row'
            : 'flex flex-col gap-3 md:flex-row'
        }
      >
        <label
          className={[
            'flex min-h-[52px] flex-1 items-center gap-4 rounded-[19px] border border-slate-200/70 bg-white shadow-[inset_0_1px_0_rgba(255,255,255,0.8)]',
            isHomeVariant ? 'px-5' : 'pl-5 pr-1.5',
          ].join(' ')}
        >
          {isHomeVariant ? (
            <Search className="h-5 w-5 shrink-0 text-slate-400" strokeWidth={2.2} />
          ) : null}
          <input
            className="w-full border-none bg-transparent text-[15px] font-medium text-slate-900 outline-none placeholder:text-slate-400"
            onChange={(event) => updateDraft({ query: event.target.value })}
            onKeyDown={(event) => {
              if (event.key === 'Enter') {
                applyDraft()
              }
            }}
            placeholder="Search suburb, postcode or state"
            value={draftFilters.query}
          />
          {!isHomeVariant ? (
            <button
              className="inline-flex size-10 shrink-0 items-center justify-center rounded-[14px] bg-slate-950 text-white shadow-[0_10px_20px_rgba(15,23,42,0.12)] transition hover:bg-slate-800"
              onClick={() => applyDraft()}
              type="button"
            >
              <Search className="h-5 w-5" strokeWidth={2.2} />
            </button>
          ) : null}
        </label>

        <Dialog onOpenChange={handleOpenChange} open={isOpen}>
          <DialogTrigger asChild>
            <button
              className="inline-flex min-h-[52px] items-center justify-between gap-3 rounded-[19px] border border-slate-200/80 bg-white px-[18px] text-left shadow-[0_10px_30px_rgba(15,23,42,0.05)] transition hover:bg-slate-50"
              type="button"
            >
              <span className="inline-flex items-center gap-2 whitespace-nowrap">
                <SlidersHorizontal className="h-4 w-4 text-slate-700" />
                <span className={`${homeSearchActionTextClass} text-slate-950`}>Filters</span>
              </span>
            </button>
          </DialogTrigger>
          <DialogContent
            className="w-[min(46rem,calc(100vw-1.5rem))] overflow-hidden rounded-[32px] border border-white/80 bg-[rgba(248,250,252,0.96)] p-0 shadow-[0_28px_90px_rgba(15,23,42,0.16)] backdrop-blur-3xl"
            showCloseButton={false}
          >
            <ListingFilterDialogPanel
              actionLabel={actionLabel}
              controller={controller}
              isHomeVariant={isHomeVariant}
            />
          </DialogContent>
        </Dialog>

        {isHomeVariant ? (
          <button
            className="inline-flex min-h-[52px] items-center justify-center rounded-[19px] bg-slate-950 px-5.5 shadow-[0_12px_24px_rgba(15,23,42,0.16)] transition hover:bg-slate-800"
            onClick={() => applyDraft()}
            type="button"
          >
            <span className={`${homeSearchActionTextClass} text-white`}>Search</span>
          </button>
        ) : null}
      </div>
    </div>
  )
}
