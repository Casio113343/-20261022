import type {
  ApartmentSubtype,
  HouseSubtype,
  ListingDetail,
  ListingStatus,
  ListingSummary,
  PropertyType,
  TransactionType,
} from '@/objects/listings'

export const formatPrice = (price: number, transactionType: TransactionType) => {
  const formatted = new Intl.NumberFormat('en-AU', {
    style: 'currency',
    currency: 'AUD',
    maximumFractionDigits: 0,
  }).format(price)

  return transactionType === 'rent' ? `${formatted} / week` : formatted
}

export const formatCompactPrice = (price: number) =>
  new Intl.NumberFormat('en-AU', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(price)

export const formatPropertyType = (propertyType: PropertyType) =>
  propertyType.charAt(0).toUpperCase() + propertyType.slice(1)

const formatSubtypeValue = (value: string) =>
  value
    .split('_')
    .map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1))
    .join(' ')

export const formatPropertySubtype = (subtype?: HouseSubtype | ApartmentSubtype) =>
  subtype ? formatSubtypeValue(subtype) : undefined

export const formatPropertyLabel = (
  propertyType: PropertyType,
  subtype?: HouseSubtype | ApartmentSubtype,
) => {
  const fallbackSubtype =
    propertyType === 'house'
      ? 'free_standing'
      : propertyType === 'apartment'
        ? 'standard'
        : undefined

  return [formatPropertyType(propertyType), formatPropertySubtype(subtype ?? fallbackSubtype)]
    .filter(Boolean)
    .join(' - ')
}

export const formatListingAddress = (
  listing: Pick<ListingSummary | ListingDetail, 'addressLine' | 'suburb' | 'state' | 'postcode'>,
) => [listing.addressLine, listing.suburb, listing.state, listing.postcode].filter(Boolean).join(', ')

export const formatListingStatus = (status: ListingStatus) =>
  status
    .split('_')
    .map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1))
    .join(' ')
