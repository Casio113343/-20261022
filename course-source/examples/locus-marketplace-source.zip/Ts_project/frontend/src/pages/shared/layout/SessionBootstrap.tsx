import { useEffect, useRef } from 'react'

import { api } from '@/apis'
import { clearSession, setSession, useSession } from '@/pages/shared/auth/session-store'

export const SessionBootstrap = () => {
  const user = useSession((state) => state.user)
  const hasCheckedRef = useRef(false)

  useEffect(() => {
    if (user || hasCheckedRef.current) {
      return
    }

    hasCheckedRef.current = true

    api.currentUser().then((response) => {
      if (response.ok) {
        setSession(response.data)
        return
      }

      clearSession()
    })
  }, [user])

  return null
}
