import type { ReactNode } from 'react'

import { cn } from '@/utils/class-names'

import { listingFilterFieldLabelClass } from './ListingFilterSectionCard'

type ListingFilterSegmentedSectionProps = {
  icon: ReactNode
  label: string
  options: readonly { label: string; value: string }[]
  value: string
  onSelect: (value: string) => void
}

const segmentClass = (isActive: boolean) =>
  cn(
    'inline-flex min-h-11 items-center justify-center px-4 text-sm font-semibold transition-colors',
    isActive
      ? 'bg-slate-950 text-white shadow-[0_10px_24px_rgba(15,23,42,0.16)]'
      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-950',
  )

export const ListingFilterSegmentedSection = ({
  icon,
  label,
  options,
  value,
  onSelect,
}: ListingFilterSegmentedSectionProps) => (
  <div>
    <div className="mb-3.5">
      <p className={listingFilterFieldLabelClass}>
        {icon}
        {label}
      </p>
      <div className="mt-2.5 h-px w-full bg-slate-200/80" />
    </div>
    <div className="flex flex-wrap overflow-hidden rounded-[20px] border border-slate-200 bg-slate-100">
      {options.map((option, index) => (
        <button
          className={cn(
            'flex-1',
            index > 0 ? 'border-l border-slate-200' : '',
            index === 0 ? 'rounded-l-[20px]' : '',
            index === options.length - 1 ? 'rounded-r-[20px]' : '',
            segmentClass(value === option.value),
          )}
          key={option.label}
          onClick={() => onSelect(option.value)}
          type="button"
        >
          {option.label}
        </button>
      ))}
    </div>
  </div>
)
