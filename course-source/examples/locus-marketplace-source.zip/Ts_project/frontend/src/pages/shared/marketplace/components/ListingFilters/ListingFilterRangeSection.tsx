import { LandPlot, Ruler, SlidersHorizontal } from 'lucide-react'

import type { RangeConfig } from '@/pages/shared/marketplace/functions/listing-filters-draft'
import {
  rangeSummary,
  toRangeDraft,
  toStoredRangeValue,
} from '@/pages/shared/marketplace/functions/listing-filters-draft'

import {
  ListingFilterSectionCard,
  listingFilterFieldLabelClass,
} from './ListingFilterSectionCard'

type ListingFilterRangeSectionProps = {
  config: RangeConfig
  minValue: string
  maxValue: string
  onChange: (
    nextRange:
      | { minPrice: string; maxPrice: string }
      | { minFloorSize: string; maxFloorSize: string }
      | { minLandSize: string; maxLandSize: string },
  ) => void
}

export const ListingFilterRangeSection = ({
  config,
  minValue,
  maxValue,
  onChange,
}: ListingFilterRangeSectionProps) => {
  const draftRange = toRangeDraft(minValue, maxValue, config.max)

  const handleChange = (nextRange: { min: number; max: number }) => {
    const nextPatch =
      config.unit === 'currency'
        ? {
            minPrice: toStoredRangeValue(nextRange.min, 'min', config.max),
            maxPrice: toStoredRangeValue(nextRange.max, 'max', config.max),
          }
        : config.kind === 'land'
          ? {
              minLandSize: toStoredRangeValue(nextRange.min, 'min', config.max),
              maxLandSize: toStoredRangeValue(nextRange.max, 'max', config.max),
            }
          : {
              minFloorSize: toStoredRangeValue(nextRange.min, 'min', config.max),
              maxFloorSize: toStoredRangeValue(nextRange.max, 'max', config.max),
            }

    onChange(nextPatch)
  }

  return (
    <ListingFilterSectionCard>
      <div className="mb-3.5">
        <p className={listingFilterFieldLabelClass}>
          {config.unit === 'currency' ? (
            <SlidersHorizontal className="h-4 w-4 text-slate-400" />
          ) : config.kind === 'land' ? (
            <LandPlot className="h-4 w-4 text-slate-400" />
          ) : (
            <Ruler className="h-4 w-4 text-slate-400" />
          )}
          {config.label}
        </p>
        <div className="mt-2.5 h-px w-full bg-slate-200/80" />
      </div>

      <div className="flex items-center justify-between gap-4">
        <p className="text-[15px] font-semibold text-slate-950">
          {rangeSummary(minValue, maxValue, config)}
        </p>

        <button
          className="inline-flex h-8 items-center justify-center rounded-full border border-slate-200 bg-white px-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
          onClick={() => handleChange({ min: 0, max: config.max })}
          type="button"
        >
          Clear
        </button>
      </div>

      <div className="mt-1.5">
        <DualRangeSlider config={config} onChange={handleChange} value={draftRange} />
      </div>
    </ListingFilterSectionCard>
  )
}

const DualRangeSlider = ({
  value,
  onChange,
  config,
}: {
  value: { min: number; max: number }
  onChange: (nextRange: { min: number; max: number }) => void
  config: RangeConfig
}) => {
  const start = (value.min / config.max) * 100
  const width = ((value.max - value.min) / config.max) * 100

  return (
    <div className="relative h-10">
      <div className="absolute inset-x-0 top-[20px] h-1.5 -translate-y-1/2 rounded-full bg-slate-200">
        <div
          className="absolute top-0 h-full rounded-full bg-slate-950"
          style={{ left: `${start}%`, width: `${width}%` }}
        />
      </div>

      <input
        className="pointer-events-none absolute inset-0 h-full w-full appearance-none bg-transparent [&::-moz-range-thumb]:pointer-events-auto [&::-moz-range-thumb]:h-5 [&::-moz-range-thumb]:w-5 [&::-moz-range-thumb]:appearance-none [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-[3px] [&::-moz-range-thumb]:border-white [&::-moz-range-thumb]:bg-slate-950 [&::-moz-range-thumb]:shadow-[0_8px_20px_rgba(15,23,42,0.18)] [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-[3px] [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:bg-slate-950 [&::-webkit-slider-thumb]:shadow-[0_8px_20px_rgba(15,23,42,0.18)]"
        max={config.max}
        min={0}
        onChange={(event) =>
          onChange({
            min: Math.min(Number(event.target.value), value.max),
            max: value.max,
          })
        }
        step={config.step}
        type="range"
        value={value.min}
      />
      <input
        className="pointer-events-none absolute inset-0 h-full w-full appearance-none bg-transparent [&::-moz-range-thumb]:pointer-events-auto [&::-moz-range-thumb]:h-5 [&::-moz-range-thumb]:w-5 [&::-moz-range-thumb]:appearance-none [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-[3px] [&::-moz-range-thumb]:border-white [&::-moz-range-thumb]:bg-slate-950 [&::-moz-range-thumb]:shadow-[0_8px_20px_rgba(15,23,42,0.18)] [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-[3px] [&::-webkit-slider-thumb]:border-white [&::-webkit-slider-thumb]:bg-slate-950 [&::-webkit-slider-thumb]:shadow-[0_8px_20px_rgba(15,23,42,0.18)]"
        max={config.max}
        min={0}
        onChange={(event) =>
          onChange({
            min: value.min,
            max: Math.max(Number(event.target.value), value.min),
          })
        }
        step={config.step}
        type="range"
        value={value.max}
      />
    </div>
  )
}
