import type {
  ListingSort,
  ListingStatus,
  ApartmentSubtype,
  HouseSubtype,
  PropertyType,
  TransactionType,
} from '@/objects/listings'
import type { SearchPublicListingsRequest as ListingSearchParams } from '@/apis/listings/ListingsApi'

export type SearchMode = 'sale' | 'rent' | 'sold' | 'leased'

export type MarketplaceFilterValues = {
  query: string
  marketMode: SearchMode
  propertyTypes: PropertyType[]
  houseSubtypes: HouseSubtype[]
  apartmentSubtypes: ApartmentSubtype[]
  sort: ListingSort
  minPrice: string
  maxPrice: string
  minFloorSize: string
  maxFloorSize: string
  minLandSize: string
  maxLandSize: string
  bedrooms: string
  bathrooms: string
  carSpaces: string
}

export const propertyTypes: PropertyType[] = ['house', 'apartment', 'vacant_land']
export const houseSubtypes: HouseSubtype[] = [
  'free_standing',
  'duplex',
  'terrace',
  'villa',
  'off_the_plan',
]
export const apartmentSubtypes: ApartmentSubtype[] = [
  'standard',
  'unit',
  'penthouse',
  'studio',
  'off_the_plan',
]
export const marketModes: SearchMode[] = ['sale', 'rent', 'sold', 'leased']
export const listingSorts: ListingSort[] = ['newest', 'price_asc', 'price_desc']

export const defaultMarketplaceFilters: MarketplaceFilterValues = {
  query: '',
  marketMode: 'sale',
  propertyTypes,
  houseSubtypes,
  apartmentSubtypes,
  sort: 'newest',
  minPrice: '',
  maxPrice: '',
  minFloorSize: '',
  maxFloorSize: '',
  minLandSize: '',
  maxLandSize: '',
  bedrooms: '',
  bathrooms: '',
  carSpaces: '',
}

const sameValues = <T extends string>(left: readonly T[], right: readonly T[]) =>
  left.length === right.length && left.every((value, index) => value === right[index])

// URLSearchParams.get returns null at the browser boundary; normalize to undefined for app code.
const readSearchParam = (searchParams: URLSearchParams, key: string) => searchParams.get(key) ?? undefined

const parseNumberValue = (value: string | undefined) => {
  const parsed = value ? Number(value) : Number.NaN
  return Number.isFinite(parsed) ? parsed : undefined
}

const parseEnum = <T extends string>(value: string | undefined, options: readonly T[]): T | '' =>
  options.find((option) => option === value) ?? ''

const parseEnums = <T extends string>(value: string | undefined, options: readonly T[]): T[] =>
  (value ?? '')
    .split(',')
    .filter((entry): entry is T => options.some((option) => option === entry))

const parseMode = (value: string | undefined, transactionType: string | undefined): SearchMode => {
  if (value === 'sale' || value === 'rent' || value === 'sold' || value === 'leased') {
    return value
  }

  return transactionType === 'rent' ? 'rent' : 'sale'
}

export const filtersFromSearchParams = (
  searchParams: URLSearchParams,
): MarketplaceFilterValues => ({
  query: readSearchParam(searchParams, 'query') ?? '',
  marketMode: parseMode(
    readSearchParam(searchParams, 'marketMode'),
    readSearchParam(searchParams, 'transactionType'),
  ),
  propertyTypes:
    searchParams.has('propertyTypes')
      ? parseEnums(readSearchParam(searchParams, 'propertyTypes'), propertyTypes)
      : defaultMarketplaceFilters.propertyTypes,
  houseSubtypes:
    searchParams.has('houseSubtypes')
      ? parseEnums(readSearchParam(searchParams, 'houseSubtypes'), houseSubtypes)
      : defaultMarketplaceFilters.houseSubtypes,
  apartmentSubtypes:
    searchParams.has('apartmentSubtypes')
      ? parseEnums(readSearchParam(searchParams, 'apartmentSubtypes'), apartmentSubtypes)
      : defaultMarketplaceFilters.apartmentSubtypes,
  sort: (parseEnum(readSearchParam(searchParams, 'sort'), listingSorts) || 'newest') as ListingSort,
  minPrice: readSearchParam(searchParams, 'minPrice') ?? '',
  maxPrice: readSearchParam(searchParams, 'maxPrice') ?? '',
  minFloorSize: readSearchParam(searchParams, 'minFloorSize') ?? '',
  maxFloorSize: readSearchParam(searchParams, 'maxFloorSize') ?? '',
  minLandSize: readSearchParam(searchParams, 'minLandSize') ?? '',
  maxLandSize: readSearchParam(searchParams, 'maxLandSize') ?? '',
  bedrooms: readSearchParam(searchParams, 'bedrooms') ?? '',
  bathrooms: readSearchParam(searchParams, 'bathrooms') ?? '',
  carSpaces: readSearchParam(searchParams, 'carSpaces') ?? '',
})

const searchConfigByMode: Record<
  SearchMode,
  { transactionType: TransactionType; listingStatuses: ListingStatus[] }
> = {
  sale: { transactionType: 'sale', listingStatuses: ['active'] },
  rent: { transactionType: 'rent', listingStatuses: ['active'] },
  sold: { transactionType: 'sale', listingStatuses: ['sold'] },
  leased: { transactionType: 'rent', listingStatuses: ['leased'] },
}

export const toListingSearchParams = (
  filters: MarketplaceFilterValues,
): ListingSearchParams => {
  const modeConfig = searchConfigByMode[filters.marketMode]
  const hasScopedHouseFilter =
    filters.propertyTypes.length === 1 &&
    filters.propertyTypes.includes('house') &&
    !sameValues(filters.houseSubtypes, defaultMarketplaceFilters.houseSubtypes)
  const hasScopedApartmentFilter =
    filters.propertyTypes.length === 1 &&
    filters.propertyTypes.includes('apartment') &&
    !sameValues(filters.apartmentSubtypes, defaultMarketplaceFilters.apartmentSubtypes)

  return {
    query: filters.query.trim() || undefined,
    transactionType: modeConfig.transactionType,
    listingStatuses: modeConfig.listingStatuses,
    propertyTypes: filters.propertyTypes,
    houseSubtypes: hasScopedHouseFilter ? filters.houseSubtypes : [],
    apartmentSubtypes: hasScopedApartmentFilter ? filters.apartmentSubtypes : [],
    minPrice: parseNumberValue(filters.minPrice),
    maxPrice: parseNumberValue(filters.maxPrice),
    minFloorSize: parseNumberValue(filters.minFloorSize),
    maxFloorSize: parseNumberValue(filters.maxFloorSize),
    minLandSize: parseNumberValue(filters.minLandSize),
    maxLandSize: parseNumberValue(filters.maxLandSize),
    bedrooms: parseNumberValue(filters.bedrooms),
    bathrooms: parseNumberValue(filters.bathrooms),
    carSpaces: parseNumberValue(filters.carSpaces),
    sort: filters.sort,
  }
}

export const applyFilterPatch = (
  searchParams: URLSearchParams,
  patch: Partial<MarketplaceFilterValues>,
) => {
  const nextParams = new URLSearchParams(searchParams)
  const nextFilters = {
    ...filtersFromSearchParams(searchParams),
    ...patch,
  }

  ;(Object.entries(nextFilters) as [keyof MarketplaceFilterValues, MarketplaceFilterValues[keyof MarketplaceFilterValues]][]).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      if (value.length > 0) {
        nextParams.set(key, value.join(','))
        return
      }

      nextParams.delete(key)
      return
    }

    if (value) {
      nextParams.set(key, value)
      return
    }

    nextParams.delete(key)
  })

  nextParams.delete('transactionType')
  nextParams.delete('listingStatuses')

  return nextParams
}

export const countActiveFilters = (filters: MarketplaceFilterValues) =>
  [
    filters.marketMode !== defaultMarketplaceFilters.marketMode,
    !sameValues(filters.propertyTypes, defaultMarketplaceFilters.propertyTypes),
    filters.propertyTypes.includes('house') &&
      !sameValues(filters.houseSubtypes, defaultMarketplaceFilters.houseSubtypes),
    filters.propertyTypes.includes('apartment') &&
      !sameValues(filters.apartmentSubtypes, defaultMarketplaceFilters.apartmentSubtypes),
    filters.sort !== defaultMarketplaceFilters.sort,
    filters.minPrice !== '',
    filters.maxPrice !== '',
    filters.minFloorSize !== '',
    filters.maxFloorSize !== '',
    filters.minLandSize !== '',
    filters.maxLandSize !== '',
    filters.bedrooms !== '',
    filters.bathrooms !== '',
    filters.carSpaces !== '',
  ].filter(Boolean).length
