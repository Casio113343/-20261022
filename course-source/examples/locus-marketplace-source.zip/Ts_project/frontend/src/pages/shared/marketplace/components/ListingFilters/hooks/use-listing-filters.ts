import { useState } from 'react'

import type {
  ApartmentSubtype,
  HouseSubtype,
  PropertyType,
} from '@/objects/listings'
import {
  clearMarketplaceDraft,
  floorSizeConfig,
  landSizeConfig,
  normalizeDraftFilters,
  rentPriceConfig,
  salePriceConfig,
  toggleApartmentSubtype,
  toggleHouseSubtype,
  toggleListingPropertyType,
} from '@/pages/shared/marketplace/functions/listing-filters-draft'
import type { MarketplaceFilterValues } from '@/pages/shared/marketplace/functions/marketplace-filters'

type UseListingFiltersInput = {
  filters: MarketplaceFilterValues
  onApply: (nextFilters: MarketplaceFilterValues) => void
  applyOnAction: boolean
  onSearchApply?: () => void
  isHomeVariant: boolean
}

export const useListingFilters = ({
  filters,
  onApply,
  applyOnAction,
  onSearchApply,
  isHomeVariant,
}: UseListingFiltersInput) => {
  const [isOpen, setIsOpen] = useState(false)
  const [draftFilters, setDraftFilters] = useState<MarketplaceFilterValues>(filters)
  const [isHouseSubtypeOpen, setIsHouseSubtypeOpen] = useState(false)
  const [isApartmentSubtypeOpen, setIsApartmentSubtypeOpen] = useState(false)

  const hasHouse = draftFilters.propertyTypes.includes('house')
  const hasApartment = draftFilters.propertyTypes.includes('apartment')
  const hasVacantLand = draftFilters.propertyTypes.includes('vacant_land')

  const updateDraft = (patch: Partial<MarketplaceFilterValues>) =>
    setDraftFilters((current) => ({ ...current, ...patch }))

  const applyDraft = (nextDraft = draftFilters) => {
    const normalizedFilters = normalizeDraftFilters(nextDraft)
    onSearchApply?.()
    onApply(normalizedFilters)
    setIsOpen(false)
  }

  const commitDraft = () => {
    const normalizedFilters = normalizeDraftFilters(draftFilters)
    setDraftFilters(normalizedFilters)

    if (applyOnAction) {
      applyDraft(normalizedFilters)
    } else {
      setIsOpen(false)
    }
  }

  const resetDraft = () => setDraftFilters(filters)

  const closeWithoutApplying = () => {
    resetDraft()
    setIsOpen(false)
  }

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open)
    resetDraft()

    if (open) {
      setIsHouseSubtypeOpen(false)
      setIsApartmentSubtypeOpen(false)
    }
  }

  const handlePropertyTypeToggle = (nextValue: PropertyType) => {
    const nextFilters = toggleListingPropertyType(draftFilters, nextValue)
    setDraftFilters(nextFilters)

    if (!nextFilters.propertyTypes.includes('house')) {
      setIsHouseSubtypeOpen(false)
    }
    if (!nextFilters.propertyTypes.includes('apartment')) {
      setIsApartmentSubtypeOpen(false)
    }
  }

  const handleHouseSubtypeToggle = (nextValue: HouseSubtype) =>
    setDraftFilters((current) => toggleHouseSubtype(current, nextValue))

  const handleApartmentSubtypeToggle = (nextValue: ApartmentSubtype) =>
    setDraftFilters((current) => toggleApartmentSubtype(current, nextValue))

  return {
    applyDraft,
    clearAll: () =>
      setDraftFilters((current) => clearMarketplaceDraft(current, isHomeVariant)),
    closeWithoutApplying,
    commitDraft,
    draftFilters,
    handleApartmentSubtypeToggle,
    handleHouseSubtypeToggle,
    handleOpenChange,
    handlePropertyTypeToggle,
    isApartmentSubtypeOpen,
    isHouseSubtypeOpen,
    isOpen,
    priceConfig:
      draftFilters.marketMode === 'rent' || draftFilters.marketMode === 'leased'
        ? rentPriceConfig
        : salePriceConfig,
    setIsApartmentSubtypeOpen,
    setIsHouseSubtypeOpen,
    showDwellingFeatures: hasHouse || hasApartment,
    showFloorSize: hasHouse || hasApartment,
    showLandSize: hasHouse || hasVacantLand,
    sizeConfigs: {
      floor: floorSizeConfig,
      land: landSizeConfig,
    },
    updateDraft,
  }
}

export type ListingFiltersController = ReturnType<typeof useListingFilters>
