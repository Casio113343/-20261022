import { CalendarDays, Heart, Menu, MessageCircleMore } from 'lucide-react'
import { Link, useLocation, useNavigate } from 'react-router-dom'

import type { ListingPreviewState } from '@/pages/AgentListingEditorPage/objects/listing-editor-types'

import { useUnreadMessageCount } from '@/pages/shared/hooks/use-unread-message-count'
import { headerActionClass, headerActionTextClass } from '@/pages/shared/marketplace/components/header-action-styles'
import { api } from '@/apis'
import { clearSession, useSession } from '@/pages/shared/auth/session-store'

export const SiteHeader = () => {
  const location = useLocation()
  const navigate = useNavigate()
  const user = useSession((state) => state.user)
  const isAuthenticated = useSession((state) => state.isAuthenticated)
  const homePath = user?.role === 'agent_admin' ? '/agent/listings' : '/'
  const isPreviewMode = location.pathname === '/agent/listings/preview'
  const previewState = location.state as ListingPreviewState | undefined
  const exitPreviewPath = previewState?.returnTo ?? '/agent/listings'
  const unreadMessageCount = useUnreadMessageCount(
    isAuthenticated && user?.role === 'agent_admin',
    user?.role === 'agent_admin' ? user.id : undefined,
  )
  const unreadMessageLabel = unreadMessageCount > 99 ? '99+' : String(unreadMessageCount)

  const handleSignOut = async () => {
    if (user) {
      await api.signOut()
    }

    // The local session should still be cleared if the server-side session already expired.
    clearSession()
    navigate('/')
  }

  return (
    <header className="sticky top-0 z-40 border-b border-white/40 bg-white/55 backdrop-blur-3xl">
      <div className="flex w-full items-center justify-between gap-6 px-4 py-4 sm:px-6 lg:px-10">
        <Link className="text-3xl font-bold tracking-tight text-slate-950" to={homePath}>
          LOCUS
        </Link>

        {isPreviewMode ? (
          <button
            className={`${headerActionClass} appearance-none`}
            onClick={() =>
              navigate(exitPreviewPath, {
                state: previewState ? { draft: previewState.editorDraft } : undefined,
              })
            }
            type="button"
          >
            <span className={headerActionTextClass}>Exit preview</span>
          </button>
        ) : (
          <>
            <div className="hidden items-center gap-3 md:flex">
              {user ? (
                <>
                  {user.role === 'buyer_renter' ? (
                    <Link
                      className={`${headerActionClass} gap-2`}
                      to="/saved"
                    >
                      <Heart className="h-4 w-4" />
                      <span className={headerActionTextClass}>Saved</span>
                    </Link>
                  ) : null}
                  {user.role === 'agent_admin' ? (
                    <Link
                      className={`${headerActionClass} gap-2`}
                      to="/agent/inspections"
                    >
                      <CalendarDays className="h-4 w-4" />
                      <span className={headerActionTextClass}>Inspections</span>
                    </Link>
                  ) : null}
                  <Link
                    aria-label={
                      unreadMessageCount > 0
                        ? `Messages, ${unreadMessageCount} unread`
                        : 'Messages'
                    }
                    className={`${headerActionClass} relative gap-2`}
                    to="/messages"
                  >
                    <MessageCircleMore className="h-4 w-4" />
                    <span className={headerActionTextClass}>Messages</span>
                    {user.role === 'agent_admin' && unreadMessageCount > 0 ? (
                      <span className="absolute -right-1 -top-1 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-medium leading-none tabular-nums text-white ring-2 ring-white/90">
                        {unreadMessageLabel}
                      </span>
                    ) : null}
                  </Link>
                  <button
                    className={`${headerActionClass} appearance-none`}
                    onClick={handleSignOut}
                    type="button"
                  >
                    <span className={headerActionTextClass}>Sign out</span>
                  </button>
                </>
              ) : (
                <Link
                  className={headerActionClass}
                  to="/sign-in"
                >
                  <span className={headerActionTextClass}>Sign in</span>
                </Link>
              )}
            </div>

            <button className="rounded-full border border-slate-200 p-2 text-slate-700 md:hidden" type="button">
              <Menu className="h-5 w-5" />
            </button>
          </>
        )}
      </div>
    </header>
  )
}
