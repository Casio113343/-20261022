import { Navigate, Outlet } from 'react-router-dom'

import { useSession } from '@/pages/shared/auth/session-store'

export const RequireAuth = () => {
  const user = useSession((state) => state.user)
  return user ? <Outlet /> : <Navigate replace to="/sign-in" />
}

export const RequireAgent = () => {
  const user = useSession((state) => state.user)
  return user?.role === 'agent_admin' ? <Outlet /> : <Navigate replace to="/sign-in" />
}
