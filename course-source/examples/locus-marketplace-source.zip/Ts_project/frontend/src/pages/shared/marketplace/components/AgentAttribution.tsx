import type { AgentSummary } from '@/objects/identity'
import { ProfileAvatar } from '@/pages/shared/marketplace/components/ProfileAvatar'

type AgentAttributionProps = {
  agent: AgentSummary
}

export const AgentAttribution = ({ agent }: AgentAttributionProps) => (
  <div className="flex min-w-0 items-center gap-3">
    <ProfileAvatar
      avatarUrl={agent.avatarUrl}
      name={agent.fullName}
    />
    <div className="min-w-0 space-y-0.5">
      <p className="truncate text-sm font-semibold text-slate-900">{agent.fullName}</p>
      <p className="truncate text-sm text-slate-500">{agent.agencyName}</p>
    </div>
  </div>
)
