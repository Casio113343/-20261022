import type { ReactNode } from 'react'

export const listingFilterFieldLabelClass =
  'flex items-center gap-2 text-[0.72rem] font-semibold uppercase tracking-[0.14em] text-slate-500'

const listingFilterCardClass =
  'rounded-[24px] border border-slate-200/80 bg-white px-5 py-5 shadow-[0_12px_36px_rgba(15,23,42,0.05)]'

export const ListingFilterSectionCard = ({ children }: { children: ReactNode }) => (
  <section className={listingFilterCardClass}>{children}</section>
)
