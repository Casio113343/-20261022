import { createStore } from 'zustand'
import { useStore } from 'zustand'

import type { ListingSummary } from '@/objects/listings'

type SavedListingsState = {
  listings: ListingSummary[]
  hasLoaded: boolean
  loading: boolean
  error?: string
  ownerKey?: string
}

const initialSavedListingsState: SavedListingsState = {
  listings: [],
  hasLoaded: false,
  loading: false,
  error: undefined,
  ownerKey: undefined,
}

const savedListingsStore = createStore<SavedListingsState>()(() => initialSavedListingsState)

const useSavedListingsStore = <T,>(selector: (state: SavedListingsState) => T) =>
  useStore(savedListingsStore, selector)

export const useSavedListingsState = () => useSavedListingsStore((state) => state)

export const clearSavedListings = () => {
  savedListingsStore.setState(initialSavedListingsState)
}

export const setSavedListingsLoading = (ownerKey: string) => {
  savedListingsStore.setState((state) => ({
    listings: state.ownerKey === ownerKey ? state.listings : [],
    hasLoaded: state.ownerKey === ownerKey ? state.hasLoaded : false,
    loading: true,
    error: undefined,
    ownerKey,
  }))
}

export const setSavedListingsLoaded = (ownerKey: string, listings: ListingSummary[]) => {
  savedListingsStore.setState((state) =>
    state.ownerKey === ownerKey
      ? {
          listings,
          hasLoaded: true,
          loading: false,
          error: undefined,
          ownerKey,
        }
      : state,
  )
}

export const setSavedListingsError = (ownerKey: string, error: string) => {
  savedListingsStore.setState((state) =>
    state.ownerKey === ownerKey
      ? {
          listings: [],
          hasLoaded: false,
          loading: false,
          error,
          ownerKey,
        }
      : state,
  )
}

export const removeSavedListing = (listingId: string) => {
  savedListingsStore.setState((state) => ({
    ...state,
    listings: state.listings.filter((listing) => listing.id !== listingId),
  }))
}
