import { ChevronDown, ChevronRight, Home } from 'lucide-react'

import { Checkbox } from '@/components/ui/checkbox'
import type {
  ApartmentSubtype,
  HouseSubtype,
  PropertyType,
} from '@/objects/listings'
import {
  apartmentSubtypeOptions,
  houseSubtypeOptions,
  propertyTypeOptions,
} from '@/pages/shared/marketplace/functions/listing-filters-draft'
import { cn } from '@/utils/class-names'

import { listingFilterFieldLabelClass } from './ListingFilterSectionCard'

type ListingFilterPropertyTypesFieldProps = {
  apartmentSubtypes: ApartmentSubtype[]
  houseSubtypes: HouseSubtype[]
  isApartmentSubtypeOpen: boolean
  isHouseSubtypeOpen: boolean
  selected: PropertyType[]
  onApartmentSubtypeToggle: (value: ApartmentSubtype) => void
  onApartmentSubtypeVisibilityChange: () => void
  onHouseSubtypeToggle: (value: HouseSubtype) => void
  onHouseSubtypeVisibilityChange: () => void
  onToggle: (value: PropertyType) => void
}

export const ListingFilterPropertyTypesField = ({
  apartmentSubtypes,
  houseSubtypes,
  isApartmentSubtypeOpen,
  isHouseSubtypeOpen,
  selected,
  onApartmentSubtypeToggle,
  onApartmentSubtypeVisibilityChange,
  onHouseSubtypeToggle,
  onHouseSubtypeVisibilityChange,
  onToggle,
}: ListingFilterPropertyTypesFieldProps) => (
  <div>
    <div className="mb-3.5">
      <p className={listingFilterFieldLabelClass}>
        <Home className="h-4 w-4 text-slate-400" />
        Property Types
      </p>
      <div className="mt-2.5 h-px w-full bg-slate-200/80" />
    </div>
    <div className="space-y-2">
      {propertyTypeOptions.map((option) => {
        const isSelected = selected.includes(option.value)
        const isHouseOption = option.value === 'house'
        const isApartmentOption = option.value === 'apartment'

        return (
          <div className="space-y-2" key={option.value}>
            <div
              className={cn(
                'flex items-center gap-3 rounded-[18px] border px-4 py-3 transition',
                isSelected
                  ? 'border-slate-950 bg-slate-50'
                  : 'border-slate-200 bg-white hover:bg-slate-50',
              )}
            >
              <Checkbox
                checked={isSelected}
                className="h-4 w-4 rounded-[5px] border-slate-300 data-[state=checked]:border-slate-950 data-[state=checked]:bg-slate-950"
                onCheckedChange={() => onToggle(option.value)}
              />
              <span className="flex-1 text-sm font-semibold text-slate-900">{option.label}</span>
              {isHouseOption || isApartmentOption ? (
                <button
                  className="inline-flex h-8 w-8 items-center justify-center rounded-full text-slate-500 transition hover:bg-slate-200/80 hover:text-slate-900"
                  onClick={
                    isHouseOption
                      ? onHouseSubtypeVisibilityChange
                      : onApartmentSubtypeVisibilityChange
                  }
                  type="button"
                >
                  {(isHouseOption && isHouseSubtypeOpen) ||
                  (isApartmentOption && isApartmentSubtypeOpen) ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </button>
              ) : null}
            </div>

            {isHouseOption && isHouseSubtypeOpen ? (
              <div className="ml-5 space-y-2 border-l border-slate-200 pl-4">
                {houseSubtypeOptions.map((houseSubtypeOption) => {
                  const isHouseSubtypeSelected = houseSubtypes.includes(houseSubtypeOption.value)

                  return (
                    <label
                      className={cn(
                        'flex cursor-pointer items-center gap-3 rounded-[16px] border px-4 py-3 transition',
                        isHouseSubtypeSelected
                          ? 'border-slate-900 bg-slate-50'
                          : 'border-slate-200 bg-white hover:bg-slate-50',
                      )}
                      key={houseSubtypeOption.value}
                    >
                      <Checkbox
                        checked={isHouseSubtypeSelected}
                        className="h-4 w-4 rounded-[5px] border-slate-300 data-[state=checked]:border-slate-950 data-[state=checked]:bg-slate-950"
                        disabled={!isSelected}
                        onCheckedChange={() => onHouseSubtypeToggle(houseSubtypeOption.value)}
                      />
                      <span className="flex-1 text-sm font-medium text-slate-800">
                        {houseSubtypeOption.label}
                      </span>
                    </label>
                  )
                })}
              </div>
            ) : null}

            {isApartmentOption && isApartmentSubtypeOpen ? (
              <div className="ml-5 space-y-2 border-l border-slate-200 pl-4">
                {apartmentSubtypeOptions.map((apartmentSubtypeOption) => {
                  const isApartmentSubtypeSelected = apartmentSubtypes.includes(
                    apartmentSubtypeOption.value,
                  )

                  return (
                    <label
                      className={cn(
                        'flex cursor-pointer items-center gap-3 rounded-[16px] border px-4 py-3 transition',
                        isApartmentSubtypeSelected
                          ? 'border-slate-900 bg-slate-50'
                          : 'border-slate-200 bg-white hover:bg-slate-50',
                      )}
                      key={apartmentSubtypeOption.value}
                    >
                      <Checkbox
                        checked={isApartmentSubtypeSelected}
                        className="h-4 w-4 rounded-[5px] border-slate-300 data-[state=checked]:border-slate-950 data-[state=checked]:bg-slate-950"
                        disabled={!isSelected}
                        onCheckedChange={() => onApartmentSubtypeToggle(apartmentSubtypeOption.value)}
                      />
                      <span className="flex-1 text-sm font-medium text-slate-800">
                        {apartmentSubtypeOption.label}
                      </span>
                    </label>
                  )
                })}
              </div>
            ) : null}
          </div>
        )
      })}
    </div>
  </div>
)
