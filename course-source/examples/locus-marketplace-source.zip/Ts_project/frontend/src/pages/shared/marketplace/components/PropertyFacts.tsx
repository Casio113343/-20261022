import { Bath, BedDouble, CarFront, LandPlot, Ruler } from 'lucide-react'

import type { PropertyType } from '@/objects/listings'

type PropertyFactsProps = {
  propertyType: PropertyType
  bedrooms: number
  bathrooms: number
  carSpaces: number
  landSize?: number
  buildingSize?: number
  size?: 'compact' | 'comfortable'
  className?: string
}

type Metric = {
  icon: typeof BedDouble
  value: string
}

export const PropertyFacts = ({
  propertyType,
  bedrooms,
  bathrooms,
  carSpaces,
  landSize,
  buildingSize,
  size = 'comfortable',
  className,
}: PropertyFactsProps) => {
  const metrics: Metric[] = [
    { icon: BedDouble, value: String(bedrooms) },
    { icon: Bath, value: String(bathrooms) },
    { icon: CarFront, value: String(carSpaces) },
    ...(buildingSize && propertyType !== 'vacant_land'
      ? [{ icon: Ruler, value: `${buildingSize} m²` }]
      : []),
    ...(landSize && propertyType !== 'apartment'
      ? [{ icon: LandPlot, value: `${landSize} m²` }]
      : []),
  ]

  return (
    <div
      className={[
        'flex flex-nowrap items-center border-b border-slate-200/80 pb-5 text-slate-900',
        size === 'compact' ? 'gap-3' : 'gap-5',
        className ?? '',
      ].join(' ')}
    >
      {metrics.map(({ icon: Icon, value }, index) => (
        <div
          key={`${value}-${index}`}
          className={[
            'flex min-w-0 items-center',
            size === 'compact' ? 'gap-1.5' : 'gap-2.5',
          ].join(' ')}
        >
          <Icon
            className={[
              'shrink-0 text-slate-500',
              size === 'compact' ? 'h-4 w-4' : 'h-4.5 w-4.5',
            ].join(' ')}
            strokeWidth={2}
          />
          <span
            className={[
              'whitespace-nowrap font-semibold tracking-tight',
              size === 'compact' ? 'text-sm sm:text-base' : 'text-xl',
            ].join(' ')}
          >
            {value}
          </span>
        </div>
      ))}
    </div>
  )
}
