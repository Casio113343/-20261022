import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { cn } from '@/utils/class-names'

type ProfileAvatarProps = {
  avatarUrl?: string
  className?: string
  fallbackClassName?: string
  name: string
}

const profileInitials = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('')

export const ProfileAvatar = ({
  avatarUrl,
  className,
  fallbackClassName,
  name,
}: ProfileAvatarProps) => (
  <Avatar className={cn('h-10 w-10 border border-white bg-slate-100 shadow-sm ring-1 ring-slate-200/70', className)}>
    {avatarUrl?.trim() ? (
      <AvatarImage
        alt={`${name} profile`}
        className="object-cover"
        src={avatarUrl}
      />
    ) : null}
    <AvatarFallback className={cn('bg-slate-100 text-[12px] font-semibold text-slate-500', fallbackClassName)}>
      {profileInitials(name)}
    </AvatarFallback>
  </Avatar>
)
