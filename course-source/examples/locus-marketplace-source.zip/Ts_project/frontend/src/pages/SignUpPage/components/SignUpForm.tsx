import { Camera } from 'lucide-react'
import { Link } from 'react-router-dom'

import { ProfileAvatar } from '@/pages/shared/marketplace/components/ProfileAvatar'
import type { UserRole } from '@/objects/identity'

type SignUpFormProps = {
  agencyName: string
  avatarFile?: File
  avatarPreviewUrl?: string
  email: string
  error?: string
  fullName: string
  onAgencyNameChange: (value: string) => void
  onEmailChange: (value: string) => void
  onFullNameChange: (value: string) => void
  onPasswordChange: (value: string) => void
  onPhoneChange: (value: string) => void
  onProfilePictureChange: (fileList: FileList | null) => void
  onRoleChange: (role: UserRole) => void
  onSubmit: () => void
  password: string
  phone: string
  role: UserRole
  submitting: boolean
}

const textInputClassName =
  'h-13 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm text-slate-950 outline-none transition focus:border-slate-400'

const roleButtonClassName = (selected: boolean) =>
  [
    'rounded-[26px] border p-4 text-left transition',
    selected ? 'border-slate-900 bg-slate-100 shadow-sm' : 'border-slate-200 bg-white hover:border-slate-300',
  ].join(' ')

export function SignUpForm({
  agencyName,
  avatarFile,
  avatarPreviewUrl,
  email,
  error,
  fullName,
  onAgencyNameChange,
  onEmailChange,
  onFullNameChange,
  onPasswordChange,
  onPhoneChange,
  onProfilePictureChange,
  onRoleChange,
  onSubmit,
  password,
  phone,
  role,
  submitting,
}: SignUpFormProps) {
  return (
    <div className="w-full max-w-2xl rounded-[36px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.82),rgba(248,250,252,0.72))] p-8 shadow-[0_24px_70px_rgba(15,23,42,0.10)] backdrop-blur-3xl sm:p-10">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-semibold tracking-tight text-slate-950">Create your account</h1>
      </div>

      <div className="space-y-5">
        <div className="grid gap-5 md:grid-cols-2">
          <div className="md:col-span-2">
            <label className="mb-2 block text-sm font-semibold text-slate-700">Full name</label>
            <input
              className={textInputClassName}
              onChange={(event) => onFullNameChange(event.target.value)}
              value={fullName}
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Email</label>
            <input
              className={textInputClassName}
              onChange={(event) => onEmailChange(event.target.value)}
              type="email"
              value={email}
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Password</label>
            <input
              className={textInputClassName}
              onChange={(event) => onPasswordChange(event.target.value)}
              type="password"
              value={password}
            />
          </div>
          <div className="md:col-span-2">
            <label className="mb-2 block text-sm font-semibold text-slate-700">Role</label>
            <div className="grid gap-3 sm:grid-cols-2">
              <button
                className={roleButtonClassName(role === 'buyer_renter')}
                onClick={() => onRoleChange('buyer_renter')}
                type="button"
              >
                <p className="text-base font-semibold text-slate-950">Buyer / renter</p>
                <p className="mt-1 text-sm text-slate-500">Save listings and explore.</p>
              </button>
              <button
                className={roleButtonClassName(role === 'agent_admin')}
                onClick={() => onRoleChange('agent_admin')}
                type="button"
              >
                <p className="text-base font-semibold text-slate-950">Agent / admin</p>
                <p className="mt-1 text-sm text-slate-500">Create and manage.</p>
              </button>
            </div>
          </div>

          <div className="md:col-span-2">
            <label className="mb-2 block text-sm font-semibold text-slate-700">Profile picture</label>
            <div className="flex items-center gap-4 rounded-[24px] border border-slate-200 bg-white px-4 py-4">
              <ProfileAvatar
                avatarUrl={avatarPreviewUrl}
                className="h-16 w-16"
                name={fullName || (role === 'agent_admin' ? 'Agent' : 'Buyer')}
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-900">
                  {avatarFile?.name || 'Upload profile photo'}
                </p>
                <p className="mt-1 text-sm text-slate-500">Required for all accounts.</p>
              </div>
              <label className="inline-flex shrink-0 cursor-pointer items-center gap-2 rounded-2xl border border-slate-200 bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:border-slate-300 hover:bg-slate-200">
                <Camera className="h-4 w-4" />
                Choose
                <input
                  accept="image/avif,image/jpeg,image/png,image/webp"
                  className="sr-only"
                  onChange={(event) => onProfilePictureChange(event.target.files)}
                  type="file"
                />
              </label>
            </div>
          </div>

          {role === 'agent_admin' ? (
            <>
              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-700">Agency name</label>
                <input
                  className={textInputClassName}
                  onChange={(event) => onAgencyNameChange(event.target.value)}
                  value={agencyName}
                />
              </div>
              <div>
                <label className="mb-2 block text-sm font-semibold text-slate-700">Phone</label>
                <input
                  className={textInputClassName}
                  onChange={(event) => onPhoneChange(event.target.value)}
                  value={phone}
                />
              </div>
            </>
          ) : null}
        </div>

        {error ? <p className="pb-2 text-sm font-medium text-rose-600">{error}</p> : null}

        <button
          className="inline-flex w-full items-center justify-center rounded-2xl border border-slate-200 bg-slate-100 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:border-slate-300 hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-60"
          disabled={submitting}
          onClick={onSubmit}
          type="button"
        >
          {submitting ? 'Creating account...' : 'Create account'}
        </button>

        <p className="text-center text-sm text-slate-500">
          Already have an account?{' '}
          <Link className="font-semibold text-slate-950" to="/sign-in">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
