import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

import { api } from '@/apis'
import type { UserRole } from '@/objects/identity'
import { setSession } from '@/pages/shared/auth/session-store'

const maxProfileUploadBytes = 5 * 1024 * 1024
const acceptedProfileImageTypes = new Set(['image/avif', 'image/jpeg', 'image/png', 'image/webp'])

export const useSignUpPage = () => {
  const navigate = useNavigate()
  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState<UserRole>('buyer_renter')
  const [agencyName, setAgencyName] = useState('')
  const [phone, setPhone] = useState('')
  const [avatarFile, setAvatarFile] = useState<File>()
  const [avatarPreviewUrl, setAvatarPreviewUrl] = useState<string>()
  const [error, setError] = useState<string>()
  const [submitting, setSubmitting] = useState(false)

  useEffect(
    () => () => {
      if (avatarPreviewUrl?.startsWith('blob:')) {
        URL.revokeObjectURL(avatarPreviewUrl)
      }
    },
    [avatarPreviewUrl],
  )

  const handleProfilePictureChange = (fileList: FileList | null) => {
    const file = fileList?.[0]

    if (!file) {
      return
    }

    if (!acceptedProfileImageTypes.has(file.type)) {
      setAvatarFile(undefined)
      setAvatarPreviewUrl(undefined)
      setError('Choose a JPEG, PNG, WebP, or AVIF image for the profile picture.')
      return
    }

    if (file.size > maxProfileUploadBytes) {
      setAvatarFile(undefined)
      setAvatarPreviewUrl(undefined)
      setError('Profile picture must be smaller than 5 MB.')
      return
    }

    const nextPreviewUrl = URL.createObjectURL(file)

    if (avatarPreviewUrl?.startsWith('blob:')) {
      URL.revokeObjectURL(avatarPreviewUrl)
    }

    setError(undefined)
    setAvatarFile(file)
    setAvatarPreviewUrl(nextPreviewUrl)
  }

  const handleSubmit = async () => {
    setSubmitting(true)
    setError(undefined)

    if (!avatarFile) {
      setError('Upload a profile picture to create your account.')
      setSubmitting(false)
      return
    }

    const response = await api.signUpWithProfilePicture(
      {
        fullName,
        email,
        password,
        role,
        agencyName: role === 'agent_admin' ? agencyName : undefined,
        phone: role === 'agent_admin' ? phone : undefined,
      },
      avatarFile,
    )

    if (!response.ok) {
      setError(response.error.message)
      setSubmitting(false)
      return
    }

    setSession(response.data.user)
    navigate(role === 'agent_admin' ? '/agent/listings' : '/')
    setSubmitting(false)
  }

  return {
    agencyName,
    avatarFile,
    avatarPreviewUrl,
    email,
    error,
    fullName,
    handleProfilePictureChange,
    handleSubmit,
    password,
    phone,
    role,
    setAgencyName,
    setEmail,
    setFullName,
    setPassword,
    setPhone,
    setRole,
    submitting,
  }
}
