import { SignUpForm } from '@/pages/SignUpPage/components/SignUpForm'
import { useSignUpPage } from '@/pages/SignUpPage/hooks/use-sign-up-page'
import { AuthVideoBackground } from '@/pages/shared/auth/AuthVideoBackground'

export default function SignUpPage() {
  const page = useSignUpPage()

  return (
    <div className="relative isolate min-h-[calc(100svh-73px)] overflow-hidden">
      <AuthVideoBackground />
      <div className="relative z-10 mx-auto flex max-w-6xl justify-center px-4 py-16 sm:px-6 lg:px-8">
        <SignUpForm
          agencyName={page.agencyName}
          avatarFile={page.avatarFile}
          avatarPreviewUrl={page.avatarPreviewUrl}
          email={page.email}
          error={page.error}
          fullName={page.fullName}
          onAgencyNameChange={page.setAgencyName}
          onEmailChange={page.setEmail}
          onFullNameChange={page.setFullName}
          onPasswordChange={page.setPassword}
          onPhoneChange={page.setPhone}
          onProfilePictureChange={page.handleProfilePictureChange}
          onRoleChange={page.setRole}
          onSubmit={page.handleSubmit}
          password={page.password}
          phone={page.phone}
          role={page.role}
          submitting={page.submitting}
        />
      </div>
    </div>
  )
}
