import { AgentListingsHeader } from '@/pages/AgentListingsPage/components/AgentListingsHeader'
import { AgentListingsPanel } from '@/pages/AgentListingsPage/components/AgentListingsPanel'
import { useAgentListingsPage } from '@/pages/AgentListingsPage/hooks/use-agent-listings-page'

export default function AgentListingsPage() {
  const page = useAgentListingsPage()

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <AgentListingsHeader
        onFilterChange={page.setSelectedFilter}
        selectedFilter={page.selectedFilter}
      />

      {page.error ? (
        <div className="mb-6 rounded-[28px] border border-rose-200 bg-rose-50 p-6 text-sm font-medium text-rose-700">
          {page.error}
        </div>
      ) : null}

      <AgentListingsPanel
        emptyMessage={page.emptyMessage}
        isLoading={page.isLoading}
        listings={page.visibleListings}
      />
    </div>
  )
}
