import { BarChart3 } from 'lucide-react'

import { HorizontalListingCard } from '@/pages/shared/marketplace/components/HorizontalListingCard'
import type { ListingSummary } from '@/objects/listings'

type AgentListingsPanelProps = {
  emptyMessage: string
  isLoading: boolean
  listings: ListingSummary[]
}

export function AgentListingsPanel({ emptyMessage, isLoading, listings }: AgentListingsPanelProps) {
  return (
    <div className="space-y-4">
      {isLoading ? (
        <div className="rounded-[28px] border border-slate-200 bg-white px-6 py-8 text-sm font-medium text-slate-500 shadow-[0_18px_50px_rgba(15,23,42,0.05)]">
          Loading your listings...
        </div>
      ) : null}

      {listings.map((listing) => (
        <HorizontalListingCard
          actionLabel="Edit"
          actionTo={`/agent/listings/${listing.id}/edit`}
          key={listing.id}
          listing={listing}
          secondaryActionIcon={<BarChart3 className="h-4 w-4" />}
          secondaryActionLabel="Analytics"
          secondaryActionTo={`/agent/listings/${listing.id}/analytics`}
          showAgentInfo={false}
          showSaveButton={false}
        />
      ))}

      {!isLoading && listings.length === 0 ? (
        <div className="rounded-[28px] border border-slate-200 bg-white px-6 py-8 text-sm font-medium text-slate-500 shadow-[0_18px_50px_rgba(15,23,42,0.05)]">
          {emptyMessage}
        </div>
      ) : null}
    </div>
  )
}
