import { PlusCircle } from 'lucide-react'
import { Link } from 'react-router-dom'

import {
  agentListingFilterOptions,
  type AgentListingFilter,
} from '@/pages/AgentListingsPage/hooks/use-agent-listings-page'
import { cn } from '@/utils/class-names'

type AgentListingsHeaderProps = {
  onFilterChange: (filter: AgentListingFilter) => void
  selectedFilter: AgentListingFilter
}

export function AgentListingsHeader({ onFilterChange, selectedFilter }: AgentListingsHeaderProps) {
  return (
    <div className="mb-8 flex flex-col gap-4">
      <div>
        <h1 className="text-4xl font-semibold tracking-tight text-slate-950">Agent Workspace</h1>
      </div>
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="inline-flex h-[46px] flex-wrap items-center gap-1 rounded-full border border-white/50 bg-white/60 p-[3px] text-sm font-medium text-slate-700 shadow-sm">
          {agentListingFilterOptions.map((option) => {
            const isSelected = option.value === selectedFilter

            return (
              <button
                className={cn(
                  'inline-flex h-full items-center rounded-full px-4 text-sm font-medium leading-none transition',
                  isSelected
                    ? 'bg-slate-950 text-white shadow-[0_10px_20px_rgba(15,23,42,0.12)]'
                    : 'text-slate-700 hover:text-slate-950',
                )}
                key={option.value}
                onClick={() => onFilterChange(option.value)}
                type="button"
              >
                {option.label}
              </button>
            )
          })}
        </div>
        <Link
          className="inline-flex h-[46px] items-center gap-2 rounded-full border border-white/50 bg-white/60 px-5 text-sm font-medium text-slate-700 shadow-sm transition hover:text-slate-950"
          to="/agent/listings/new"
        >
          <PlusCircle className="h-4 w-4" />
          New listing
        </Link>
      </div>
    </div>
  )
}
