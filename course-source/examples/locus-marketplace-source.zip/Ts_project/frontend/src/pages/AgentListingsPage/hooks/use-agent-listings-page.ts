import { useCallback, useEffect, useMemo, useState } from 'react'

import { api } from '@/apis'
import type { ListingSummary } from '@/objects/listings'
import { useSession } from '@/pages/shared/auth/session-store'

export type AgentListingFilter = 'all' | 'sale' | 'rent' | 'sold' | 'leased' | 'archived'

type AgentListingsState =
  | { status: 'loading' }
  | { status: 'ready'; listings: ListingSummary[] }
  | { status: 'empty' }
  | { status: 'error'; message: string }

export type AgentListingFilterOption = {
  label: string
  value: AgentListingFilter
}

export const agentListingFilterOptions: AgentListingFilterOption[] = [
  { label: 'View all', value: 'all' },
  { label: 'For sale', value: 'sale' },
  { label: 'For rent', value: 'rent' },
  { label: 'Sold', value: 'sold' },
  { label: 'Leased', value: 'leased' },
  { label: 'Archived', value: 'archived' },
]

const matchesAgentListingFilter = (listing: ListingSummary, filter: AgentListingFilter) => {
  switch (filter) {
    case 'all':
      return true
    case 'sale':
      return listing.transactionType === 'sale' && listing.listingStatus === 'active'
    case 'rent':
      return listing.transactionType === 'rent' && listing.listingStatus === 'active'
    case 'sold':
      return listing.listingStatus === 'sold'
    case 'leased':
      return listing.listingStatus === 'leased'
    case 'archived':
      return listing.listingStatus === 'archived'
  }
}

export const useAgentListingsPage = () => {
  const isAuthenticated = useSession((state) => state.isAuthenticated)
  const [state, setState] = useState<AgentListingsState>({ status: 'loading' })
  const [selectedFilter, setSelectedFilter] = useState<AgentListingFilter>('all')

  const loadListings = useCallback(() =>
    isAuthenticated
      ? api
          .listAgentListings()
          .then((response) => {
            if (response.ok) {
              setState(response.data.length === 0 ? { status: 'empty' } : { status: 'ready', listings: response.data })
              return
            }

            setState({ status: 'error', message: response.error.message })
          })
      : Promise.resolve().then(() =>
          setState({ status: 'error', message: 'You must be signed in to manage listings.' }),
        ), [isAuthenticated])

  useEffect(() => {
    void loadListings()
  }, [loadListings])

  const visibleListings = useMemo(
    () =>
      state.status === 'ready'
        ? state.listings.filter((listing) => matchesAgentListingFilter(listing, selectedFilter))
        : [],
    [state, selectedFilter],
  )

  const emptyMessage =
    state.status === 'empty'
      ? 'Create your first listing to start managing your portfolio.'
      : 'No listings match the current filter.'

  return {
    emptyMessage,
    error: state.status === 'error' ? state.message : undefined,
    isLoading: state.status === 'loading',
    selectedFilter,
    setSelectedFilter,
    visibleListings,
  }
}
