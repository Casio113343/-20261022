import type { AgentInspectionSlot } from '@/objects/inspections'

export const inspectionDayKey = (date: Date) => {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')

  return `${year}-${month}-${day}`
}

export const slotsForListing = (
  slots: AgentInspectionSlot[],
  listingId?: string,
) =>
  slots
    .filter((slot) => slot.listing.id === listingId)
    .sort(
      (first, second) =>
        new Date(first.startsAt).getTime() -
        new Date(second.startsAt).getTime(),
    )
