import { Link } from 'react-router-dom'

import { CalendarPanel } from '@/pages/AgentInspectionsPage/components/CalendarPanel'
import { CancelInspectionDialog } from '@/pages/AgentInspectionsPage/components/CancelInspectionDialog'
import { ListingSelectionPanel } from '@/pages/AgentInspectionsPage/components/ListingSelectionPanel'
import { SelectedDayPanel } from '@/pages/AgentInspectionsPage/components/SelectedDayPanel'
import { useAgentInspectionsPage } from '@/pages/AgentInspectionsPage/hooks/use-agent-inspections-page'

export default function AgentInspectionsPage() {
  const { calendarDays, inspections } = useAgentInspectionsPage()

  return (
    <div className="min-h-[calc(100vh-81px)] px-4 pt-4 pb-6 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-[1500px]">
        <div className="mb-4 flex items-center gap-2 text-sm text-slate-500">
          <Link className="transition hover:text-slate-950" to="/agent/listings">
            Back to Agent Workspace
          </Link>
          <span>/</span>
          <span>Inspection calendar</span>
        </div>

        <div className="flex min-h-0 flex-col gap-4 pb-2 lg:h-[calc(100vh-10rem)] lg:flex-row">
          <ListingSelectionPanel inspections={inspections} />

          <section className="flex min-h-[40rem] min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-slate-200/60 bg-white shadow-lg">
            <div className="grid min-h-0 flex-1 grid-cols-1 bg-white lg:grid-cols-[minmax(0,1fr)_22rem]">
              <CalendarPanel calendarDays={calendarDays} inspections={inspections} />
              <SelectedDayPanel inspections={inspections} />
            </div>
          </section>
        </div>
      </div>

      <CancelInspectionDialog inspections={inspections} />
    </div>
  )
}
