import { useMemo, useState } from 'react'

import type { AgentInspectionSlot } from '@/objects/inspections'
import type { ListingSummary } from '@/objects/listings'
import {
  inspectionDayKey,
  slotsForListing,
} from '@/pages/AgentInspectionsPage/functions/inspection-selection'

type UseInspectionCalendarSelectionParams = {
  listings: ListingSummary[]
  setError: (message?: string) => void
  slots: AgentInspectionSlot[]
}

const listingAddress = (
  listing: Pick<
    ListingSummary,
    'addressLine' | 'suburb' | 'state' | 'postcode'
  >,
) =>
  `${listing.addressLine}, ${listing.suburb}, ${listing.state} ${listing.postcode}`

export const useInspectionCalendarSelection = ({
  listings,
  setError,
  slots,
}: UseInspectionCalendarSelectionParams) => {
  const [requestedListingId, setRequestedListingId] = useState<string>()
  const [selectedDateKey, setSelectedDateKey] = useState(() =>
    inspectionDayKey(new Date()),
  )
  const [monthAnchor, setMonthAnchor] = useState(() => new Date())
  const [query, setQuery] = useState('')
  const [todayKey] = useState(() => inspectionDayKey(new Date()))

  const selectedListingId =
    requestedListingId &&
    listings.some((listing) => listing.id === requestedListingId)
      ? requestedListingId
      : listings[0]?.id

  const normalizedQuery = query.trim().toLowerCase()
  const filteredListings = useMemo(
    () =>
      normalizedQuery
        ? listings.filter((listing) =>
            listingAddress(listing).toLowerCase().includes(normalizedQuery),
          )
        : listings,
    [listings, normalizedQuery],
  )
  const selectedListing = listings.find(
    (listing) => listing.id === selectedListingId,
  )
  const selectedListingSlots = useMemo(
    () => slotsForListing(slots, selectedListingId),
    [selectedListingId, slots],
  )
  const selectedDateSlots = selectedListingSlots.filter(
    (slot) => slot.startsAt.slice(0, 10) === selectedDateKey,
  )
  const slotsByDate = useMemo(
    () =>
      selectedListingSlots.reduce<Record<string, AgentInspectionSlot[]>>(
        (grouped, slot) => ({
          ...grouped,
          [slot.startsAt.slice(0, 10)]: [
            ...(grouped[slot.startsAt.slice(0, 10)] ?? []),
            slot,
          ],
        }),
        {},
      ),
    [selectedListingSlots],
  )

  const selectListing = (listingId: string) => {
    const nextSlots = slotsForListing(slots, listingId)
    const nextDateKey = nextSlots[0]?.startsAt.slice(0, 10) ?? todayKey
    const nextDate = new Date(`${nextDateKey}T00:00:00`)

    setRequestedListingId(listingId)
    setSelectedDateKey(nextDateKey)
    setMonthAnchor(new Date(nextDate.getFullYear(), nextDate.getMonth(), 1))
    setError(undefined)
  }

  const selectDate = (key: string) => {
    setSelectedDateKey(key)
    setError(undefined)
  }

  return {
    filteredListings,
    monthAnchor,
    moveMonth: (delta: -1 | 1) =>
      setMonthAnchor(
        (current) =>
          new Date(current.getFullYear(), current.getMonth() + delta, 1),
      ),
    query,
    selectDate,
    selectedDate: new Date(`${selectedDateKey}T00:00:00`),
    selectedDateKey,
    selectedDateSlots,
    selectedListing,
    selectedListingId,
    selectedListingSlots,
    selectListing,
    setQuery,
    slotsByDate,
    todayKey,
  }
}
