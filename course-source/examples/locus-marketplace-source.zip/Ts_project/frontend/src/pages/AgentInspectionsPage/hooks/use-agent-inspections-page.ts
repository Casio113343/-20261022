import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'

import { buildCalendarDays } from '@/pages/AgentInspectionsPage/functions/inspection-calendar'
import { useAgentInspections } from '@/pages/AgentInspectionsPage/hooks/use-agent-inspections'
import { useSession } from '@/pages/shared/auth/session-store'

export const useAgentInspectionsPage = () => {
  const navigate = useNavigate()
  const isAuthenticated = useSession((state) => state.isAuthenticated)
  const inspections = useAgentInspections(isAuthenticated, (conversationId) => {
    navigate(`/messages?${new URLSearchParams({ conversationId }).toString()}`)
  })
  const calendarDays = useMemo(() => buildCalendarDays(inspections.monthAnchor), [inspections.monthAnchor])

  return {
    calendarDays,
    inspections,
  }
}

export type AgentInspectionsPageState = ReturnType<typeof useAgentInspectionsPage>
