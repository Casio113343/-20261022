import type { AgentInspectionSlot } from '@/objects/inspections'

export const timeFormatter = new Intl.DateTimeFormat(undefined, {
  hour: 'numeric',
  minute: '2-digit',
})

export const monthFormatter = new Intl.DateTimeFormat(undefined, {
  month: 'long',
  year: 'numeric',
})

export const fullDateFormatter = new Intl.DateTimeFormat(undefined, {
  weekday: 'long',
  month: 'long',
  day: 'numeric',
})

export const buildCalendarDays = (anchorDate: Date) => {
  const firstOfMonth = new Date(anchorDate.getFullYear(), anchorDate.getMonth(), 1)
  const gridStart = new Date(firstOfMonth)
  gridStart.setDate(firstOfMonth.getDate() - firstOfMonth.getDay())

  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(gridStart)
    date.setDate(gridStart.getDate() + index)
    return date
  })
}

const inputDateTime = (selectedDateKey: string, time: string) => new Date(`${selectedDateKey}T${time}`)

export const startTimeOptions = Array.from({ length: 25 }, (_, index) => {
  const totalMinutes = 8 * 60 + index * 30
  const hours = String(Math.floor(totalMinutes / 60)).padStart(2, '0')
  const minutes = String(totalMinutes % 60).padStart(2, '0')
  const value = `${hours}:${minutes}`

  return { label: timeFormatter.format(inputDateTime('2026-01-01', value)), value }
})

export const durationOptions = [
  { label: '15 min', value: 15 },
  { label: '30 min', value: 30 },
  { label: '45 min', value: 45 },
  { label: '1 hour', value: 60 },
  { label: '90 min', value: 90 },
]

export const calendarDayView = ({
  date,
  monthAnchor,
  selectedDateKey,
  slotsByDate,
  todayKey,
}: {
  date: Date
  monthAnchor: Date
  selectedDateKey: string
  slotsByDate: Record<string, AgentInspectionSlot[]>
  todayKey: string
}) => {
  const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
  const daySlots = slotsByDate[key] ?? []
  const availableCount = daySlots.filter((slot) => !slot.buyer).length
  const bookedCount = daySlots.filter((slot) => slot.buyer).length
  const hasAvailableSlots = availableCount > 0
  const hasBookedSlots = bookedCount > 0
  const isToday = key === todayKey
  const isSelected = key === selectedDateKey

  return {
    availableCount,
    bookedCount,
    bookedLabel: bookedCount === 1 ? '1 booked' : `${bookedCount} booked`,
    cellTone: isSelected && hasBookedSlots
      ? 'border-violet-300 bg-violet-50 text-violet-950 shadow-[0_16px_34px_rgba(124,58,237,0.13)] ring-2 ring-inset ring-violet-400'
      : isSelected && isToday
        ? 'border-sky-300 bg-sky-50 text-sky-950 shadow-[0_16px_34px_rgba(14,165,233,0.14)] ring-2 ring-inset ring-sky-400'
        : isSelected && hasAvailableSlots
          ? 'border-emerald-400 bg-emerald-50 text-emerald-950 shadow-[0_16px_34px_rgba(16,185,129,0.14)] ring-2 ring-inset ring-emerald-400'
          : isSelected
            ? 'border-slate-300 bg-white text-slate-600 shadow-[0_14px_30px_rgba(15,23,42,0.06)] ring-2 ring-inset ring-slate-300'
            : isToday
              ? 'border-sky-200 bg-sky-50 text-sky-950 hover:bg-sky-100'
              : hasAvailableSlots
                ? 'border-emerald-200 bg-emerald-50/80 text-emerald-950 hover:-translate-y-0.5 hover:border-emerald-300 hover:bg-emerald-50 hover:shadow-sm'
                : hasBookedSlots
                  ? 'border-violet-200 bg-violet-50/80 text-violet-950 hover:border-violet-300 hover:bg-violet-50'
                  : 'border-slate-200/70 bg-white/70 text-slate-400 hover:bg-white',
    dayTone: hasBookedSlots
      ? 'bg-violet-600 text-white'
      : isToday
        ? 'bg-sky-600 text-white'
        : hasAvailableSlots
          ? 'bg-emerald-600 text-white'
          : isSelected
            ? 'bg-slate-600 text-white'
            : 'bg-slate-100 text-slate-400',
    hasAvailableSlots,
    isCurrentMonth: date.getMonth() === monthAnchor.getMonth(),
    isSelected,
    isToday,
    key,
    slotLabel: availableCount === 1 ? '1 slot' : `${availableCount} slots`,
  }
}
