import { useCallback, useEffect, useState, type SetStateAction } from 'react'

import { api } from '@/apis'
import type { AgentInspectionSlot } from '@/objects/inspections'
import type { ListingSummary } from '@/objects/listings'

type AgentInspectionDataState =
  | { status: 'loading' }
  | { status: 'ready'; listings: ListingSummary[]; slots: AgentInspectionSlot[]; error?: string }
  | { status: 'empty'; error?: string }
  | { status: 'error'; message: string }

export const useAgentInspectionData = (isAuthenticated: boolean) => {
  const [state, setState] = useState<AgentInspectionDataState>({ status: 'loading' })

  const load = useCallback(
    () =>
      isAuthenticated
        ? Promise.all([
            api.listAgentInspections(),
            api.listAgentListings(),
          ]).then(([slotsResponse, listingsResponse]) => {
            if (!slotsResponse.ok) {
              setState({ status: 'error', message: slotsResponse.error.message })
              return
            }

            if (!listingsResponse.ok) {
              setState({ status: 'error', message: listingsResponse.error.message })
              return
            }

            setState(
              listingsResponse.data.length === 0
                ? { status: 'empty' }
                : { status: 'ready', listings: listingsResponse.data, slots: slotsResponse.data },
            )
          })
        : Promise.resolve().then(() => setState({ status: 'error', message: 'You must be signed in to manage inspections.' })),
    [isAuthenticated],
  )

  useEffect(() => {
    const initialRefreshId = window.setTimeout(() => void load(), 0)
    const intervalId = window.setInterval(() => void load(), 60_000)
    const refreshOnFocus = () => void load()
    const refreshWhenVisible = () =>
      document.visibilityState === 'visible' && void load()

    window.addEventListener('focus', refreshOnFocus)
    document.addEventListener('visibilitychange', refreshWhenVisible)

    return () => {
      window.clearTimeout(initialRefreshId)
      window.clearInterval(intervalId)
      window.removeEventListener('focus', refreshOnFocus)
      document.removeEventListener('visibilitychange', refreshWhenVisible)
    }
  }, [load])

  const setSlots = (nextSlots: SetStateAction<AgentInspectionSlot[]>) => {
    setState((current) =>
      current.status === 'ready'
        ? {
            ...current,
            slots: typeof nextSlots === 'function' ? nextSlots(current.slots) : nextSlots,
          }
        : current,
    )
  }

  const setError = (message?: string) => {
    setState((current) => {
      switch (current.status) {
        case 'ready':
          return { ...current, error: message }
        case 'empty':
          return { ...current, error: message }
        case 'loading':
          return message ? { status: 'error', message } : current
        case 'error':
          return message ? { status: 'error', message } : current
      }
    })
  }

  return {
    error:
      state.status === 'error'
        ? state.message
        : state.status === 'ready' || state.status === 'empty'
          ? state.error
          : undefined,
    isEmpty: state.status === 'empty',
    isLoading: state.status === 'loading',
    listings: state.status === 'ready' ? state.listings : [],
    setError,
    setSlots,
    slots: state.status === 'ready' ? state.slots : [],
  }
}
