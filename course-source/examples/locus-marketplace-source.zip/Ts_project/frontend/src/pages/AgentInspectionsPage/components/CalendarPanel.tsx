import { ChevronLeft, ChevronRight } from 'lucide-react'

import { calendarDayView, monthFormatter } from '@/pages/AgentInspectionsPage/functions/inspection-calendar'
import type { AgentInspectionsPageState } from '@/pages/AgentInspectionsPage/hooks/use-agent-inspections-page'
import { cn } from '@/utils/class-names'

type CalendarPanelProps = {
  calendarDays: AgentInspectionsPageState['calendarDays']
  inspections: AgentInspectionsPageState['inspections']
}

export const CalendarPanel = ({ calendarDays, inspections }: CalendarPanelProps) => (
  <div className="flex min-h-0 flex-col overflow-hidden bg-white">
    <div className="grid h-[64px] shrink-0 grid-cols-[1fr_auto_1fr] items-center gap-4 border-b border-slate-200/80 px-5">
      <span aria-hidden="true" />
      <div className="inline-flex items-center gap-1 justify-self-center rounded-full border border-slate-200 bg-slate-50 p-1 shadow-sm">
        <button
          aria-label="Previous month"
          className="inline-flex h-8 w-8 items-center justify-center rounded-full text-slate-500 transition hover:bg-white hover:text-slate-950 hover:shadow-sm"
          onClick={() => inspections.moveMonth(-1)}
          type="button"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <p className="min-w-40 px-3 text-center text-base font-semibold tracking-tight text-slate-950">
          {monthFormatter.format(inspections.monthAnchor)}
        </p>
        <button
          aria-label="Next month"
          className="inline-flex h-8 w-8 items-center justify-center rounded-full text-slate-500 transition hover:bg-white hover:text-slate-950 hover:shadow-sm"
          onClick={() => inspections.moveMonth(1)}
          type="button"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
      <span aria-hidden="true" />
    </div>

    <div className="flex min-h-0 flex-1 flex-col p-4 pt-3">
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-[26px] bg-slate-100/80 p-2">
        <div className="mb-1 grid h-8 shrink-0 grid-cols-7 text-center text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-500">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((label) => (
            <div className="flex items-center justify-center" key={label}>
              {label}
            </div>
          ))}
        </div>
        <div className="grid min-h-0 flex-1 grid-cols-7 grid-rows-[repeat(6,minmax(0,1fr))] gap-2">
          {calendarDays.map((date) => {
            const day = calendarDayView({
              date,
              monthAnchor: inspections.monthAnchor,
              selectedDateKey: inspections.selectedDateKey,
              slotsByDate: inspections.slotsByDate,
              todayKey: inspections.todayKey,
            })

            return (
              <button
                className={cn(
                  'group flex min-h-0 flex-col overflow-hidden rounded-[22px] border p-2.5 text-left transition',
                  day.cellTone,
                  !day.isCurrentMonth && 'opacity-40',
                )}
                key={day.key}
                onClick={() => inspections.selectDate(day.key)}
                type="button"
              >
                <span
                  className={cn(
                    'inline-flex h-7 w-7 items-center justify-center rounded-full text-sm font-semibold tracking-tight',
                    day.dayTone,
                  )}
                >
                  {date.getDate()}
                </span>
                <div className="mt-auto">
                  {day.bookedCount > 0 ? (
                    <span className="inline-flex w-full items-center justify-center rounded-[15px] bg-violet-600 px-2 py-1.5 text-[11px] font-semibold leading-none tracking-tight text-white shadow-[0_8px_18px_rgba(124,58,237,0.18)]">
                      {day.bookedLabel}
                    </span>
                  ) : day.availableCount > 0 ? (
                    <span
                      className={cn(
                        'inline-flex w-full items-center justify-center rounded-[15px] px-2 py-1.5 text-[11px] font-semibold leading-none tracking-tight',
                        day.isToday
                          ? day.isSelected
                            ? 'bg-sky-600 text-white shadow-[0_8px_18px_rgba(14,165,233,0.18)]'
                            : 'bg-white/90 text-sky-700 shadow-sm ring-1 ring-sky-100/80 group-hover:bg-white'
                          : day.isSelected
                            ? 'bg-emerald-600 text-white shadow-[0_8px_18px_rgba(5,150,105,0.18)]'
                            : 'bg-white/90 text-emerald-700 shadow-sm ring-1 ring-emerald-100/80 group-hover:bg-white',
                      )}
                    >
                      {day.slotLabel}
                    </span>
                  ) : null}
                </div>
              </button>
            )
          })}
        </div>
      </div>
    </div>
  </div>
)
