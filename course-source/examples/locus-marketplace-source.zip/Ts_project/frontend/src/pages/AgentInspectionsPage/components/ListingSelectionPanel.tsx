import { Search } from 'lucide-react'

import { slotsForListing } from '@/pages/AgentInspectionsPage/functions/inspection-selection'
import type { AgentInspectionsPageState } from '@/pages/AgentInspectionsPage/hooks/use-agent-inspections-page'
import { cn } from '@/utils/class-names'

type ListingSelectionPanelProps = {
  inspections: AgentInspectionsPageState['inspections']
}

export const ListingSelectionPanel = ({ inspections }: ListingSelectionPanelProps) => (
  <aside className="flex shrink-0 flex-col overflow-hidden rounded-xl border border-slate-200/60 bg-white shadow-lg lg:w-[19rem]">
    <div className="flex h-[64px] shrink-0 items-center border-b border-slate-200/80 px-4">
      <div className="flex h-10 w-full items-center gap-2.5 rounded-full bg-slate-100/80 px-3.5">
        <Search className="h-4 w-4 shrink-0 text-slate-400" />
        <input
          className="min-w-0 flex-1 bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400"
          onChange={(event) => inspections.setQuery(event.target.value)}
          placeholder="Search address"
          value={inspections.query}
        />
      </div>
    </div>
    <div className="min-h-0 flex-1 overflow-y-auto p-3">
      <div className="space-y-1.5">
        {inspections.isLoading ? (
          <p className="px-3 py-6 text-center text-sm text-slate-500">Loading properties...</p>
        ) : null}

        {inspections.filteredListings.map((listing) => {
          const listingSlots = slotsForListing(inspections.slots, listing.id)
          const bookedCount = listingSlots.filter((slot) => slot.buyer).length
          const isSelected = inspections.selectedListingId === listing.id

          return (
            <button
              className={cn(
                'w-full rounded-[18px] px-3.5 py-3 text-left transition',
                isSelected
                  ? 'bg-slate-950 text-white shadow-[0_12px_26px_rgba(15,23,42,0.16)]'
                  : 'text-slate-700 hover:bg-slate-50',
              )}
              key={listing.id}
              onClick={() => inspections.selectListing(listing.id)}
              type="button"
            >
              <p className="truncate text-sm font-semibold">{listing.addressLine}</p>
              <div className="mt-1 flex items-center justify-between gap-2">
                <p className={cn('truncate text-xs', isSelected ? 'text-slate-300' : 'text-slate-500')}>
                  {listing.suburb}
                </p>
                {bookedCount > 0 ? (
                  <span
                    className={cn(
                      'shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold',
                      isSelected ? 'bg-white/15 text-white' : 'bg-violet-50 text-violet-700',
                    )}
                  >
                    {bookedCount} booked
                  </span>
                ) : null}
              </div>
            </button>
          )
        })}
        {!inspections.isLoading && inspections.filteredListings.length === 0 ? (
          <p className="px-3 py-6 text-center text-sm text-slate-500">
            {inspections.isEmpty ? 'No properties available for inspections' : 'No matching properties'}
          </p>
        ) : null}
      </div>
    </div>
  </aside>
)
