import { useAgentInspectionData } from '@/pages/AgentInspectionsPage/hooks/use-agent-inspection-data'
import { useInspectionCalendarSelection } from '@/pages/AgentInspectionsPage/hooks/use-inspection-calendar-selection'
import { useInspectionSlotActions } from '@/pages/AgentInspectionsPage/hooks/use-inspection-slot-actions'

export const useAgentInspections = (
  isAuthenticated: boolean,
  onConversationOpened: (conversationId: string) => void,
) => {
  const data = useAgentInspectionData(isAuthenticated)
  const selection = useInspectionCalendarSelection({
    listings: data.listings,
    setError: data.setError,
    slots: data.slots,
  })
  const actions = useInspectionSlotActions({
    onConversationOpened,
    selectedDateKey: selection.selectedDateKey,
    selectedListingId: selection.selectedListingId,
    selectedListingSlots: selection.selectedListingSlots,
    setError: data.setError,
    setSlots: data.setSlots,
    slots: data.slots,
    isAuthenticated,
  })

  const selectListing = (listingId: string) => {
    selection.selectListing(listingId)
    actions.setIsAddingSlot(false)
    actions.setSlotPendingCancellation(undefined)
  }

  const selectDate = (dateKey: string) => {
    selection.selectDate(dateKey)
    actions.setIsAddingSlot(false)
  }

  return {
    ...actions,
    ...selection,
    error: data.error,
    isEmpty: data.isEmpty,
    isLoading: data.isLoading,
    selectDate,
    selectListing,
    setError: data.setError,
    slots: data.slots,
  }
}
