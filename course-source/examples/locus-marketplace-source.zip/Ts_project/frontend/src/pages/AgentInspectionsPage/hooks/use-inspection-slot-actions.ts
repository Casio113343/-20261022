import { useState, type Dispatch, type SetStateAction } from 'react'

import { api } from '@/apis'
import type { AgentInspectionSlot } from '@/objects/inspections'

type UseInspectionSlotActionsParams = {
  onConversationOpened: (conversationId: string) => void
  selectedDateKey: string
  selectedListingId?: string
  selectedListingSlots: AgentInspectionSlot[]
  setError: (message?: string) => void
  setSlots: Dispatch<SetStateAction<AgentInspectionSlot[]>>
  slots: AgentInspectionSlot[]
  isAuthenticated: boolean
}

const inputDateTime = (dateKey: string, time: string) =>
  new Date(`${dateKey}T${time}`)

export const useInspectionSlotActions = ({
  onConversationOpened,
  selectedDateKey,
  selectedListingId,
  selectedListingSlots,
  setError,
  setSlots,
  slots,
  isAuthenticated,
}: UseInspectionSlotActionsParams) => {
  const [startTime, setStartTime] = useState('10:00')
  const [durationMinutes, setDurationMinutes] = useState(30)
  const [isAddingSlot, setIsAddingSlot] = useState(false)
  const [slotPendingCancellation, setSlotPendingCancellation] =
    useState<AgentInspectionSlot>()
  const [isDeletingSlot, setIsDeletingSlot] = useState(false)
  const [openingConversationSlotId, setOpeningConversationSlotId] =
    useState<string>()
  const proposedStart = inputDateTime(selectedDateKey, startTime)
  const proposedEnd = new Date(
    proposedStart.getTime() + durationMinutes * 60_000,
  )
  const duplicateSlotExists = selectedListingSlots.some(
    (slot) => new Date(slot.startsAt).getTime() === proposedStart.getTime(),
  )

  const currentSlotPendingCancellation =
    slotPendingCancellation &&
    slots.some((slot) => slot.id === slotPendingCancellation.id)
      ? slotPendingCancellation
      : undefined

  const createSlot = async () => {
    if (!isAuthenticated || !selectedListingId) {
      return
    }

    if (duplicateSlotExists) {
      setError('A slot already exists at this time.')
      return
    }

    const response = await api.createInspectionSlot({
      listingId: selectedListingId,
      startsAt: proposedStart.toISOString(),
      endsAt: proposedEnd.toISOString(),
    })

    if (!response.ok) {
      setError(response.error.message)
      return
    }

    setSlots((current) => [...current, response.data])
    setIsAddingSlot(false)
    setError(undefined)
  }

  const deleteSlot = async (slot: AgentInspectionSlot) => {
    if (!isAuthenticated) {
      return
    }

    setIsDeletingSlot(true)
    const response = await api.deleteInspectionSlot(slot.id)
    setIsDeletingSlot(false)

    if (!response.ok) {
      setError(response.error.message)
      return
    }

    setSlots((current) =>
      current.filter((currentSlot) => currentSlot.id !== slot.id),
    )
    setSlotPendingCancellation(undefined)
    setError(undefined)
  }

  const openBookedSlotConversation = async (slot: AgentInspectionSlot) => {
    if (!isAuthenticated) {
      return
    }

    setOpeningConversationSlotId(slot.id)
    const response = await api.openBookedInspectionConversation(slot.id)
    setOpeningConversationSlotId(undefined)

    if (!response.ok) {
      setError(response.error.message)
      return
    }

    onConversationOpened(response.data.conversationId)
  }

  return {
    createSlot,
    deleteSlot,
    duplicateSlotExists,
    durationMinutes,
    isAddingSlot,
    isDeletingSlot,
    openBookedSlotConversation,
    openingConversationSlotId,
    setDurationMinutes,
    setIsAddingSlot,
    setSlotPendingCancellation,
    setStartTime,
    slotPendingCancellation: currentSlotPendingCancellation,
    startTime,
  }
}
