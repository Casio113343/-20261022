import { CalendarCheck, MessageCircleMore, Plus, Trash2 } from 'lucide-react'

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  durationOptions,
  fullDateFormatter,
  startTimeOptions,
  timeFormatter,
} from '@/pages/AgentInspectionsPage/functions/inspection-calendar'
import type { AgentInspectionsPageState } from '@/pages/AgentInspectionsPage/hooks/use-agent-inspections-page'
import { ProfileAvatar } from '@/pages/shared/marketplace/components/ProfileAvatar'

type SelectedDayPanelProps = {
  inspections: AgentInspectionsPageState['inspections']
}

export const SelectedDayPanel = ({ inspections }: SelectedDayPanelProps) => (
  <aside className="flex min-h-0 flex-col border-t border-slate-200/80 bg-[linear-gradient(180deg,#f8fafc_0%,#ffffff_48%)] lg:border-l lg:border-t-0">
    <div className="flex h-[64px] shrink-0 items-center gap-3.5 border-b border-slate-200/80 px-5">
      <div className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-[13px] bg-slate-950 text-white shadow-[0_10px_22px_rgba(15,23,42,0.14)]">
        <CalendarCheck className="h-[18px] w-[18px]" />
      </div>
      <p className="truncate text-base font-semibold tracking-tight text-slate-950">
        {fullDateFormatter.format(inspections.selectedDate)}
      </p>
    </div>

    <div className="flex min-h-0 flex-1 flex-col px-5 pb-4 pt-3">
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto pr-1">
        {inspections.selectedDateSlots.map((slot) =>
          slot.buyer ? (
            <div
              className="rounded-[20px] border border-violet-400 bg-violet-50 p-3.5 text-violet-950 shadow-[0_14px_30px_rgba(124,58,237,0.08)] ring-1 ring-inset ring-violet-300"
              key={slot.id}
            >
              <div className="flex w-full items-center justify-between gap-3">
                <span className="text-[15px] font-semibold tracking-tight">
                  {timeFormatter.format(new Date(slot.startsAt))} - {timeFormatter.format(new Date(slot.endsAt))}
                </span>
                <span className="shrink-0 rounded-full bg-violet-100 px-2.5 py-1 text-[11px] font-semibold text-violet-700">
                  Booked
                </span>
              </div>
              <div className="mt-3 flex items-center gap-3 border-t border-violet-200/80 pt-3">
                <ProfileAvatar
                  avatarUrl={slot.buyer.avatarUrl}
                  className="h-10 w-10 ring-1 ring-white"
                  name={slot.buyer.fullName}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-slate-950">{slot.buyer.fullName}</p>
                  <p className="truncate text-xs text-slate-500">{slot.buyer.email}</p>
                </div>
                <button
                  aria-label={`Message ${slot.buyer.fullName}`}
                  className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-violet-200 bg-white text-violet-700 shadow-sm transition hover:border-violet-300 hover:bg-violet-100 disabled:cursor-not-allowed disabled:opacity-50"
                  disabled={inspections.openingConversationSlotId === slot.id}
                  onClick={() => void inspections.openBookedSlotConversation(slot)}
                  title={`Message ${slot.buyer.fullName}`}
                  type="button"
                >
                  <MessageCircleMore className="h-4 w-4" />
                </button>
                <button
                  aria-label="Cancel booked inspection"
                  className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-violet-200 bg-white text-violet-500 shadow-sm transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600 disabled:cursor-not-allowed disabled:opacity-50"
                  disabled={inspections.isDeletingSlot}
                  onClick={() => {
                    inspections.setSlotPendingCancellation(slot)
                    inspections.setError(undefined)
                  }}
                  title="Cancel booking and notify buyer"
                  type="button"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ) : (
            <div
              className="flex h-[50px] items-center justify-between rounded-[20px] border border-slate-200 bg-white/80 px-4 text-slate-700 transition hover:-translate-y-0.5 hover:border-slate-300 hover:bg-white hover:shadow-sm"
              key={slot.id}
            >
              <span className="text-[15px] font-semibold tracking-tight">
                {timeFormatter.format(new Date(slot.startsAt))} - {timeFormatter.format(new Date(slot.endsAt))}
              </span>
              <button
                aria-label="Delete available slot"
                className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-slate-400 transition hover:bg-white hover:text-rose-600 disabled:cursor-not-allowed disabled:opacity-50"
                disabled={inspections.isDeletingSlot}
                onClick={() => void inspections.deleteSlot(slot)}
                title="Delete slot"
                type="button"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ),
        )}
        {inspections.isLoading ? (
          <div className="grid min-h-full grid-rows-[1fr_auto_2fr] rounded-[24px] border border-dashed border-slate-200 bg-white/70 p-8 text-center">
            <span aria-hidden="true" />
            <p className="text-sm font-semibold text-slate-600">Loading inspection calendar...</p>
            <span aria-hidden="true" />
          </div>
        ) : null}
        {!inspections.isLoading && inspections.selectedDateSlots.length === 0 && !inspections.isAddingSlot ? (
          <div className="grid min-h-full grid-rows-[1fr_auto_2fr] rounded-[24px] border border-dashed border-slate-200 bg-white/70 p-8 text-center">
            <span aria-hidden="true" />
            <p className="text-sm font-semibold text-slate-600">
              {inspections.isEmpty ? 'Create a listing before adding inspection slots' : 'No slots available'}
            </p>
            <span aria-hidden="true" />
          </div>
        ) : null}
      </div>

      {inspections.error ? (
        <p className="mt-3 rounded-[16px] bg-rose-50 px-3.5 py-2.5 text-sm font-medium text-rose-700">
          {inspections.error}
        </p>
      ) : null}

      {inspections.isAddingSlot ? (
        <div className="mt-4 rounded-[20px] border border-slate-200 bg-white p-3 shadow-[0_10px_30px_rgba(15,23,42,0.05)]">
          <div className="grid grid-cols-2 gap-2.5">
            <label className="text-[11px] font-semibold text-slate-500">
              Start time
              <Select onValueChange={inspections.setStartTime} value={inspections.startTime}>
                <SelectTrigger className="mt-1.5 h-11 rounded-[13px] border-slate-200 bg-slate-50 px-3 text-sm font-medium text-slate-900 shadow-none focus-visible:ring-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="rounded-[14px] border-slate-200 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.14)]">
                  {startTimeOptions.map((option) => (
                    <SelectItem className="rounded-[9px] py-2 text-sm" key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
            <label className="text-[11px] font-semibold text-slate-500">
              Duration
              <Select
                onValueChange={(value) => inspections.setDurationMinutes(Number(value))}
                value={String(inspections.durationMinutes)}
              >
                <SelectTrigger className="mt-1.5 h-11 rounded-[13px] border-slate-200 bg-slate-50 px-3 text-sm font-medium text-slate-900 shadow-none focus-visible:ring-slate-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="rounded-[14px] border-slate-200 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.14)]">
                  {durationOptions.map((option) => (
                    <SelectItem className="rounded-[9px] py-2 text-sm" key={option.value} value={String(option.value)}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
          </div>
          <div className="mt-3 flex gap-2">
            <button
              className="inline-flex h-10 flex-1 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-sm font-semibold text-slate-700 shadow-sm transition hover:border-slate-300 hover:bg-white hover:text-slate-950"
              onClick={() => inspections.setIsAddingSlot(false)}
              type="button"
            >
              Cancel
            </button>
            <button
              className="inline-flex h-10 flex-1 items-center justify-center rounded-full bg-slate-950 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300"
              disabled={inspections.duplicateSlotExists}
              onClick={() => void inspections.createSlot()}
              type="button"
            >
              Add slot
            </button>
          </div>
        </div>
      ) : (
        <button
          className="mt-5 inline-flex h-12 items-center justify-center gap-2 rounded-full bg-slate-950 px-5 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(15,23,42,0.18)] transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300"
          disabled={inspections.isLoading || !inspections.selectedListing}
          onClick={() => inspections.setIsAddingSlot(true)}
          type="button"
        >
          <Plus className="h-4 w-4" />
          Add slot
        </button>
      )}
    </div>
  </aside>
)
