import { HomeHeroSection } from '@/pages/HomePage/components/HomeHeroSection'
import { HomeListingSection } from '@/pages/HomePage/components/HomeListingSection'
import { HomeSectionRail } from '@/pages/HomePage/components/HomeSectionRail'
import { useHomePage } from '@/pages/HomePage/hooks/use-home-page'
import { homeSectionItems } from '@/pages/HomePage/objects/home-page-sections'

export default function HomePage() {
  const {
    activeSectionId,
    errorMessage,
    listingSections,
    savedIds,
    scrollContainerRef,
    selectSection,
    setSectionRef,
    toggleSaved,
  } = useHomePage()

  return (
    <div className="relative isolate">
      <HomeSectionRail
        activeSectionId={activeSectionId}
        items={homeSectionItems}
        onSelect={selectSection}
      />

      {errorMessage ? (
        <div className="fixed bottom-5 left-1/2 z-30 w-[min(38rem,calc(100vw-2rem))] -translate-x-1/2 rounded-full border border-white/70 bg-white/72 px-5 py-3 text-center text-sm font-medium text-slate-500 shadow-[0_18px_56px_rgba(15,23,42,0.1)] backdrop-blur-3xl">
          {errorMessage}
        </div>
      ) : null}

      <div
        className="h-[calc(100svh-73px)] snap-y snap-mandatory overflow-y-auto scroll-smooth overscroll-contain bg-[radial-gradient(ellipse_at_50%_8rem,_rgba(219,234,254,0.76)_0%,_rgba(248,250,252,0.42)_38%,_rgba(255,255,255,0)_70%),linear-gradient(180deg,_#fcfdff_0%,_#f8fbff_42%,_#ffffff_100%)] [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        ref={scrollContainerRef}
      >
        <HomeHeroSection
          isActive={activeSectionId === 'find-home'}
          setSectionRef={setSectionRef}
        />

        {listingSections.map((section) => (
          <HomeListingSection
            id={section.id}
            isActive={activeSectionId === section.id}
            key={section.id}
            listings={section.listings}
            marketMode={section.marketMode}
            onToggleSave={toggleSaved}
            savedIds={savedIds}
            setSectionRef={setSectionRef}
            title={section.title}
          />
        ))}
      </div>
    </div>
  )
}
