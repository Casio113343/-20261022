import { useCallback, useRef, useState } from 'react'

import {
  getSectionScrollTop,
  isHomeSectionId,
} from '@/pages/HomePage/functions/home-section-navigation'
import { useHomeSectionRefs } from '@/pages/HomePage/hooks/use-home-section-refs'
import {
  useHomeSectionRouteState,
  useInitialHomeSectionId,
} from '@/pages/HomePage/hooks/use-home-section-route-state'
import { useInitialSectionRestore } from '@/pages/HomePage/hooks/use-initial-section-restore'
import { useObservedActiveHomeSection } from '@/pages/HomePage/hooks/use-observed-active-home-section'
import {
  homeSectionItems,
  type HomeSectionId,
} from '@/pages/HomePage/objects/home-page-sections'

export const useHomeSectionNavigation = (isLoading: boolean) => {
  const { scrollContainerRef, sectionRefs, setSectionRef } =
    useHomeSectionRefs()
  const initialSectionId = useInitialHomeSectionId()
  const [activeSectionId, setActiveSectionId] =
    useState<HomeSectionId>(initialSectionId)
  const isRestoringSectionRef = useRef(
    initialSectionId !== homeSectionItems[0].id,
  )

  useHomeSectionRouteState(activeSectionId)

  const selectSection = useCallback((sectionId: string) => {
    const root = scrollContainerRef.current
    const section = sectionRefs.current[sectionId]

    if (!root || !section || !isHomeSectionId(sectionId)) {
      return
    }

    setActiveSectionId(sectionId)
    root.scrollTo({
      behavior: 'smooth',
      top: getSectionScrollTop(root, section),
    })
  }, [scrollContainerRef, sectionRefs])

  useInitialSectionRestore({
    initialSectionId,
    isLoading,
    isRestoringSectionRef,
    scrollContainerRef,
    sectionRefs,
  })

  useObservedActiveHomeSection({
    isRestoringSectionRef,
    scrollContainerRef,
    sectionRefs,
    setActiveSectionId,
  })

  return {
    activeSectionId,
    scrollContainerRef,
    selectSection,
    setSectionRef,
  }
}
