import { useEffect, useRef } from 'react'

import { mediaAssets } from '@/config/media-assets'
import { SearchPanel } from '@/pages/HomePage/components/SearchPanel'

type HomeHeroSectionProps = {
  isActive: boolean
  setSectionRef: (sectionId: string) => (element: HTMLElement | null) => void
}

export const HomeHeroSection = ({
  isActive,
  setSectionRef,
}: HomeHeroSectionProps) => {
  const videoRef = useRef<HTMLVideoElement | null>(null)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    if (isActive) {
      void video.play().catch(() => undefined)
      return
    }

    video.pause()
  }, [isActive])

  return (
    <section
      className="relative grid h-full min-h-full snap-start snap-always place-items-center overflow-hidden bg-slate-950 px-4 sm:px-6 lg:px-8"
      id="find-home"
      ref={setSectionRef('find-home')}
    >
      <video
        aria-hidden="true"
        autoPlay
        className="absolute inset-0 h-full w-full object-cover"
        loop
        muted
        playsInline
        poster="/fallbacks/property-location.jpg"
        ref={videoRef}
        src={mediaAssets.homeHeroVideo}
      />

      <div
        className={[
          'relative mx-auto grid w-full max-w-6xl grid-rows-[1fr_auto_1fr] items-center px-4 text-center transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] before:absolute before:left-1/2 before:top-1/2 before:-z-10 before:h-[28rem] before:w-[min(52rem,92vw)] before:-translate-x-1/2 before:-translate-y-1/2 before:rounded-full before:bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.46)_0%,_rgba(255,255,255,0.28)_34%,_rgba(255,255,255,0.10)_58%,_transparent_78%)] before:blur-2xl sm:px-8 lg:px-12',
          isActive ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-[0.992] opacity-65',
        ].join(' ')}
      >
        <div className="flex items-end justify-center pb-12">
          <h1 className="relative max-w-4xl text-5xl font-semibold tracking-tight text-slate-950 drop-shadow-[0_2px_20px_rgba(255,255,255,0.46)] before:absolute before:-inset-x-14 before:-inset-y-6 before:-z-10 before:rounded-full before:bg-white/34 before:blur-3xl sm:text-6xl lg:text-7xl">
            Find your home.
          </h1>
        </div>

        <div className="w-full">
          <SearchPanel />
        </div>

        <div />
      </div>
    </section>
  )
}
