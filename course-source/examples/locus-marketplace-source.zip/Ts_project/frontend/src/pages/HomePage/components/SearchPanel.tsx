import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'

import { ListingFilters } from '@/pages/shared/marketplace/components/ListingFilters'
import type { TransactionType } from '@/objects/listings'
import {
  applyFilterPatch,
  defaultMarketplaceFilters,
  type MarketplaceFilterValues,
} from '@/pages/shared/marketplace/functions/marketplace-filters'

type SearchPanelProps = {
  initialTransactionType?: TransactionType
  initialQuery?: string
}

export const SearchPanel = ({
  initialTransactionType = 'sale',
  initialQuery = '',
}: SearchPanelProps) => {
  const navigate = useNavigate()
  const [hasUsedSearchBar, setHasUsedSearchBar] = useState(false)
  const filters = useMemo<MarketplaceFilterValues>(
    () => ({
      ...defaultMarketplaceFilters,
      marketMode: initialTransactionType,
      query: initialQuery,
    }),
    [initialTransactionType, initialQuery],
  )

  const handleApply = (nextFilters: MarketplaceFilterValues) => {
    const searchParams = applyFilterPatch(new URLSearchParams(), nextFilters)
    navigate(`/listings?${searchParams.toString()}`)
  }

  return (
    <div className="mx-auto w-full max-w-4xl">
      <ListingFilters
        actionLabel="Save"
        applyOnAction={hasUsedSearchBar}
        draftVersion={`${initialTransactionType}:${initialQuery}`}
        filters={filters}
        onApply={handleApply}
        onSearchApply={() => setHasUsedSearchBar(true)}
        variant="home"
      />
    </div>
  )
}
