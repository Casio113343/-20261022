type HomeSectionRailItem = {
  id: string
  label: string
}

type HomeSectionRailProps = {
  activeSectionId: string
  items: readonly HomeSectionRailItem[]
  onSelect: (sectionId: string) => void
}

export const HomeSectionRail = ({
  activeSectionId,
  items,
  onSelect,
}: HomeSectionRailProps) => (
  <nav
    aria-label="Homepage sections"
    className="fixed right-5 top-1/2 z-30 hidden -translate-y-1/2 lg:block"
  >
    <div className="flex h-[34vh] min-h-72 flex-col gap-2">
      {items.map((item, index) => {
        const isActive = item.id === activeSectionId

        return (
          <button
            aria-label={`Go to ${item.label}`}
            aria-current={isActive ? 'true' : undefined}
            className={[
              'group flex w-7 flex-1 items-stretch justify-end transition duration-300',
              isActive ? 'opacity-100' : 'opacity-70 hover:opacity-90',
            ].join(' ')}
            key={item.id}
            onClick={() => onSelect(item.id)}
            type="button"
          >
            <span
              className={[
                'block h-full w-[2px] rounded-full transition-colors duration-300 ease-out',
                isActive
                  ? 'bg-slate-950'
                  : 'bg-slate-300 group-hover:bg-slate-500',
              ].join(' ')}
            />
            <span className="sr-only">{`${index + 1}. ${item.label}`}</span>
          </button>
        )
      })}
    </div>
  </nav>
)
