import { useMemo } from 'react'

import { useHomeListings } from '@/pages/HomePage/hooks/use-home-listings'
import { useHomeSectionNavigation } from '@/pages/HomePage/hooks/use-home-section-navigation'
import type { HomeListingSection } from '@/pages/HomePage/objects/home-page-sections'
import { useSavedListings } from '@/pages/shared/hooks/use-saved-listings'

export const useHomePage = () => {
  const { errorMessage, isLoading, sections } = useHomeListings()
  const { savedIds, toggleSaved } = useSavedListings()
  const sectionNavigation = useHomeSectionNavigation(isLoading)
  const listingSections = useMemo<HomeListingSection[]>(
    () => [
      {
        id: 'for-sale',
        listings: sections.sale,
        marketMode: 'sale',
        title: 'For sale',
      },
      {
        id: 'for-rent',
        listings: sections.rent,
        marketMode: 'rent',
        title: 'For rent',
      },
      {
        id: 'recently-sold',
        listings: sections.sold,
        marketMode: 'sold',
        title: 'Recently sold',
      },
      {
        id: 'recently-leased',
        listings: sections.leased,
        marketMode: 'leased',
        title: 'Recently leased',
      },
    ],
    [sections.leased, sections.rent, sections.sale, sections.sold],
  )

  return {
    ...sectionNavigation,
    errorMessage,
    listingSections,
    savedIds,
    toggleSaved,
  }
}
