import { useEffect, useRef, type RefObject } from 'react'

import {
  mostVisibleSection,
  sectionVisibilityRatios,
} from '@/pages/HomePage/functions/home-section-navigation'
import {
  homeSectionItems,
  type HomeSectionId,
} from '@/pages/HomePage/objects/home-page-sections'

type UseObservedActiveHomeSectionArgs = {
  isRestoringSectionRef: RefObject<boolean>
  scrollContainerRef: RefObject<HTMLDivElement | null>
  sectionRefs: RefObject<Record<string, HTMLElement | null>>
  setActiveSectionId: (sectionId: HomeSectionId) => void
}

export const useObservedActiveHomeSection = ({
  isRestoringSectionRef,
  scrollContainerRef,
  sectionRefs,
  setActiveSectionId,
}: UseObservedActiveHomeSectionArgs) => {
  const visibilityRatiosRef = useRef<Record<string, number>>({})

  useEffect(() => {
    const root = scrollContainerRef.current
    const sectionsToObserve = homeSectionItems
      .map((item) => sectionRefs.current[item.id])
      .filter((section): section is HTMLElement => Boolean(section))

    if (!root || sectionsToObserve.length === 0) {
      return undefined
    }

    visibilityRatiosRef.current = sectionVisibilityRatios(
      root,
      sectionsToObserve,
    )

    if (!isRestoringSectionRef.current) {
      setActiveSectionId(mostVisibleSection(visibilityRatiosRef.current))
    }

    const observer = new IntersectionObserver(
      (entries) => {
        visibilityRatiosRef.current = entries.reduce<Record<string, number>>(
          (ratios, entry) => ({
            ...ratios,
            [entry.target.id]: entry.isIntersecting
              ? entry.intersectionRatio
              : 0,
          }),
          visibilityRatiosRef.current,
        )

        if (!isRestoringSectionRef.current) {
          setActiveSectionId(mostVisibleSection(visibilityRatiosRef.current))
        }
      },
      {
        root,
        threshold: [0, 0.01, 0.1, 0.25, 0.35, 0.5, 0.65, 0.8, 1],
      },
    )

    sectionsToObserve.forEach((section) => observer.observe(section))

    return () => {
      observer.disconnect()
      visibilityRatiosRef.current = {}
    }
  }, [
    isRestoringSectionRef,
    scrollContainerRef,
    sectionRefs,
    setActiveSectionId,
  ])
}
