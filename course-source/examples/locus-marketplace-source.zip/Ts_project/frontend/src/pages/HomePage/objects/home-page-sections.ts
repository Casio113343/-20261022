import type { ListingSummary } from '@/objects/listings'

export const homeSectionItems = [
  { id: 'find-home', label: 'Find your home' },
  { id: 'for-sale', label: 'For sale' },
  { id: 'for-rent', label: 'For rent' },
  { id: 'recently-sold', label: 'Recently sold' },
  { id: 'recently-leased', label: 'Recently leased' },
] as const

export type HomeSectionId = (typeof homeSectionItems)[number]['id']

export type HomeListingSection = {
  id: Exclude<HomeSectionId, 'find-home'>
  listings: ListingSummary[]
  marketMode: 'sale' | 'rent' | 'sold' | 'leased'
  title: string
}

export type HomePageLocationState = Record<string, unknown> & {
  homeSectionId?: unknown
}
