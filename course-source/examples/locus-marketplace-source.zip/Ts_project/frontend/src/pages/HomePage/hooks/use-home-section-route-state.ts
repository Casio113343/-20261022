import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

import {
  getInitialSectionId,
  getLocationState,
} from '@/pages/HomePage/functions/home-section-navigation'
import type { HomeSectionId } from '@/pages/HomePage/objects/home-page-sections'

export const useInitialHomeSectionId = () => {
  const location = useLocation()
  const [initialSectionId] = useState<HomeSectionId>(() =>
    getInitialSectionId(location.state),
  )

  return initialSectionId
}

export const useHomeSectionRouteState = (activeSectionId: HomeSectionId) => {
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => {
    const locationState = getLocationState(location.state)

    if (locationState.homeSectionId !== activeSectionId) {
      void navigate(
        {
          hash: location.hash,
          pathname: location.pathname,
          search: location.search,
        },
        {
          replace: true,
          state: { ...locationState, homeSectionId: activeSectionId },
        },
      )
    }
  }, [
    activeSectionId,
    location.hash,
    location.pathname,
    location.search,
    location.state,
    navigate,
  ])
}
