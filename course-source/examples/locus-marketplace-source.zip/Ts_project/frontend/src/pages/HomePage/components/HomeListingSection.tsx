import { ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'

import { ListingCard } from '@/pages/HomePage/components/ListingCard'
import type { ListingSummary } from '@/objects/listings'

type HomeListingSectionProps = {
  isActive: boolean
  id: string
  listings: ListingSummary[]
  marketMode: 'sale' | 'rent' | 'sold' | 'leased'
  onToggleSave: (listingId: string) => void
  savedIds: string[]
  setSectionRef: (sectionId: string) => (element: HTMLElement | null) => void
  title: string
}

export const HomeListingSection = ({
  isActive,
  id,
  listings,
  marketMode,
  onToggleSave,
  savedIds,
  setSectionRef,
  title,
}: HomeListingSectionProps) => (
  <section
    className="relative flex h-full min-h-full snap-start snap-always items-center overflow-hidden px-4 py-10 sm:px-6 lg:px-8"
    id={id}
    ref={setSectionRef(id)}
  >
    <div
      className={[
        'relative z-10 mx-auto w-full max-w-6xl transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]',
        isActive ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-4 scale-[0.992] opacity-65',
      ].join(' ')}
    >
      <div className={`flex items-end justify-between gap-4 ${listings.length > 0 ? 'mb-7' : ''}`}>
        <h2
          className="relative text-4xl font-semibold tracking-tight text-slate-950 sm:text-5xl"
        >
          {title}
        </h2>
        <Link
          className="mb-1 inline-flex items-center gap-2 rounded-full border border-white/70 bg-white/62 px-4 py-2 text-sm font-semibold text-slate-500 shadow-[0_16px_40px_rgba(15,23,42,0.07)] backdrop-blur-2xl transition hover:-translate-y-0.5 hover:text-slate-950"
          to={`/listings?marketMode=${marketMode}`}
        >
          View all
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      {listings.length > 0 ? (
        <div className="grid auto-cols-[minmax(18rem,1fr)] grid-flow-col gap-5 overflow-x-auto pb-4 [-ms-overflow-style:none] [scrollbar-width:none] md:auto-cols-auto md:grid-flow-row md:grid-cols-3 md:overflow-visible md:pb-0 [&::-webkit-scrollbar]:hidden">
          {listings.map((listing) => (
            <ListingCard
              isSaved={savedIds.includes(listing.id)}
              key={listing.id}
              listing={listing}
              onToggleSave={onToggleSave}
            />
          ))}
        </div>
      ) : null}
    </div>
  </section>
)
