import {
  homeSectionItems,
  type HomePageLocationState,
  type HomeSectionId,
} from '@/pages/HomePage/objects/home-page-sections'

export const isHomeSectionId = (value: unknown): value is HomeSectionId =>
  homeSectionItems.some((item) => item.id === value)

export const getLocationState = (state: unknown): HomePageLocationState =>
  typeof state === 'object' && state !== null
    ? (state as HomePageLocationState)
    : {}

export const getInitialSectionId = (state: unknown): HomeSectionId => {
  const sectionId = getLocationState(state).homeSectionId
  return isHomeSectionId(sectionId) ? sectionId : homeSectionItems[0].id
}

export const getSectionScrollTop = (
  root: HTMLElement,
  section: HTMLElement,
) =>
  root.scrollTop +
  section.getBoundingClientRect().top -
  root.getBoundingClientRect().top

export const alignSectionWithContainer = (
  root: HTMLElement,
  section: HTMLElement,
) => {
  const previousScrollBehavior = root.style.scrollBehavior

  root.style.scrollBehavior = 'auto'
  root.scrollTop = getSectionScrollTop(root, section)
  root.style.scrollBehavior = previousScrollBehavior
}

const visibleRatio = (root: HTMLElement, section: HTMLElement) => {
  const sectionRect = section.getBoundingClientRect()
  const rootRect = root.getBoundingClientRect()
  const visibleHeight = Math.max(
    0,
    Math.min(sectionRect.bottom, rootRect.bottom) -
      Math.max(sectionRect.top, rootRect.top),
  )

  return visibleHeight / Math.max(sectionRect.height, 1)
}

export const sectionVisibilityRatios = (
  root: HTMLElement,
  sections: HTMLElement[],
) =>
  Object.fromEntries(
    sections.map((section) => [section.id, visibleRatio(root, section)]),
  )

export const mostVisibleSection = (
  ratios: Record<string, number>,
): HomeSectionId =>
  homeSectionItems
    .map((item) => ({ id: item.id, ratio: ratios[item.id] ?? 0 }))
    .sort((left, right) => right.ratio - left.ratio)[0]?.id ??
  homeSectionItems[0].id
