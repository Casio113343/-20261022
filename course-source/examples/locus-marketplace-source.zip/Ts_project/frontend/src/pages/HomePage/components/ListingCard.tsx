import { Heart } from 'lucide-react'
import { Link } from 'react-router-dom'

import { AgentAttribution } from '@/pages/shared/marketplace/components/AgentAttribution'
import { listingDetailState } from '@/pages/ListingDetailPage/objects/listing-detail-navigation'
import { PropertyFacts } from '@/pages/shared/marketplace/components/PropertyFacts'
import type { ListingSummary } from '@/objects/listings'
import {
  formatPropertyLabel,
  formatPrice,
} from '@/pages/shared/marketplace/functions/marketplace-format'

type ListingCardProps = {
  listing: ListingSummary
  isSaved: boolean
  onToggleSave: (listingId: string) => void
}

export const ListingCard = ({ listing, isSaved, onToggleSave }: ListingCardProps) => (
  <article className="overflow-hidden rounded-[28px] bg-white/66 shadow-[0_24px_72px_rgba(15,23,42,0.08)] ring-1 ring-white/70 backdrop-blur-2xl transition duration-300 hover:-translate-y-1 hover:bg-white/78 hover:shadow-[0_30px_90px_rgba(15,23,42,0.12)]">
    <div className="relative">
      <Link state={listingDetailState('recommendations')} to={`/listings/${listing.id}`}>
        <img
          alt={listing.title}
          className="h-56 w-full object-cover sm:h-60 lg:h-[min(16rem,31vh)]"
          src={listing.primaryImageUrl ?? '/fallbacks/property-location.jpg'}
        />
      </Link>
      <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-slate-950/55 to-transparent" />
      <div className="absolute left-5 top-5 inline-flex rounded-full bg-white/82 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-700 shadow-sm backdrop-blur">
        {formatPropertyLabel(listing.propertyType, listing.houseSubtype ?? listing.apartmentSubtype)}
      </div>
      <button
        className={[
          'absolute right-5 top-5 inline-flex h-11 w-11 items-center justify-center rounded-full border bg-white/88 shadow-sm backdrop-blur transition',
          isSaved
            ? 'border-rose-200 text-rose-600'
            : 'border-white/50 text-slate-700 hover:text-slate-950',
        ].join(' ')}
        onClick={() => onToggleSave(listing.id)}
        type="button"
      >
        <Heart className={`h-5 w-5 ${isSaved ? 'fill-current' : ''}`} />
      </button>
      <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4 text-white">
        <div>
          <p className="text-3xl font-semibold tracking-tight">
            {formatPrice(listing.price, listing.transactionType)}
          </p>
        </div>
      </div>
    </div>

    <div className="space-y-4 px-5 py-5 sm:px-6">
      <div className="space-y-1">
        <p className="text-base font-medium leading-7 text-slate-950">
          {`${listing.addressLine},`}
        </p>
        <p className="text-base font-medium leading-7 text-slate-950">
          {[listing.suburb, listing.state, listing.postcode].filter(Boolean).join(', ')}
        </p>
      </div>

      <PropertyFacts
        propertyType={listing.propertyType}
        bathrooms={listing.bathrooms}
        bedrooms={listing.bedrooms}
        buildingSize={listing.buildingSize}
        carSpaces={listing.carSpaces}
        landSize={listing.landSize}
        size="compact"
      />

      <div className="flex items-center justify-between gap-4">
        <AgentAttribution agent={listing.agent} />
        <Link
          className="inline-flex shrink-0 items-center rounded-full border border-slate-200 bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-950 transition hover:border-slate-300 hover:bg-slate-200"
          state={listingDetailState('recommendations')}
          to={`/listings/${listing.id}`}
        >
          View
        </Link>
      </div>
    </div>
  </article>
)
