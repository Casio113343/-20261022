import { useEffect, useLayoutEffect, type RefObject } from 'react'

import {
  alignSectionWithContainer,
} from '@/pages/HomePage/functions/home-section-navigation'
import type { HomeSectionId } from '@/pages/HomePage/objects/home-page-sections'

type UseInitialSectionRestoreArgs = {
  initialSectionId: HomeSectionId
  isLoading: boolean
  isRestoringSectionRef: RefObject<boolean>
  scrollContainerRef: RefObject<HTMLDivElement | null>
  sectionRefs: RefObject<Record<string, HTMLElement | null>>
}

export const useInitialSectionRestore = ({
  initialSectionId,
  isLoading,
  isRestoringSectionRef,
  scrollContainerRef,
  sectionRefs,
}: UseInitialSectionRestoreArgs) => {
  useLayoutEffect(() => {
    const root = scrollContainerRef.current
    const section = sectionRefs.current[initialSectionId]

    if (root && section) {
      alignSectionWithContainer(root, section)
    }
  }, [initialSectionId, scrollContainerRef, sectionRefs])

  useEffect(() => {
    const root = scrollContainerRef.current
    const section = sectionRefs.current[initialSectionId]

    if (
      !isRestoringSectionRef.current ||
      isLoading ||
      !root ||
      !section
    ) {
      return undefined
    }

    alignSectionWithContainer(root, section)
    const restoration = new AbortController()
    const firstFrame = window.requestAnimationFrame(() => {
      if (restoration.signal.aborted) return

      alignSectionWithContainer(root, section)
      window.requestAnimationFrame(() => {
        if (restoration.signal.aborted) return

        alignSectionWithContainer(root, section)
        isRestoringSectionRef.current = false
      })
    })

    return () => {
      restoration.abort()
      window.cancelAnimationFrame(firstFrame)
    }
  }, [
    initialSectionId,
    isLoading,
    isRestoringSectionRef,
    scrollContainerRef,
    sectionRefs,
  ])
}
