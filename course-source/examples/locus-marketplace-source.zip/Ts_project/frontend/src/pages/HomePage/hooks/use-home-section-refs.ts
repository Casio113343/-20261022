import { useCallback, useRef } from 'react'

export const useHomeSectionRefs = () => {
  const scrollContainerRef = useRef<HTMLDivElement | null>(null)
  const sectionRefs = useRef<Record<string, HTMLElement | null>>({})

  const setSectionRef = useCallback(
    (sectionId: string) => (element: HTMLElement | null) => {
      sectionRefs.current[sectionId] = element
    },
    [],
  )

  return {
    scrollContainerRef,
    sectionRefs,
    setSectionRef,
  }
}
