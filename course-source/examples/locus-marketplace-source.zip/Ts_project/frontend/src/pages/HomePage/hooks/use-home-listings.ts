import { useEffect, useState } from 'react'

import type { ListingSummary } from '@/objects/listings'
import { api } from '@/apis'
import type { ResultError } from '@/utils/result'

export type HomeListingsSections = {
  sale: ListingSummary[]
  rent: ListingSummary[]
  sold: ListingSummary[]
  leased: ListingSummary[]
}

type HomeListingsState =
  | { status: 'loading' }
  | { status: 'ready'; sections: HomeListingsSections }
  | { status: 'error'; message: string; sections: HomeListingsSections }

export const emptyHomeSections: HomeListingsSections = {
  sale: [],
  rent: [],
  sold: [],
  leased: [],
}

const humanizeListingError = (error: ResultError) =>
  error.kind === 'network'
    ? 'Listings cannot be loaded because the backend is unreachable.'
    : error.message

export const useHomeListings = () => {
  const [state, setState] = useState<HomeListingsState>({ status: 'loading' })

  useEffect(() => {
    let cancelled = false
    const sharedSearchFields = {
      propertyTypes: [],
      houseSubtypes: [],
      apartmentSubtypes: [],
      limit: 3,
      sort: 'newest' as const,
    }

    Promise.all([
      api.searchListings({ ...sharedSearchFields, transactionType: 'sale', listingStatuses: ['active'] }),
      api.searchListings({ ...sharedSearchFields, transactionType: 'rent', listingStatuses: ['active'] }),
      api.searchListings({ ...sharedSearchFields, transactionType: 'sale', listingStatuses: ['sold'] }),
      api.searchListings({ ...sharedSearchFields, transactionType: 'rent', listingStatuses: ['leased'] }),
    ])
      .then(([saleResponse, rentResponse, soldResponse, leasedResponse]) => {
        if (cancelled) {
          return
        }

        if (!saleResponse.ok || !rentResponse.ok || !soldResponse.ok || !leasedResponse.ok) {
          const failure =
            [saleResponse, rentResponse, soldResponse, leasedResponse].find((response) => !response.ok)?.error

          setState({
            status: 'error',
            message: failure ? humanizeListingError(failure) : 'Listings could not be loaded.',
            sections: emptyHomeSections,
          })
          return
        }

        setState({
          status: 'ready',
          sections: {
            sale: saleResponse.data.listings,
            rent: rentResponse.data.listings,
            sold: soldResponse.data.listings,
            leased: leasedResponse.data.listings,
          },
        })
      })

    return () => {
      cancelled = true
    }
  }, [])

  return {
    errorMessage: state.status === 'error' ? state.message : undefined,
    isLoading: state.status === 'loading',
    sections: state.status === 'loading' ? emptyHomeSections : state.sections,
  }
}
