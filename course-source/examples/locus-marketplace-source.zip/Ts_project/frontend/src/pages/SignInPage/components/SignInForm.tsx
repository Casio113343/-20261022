import { Link } from 'react-router-dom'

type SignInFormProps = {
  email: string
  error?: string
  onEmailChange: (value: string) => void
  onPasswordChange: (value: string) => void
  onSubmit: () => void
  password: string
  submitting: boolean
}

const textInputClassName =
  'h-13 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-slate-400'

export const SignInForm = ({
  email,
  error,
  onEmailChange,
  onPasswordChange,
  onSubmit,
  password,
  submitting,
}: SignInFormProps) => (
  <div className="w-full max-w-2xl rounded-[36px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.82),rgba(248,250,252,0.72))] p-8 shadow-[0_24px_70px_rgba(15,23,42,0.10)] backdrop-blur-3xl sm:p-10">
    <div className="mb-8 text-center">
      <h1 className="text-4xl font-semibold tracking-tight text-slate-950">Welcome back</h1>
    </div>

    <div className="space-y-5">
      <div>
        <label className="mb-2 block text-sm font-semibold text-slate-700">Email</label>
        <input
          className={textInputClassName}
          onChange={(event) => onEmailChange(event.target.value)}
          type="email"
          value={email}
        />
      </div>
      <div>
        <label className="mb-2 block text-sm font-semibold text-slate-700">Password</label>
        <input
          className={textInputClassName}
          onChange={(event) => onPasswordChange(event.target.value)}
          type="password"
          value={password}
        />
      </div>

      {error ? <p className="pb-2 text-sm font-medium text-rose-600">{error}</p> : null}

      <button
        className="inline-flex w-full items-center justify-center rounded-2xl border border-slate-200 bg-slate-100 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:border-slate-300 hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-60"
        disabled={submitting}
        onClick={onSubmit}
        type="button"
      >
        {submitting ? 'Signing in...' : 'Sign in'}
      </button>

      <p className="text-center text-sm text-slate-500">
        Need an account?{' '}
        <Link className="font-semibold text-slate-950" to="/sign-up">
          Create one
        </Link>
      </p>
    </div>
  </div>
)
