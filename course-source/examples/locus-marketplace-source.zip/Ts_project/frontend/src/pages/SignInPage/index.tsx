import { SignInForm } from '@/pages/SignInPage/components/SignInForm'
import { useSignInPage } from '@/pages/SignInPage/hooks/use-sign-in-page'
import { AuthVideoBackground } from '@/pages/shared/auth/AuthVideoBackground'

export default function SignInPage() {
  const page = useSignInPage()

  return (
    <div className="relative isolate min-h-[calc(100svh-73px)] overflow-hidden">
      <AuthVideoBackground />
      <div className="relative z-10 mx-auto flex max-w-6xl justify-center px-4 py-16 sm:px-6 lg:px-8">
        <SignInForm
          email={page.email}
          error={page.error}
          onEmailChange={page.setEmail}
          onPasswordChange={page.setPassword}
          onSubmit={page.handleSubmit}
          password={page.password}
          submitting={page.submitting}
        />
      </div>
    </div>
  )
}
