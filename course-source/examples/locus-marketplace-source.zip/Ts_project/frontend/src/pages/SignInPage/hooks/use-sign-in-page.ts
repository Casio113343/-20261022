import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

import { api } from '@/apis'
import { setSession } from '@/pages/shared/auth/session-store'

export const useSignInPage = () => {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string>()
  const [submitting, setSubmitting] = useState(false)

  const handleSubmit = async () => {
    setSubmitting(true)
    setError(undefined)

    const response = await api.signIn({ email, password })

    if (!response.ok) {
      setError(response.error.message)
      setSubmitting(false)
      return
    }

    setSession(response.data.user)
    navigate(response.data.user.role === 'agent_admin' ? '/agent/listings' : '/')
    setSubmitting(false)
  }

  return {
    email,
    error,
    handleSubmit,
    password,
    setEmail,
    setPassword,
    submitting,
  }
}
