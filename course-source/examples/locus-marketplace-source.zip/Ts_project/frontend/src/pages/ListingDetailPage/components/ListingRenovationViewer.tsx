import { ArrowLeft, ArrowRight, LoaderCircle, Sparkles, X } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'

import type { ListingDetail } from '@/objects/listings'
import { cycleImageIndex } from '@/pages/ListingDetailPage/functions/listing-detail'
import type { RenovationImagePair } from '@/pages/ListingDetailPage/functions/renovation-gallery'

type ListingRenovationViewerProps = {
  activeIndex: number
  listing: ListingDetail
  onClose: () => void
  onIndexChange: (index: number) => void
  pairs: RenovationImagePair[]
}

const preloadImage = (src: string) =>
  new Promise<void>((resolve) => {
    const image = new Image()
    image.onload = () => resolve()
    image.onerror = () => resolve()
    image.src = src
  })

const preloadPair = (pair: RenovationImagePair) =>
  Promise.all([
    preloadImage(pair.original.url),
    ...(pair.renovated.url ? [preloadImage(pair.renovated.url)] : []),
  ]).then(() => undefined)

const ComparisonImagePanel = ({
  alt,
  label,
  src,
}: {
  alt: string
  label: string
  src: string
}) => (
  <figure className="flex min-h-0 flex-col items-center justify-center gap-4 overflow-hidden">
    <figcaption className="rounded-full border border-white/14 bg-zinc-950/58 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-zinc-100 shadow-[0_12px_32px_rgba(0,0,0,0.18)] backdrop-blur-xl">
      {label}
    </figcaption>
    <ImageWithFallback alt={alt} src={src} />
  </figure>
)

const RenovationStatePanel = ({ pair }: { pair: RenovationImagePair }) => {
  if (pair.status === 'completed' && pair.renovated.url) {
    return (
      <ComparisonImagePanel
        alt={pair.renovated.altText}
        label="Renovated"
        src={pair.renovated.url}
      />
    )
  }

  const failed = pair.status === 'failed'

  return (
    <figure className="flex min-h-0 flex-col items-center justify-center gap-4 overflow-hidden">
      <figcaption className="rounded-full border border-white/14 bg-zinc-950/58 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-zinc-100 shadow-[0_12px_32px_rgba(0,0,0,0.18)] backdrop-blur-xl">
        Renovated
      </figcaption>
      <div className="flex h-full w-full items-center justify-center bg-zinc-900 px-8 text-center">
        <div className="max-w-sm">
          {failed ? (
            <Sparkles className="mx-auto h-7 w-7 text-rose-200" />
          ) : (
            <LoaderCircle className="mx-auto h-7 w-7 animate-spin text-amber-200" />
          )}
          <p className="mt-4 text-sm font-semibold text-zinc-100">
            {failed
              ? 'This renovation concept could not be generated.'
              : 'Preparing this renovation concept...'}
          </p>
          <p className="mt-2 text-xs leading-5 text-zinc-400">
            {failed
              ? 'The listing agent can retry by turning Renovate with AI off and on again.'
              : 'Gemini is creating an edited version of this photo. This page updates automatically.'}
          </p>
        </div>
      </div>
    </figure>
  )
}

const ImageWithFallback = ({
  alt,
  src,
}: {
  alt: string
  src: string
}) => {
  const [failedSrc, setFailedSrc] = useState<string>()
  const hasLoadError = failedSrc === src

  return hasLoadError ? (
    <div className="flex h-full w-full items-center justify-center bg-zinc-900 px-8 text-center">
      <div className="max-w-sm">
        <Sparkles className="mx-auto h-6 w-6 text-amber-200" />
        <p className="mt-3 text-sm font-semibold text-zinc-200">
          Renovation image is not available in MinIO yet.
        </p>
        <p className="mt-2 text-xs leading-5 text-zinc-500">
          Upload the concept image to the configured object key to enable this comparison.
        </p>
      </div>
    </div>
  ) : (
      <img
        alt={alt}
        className="max-h-full max-w-full object-contain"
        onError={() => setFailedSrc(src)}
        src={src}
      />
  )
}

export const ListingRenovationViewer = ({
  activeIndex,
  listing,
  onClose,
  onIndexChange,
  pairs,
}: ListingRenovationViewerProps) => {
  const activePair = pairs[activeIndex] ?? pairs[0]
  const canNavigate = pairs.length > 1
  const navigationRequestRef = useRef(0)
  const move = useCallback((direction: -1 | 1) => {
    if (!canNavigate) {
      return
    }

    const targetIndex = cycleImageIndex(activeIndex, direction, pairs.length)
    const targetPair = pairs[targetIndex]

    if (!targetPair) {
      return
    }

    const requestId = navigationRequestRef.current + 1
    navigationRequestRef.current = requestId

    void preloadPair(targetPair).then(() => {
      if (navigationRequestRef.current === requestId) {
        onIndexChange(targetIndex)
      }
    })
  }, [activeIndex, canNavigate, onIndexChange, pairs])

  useEffect(() => {
    pairs.forEach((pair) => {
      void preloadPair(pair)
    })
  }, [pairs])

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose()
      }

      if (event.key === 'ArrowLeft') {
        move(-1)
      }

      if (event.key === 'ArrowRight') {
        move(1)
      }
    }

    window.addEventListener('keydown', handleKeyDown)

    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [move, onClose])

  return (
    <div className="fixed inset-x-0 bottom-0 top-[69px] z-50 overflow-hidden bg-black text-white">
      {activePair ? (
        <div className="relative grid h-full min-h-0 grid-rows-2 gap-5 px-12 py-7 sm:px-16 sm:py-9 lg:grid-cols-2 lg:grid-rows-1 lg:gap-10 lg:px-20 lg:py-10 xl:gap-12 xl:px-24">
          <button
            aria-label="Close renovation viewer"
            className="absolute right-5 top-5 z-20 inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.07] text-zinc-200 transition hover:bg-white/[0.14]"
            onClick={onClose}
            type="button"
          >
            <X className="h-5 w-5" />
          </button>

            <ComparisonImagePanel
              alt={activePair.original.altText ?? `Original photo for ${listing.addressLine}`}
              label="Original"
              src={activePair.original.url}
            />
            <RenovationStatePanel pair={activePair} />

            <p className="pointer-events-none absolute bottom-3 left-1/2 z-20 -translate-x-1/2 rounded-full border border-white/10 bg-black/55 px-4 py-1.5 text-center text-[11px] leading-4 text-zinc-300 backdrop-blur">
              AI-generated renovation concept only. Features, dimensions and build feasibility may differ.
            </p>

          {canNavigate ? (
            <>
              <button
                aria-label="View previous renovation"
                className="absolute left-5 top-1/2 z-10 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/58 text-slate-800 shadow-sm backdrop-blur transition hover:bg-white/80"
                onClick={() => move(-1)}
                type="button"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <button
                aria-label="View next renovation"
                className="absolute right-5 top-1/2 z-10 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/58 text-slate-800 shadow-sm backdrop-blur transition hover:bg-white/80"
                onClick={() => move(1)}
                type="button"
              >
                <ArrowRight className="h-5 w-5" />
              </button>
            </>
          ) : null}
        </div>
      ) : (
        <div className="flex h-full items-center justify-center px-6 text-center">
          <div className="max-w-md">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-white/10 bg-white/[0.06] text-amber-200">
              <Sparkles className="h-6 w-6" />
            </div>
            <h2 className="mt-5 text-2xl font-semibold text-white">
              Renovation preview is not ready for this listing yet.
            </h2>
            <p className="mt-3 text-sm leading-6 text-zinc-400">
              This listing does not have an eligible renovation image yet.
            </p>
            <button
              className="mt-6 inline-flex h-11 items-center rounded-full border border-white/10 bg-white px-5 text-sm font-semibold text-zinc-950 transition hover:bg-zinc-200"
              onClick={onClose}
              type="button"
            >
              Back to listing
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
