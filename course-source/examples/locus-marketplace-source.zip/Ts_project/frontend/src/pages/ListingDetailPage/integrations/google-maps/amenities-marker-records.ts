import type {
  AdvancedMarkerElementInstance,
  GoogleMapsApi,
  MapInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'
import { getGoogleMapsEnv } from '@/pages/ListingDetailPage/functions/google-maps-env'
import { ensureMarkerLibrary, loadGoogleMaps } from '@/pages/ListingDetailPage/integrations/google-maps/google-maps-loader'
import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'
import { failure, failureFromUnknown, success, type Result } from '@/utils/result'

import {
  createMarkerView,
  type MarkerRecord,
  type MarkerView,
} from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'

export type AmenitySubcategory = {
  id: string
  emoji: string
}

type BuildAmenitiesMarkerRecordsArgs = {
  activeMarkerRef: { current: AdvancedMarkerElementInstance | undefined }
  applyGlow: (marker: AdvancedMarkerElementInstance) => void
  map: MapInstance
  markerViewsRef: { current: WeakMap<AdvancedMarkerElementInstance, MarkerView> }
  nextPlaces: NearbyAmenity[]
  onCloseMarker: (marker: AdvancedMarkerElementInstance) => void
  onOpenMarker: (marker: AdvancedMarkerElementInstance, placeId: string) => void
  onRemoveGlow: (marker: AdvancedMarkerElementInstance) => void
  setSelectedPlaceId: (value: string | undefined) => void
  subcategory: AmenitySubcategory
}

export const buildAmenitiesMarkerRecords = async ({
  activeMarkerRef,
  applyGlow,
  map,
  markerViewsRef,
  nextPlaces,
  onCloseMarker,
  onOpenMarker,
  onRemoveGlow,
  setSelectedPlaceId,
  subcategory,
}: BuildAmenitiesMarkerRecordsArgs): Promise<Result<MarkerRecord[]>> => {
  const env = getGoogleMapsEnv()

  if (!env) {
    return failure('library', 'Google Maps marker library is unavailable')
  }

  let mapsApi: GoogleMapsApi

  try {
    mapsApi = await loadGoogleMaps(env)
  } catch (error: unknown) {
    return failureFromUnknown(error, 'library', 'Unable to load amenities')
  }

  const markerLibrary = await ensureMarkerLibrary(mapsApi)

  if (!markerLibrary?.AdvancedMarkerElement) {
    return failure('library', 'Google Maps marker library is unavailable')
  }

  return nextPlaces.reduce<Result<MarkerRecord[]>>((result, place) => {
    if (!result.ok) {
      return result
    }

    const viewResult = createMarkerView(place, subcategory.emoji)

    if (!viewResult.ok) {
      return viewResult
    }

    const view = viewResult.data
    const marker = new markerLibrary.AdvancedMarkerElement({
      position: place.location,
      map,
      content: view.container,
      title: place.name,
      zIndex: 10,
    })
    markerViewsRef.current.set(marker, view)

    view.closeButton.addEventListener('click', (event) => {
      event.stopPropagation()
      if (activeMarkerRef.current === marker) {
        onCloseMarker(marker)
        activeMarkerRef.current = undefined
        setSelectedPlaceId(undefined)
      }
    })

    view.container.addEventListener('mouseenter', () => {
      applyGlow(marker)
      view.label.classList.add('amenity-marker-label-visible')
    })

    view.container.addEventListener('mouseleave', () => {
      if (activeMarkerRef.current !== marker) {
        onRemoveGlow(marker)
        view.label.classList.remove('amenity-marker-label-visible')
      }
    })

    view.container.addEventListener('click', (event) => {
      event.stopPropagation()
      onOpenMarker(marker, place.id)
    })

    return success([
      ...result.data,
      { marker, placeId: place.id, view },
    ])
  }, success([]))
}
