import { useCallback, useEffect, useState } from 'react'
import { useLocation, useParams } from 'react-router-dom'

import type { ListingDetail } from '@/objects/listings'
import type {
  ListingEditorPageState,
  ListingPreviewState,
} from '@/pages/AgentListingEditorPage/objects/listing-editor-types'
import type { ListingDetailSectionId } from '@/pages/ListingDetailPage/functions/listing-detail'
import { useListingMapLocation } from '@/pages/ListingDetailPage/hooks/use-listing-map-location'
import { useMessagingSession } from '@/pages/shared/hooks/use-messaging-session'
import { useSavedListings } from '@/pages/shared/hooks/use-saved-listings'
import { api } from '@/apis'
import { useSession } from '@/pages/shared/auth/session-store'
import { recordListingAnalyticsEvent, recordListingView } from '@/pages/shared/analytics/record-listing-analytics'
import { listingViewSourceFromState } from '@/pages/ListingDetailPage/objects/listing-detail-navigation'

type RemoteListingState =
  | { status: 'idle' | 'loading' }
  | { status: 'ready'; listing: ListingDetail }
  | { status: 'error'; message: string }

export const useListingDetailPage = () => {
  const location = useLocation()
  const { listingId } = useParams()
  const isPreviewMode = location.pathname === '/agent/listings/preview'
  const previewState = location.state as ListingPreviewState | undefined
  const listingViewSource = isPreviewMode
    ? 'agent_dashboard_preview'
    : listingViewSourceFromState(location.state)
  const previewListing = isPreviewMode ? previewState?.previewListing : undefined
  const previewEditorState: ListingEditorPageState | undefined = previewState
    ? { draft: previewState.editorDraft }
    : undefined
  const [remoteState, setRemoteState] = useState<RemoteListingState>(
    isPreviewMode ? { status: 'idle' } : { status: 'loading' },
  )
  const [activeImageIndex, setActiveImageIndex] = useState(0)
  const [activeSection, setActiveSection] = useState<ListingDetailSectionId>('overview')
  const isAuthenticated = useSession((state) => state.isAuthenticated)
  const user = useSession((state) => state.user)
  const messaging = useMessagingSession(isAuthenticated)
  const { savedIds, toggleSaved } = useSavedListings(!isPreviewMode)
  const listing =
    isPreviewMode
      ? previewListing
      : remoteState.status === 'ready'
        ? remoteState.listing
        : undefined
  const viewedListingId = listing?.id
  const error =
    isPreviewMode
      ? (previewListing ? undefined : 'Preview unavailable. Return to the editor and try again.')
      : remoteState.status === 'error'
        ? remoteState.message
        : undefined
  const isLoading = !isPreviewMode && remoteState.status !== 'ready' && remoteState.status !== 'error'
  const locationState = useListingMapLocation(
    listing,
    activeSection === 'amenities' || activeSection === 'street-view',
  )
  const listingStateKey = `${isPreviewMode ? 'preview' : 'live'}:${listing?.id ?? listingId ?? 'missing'}`
  const handleTypingChange = useCallback((conversationId: string, isTyping: boolean) => {
    messaging.sendSocketEvent({
      type: isTyping ? 'typing_started' : 'typing_stopped',
      conversationId,
    })
  }, [messaging])

  useEffect(() => {
    if (isPreviewMode || !listingId) {
      return
    }

    let cancelled = false

    queueMicrotask(() => {
      if (!cancelled) {
        setRemoteState({ status: 'loading' })
      }
    })

    api
      .getListing(listingId)
      .then((response) => {
        if (cancelled) {
          return
        }

        if (!response.ok) {
          setRemoteState({ status: 'error', message: response.error.message })
          return
        }

        setRemoteState({ status: 'ready', listing: response.data })
      })

    return () => {
      cancelled = true
    }
  }, [isPreviewMode, listingId])

  useEffect(() => {
    queueMicrotask(() => {
      setActiveImageIndex(0)
      setActiveSection('overview')
    })
  }, [listingStateKey])

  useEffect(() => {
    if (!viewedListingId || viewedListingId === 'preview-listing') {
      return
    }

    recordListingView(viewedListingId, listingViewSource)
  }, [listingViewSource, viewedListingId])

  useEffect(() => {
    if (!listing || activeSection !== 'messages' || !isAuthenticated || !user) {
      return
    }

    const existingConversation = messaging.conversations.find(
      (conversation) => conversation.listing.id === listing.id,
    )

    if (existingConversation) {
      messaging.selectConversation(existingConversation.id)
      return
    }

    if (user.role === 'buyer_renter') {
      void messaging.startConversation(listing.id).then((conversation) => {
        if (conversation) {
          recordListingAnalyticsEvent(listing.id, 'message_start', { action: 'conversation_started' })
        }
      })
    }
  }, [activeSection, listing, messaging, isAuthenticated, user])

  const handleImageChange = useCallback((index: number) => {
    setActiveImageIndex(index)

    if (listing && !isPreviewMode) {
      const photoNumber = index + 1
      const photo = listing.images[index]

      recordListingAnalyticsEvent(listing.id, 'photo_open', {
        photo: {
          kind: photo?.isFloorPlan ? 'floor_plan' : 'photo',
          index: photoNumber,
        },
      })
    }
  }, [isPreviewMode, listing])

  return {
    activeImageIndex,
    activeSection,
    error,
    handleTypingChange,
    isLoading,
    isPreviewMode,
    listing,
    locationState,
    messaging,
    previewEditorState,
    previewState,
    savedIds,
    setActiveImageIndex: handleImageChange,
    setActiveSection,
    toggleSaved,
    isAuthenticated,
    user,
  }
}
