import { useCallback } from 'react'

import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'
import type { AdvancedMarkerElementInstance, MapInstance } from '@/pages/ListingDetailPage/objects/google-maps-types'
import {
  type MarkerRecord,
  type MarkerView,
} from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'
import { buildAmenitiesMarkerRecords, type AmenitySubcategory } from '@/pages/ListingDetailPage/integrations/google-maps/amenities-marker-records'
import {
  useAmenitiesMarkerRegistryActions,
} from '@/pages/ListingDetailPage/hooks/use-amenities-marker-registry-actions'
import {
  useActiveSubcategoryMarkerVisibility,
  useBuildCurrentAmenityMarkers,
  useHideAmenitiesMarkersOnUnmount,
  useSelectedAmenityMarkerSync,
} from '@/pages/ListingDetailPage/hooks/use-amenities-marker-registry-effects'
import { failure, type Result } from '@/utils/result'

type UseAmenitiesMarkerRegistryArgs = {
  activeSubcategory: AmenitySubcategory
  activeSubcategoryIdKey: string
  currentPlaces: NearbyAmenity[]
  hasLoadedCurrentPlaces: boolean
  isMapReady: boolean
  locationKey: string
  mapPosition?: { lat: number; lng: number }
  mapRef: { current: MapInstance | undefined }
  markerViewsRef: { current: WeakMap<AdvancedMarkerElementInstance, MarkerView> }
  onError: (message?: string) => void
  openMarker: (marker: AdvancedMarkerElementInstance, placeId: string) => void
  selectedMarkerRef: { current: AdvancedMarkerElementInstance | undefined }
  selectedPlaceId?: string
  setSelectedPlaceId: (value: string | undefined) => void
  applyGlow: (marker: AdvancedMarkerElementInstance) => void
  removeGlow: (marker: AdvancedMarkerElementInstance) => void
  removeSelected: (marker: AdvancedMarkerElementInstance) => void
  hideMarker: (marker: AdvancedMarkerElementInstance) => void
}

export const useAmenitiesMarkerRegistry = ({
  activeSubcategory,
  activeSubcategoryIdKey,
  currentPlaces,
  hasLoadedCurrentPlaces,
  isMapReady,
  locationKey,
  mapPosition,
  mapRef,
  markerViewsRef,
  onError,
  openMarker,
  selectedMarkerRef,
  selectedPlaceId,
  setSelectedPlaceId,
  applyGlow,
  removeGlow,
  removeSelected,
  hideMarker,
}: UseAmenitiesMarkerRegistryArgs) => {
  const {
    findMarkerByPlaceId,
    hideAllMarkers,
    markersBySubcategoryRef,
    showActiveSubcategoryMarkers,
    showOnlyPlaceMarker,
  } = useAmenitiesMarkerRegistryActions({
    activeSubcategoryIdKey,
    hideMarker,
    mapRef,
    openMarker,
    selectedMarkerRef,
  })

  const buildMarkerRecords = useCallback(
    (
      subcategory: AmenitySubcategory,
      nextPlaces: NearbyAmenity[],
    ): Promise<Result<MarkerRecord[]>> => {
      const map = mapRef.current

      if (!map) {
        return Promise.resolve(failure('library', 'Google Maps marker library is unavailable'))
      }

      return buildAmenitiesMarkerRecords({
        activeMarkerRef: selectedMarkerRef,
        applyGlow,
        map,
        markerViewsRef,
        nextPlaces,
        onCloseMarker: removeSelected,
        onOpenMarker: openMarker,
        onRemoveGlow: removeGlow,
        setSelectedPlaceId,
        subcategory,
      })
    },
    [applyGlow, mapRef, markerViewsRef, openMarker, removeGlow, removeSelected, selectedMarkerRef, setSelectedPlaceId],
  )

  useActiveSubcategoryMarkerVisibility({
    activeSubcategoryIdKey,
    currentPlaces,
    hasLoadedCurrentPlaces,
    hideAllMarkers,
    isMapReady,
    mapPosition,
    mapRef,
    markersBySubcategoryRef,
  })

  useBuildCurrentAmenityMarkers({
    activeSubcategory,
    activeSubcategoryIdKey,
    buildMarkerRecords,
    currentPlaces,
    hasLoadedCurrentPlaces,
    isMapReady,
    locationKey,
    mapPosition,
    markersBySubcategoryRef,
    onError,
  })

  useSelectedAmenityMarkerSync({
    activeSubcategoryIdKey,
    currentPlaces,
    isMapReady,
    mapPosition,
    markersBySubcategoryRef,
    openMarker,
    selectedMarkerRef,
    selectedPlaceId,
  })

  useHideAmenitiesMarkersOnUnmount(hideAllMarkers)

  return {
    findMarkerByPlaceId,
    hideAllMarkers,
    showActiveSubcategoryMarkers,
    showOnlyPlaceMarker,
  }
}
