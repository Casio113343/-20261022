import { CATEGORIES, findAmenityCategory } from '@/pages/ListingDetailPage/functions/amenity-categories'
import { cn } from '@/utils/class-names'

type AmenitiesCategorySelectorProps = {
  activeCategoryId: string
  activeSubcategoryId: string
  hoveredCategoryId?: string
  onCategorySelect: (categoryId: string, subcategoryId: string) => void
  onHoverCategory: (categoryId: string | undefined) => void
  onSubcategorySelect: (subcategoryId: string) => void
}

export const AmenitiesCategorySelector = ({
  activeCategoryId,
  activeSubcategoryId,
  hoveredCategoryId,
  onCategorySelect,
  onHoverCategory,
  onSubcategorySelect,
}: AmenitiesCategorySelectorProps) => {
  const activeCategory = findAmenityCategory(activeCategoryId)
  const activeSubcategory =
    activeCategory.subcategories.find((subcategory) => subcategory.id === activeSubcategoryId) ??
    activeCategory.subcategories[0]
  const hoveredCategory = CATEGORIES.find((category) => category.id === hoveredCategoryId)

  return (
    <div className="flex min-h-[18rem] min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-slate-200/50 bg-white/92 shadow-lg">
      <div className="sticky top-0 z-10 border-b border-slate-200 bg-white/98 px-4 py-3 backdrop-blur">
        <h3 className="text-base font-medium text-slate-800">Categories</h3>
      </div>

      <div className="px-4 pt-4 pb-3">
        <div className="mb-4">
          <div className="flex space-x-1 rounded-lg bg-slate-100 p-1">
            {CATEGORIES.map((category) => (
              <button
                key={category.id}
                onClick={() => onCategorySelect(category.id, category.subcategories[0].id)}
                onMouseEnter={() => onHoverCategory(category.id)}
                onMouseLeave={() => onHoverCategory(undefined)}
                className={cn(
                  'flex-1 rounded-md py-2 transition-all',
                  activeCategory.id === category.id
                    ? 'border border-slate-300 bg-white shadow'
                    : 'hover:bg-slate-200/60',
                )}
                type="button"
              >
                <span className="text-xl">{category.emoji}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="pb-3">
          <span className="text-base font-medium text-slate-800">
            {activeCategory.label}
            {hoveredCategory && hoveredCategory.id !== activeCategory.id ? (
              <span className="text-slate-400">
                <span className="mx-1.5">·</span>
                {hoveredCategory.label}
              </span>
            ) : null}
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-4">
        <div className="space-y-1.5">
          {activeCategory.subcategories.map((subcategory) => (
            <button
              key={subcategory.id}
              onClick={() => onSubcategorySelect(subcategory.id)}
              className={cn(
                'flex w-full items-center rounded-lg px-3 py-2.5 text-left transition-colors',
                activeSubcategory.id === subcategory.id
                  ? 'border border-slate-300 bg-white text-slate-900 shadow'
                  : 'bg-slate-50 text-slate-800 hover:bg-slate-100',
              )}
              type="button"
            >
              <span className="mr-3 text-lg">{subcategory.emoji}</span>
              <span className="truncate text-sm font-medium">{subcategory.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
