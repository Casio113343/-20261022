import { useEffect, useRef } from 'react'

import type {
  MapInstance,
  PolylineInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'
import type { ListingMapPosition } from '@/pages/ListingDetailPage/functions/listing-detail'

type UseAmenityRouteLineArgs = {
  destination?: ListingMapPosition
  mapRef: { current: MapInstance | undefined }
  origin?: ListingMapPosition
  path?: ListingMapPosition[]
}

export const useAmenityRouteLine = ({
  destination,
  mapRef,
  origin,
  path,
}: UseAmenityRouteLineArgs) => {
  const routeLineRef = useRef<PolylineInstance | undefined>(undefined)

  useEffect(() => {
    routeLineRef.current?.setMap(null)
    routeLineRef.current = undefined

    const map = mapRef.current
    const maps = window.google?.maps

    if (!map || !maps?.Polyline || !origin || !destination || !path || path.length === 0) {
      return
    }

    const routeLine = new maps.Polyline({
      path,
      geodesic: true,
      strokeColor: '#2563eb',
      strokeOpacity: 0.92,
      strokeWeight: 5,
      map,
    })
    routeLineRef.current = routeLine

    if (maps.LatLngBounds && typeof map.fitBounds === 'function') {
      const bounds = new maps.LatLngBounds()
      path.forEach((position) => bounds.extend(position))
      map.fitBounds(bounds, 72)
    }

    return () => {
      routeLine.setMap(null)
    }
  }, [destination, mapRef, origin, path])
}
