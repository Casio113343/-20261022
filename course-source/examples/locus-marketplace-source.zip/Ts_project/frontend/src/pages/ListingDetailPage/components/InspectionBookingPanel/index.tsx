import { useMemo, useState } from 'react'

import type { ListingDetail } from '@/objects/listings'
import { CancelBookingDialog } from '@/pages/ListingDetailPage/components/InspectionBookingPanel/CancelBookingDialog'
import { InspectionMonthPanel } from '@/pages/ListingDetailPage/components/InspectionBookingPanel/InspectionMonthPanel'
import { InspectionSlotPanel } from '@/pages/ListingDetailPage/components/InspectionBookingPanel/InspectionSlotPanel'
import {
  buildInspectionCalendarDays,
  inspectionDayKey,
} from '@/pages/ListingDetailPage/functions/inspection-booking-calendar'
import { useInspectionBooking } from '@/pages/ListingDetailPage/hooks/use-inspection-booking'

type InspectionBookingPanelProps = {
  listing: ListingDetail
  isAuthenticated: boolean
}

export const InspectionBookingPanel = ({ listing, isAuthenticated }: InspectionBookingPanelProps) => {
  const booking = useInspectionBooking(listing.id, isAuthenticated)
  const [monthAnchor, setMonthAnchor] = useState(() => new Date())
  const [todayKey] = useState(() => inspectionDayKey(new Date()))
  const availableDates = useMemo(
    () => new Set(
      Object.entries(booking.slotsByDate)
        .filter(([, slots]) => slots.some((slot) => !slot.isBooked))
        .map(([key]) => key),
    ),
    [booking.slotsByDate],
  )
  const calendarDays = useMemo(() => buildInspectionCalendarDays(monthAnchor), [monthAnchor])
  const selectedDate = booking.selectedDateKey ? new Date(`${booking.selectedDateKey}T00:00:00`) : undefined
  const selectedDateIsToday = booking.selectedDateKey === todayKey
  const moveMonth = (delta: -1 | 1) =>
    setMonthAnchor((current) => new Date(current.getFullYear(), current.getMonth() + delta, 1))

  return (
    <section className="flex h-full min-h-[40rem] flex-col overflow-hidden rounded-xl border border-slate-200/60 bg-white shadow-lg">
      <div className="grid min-h-0 flex-1 grid-cols-1 bg-white lg:grid-cols-[minmax(0,1fr)_22rem]">
        <InspectionMonthPanel
          availableDates={availableDates}
          calendarDays={calendarDays}
          monthAnchor={monthAnchor}
          onDateSelect={booking.selectDate}
          onMonthMove={moveMonth}
          selectedDateKey={booking.selectedDateKey}
          slotsByDate={booking.slotsByDate}
          todayKey={todayKey}
        />

        <InspectionSlotPanel
          bookedSlot={booking.bookedSlot}
          isBooking={booking.isBooking}
          onBookSelectedSlot={() => void booking.bookSelectedSlot()}
          onCancelDialogOpen={() => {
            booking.setCancelError(undefined)
            booking.setIsCancelDialogOpen(true)
          }}
          onSlotSelect={booking.selectSlot}
          selectedBookedSlot={booking.selectedBookedSlot}
          selectedDate={selectedDate}
          selectedDateIsToday={selectedDateIsToday}
          selectedDateSlots={booking.selectedDateSlots}
          selectedSlot={booking.selectedSlot}
          selectedSlotId={booking.selectedSlotId}
          isAuthenticated={isAuthenticated}
        />
      </div>

      <CancelBookingDialog
        bookedSlot={booking.bookedSlot}
        cancelError={booking.cancelError}
        isBooking={booking.isBooking}
        isOpen={booking.isCancelDialogOpen}
        onCancelBooking={() => void booking.cancelBooking()}
        onCancelErrorClear={() => booking.setCancelError(undefined)}
        onOpenChange={booking.setIsCancelDialogOpen}
      />
    </section>
  )
}
