import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react'
import { useEffect, useRef } from 'react'

import type { ListingDetail } from '@/objects/listings'
import { ListingStatusPill } from '@/pages/shared/marketplace/components/ListingStatusPill'
import {
  cycleImageIndex,
  listingImageGallery,
} from '@/pages/ListingDetailPage/functions/listing-detail'

type ListingOverviewGalleryProps = {
  activeImageIndex: number
  canRenovateWithAi: boolean
  listing: ListingDetail
  onImageChange: (index: number) => void
  onOpenRenovationViewer: () => void
}

export const ListingOverviewGallery = ({
  activeImageIndex,
  canRenovateWithAi,
  listing,
  onImageChange,
  onOpenRenovationViewer,
}: ListingOverviewGalleryProps) => {
  const gallery = listingImageGallery(listing)
  const hasImages = gallery.length > 0
  const activeImage = gallery[activeImageIndex] ?? gallery[0]
  const thumbnailRefs = useRef<Array<HTMLButtonElement | undefined>>([])

  useEffect(() => {
    thumbnailRefs.current[activeImageIndex]?.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center',
    })
  }, [activeImageIndex])

  return (
    <div className="flex min-h-[24rem] min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-slate-200/60 bg-white shadow-lg">
      <div className="relative min-h-0 flex-1 overflow-hidden bg-slate-100">
        {activeImage ? (
          <img
            alt={activeImage.altText ?? listing.addressLine}
            className="h-full w-full object-cover"
            src={activeImage.url}
          />
        ) : (
          <div className="flex h-full min-h-[24rem] items-center justify-center bg-[linear-gradient(180deg,rgba(241,245,249,0.9),rgba(226,232,240,0.9))] px-6 text-center">
            <div className="space-y-2">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">
                No Photos
              </p>
              <p className="text-base text-slate-600">
                This listing does not have any uploaded images yet.
              </p>
            </div>
          </div>
        )}

        <div className="absolute right-6 top-6">
          <ListingStatusPill
            listingStatus={listing.listingStatus}
            transactionType={listing.transactionType}
          />
        </div>

        {canRenovateWithAi ? (
          <button
            className="absolute bottom-5 left-5 inline-flex h-12 items-center gap-2 rounded-full border border-white/40 bg-slate-950/75 px-5 text-sm font-semibold text-white shadow-[0_16px_44px_rgba(15,23,42,0.36)] backdrop-blur-xl transition hover:bg-slate-950/90"
            onClick={onOpenRenovationViewer}
            type="button"
          >
            <Sparkles className="h-4 w-4 text-amber-200" />
            Renovate with AI
          </button>
        ) : null}

        {gallery.length > 1 ? (
          <>
            <button
              aria-label="View previous photo"
              className="absolute left-5 top-1/2 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/58 text-slate-800 shadow-sm backdrop-blur hover:bg-white/80"
              onClick={() => onImageChange(cycleImageIndex(activeImageIndex, -1, gallery.length))}
              type="button"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              aria-label="View next photo"
              className="absolute right-5 top-1/2 inline-flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/58 text-slate-800 shadow-sm backdrop-blur hover:bg-white/80"
              onClick={() => onImageChange(cycleImageIndex(activeImageIndex, 1, gallery.length))}
              type="button"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </>
        ) : null}
      </div>

      <div className="border-t border-slate-200/70 bg-[linear-gradient(180deg,#ffffff,rgba(248,250,252,0.96))] px-4 py-3">
        {hasImages ? (
          <div className="overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            <div className="flex min-w-max gap-3">
              {gallery.map((image, index) => (
                <button
                  key={image.id}
                  ref={(element) => {
                    thumbnailRefs.current[index] = element ?? undefined
                  }}
                  className={[
                    'relative h-24 w-36 shrink-0 overflow-hidden rounded-[18px] border bg-slate-100 transition',
                    activeImageIndex === index
                      ? 'border-[3px] border-black'
                      : 'border-slate-200/80 opacity-80 hover:border-slate-300 hover:opacity-100',
                  ].join(' ')}
                  onClick={() => onImageChange(index)}
                  type="button"
                >
                  <img
                    alt={image.altText ?? listing.addressLine}
                    className="h-full w-full object-cover"
                    src={image.url}
                  />
                  <div
                    className={[
                      'pointer-events-none absolute inset-0 transition',
                      activeImageIndex === index ? '' : 'bg-slate-950/8',
                    ].join(' ')}
                  />
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="py-3 text-center text-sm text-slate-500">
            Upload images in the agent workspace to show a photo gallery here.
          </div>
        )}
      </div>
    </div>
  )
}
