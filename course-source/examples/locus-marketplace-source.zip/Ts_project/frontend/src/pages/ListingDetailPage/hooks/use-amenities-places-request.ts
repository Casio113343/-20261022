import { useEffect } from 'react'

import { amenitiesApi } from '@/apis/amenities/api/client/amenities-api'
import { mergePlaces } from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'

import type { AmenitySubcategory, PlacesResource } from '@/pages/ListingDetailPage/hooks/use-amenities-places-resource'

type UseAmenitiesPlacesRequestArgs = {
  activeSubcategory: AmenitySubcategory
  isMapReady: boolean
  mapPosition?: { lat: number; lng: number }
  onError: (message?: string) => void
  resource?: PlacesResource
  resourceKey: string
  setResourcesByKey: React.Dispatch<React.SetStateAction<Record<string, PlacesResource>>>
}

export const useAmenitiesPlacesRequest = ({
  activeSubcategory,
  isMapReady,
  mapPosition,
  onError,
  resource,
  resourceKey,
  setResourcesByKey,
}: UseAmenitiesPlacesRequestArgs) => {
  useEffect(() => {
    if (!mapPosition || !isMapReady || resource?.status !== 'loading') {
      return
    }

    let cancelled = false

    amenitiesApi.searchNearbyAmenities({
      location: mapPosition,
      includedTypes: activeSubcategory.types,
    })
      .then((result) => {
        if (cancelled) {
          return
        }

        if (!result.ok) {
          onError(result.error.message)
          setResourcesByKey((current) => ({
            ...current,
            [resourceKey]: {
              status: 'error',
              message: result.error.message,
              places: [],
            },
          }))
          return
        }

        const places = mergePlaces(
          result.data
            .places
            .filter((place) => place.types.some((type) => activeSubcategory.types.includes(type))),
        )

        setResourcesByKey((current) => ({
          ...current,
          [resourceKey]: {
            status: 'ready',
            places,
          },
        }))
      })

    return () => {
      cancelled = true
    }
  }, [activeSubcategory.types, isMapReady, mapPosition, onError, resource?.status, resourceKey, setResourcesByKey])
}
