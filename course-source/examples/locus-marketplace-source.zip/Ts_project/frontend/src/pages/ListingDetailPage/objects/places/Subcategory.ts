export type Subcategory = {
  id: string
  label: string
  emoji: string
  types: string[]
  color: string
}
