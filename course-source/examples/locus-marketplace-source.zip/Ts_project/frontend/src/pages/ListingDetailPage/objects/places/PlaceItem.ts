export type PlaceItem = {
  place_id: string
  name: string
  formatted_address?: string
  photos?: unknown[]
  types?: string[]
  location?: { lat: number; lng: number }
  raw?: unknown
  rating?: number
  userRatingCount?: number
}
