import { useMemo } from 'react'
import {
  type AmenitySubcategory,
  useAmenitiesPlacesResource,
} from '@/pages/ListingDetailPage/hooks/use-amenities-places-resource'
import { useAmenitiesPlacesRequest } from '@/pages/ListingDetailPage/hooks/use-amenities-places-request'

type UseAmenitiesPlacesArgs = {
  activeSubcategory: AmenitySubcategory
  isMapReady: boolean
  locationKey: string
  mapPosition?: { lat: number; lng: number }
  onError: (message?: string) => void
}

export const useAmenitiesPlaces = ({
  activeSubcategory,
  isMapReady,
  locationKey,
  mapPosition,
  onError,
}: UseAmenitiesPlacesArgs) => {
  const { resource, resourceKey, setResourcesByKey } = useAmenitiesPlacesResource({
    activeSubcategory,
    isMapReady,
    locationKey,
    mapPosition,
    onError,
  })

  useAmenitiesPlacesRequest({
    activeSubcategory,
    isMapReady,
    mapPosition,
    onError,
    resource,
    resourceKey,
    setResourcesByKey,
  })

  const places = useMemo(
    () =>
      resource?.status === 'ready' || resource?.status === 'error'
        ? resource.places
        : [],
    [resource],
  )

  return {
    hasLoadedPlaces: resource !== undefined && resource.status !== 'loading',
    isLoading: resource?.status === 'loading',
    places,
  }
}
