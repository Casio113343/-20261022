import { useEffect } from 'react'

import {
  type MarkerRecord,
  setMarkerMap,
} from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'
import type { AmenitySubcategory } from '@/pages/ListingDetailPage/integrations/google-maps/amenities-marker-records'
import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'
import type {
  AdvancedMarkerElementInstance,
  MapInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'
import type { Result } from '@/utils/result'

type MarkerRegistryRef = {
  current: Record<string, MarkerRecord[]>
}

type UseActiveSubcategoryMarkerVisibilityArgs = {
  activeSubcategoryIdKey: string
  currentPlaces: NearbyAmenity[]
  hasLoadedCurrentPlaces: boolean
  hideAllMarkers: () => void
  isMapReady: boolean
  mapPosition?: { lat: number; lng: number }
  mapRef: { current: MapInstance | undefined }
  markersBySubcategoryRef: MarkerRegistryRef
}

export const useActiveSubcategoryMarkerVisibility = ({
  activeSubcategoryIdKey,
  currentPlaces,
  hasLoadedCurrentPlaces,
  hideAllMarkers,
  isMapReady,
  mapPosition,
  mapRef,
  markersBySubcategoryRef,
}: UseActiveSubcategoryMarkerVisibilityArgs) => {
  useEffect(() => {
    if (!mapPosition || !isMapReady) {
      return
    }

    hideAllMarkers()

    const existingMarkers = markersBySubcategoryRef.current[activeSubcategoryIdKey]

    if (!hasLoadedCurrentPlaces) {
      return
    }

    if (existingMarkers && mapRef.current) {
      existingMarkers.forEach(({ marker }) => {
        setMarkerMap(marker, mapRef.current)
      })
    }
  }, [
    activeSubcategoryIdKey,
    currentPlaces,
    hasLoadedCurrentPlaces,
    hideAllMarkers,
    isMapReady,
    mapPosition,
    mapRef,
    markersBySubcategoryRef,
  ])
}

type UseBuildCurrentAmenityMarkersArgs = {
  activeSubcategory: AmenitySubcategory
  activeSubcategoryIdKey: string
  buildMarkerRecords: (
    subcategory: AmenitySubcategory,
    nextPlaces: NearbyAmenity[],
  ) => Promise<Result<MarkerRecord[]>>
  currentPlaces: NearbyAmenity[]
  hasLoadedCurrentPlaces: boolean
  isMapReady: boolean
  locationKey: string
  mapPosition?: { lat: number; lng: number }
  markersBySubcategoryRef: MarkerRegistryRef
  onError: (message?: string) => void
}

export const useBuildCurrentAmenityMarkers = ({
  activeSubcategory,
  activeSubcategoryIdKey,
  buildMarkerRecords,
  currentPlaces,
  hasLoadedCurrentPlaces,
  isMapReady,
  locationKey,
  mapPosition,
  markersBySubcategoryRef,
  onError,
}: UseBuildCurrentAmenityMarkersArgs) => {
  useEffect(() => {
    if (!mapPosition || !isMapReady || !hasLoadedCurrentPlaces) {
      return
    }

    if (markersBySubcategoryRef.current[activeSubcategoryIdKey]) {
      return
    }

    const build = new AbortController()

    buildMarkerRecords(activeSubcategory, currentPlaces).then((result) => {
      if (build.signal.aborted) {
        return
      }

      if (!result.ok) {
        onError(result.error.message)
        return
      }

      markersBySubcategoryRef.current[activeSubcategoryIdKey] = result.data
    })

    return () => {
      build.abort()
    }
  }, [
    activeSubcategory,
    activeSubcategoryIdKey,
    buildMarkerRecords,
    currentPlaces,
    hasLoadedCurrentPlaces,
    isMapReady,
    locationKey,
    mapPosition,
    markersBySubcategoryRef,
    onError,
  ])
}

type UseSelectedAmenityMarkerSyncArgs = {
  activeSubcategoryIdKey: string
  currentPlaces: NearbyAmenity[]
  isMapReady: boolean
  mapPosition?: { lat: number; lng: number }
  markersBySubcategoryRef: MarkerRegistryRef
  openMarker: (marker: AdvancedMarkerElementInstance, placeId: string) => void
  selectedMarkerRef: { current: AdvancedMarkerElementInstance | undefined }
  selectedPlaceId?: string
}

export const useSelectedAmenityMarkerSync = ({
  activeSubcategoryIdKey,
  currentPlaces,
  isMapReady,
  mapPosition,
  markersBySubcategoryRef,
  openMarker,
  selectedMarkerRef,
  selectedPlaceId,
}: UseSelectedAmenityMarkerSyncArgs) => {
  useEffect(() => {
    if (!mapPosition || !isMapReady || !selectedPlaceId) {
      return
    }

    const markerRecord = markersBySubcategoryRef.current[activeSubcategoryIdKey]?.find(
      ({ placeId }) => placeId === selectedPlaceId,
    )

    if (!markerRecord || selectedMarkerRef.current === markerRecord.marker) {
      return
    }

    openMarker(markerRecord.marker, selectedPlaceId)
  }, [
    activeSubcategoryIdKey,
    currentPlaces,
    isMapReady,
    mapPosition,
    markersBySubcategoryRef,
    openMarker,
    selectedMarkerRef,
    selectedPlaceId,
  ])
}

export const useHideAmenitiesMarkersOnUnmount = (
  hideAllMarkers: () => void,
) => {
  useEffect(() => () => hideAllMarkers(), [hideAllMarkers])
}
