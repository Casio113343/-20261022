import type { ListingDetail } from '@/objects/listings'
import { AnalysisResultPanel } from '@/pages/ListingDetailPage/components/ListingFengshuiPanel/AnalysisResultPanel'
import { FloorPlanPreviewPanel } from '@/pages/ListingDetailPage/components/ListingFengshuiPanel/FloorPlanPreviewPanel'
import { FengshuiPanelHeader } from '@/pages/ListingDetailPage/components/ListingFengshuiPanel/FengshuiPanelHeader'
import { UnavailableAnalysisPanel } from '@/pages/ListingDetailPage/components/ListingFengshuiPanel/UnavailableAnalysisPanel'
import { listingFloorPlanImage } from '@/pages/ListingDetailPage/functions/listing-detail'
import { useFengshuiAnalysis } from '@/pages/ListingDetailPage/hooks/use-fengshui-analysis'

type ListingFengshuiPanelProps = {
  listing: ListingDetail
}

export const ListingFengshuiPanel = ({ listing }: ListingFengshuiPanelProps) => {
  const floorPlanImage = listingFloorPlanImage(listing)
  const analysis = useFengshuiAnalysis(listing.id, floorPlanImage !== undefined)

  return (
    <div className="flex h-full min-h-0 flex-col gap-4 xl:flex-row">
      <FloorPlanPreviewPanel
        floorPlanImage={floorPlanImage}
        listing={listing}
      />

      <aside
        aria-label="Fengshui analysis panel"
        className="flex min-h-[30rem] min-w-0 flex-col overflow-hidden rounded-xl border border-slate-200/70 bg-[linear-gradient(180deg,rgba(248,250,252,0.98),rgba(241,245,249,0.96))] shadow-lg xl:w-[34%] xl:max-w-[34%]"
      >
        {!floorPlanImage ? (
          <UnavailableAnalysisPanel />
        ) : analysis.analysisState.status === 'result' ? (
          <AnalysisResultPanel
            analysis={analysis.analysisState.analysis}
          />
        ) : (
          <AutomaticAnalysisStatePanel analysisState={analysis.analysisState} />
        )}
      </aside>
    </div>
  )
}

const AutomaticAnalysisStatePanel = ({
  analysisState,
}: {
  analysisState: ReturnType<typeof useFengshuiAnalysis>['analysisState']
}) => (
  <>
    <FengshuiPanelHeader>
      <h2 className="text-[1.35rem] font-semibold tracking-tight text-slate-950">Fengshui Analysis</h2>
    </FengshuiPanelHeader>
    <div className="flex flex-1 items-center justify-center px-8 text-center">
      <p className="text-sm leading-6 text-slate-500">
        {analysisState.status === 'error'
          ? analysisState.message
          : 'Analysing the nominated floor plan...'}
      </p>
    </div>
  </>
)
