import { useCallback, useEffect, useRef, useState } from 'react'

import type {
  AdvancedMarkerElementInstance,
  MapInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'
import { getGoogleMapsEnv } from '@/pages/ListingDetailPage/functions/google-maps-env'
import {
  AMENITIES_INITIAL_ZOOM,
  initializeAmenitiesMap,
} from '@/pages/ListingDetailPage/integrations/google-maps/amenities-map-runtime'
import { setMarkerMap } from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'

type UseAmenitiesMapInstanceArgs = {
  clearSelectedMarker: () => void
  locationKey: string
  mapPosition?: { lat: number; lng: number }
  onError: (message?: string) => void
}

export const useAmenitiesMapInstance = ({
  clearSelectedMarker,
  locationKey,
  mapPosition,
  onError,
}: UseAmenitiesMapInstanceArgs) => {
  const [isMapReady, setIsMapReady] = useState(false)
  const mapContainerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<MapInstance | undefined>(undefined)
  const listingMarkerRef = useRef<AdvancedMarkerElementInstance | undefined>(undefined)
  const hasRegisteredMapClickRef = useRef(false)
  const resetMapCamera = useCallback(() => {
    const map = mapRef.current

    if (!map || !mapPosition) {
      return
    }

    map.setCenter(mapPosition)
    map.setZoom(AMENITIES_INITIAL_ZOOM)
  }, [mapPosition])

  useEffect(() => {
    if (!mapPosition || !mapContainerRef.current) {
      return
    }

    const env = getGoogleMapsEnv()

    if (!env) {
      return
    }

    let cancelled = false
    let activeMarker: AdvancedMarkerElementInstance | undefined

    initializeAmenitiesMap({
      clearSelectedMarker,
      env,
      hasRegisteredMapClickRef,
      listingMarkerRef,
      mapContainer: mapContainerRef.current,
      mapPosition,
      mapRef,
    }).then((result) => {
      if (!result.ok) {
        if (cancelled) {
          return
        }

        setIsMapReady(false)
        onError(result.error.message)
        return
      }

      if (cancelled) {
        setMarkerMap(result.data, undefined)
        return
      }

      activeMarker = result.data
      setIsMapReady(true)
      onError(undefined)
    })

    return () => {
      cancelled = true
      if (activeMarker) {
        setMarkerMap(activeMarker, undefined)
      }
    }
  }, [clearSelectedMarker, locationKey, mapPosition, onError])

  return {
    isMapReady,
    mapContainerRef,
    mapRef,
    resetMapCamera,
  }
}
