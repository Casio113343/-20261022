import type { Subcategory } from '@/pages/ListingDetailPage/objects/places/Subcategory'

export type Category = {
  id: string
  label: string
  emoji: string
  subcategories: Subcategory[]
}
