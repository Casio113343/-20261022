import { amenitiesApi } from '@/apis/amenities/api/client/amenities-api'
import type { AmenityDetails, ListingMapPosition, NearbyAmenity, TravelSummary } from '@/objects/amenities'

export type { AmenityDetails, TravelMode, TravelSummary } from '@/objects/amenities'

export type AmenityDetailResource =
  | { status: 'idle' | 'loading' }
  | { status: 'ready'; details: AmenityDetails; routes: TravelSummary[] }
  | { status: 'error'; message: string }

export const amenityDetailsTimeoutInMs = 7000

export const fetchAmenityDetailResource = async (
  origin: ListingMapPosition,
  place: NearbyAmenity,
): Promise<AmenityDetailResource> => {
  const response = await amenitiesApi.getAmenityDetails({ origin, place })

  return response.ok
    ? {
        status: 'ready',
        details: response.data.details,
        routes: response.data.routes,
      }
    : { status: 'error', message: response.error.message }
}
