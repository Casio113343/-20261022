export type LatLngLiteral = {
  lat: number
  lng: number
}

export type GeocoderResult = {
  geometry?: {
    location?: {
      lat: () => number
      lng: () => number
    }
  }
}

export type GeocoderInstance = {
  geocode: (
    request: { address: string },
    callback: (results: GeocoderResult[] | undefined, status: string) => void,
  ) => void
}

export type GeocodingLibrary = {
  Geocoder: new () => GeocoderInstance
}

export type MapInstance = {
  panTo: (position: LatLngLiteral) => void
  setCenter: (position: LatLngLiteral) => void
  setZoom: (zoom: number) => void
  addListener: (eventName: string, handler: () => void) => void
  fitBounds?: (bounds: unknown, padding?: number) => void
}

export type PolylineInstance = {
  setMap: (map: MapInstance | null) => void
}

export type AdvancedMarkerElementInstance = {
  content?: Node
  position?: LatLngLiteral
  // Google Maps uses null to detach markers from the map at the library boundary.
  map?: MapInstance | null
  zIndex?: number
  setMap?: (map: MapInstance | null) => void
}

export type MarkerLibrary = {
  AdvancedMarkerElement: new (options: {
    map?: MapInstance
    position: LatLngLiteral
    content?: Node
    title?: string
    zIndex?: number
  }) => AdvancedMarkerElementInstance
  PinElement: new (options: {
    background: string
    borderColor: string
    glyphColor: string
    scale: number
  }) => { element: HTMLElement }
}

export type StreetViewPanoramaInstance = {
  setPosition: (position: LatLngLiteral) => void
  addListener: (eventName: string, handler: () => void) => void
  getStatus?: () => string
}

export type MapsApi = {
  Geocoder: new () => GeocoderInstance
  Map: new (
    container: HTMLElement,
    options: {
      center: LatLngLiteral
      zoom: number
      mapId?: string
      disableDefaultUI?: boolean
      gestureHandling?: string
    },
  ) => MapInstance
  LatLngBounds?: new () => {
    extend: (position: LatLngLiteral) => void
  }
  Polyline?: new (options: {
    path: LatLngLiteral[]
    geodesic?: boolean
    strokeColor?: string
    strokeOpacity?: number
    strokeWeight?: number
    map?: MapInstance
  }) => PolylineInstance
  StreetViewPanorama: new (
    container: HTMLElement,
    options: {
      position: LatLngLiteral
      pov: { heading: number; pitch: number }
      zoom: number
      addressControl: boolean
      fullscreenControl: boolean
      linksControl: boolean
      motionTracking: boolean
      showRoadLabels: boolean
    },
  ) => StreetViewPanoramaInstance
  importLibrary?: (name: string) => Promise<unknown>
  marker?: MarkerLibrary
}

export type GoogleMapsApi = {
  maps: MapsApi
  geocoding?: GeocodingLibrary
  marker?: MarkerLibrary
}
