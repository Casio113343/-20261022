import { useState } from 'react'

import type { FengshuiAnalysis } from '@/objects/fengshui'
import { FengshuiPanelHeader } from '@/pages/ListingDetailPage/components/ListingFengshuiPanel/FengshuiPanelHeader'
import { cn } from '@/utils/class-names'

type AnalysisResultPanelProps = {
  analysis: FengshuiAnalysis
}

export const AnalysisResultPanel = ({ analysis }: AnalysisResultPanelProps) => {
  const [activeTab, setActiveTab] = useState<'strengths' | 'actions'>('strengths')

  return (
    <>
      <FengshuiPanelHeader>
        <h2 className="text-[1.35rem] font-semibold tracking-tight text-slate-950">Fengshui Analysis</h2>
      </FengshuiPanelHeader>

      <div className="flex min-h-0 flex-1 flex-col">
        <div className="shrink-0 border-b border-slate-200/70 bg-slate-50 px-4 py-3">
          <div className="grid h-9 grid-cols-2 overflow-hidden rounded-[14px] border border-slate-200/90 bg-slate-100/70 shadow-inner shadow-white/50">
            {(['strengths', 'actions'] as const).map((tab) => (
              <button
                className={cn(
                  'h-full text-[12px] font-medium capitalize transition',
                  tab !== 'strengths' ? 'border-l border-slate-200/90' : '',
                  activeTab === tab
                    ? 'bg-slate-900 text-white hover:bg-slate-900'
                    : 'text-slate-500 hover:bg-slate-200/75 hover:text-slate-900',
                )}
                key={tab}
                onClick={() => setActiveTab(tab)}
                type="button"
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-3">
          {activeTab === 'strengths' ? <StrengthsTab analysis={analysis} /> : null}
          {activeTab === 'actions' ? <ActionsTab analysis={analysis} /> : null}
        </div>
      </div>
    </>
  )
}

const StrengthsTab = ({ analysis }: { analysis: FengshuiAnalysis }) => (
  <div className="mt-3">
    <section className="rounded-[18px] border border-white/80 bg-white/66 px-4 py-5 shadow-sm ring-1 ring-slate-200/50">
      <ol className="space-y-6">
        {analysis.houseInsights.slice(0, 5).map((insight, index) => (
          <StrengthItem
            index={index}
            insight={insight}
            key={insight.id}
          />
        ))}
      </ol>
    </section>
  </div>
)

const ActionsTab = ({ analysis }: { analysis: FengshuiAnalysis }) => (
  <div className="mt-3">
    <section className="rounded-[18px] border border-white/80 bg-white/66 px-4 py-5 shadow-sm ring-1 ring-slate-200/50">
      <ol className="space-y-6">
        {orderedActions(analysis.priorityActions).slice(0, 3).map((action, index) => (
          <ActionItem
            action={action}
            index={index}
            key={action.id}
          />
        ))}
      </ol>
    </section>
  </div>
)

const ActionItem = ({
  action,
  index,
}: {
  action: FengshuiAnalysis['priorityActions'][number]
  index: number
}) => (
  <li className="flex gap-3.5">
    <NumberBadge index={index} />
    <div className="min-w-0">
      <h3 className="text-sm font-semibold leading-5 text-slate-950">{action.title}</h3>
      <p className="mt-2 text-sm leading-6 text-slate-700">{action.recommendation}</p>
      <p className="mt-2 text-sm leading-6 text-slate-500">{action.reason}</p>
    </div>
  </li>
)

const StrengthItem = ({
  index,
  insight,
}: {
  index: number
  insight: FengshuiAnalysis['houseInsights'][number]
}) => (
  <li className="flex gap-3.5">
    <NumberBadge index={index} />
    <div className="min-w-0">
      <h3 className="text-sm font-semibold leading-5 text-slate-950">{insight.title}</h3>
      <p className="mt-2 text-sm leading-6 text-slate-700">{insight.summary}</p>
    </div>
  </li>
)

const NumberBadge = ({ index }: { index: number }) => (
  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-[11px] font-semibold tabular-nums text-slate-500">
    {index + 1}
  </span>
)

const priorityRank = {
  high: 0,
  medium: 1,
  low: 2,
} satisfies Record<FengshuiAnalysis['priorityActions'][number]['priority'], number>

const orderedActions = (actions: FengshuiAnalysis['priorityActions']) =>
  [...actions].sort((left, right) => priorityRank[left.priority] - priorityRank[right.priority])
