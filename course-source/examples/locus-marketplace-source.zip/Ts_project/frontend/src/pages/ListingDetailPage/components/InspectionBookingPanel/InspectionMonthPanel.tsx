import { ChevronLeft, ChevronRight } from 'lucide-react'

import type { PublicInspectionSlot } from '@/objects/inspections'
import {
  inspectionDayKey,
  inspectionMonthFormatter,
  inspectionTimeFormatter,
} from '@/pages/ListingDetailPage/functions/inspection-booking-calendar'
import { cn } from '@/utils/class-names'

type InspectionMonthPanelProps = {
  availableDates: Set<string>
  calendarDays: Date[]
  monthAnchor: Date
  onDateSelect: (dateKey: string) => void
  onMonthMove: (delta: -1 | 1) => void
  selectedDateKey?: string
  slotsByDate: Record<string, PublicInspectionSlot[]>
  todayKey: string
}

export const InspectionMonthPanel = ({
  availableDates,
  calendarDays,
  monthAnchor,
  onDateSelect,
  onMonthMove,
  selectedDateKey,
  slotsByDate,
  todayKey,
}: InspectionMonthPanelProps) => (
  <div className="flex min-h-0 flex-col overflow-hidden bg-white">
    <div className="grid h-[64px] shrink-0 grid-cols-[1fr_auto_1fr] items-center gap-4 border-b border-slate-200/80 px-5">
      <span aria-hidden="true" />
      <div className="inline-flex items-center gap-1 justify-self-center rounded-full border border-slate-200 bg-slate-50 p-1 shadow-sm">
        <button
          aria-label="Previous month"
          className="inline-flex h-8 w-8 items-center justify-center rounded-full text-slate-500 transition hover:bg-white hover:text-slate-950 hover:shadow-sm"
          onClick={() => onMonthMove(-1)}
          type="button"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <p className="min-w-40 px-3 text-center text-base font-semibold tracking-tight text-slate-950">
          {inspectionMonthFormatter.format(monthAnchor)}
        </p>
        <button
          aria-label="Next month"
          className="inline-flex h-8 w-8 items-center justify-center rounded-full text-slate-500 transition hover:bg-white hover:text-slate-950 hover:shadow-sm"
          onClick={() => onMonthMove(1)}
          type="button"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
      <span aria-hidden="true" />
    </div>

    <div className="flex min-h-0 flex-1 flex-col p-4 pt-3">
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-[26px] bg-slate-100/80 p-2">
        <div className="mb-1 grid h-8 shrink-0 grid-cols-7 text-center text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-500">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((label) => (
            <div className="flex items-center justify-center" key={label}>
              {label}
            </div>
          ))}
        </div>

        <div className="grid min-h-0 flex-1 grid-cols-7 grid-rows-[repeat(6,minmax(0,1fr))] gap-2">
          {calendarDays.map((date) => (
            <InspectionDayButton
              availableDates={availableDates}
              date={date}
              key={inspectionDayKey(date)}
              monthAnchor={monthAnchor}
              onDateSelect={onDateSelect}
              selectedDateKey={selectedDateKey}
              slotsByDate={slotsByDate}
              todayKey={todayKey}
            />
          ))}
        </div>
      </div>
    </div>
  </div>
)

const InspectionDayButton = ({
  availableDates,
  date,
  monthAnchor,
  onDateSelect,
  selectedDateKey,
  slotsByDate,
  todayKey,
}: {
  availableDates: Set<string>
  date: Date
  monthAnchor: Date
  onDateSelect: (dateKey: string) => void
  selectedDateKey?: string
  slotsByDate: Record<string, PublicInspectionSlot[]>
  todayKey: string
}) => {
  const key = inspectionDayKey(date)
  const hasSlots = availableDates.has(key)
  const isToday = key === todayKey
  const isSelected = selectedDateKey === key
  const isCurrentMonth = date.getMonth() === monthAnchor.getMonth()
  const daySlots = slotsByDate[key] ?? []
  const bookedDaySlot = daySlots.find((slot) => slot.isBookedByCurrentUser)
  const isBookedByCurrentUser = Boolean(bookedDaySlot)
  const slotLabel = daySlots.length === 1 ? '1 slot' : `${daySlots.length} slots`
  const cellTone =
    isSelected && isBookedByCurrentUser
      ? 'border-violet-300 bg-violet-50 text-violet-950 shadow-[0_16px_34px_rgba(124,58,237,0.13)] ring-2 ring-inset ring-violet-400'
      : isBookedByCurrentUser
        ? 'border-violet-200 bg-violet-50/80 text-violet-950 hover:border-violet-300 hover:bg-violet-50'
        : isSelected && isToday
          ? 'border-sky-300 bg-sky-50 text-sky-950 shadow-[0_16px_34px_rgba(14,165,233,0.14)] ring-2 ring-inset ring-sky-400'
          : isSelected && hasSlots
            ? 'border-emerald-400 bg-emerald-50 text-emerald-950 shadow-[0_16px_34px_rgba(16,185,129,0.14)] ring-2 ring-inset ring-emerald-400'
            : isSelected
              ? 'border-slate-300 bg-white text-slate-600 shadow-[0_14px_30px_rgba(15,23,42,0.06)] ring-2 ring-inset ring-slate-300'
              : isToday
                ? 'border-sky-200 bg-sky-50 text-sky-950 hover:bg-sky-100'
                : hasSlots
                  ? 'border-emerald-200 bg-emerald-50/80 text-emerald-950 hover:-translate-y-0.5 hover:border-emerald-300 hover:bg-emerald-50 hover:shadow-sm'
                  : 'border-slate-200/70 bg-white/70 text-slate-400 hover:bg-white'
  const dayTone =
    isBookedByCurrentUser
      ? 'bg-violet-600 text-white'
      : isToday
        ? 'bg-sky-600 text-white'
        : isSelected && hasSlots
          ? 'bg-emerald-600 text-white'
          : hasSlots
            ? 'bg-emerald-600 text-white'
            : isSelected
              ? 'bg-slate-600 text-white'
              : 'bg-slate-100 text-slate-400'

  return (
    <button
      className={cn(
        'group flex min-h-0 flex-col overflow-hidden rounded-[22px] border p-2.5 text-left transition',
        cellTone,
        !isCurrentMonth && 'opacity-40',
      )}
      onClick={() => onDateSelect(key)}
      type="button"
    >
      <div className="flex items-center justify-between gap-2">
        <span className={cn('inline-flex h-7 w-7 items-center justify-center rounded-full text-sm font-semibold tracking-tight', dayTone)}>
          {date.getDate()}
        </span>
      </div>
      {bookedDaySlot ? (
        <span className="mt-auto inline-flex w-full items-center justify-center whitespace-nowrap rounded-[15px] bg-violet-600 px-1.5 py-1.5 text-[11px] font-semibold leading-none tracking-tight text-white shadow-[0_8px_18px_rgba(124,58,237,0.18)]">
          {inspectionTimeFormatter.format(new Date(bookedDaySlot.startsAt))} - {inspectionTimeFormatter.format(new Date(bookedDaySlot.endsAt))}
        </span>
      ) : hasSlots ? (
        <span
          className={cn(
            'mt-auto inline-flex w-full items-center justify-center rounded-[15px] px-2 py-1.5 text-[11px] font-semibold leading-none tracking-tight',
            isToday && isSelected
              ? 'bg-sky-600 text-white shadow-[0_8px_18px_rgba(14,165,233,0.18)]'
              : isToday
                ? 'bg-white/90 text-sky-700 shadow-sm ring-1 ring-sky-100/80 group-hover:bg-white'
                : isSelected
                  ? 'bg-emerald-600 text-white shadow-[0_8px_18px_rgba(5,150,105,0.18)]'
                  : 'bg-white/90 text-emerald-700 shadow-sm ring-1 ring-emerald-100/80 group-hover:bg-white',
          )}
        >
          {slotLabel}
        </span>
      ) : (
        <span className="mt-auto block h-6" aria-hidden="true" />
      )}
    </button>
  )
}
