import { Clock, ExternalLink, Globe, MapPin, Phone, Star, X } from 'lucide-react'
import { useMemo, useState, type ReactNode } from 'react'

import {
  InlineMessage,
  LoadingState,
} from '@/pages/ListingDetailPage/components/AmenitiesPanel/AmenitiesStates'
import type {
  AmenityDetailResource,
  TravelMode,
  TravelSummary,
} from '@/pages/ListingDetailPage/functions/amenity-details'
import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'
import { cn } from '@/utils/class-names'

type AmenityDetailPageProps = {
  onExit: () => void
  place: NearbyAmenity
  resource: AmenityDetailResource
}

const travelModeLabel: Record<TravelMode, string> = {
  walking: 'Walk',
  driving: 'Drive',
  transit: 'Transit',
}

const travelSummary = (routes: TravelSummary[], mode: TravelMode) =>
  routes.find((route) => route.mode === mode)

const TravelTimes = ({ routes }: { routes: TravelSummary[] }) => (
  <div className="grid grid-cols-3 gap-2">
    {(['walking', 'driving', 'transit'] as const).map((mode) => {
      const route = travelSummary(routes, mode)

      return (
        <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-center" key={mode}>
          <div className="text-xs font-medium text-slate-600">{travelModeLabel[mode]}</div>
          <div className="mt-0.5 text-sm font-semibold text-slate-950">
            {route?.durationLabel ?? '-'}
          </div>
        </div>
      )
    })}
  </div>
)

const DetailHeader = ({ onExit, place }: { onExit: () => void; place: NearbyAmenity }) => (
  <div className="sticky top-0 z-10 border-b border-slate-200 bg-white/98 px-4 py-3 backdrop-blur">
    <h3 className="truncate pr-10 text-base font-medium text-slate-800">{place.name}</h3>
    <button
      aria-label="Exit place details"
      className="absolute right-3 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
      onClick={onExit}
      type="button"
    >
      <X aria-hidden="true" className="h-4 w-4" />
    </button>
  </div>
)

const DetailPhotoGallery = ({ photoUrls, place }: { photoUrls: string[]; place: NearbyAmenity }) => {
  const photos = useMemo(
    () => (photoUrls.length > 0 ? photoUrls : place.photoUrl ? [place.photoUrl] : []),
    [photoUrls, place.photoUrl],
  )
  const [activePhotoIndex, setActivePhotoIndex] = useState(0)
  const activePhotoUrl = photos[activePhotoIndex] ?? place.photoUrl

  return activePhotoUrl ? (
    <section className="px-4 pt-4">
      <div className="aspect-[16/10] w-full overflow-hidden rounded-lg bg-slate-100">
        <img alt={place.name} className="h-full w-full object-cover" src={activePhotoUrl} />
      </div>
      {photos.length > 1 ? (
        <div className="mt-3">
          <div className="mb-2 text-xs font-medium text-slate-600">More photos</div>
          <div className="flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {photos.slice(0, 10).map((photoUrl, index) => (
              <button
                aria-label={`View photo ${index + 1}`}
                className={cn(
                  'h-16 w-24 shrink-0 overflow-hidden rounded-md border bg-slate-100 transition',
                  activePhotoIndex === index
                    ? 'border-blue-600 ring-2 ring-blue-100'
                    : 'border-transparent hover:border-slate-300',
                )}
                key={`${photoUrl}-${index}`}
                onClick={() => setActivePhotoIndex(index)}
                type="button"
              >
                <img
                  alt={`${place.name} photo ${index + 1}`}
                  className="h-full w-full object-cover"
                  src={photoUrl}
                />
              </button>
            ))}
          </div>
        </div>
      ) : null}
      <div className="mt-4 border-b border-slate-200" />
    </section>
  ) : null
}

const DetailInfoRow = ({
  align = 'start',
  children,
  icon,
}: {
  align?: 'center' | 'start'
  children: ReactNode
  icon: ReactNode
}) => (
  <div className={cn('flex gap-3 py-3 text-sm text-slate-700', align === 'center' ? 'items-center' : '')}>
    <div
      className={cn(
        'text-slate-500',
        align === 'center' ? 'flex h-5 w-5 shrink-0 items-center justify-center' : 'mt-0.5',
      )}
    >
      {icon}
    </div>
    <div className="min-w-0 flex-1">{children}</div>
  </div>
)

export const AmenityDetailPage = ({ onExit, place, resource }: AmenityDetailPageProps) => {
  if (resource.status === 'idle' || resource.status === 'loading') {
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <DetailHeader onExit={onExit} place={place} />
        <div className="px-4 pt-4 pb-4">
          <LoadingState label="Loading place details and travel times..." compact />
        </div>
      </div>
    )
  }

  if (resource.status === 'error') {
    return (
      <div className="flex min-h-0 flex-1 flex-col">
        <DetailHeader onExit={onExit} place={place} />
        <div className="px-4 pt-4 pb-4">
          <InlineMessage message={resource.message} tone="error" />
        </div>
      </div>
    )
  }

  if (resource.status !== 'ready') {
    return null
  }

  const { details, routes } = resource

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <DetailHeader onExit={onExit} place={place} />
      <div className="flex-1 overflow-y-auto">
        <DetailPhotoGallery photoUrls={details.photoUrls} place={place} />

        <section className="px-4 pt-3">
          <DetailInfoRow icon={<MapPin aria-hidden="true" className="h-5 w-5" />}>
            {place.address}
          </DetailInfoRow>
          <div className="mt-1.5">
            <TravelTimes routes={routes} />
          </div>
          <div className="mt-3 border-b border-slate-200" />
        </section>

        <section className="divide-y divide-slate-100 px-4 pb-5">
          <DetailInfoRow icon={<Clock aria-hidden="true" className="h-5 w-5" />}>
            <div className="space-y-1.5">
              {details.openingStatus ? (
                <div
                  className={cn(
                    'font-medium',
                    details.openingStatus === 'Open now' ? 'text-emerald-700' : 'text-slate-700',
                  )}
                >
                  {details.openingStatus}
                </div>
              ) : null}
              {details.weekdayDescriptions.length > 0 ? (
                <div className="space-y-1 text-slate-600">
                  {details.weekdayDescriptions.map((hours) => (
                    <div key={hours}>{hours}</div>
                  ))}
                </div>
              ) : (
                <div className="text-slate-500">Opening hours unavailable</div>
              )}
            </div>
          </DetailInfoRow>

          <DetailInfoRow align="center" icon={<Star aria-hidden="true" className="h-5 w-5" />}>
            {place.rating ? (
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="font-medium text-slate-900">{place.rating.toFixed(1)}</span>
                {place.userRatingCount ? (
                  <span className="text-slate-500">({place.userRatingCount.toLocaleString()} ratings)</span>
                ) : null}
              </div>
            ) : (
              <span className="text-slate-500">No rating available</span>
            )}
          </DetailInfoRow>

          {details.nationalPhoneNumber ? (
            <DetailInfoRow align="center" icon={<Phone aria-hidden="true" className="h-5 w-5" />}>
              <a className="text-blue-700 hover:underline" href={`tel:${details.nationalPhoneNumber}`}>
                {details.nationalPhoneNumber}
              </a>
            </DetailInfoRow>
          ) : null}

          {details.websiteUri ? (
            <DetailInfoRow align="center" icon={<Globe aria-hidden="true" className="h-5 w-5" />}>
              <a
                className="inline-flex min-w-0 items-center gap-1.5 text-blue-700 hover:underline"
                href={details.websiteUri}
                rel="noreferrer"
                target="_blank"
              >
                <span className="truncate">Website</span>
                <ExternalLink aria-hidden="true" className="h-3.5 w-3.5 shrink-0" />
              </a>
            </DetailInfoRow>
          ) : null}
        </section>
      </div>
    </div>
  )
}
