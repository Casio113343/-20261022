import { FengshuiPanelHeader } from '@/pages/ListingDetailPage/components/ListingFengshuiPanel/FengshuiPanelHeader'

export const UnavailableAnalysisPanel = () => (
  <>
    <FengshuiPanelHeader>
      <h2 className="text-[1.35rem] font-semibold tracking-tight text-slate-950">Fengshui Analysis</h2>
    </FengshuiPanelHeader>
    <div className="flex flex-1 items-center justify-center px-8 text-center">
      <p className="text-sm leading-6 text-slate-500">
        Analysis becomes available once a floor plan is provided.
      </p>
    </div>
  </>
)
