import { useCallback, useMemo, useState } from 'react'

import type { PublicInspectionSlot } from '@/objects/inspections'
import { api } from '@/apis'
import { useInspectionSlots } from '@/pages/ListingDetailPage/hooks/use-inspection-slots'
import { recordListingAnalyticsEvent } from '@/pages/shared/analytics/record-listing-analytics'

type BookingSelection = {
  selectedDateKey?: string
  selectedSlotId?: string
}

export const useInspectionBooking = (listingId: string, isAuthenticated: boolean) => {
  const [selection, setSelection] = useState<BookingSelection>({})
  const [isBooking, setIsBooking] = useState(false)
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false)
  const [cancelError, setCancelError] = useState<string>()

  const handleSlotsLoaded = useCallback((
    slots: PublicInspectionSlot[],
    isDifferentListing: boolean,
  ) => {
    const initialDateKey =
      (
        slots.find((slot) => slot.isBookedByCurrentUser) ??
        slots.find((slot) => !slot.isBooked)
      )?.startsAt.slice(0, 10)

    setSelection((current) => ({
      selectedDateKey: isDifferentListing ? initialDateKey : current.selectedDateKey ?? initialDateKey,
      selectedSlotId: !isDifferentListing && slots.some((slot) => slot.id === current.selectedSlotId && !slot.isBooked)
        ? current.selectedSlotId
        : undefined,
    }))

    if (!slots.some((slot) => slot.isBookedByCurrentUser)) {
      setIsCancelDialogOpen(false)
      setCancelError(undefined)
    }
  }, [])
  const { replaceSlot, slots } = useInspectionSlots({
    listingId,
    onSlotsLoaded: handleSlotsLoaded,
  })

  const bookedSlot = slots.find((slot) => slot.isBookedByCurrentUser)
  const visibleSlots = useMemo(
    () => slots.filter((slot) => !slot.isBooked || slot.isBookedByCurrentUser),
    [slots],
  )
  const slotsByDate = useMemo(
    () => visibleSlots.reduce<Record<string, PublicInspectionSlot[]>>(
      (groups, slot) => ({
        ...groups,
        [slot.startsAt.slice(0, 10)]: [...(groups[slot.startsAt.slice(0, 10)] ?? []), slot],
      }),
      {},
    ),
    [visibleSlots],
  )
  const selectedDateSlots = useMemo(
    () => visibleSlots.filter((slot) => slot.startsAt.slice(0, 10) === selection.selectedDateKey),
    [selection.selectedDateKey, visibleSlots],
  )
  const selectedBookedSlot = selectedDateSlots.find((slot) => slot.isBookedByCurrentUser)
  const selectedSlot = selectedDateSlots.find((slot) => !slot.isBooked && slot.id === selection.selectedSlotId)

  const selectDate = (selectedDateKey: string) =>
    setSelection({ selectedDateKey })

  const selectSlot = (selectedSlotId: string) =>
    setSelection((current) => ({ ...current, selectedSlotId }))

  const bookSelectedSlot = async () => {
    if (!isAuthenticated || !selectedSlot) {
      return
    }

    setIsBooking(true)
    const response = await api.bookInspectionSlot(selectedSlot.id)
    setIsBooking(false)

    if (response.ok) {
      replaceSlot(response.data)
      setSelection((current) => ({ ...current, selectedSlotId: undefined }))
      recordListingAnalyticsEvent(listingId, 'inspection_request', { action: 'inspection_requested' })
    }
  }

  const cancelBooking = async () => {
    if (!isAuthenticated || !bookedSlot) {
      return
    }

    setCancelError(undefined)
    setIsBooking(true)
    const response = await api.cancelInspectionBooking(bookedSlot.id)
    setIsBooking(false)

    if (!response.ok) {
      setCancelError(response.error.message)
      return
    }

    replaceSlot(response.data)
    setSelection((current) => ({ ...current, selectedSlotId: undefined }))
    setCancelError(undefined)
    setIsCancelDialogOpen(false)
  }

  return {
    bookSelectedSlot,
    bookedSlot,
    cancelBooking,
    cancelError,
    isBooking,
    isCancelDialogOpen,
    selectedBookedSlot,
    selectedDateKey: selection.selectedDateKey,
    selectedDateSlots,
    selectedSlot,
    selectedSlotId: selection.selectedSlotId,
    selectDate,
    selectSlot,
    setCancelError,
    setIsCancelDialogOpen,
    slotsByDate,
  }
}
