import { CalendarDays, Compass, House, Map, MessageCircleMore, Video } from 'lucide-react'

import type { ListingDetailSectionId } from '@/pages/ListingDetailPage/functions/listing-detail'
import { cn } from '@/utils/class-names'

type ListingDetailSectionRailProps = {
  activeSection: ListingDetailSectionId
  onSelect: (section: ListingDetailSectionId) => void
}

const sections = [
  { id: 'overview' as const, label: 'Photos', icon: House },
  { id: 'amenities' as const, label: 'Amenities', icon: Map },
  { id: 'street-view' as const, label: 'Street view', icon: Video },
  { id: 'messages' as const, label: 'Messages', icon: MessageCircleMore },
  { id: 'inspections' as const, label: 'Inspections', icon: CalendarDays },
  { id: 'fengshui' as const, label: 'Fengshui', icon: Compass },
]

export const ListingDetailSectionRail = ({
  activeSection,
  onSelect,
}: ListingDetailSectionRailProps) => (
  <aside className="flex w-full shrink-0 flex-row items-center gap-2 rounded-xl border border-slate-200/50 bg-slate-100/75 p-2 shadow-lg lg:h-full lg:w-14 lg:flex-col lg:gap-0">
    {sections.map(({ id, label, icon: Icon }) => (
      <button
        key={id}
        aria-label={label}
        title={label}
        className={cn(
          'flex h-11 flex-1 items-center justify-center gap-2 rounded-lg px-3 transition lg:mb-3 lg:w-11 lg:flex-none lg:px-0 lg:last:mb-0',
          activeSection === id
            ? 'bg-slate-800 text-white shadow'
            : 'bg-white/85 text-slate-700 hover:bg-white',
        )}
        onClick={() => onSelect(id)}
        type="button"
      >
        <Icon className="h-5 w-5" />
        <span className="text-sm font-medium lg:hidden">{label}</span>
      </button>
    ))}
  </aside>
)
