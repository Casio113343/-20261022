export type { Category } from '@/pages/ListingDetailPage/objects/places/Category'
export type { PlaceItem } from '@/pages/ListingDetailPage/objects/places/PlaceItem'
export type { Subcategory } from '@/pages/ListingDetailPage/objects/places/Subcategory'
