import type { ListingMapPosition } from '@/objects/amenities'
import type { ListingDetail, ListingImage } from '@/objects/listings'
import { formatListingAddress } from '@/pages/shared/marketplace/functions/marketplace-format'

export type ListingDetailSectionId = 'overview' | 'amenities' | 'street-view' | 'messages' | 'inspections' | 'fengshui'
export type { ListingMapPosition, NearbyAmenity } from '@/objects/amenities'

export type ListingMapLocationState =
  | { status: 'idle' | 'loading' }
  | { status: 'missing-config'; message: string }
  | { status: 'error'; message: string }
  | { status: 'ready'; position: ListingMapPosition }

export const listingAddress = (listing: ListingDetail) => formatListingAddress(listing)

export const listingImageGallery = (listing: ListingDetail): ListingImage[] =>
  listing.images.filter((image) => !image.isFloorPlan)

export const listingFloorPlanImage = (listing: ListingDetail): ListingImage | undefined =>
  listing.images.find((image) => image.isFloorPlan)

export const listingPropertyDescription = (listing: ListingDetail) => listing.description

export const cycleImageIndex = (currentIndex: number, direction: -1 | 1, imageCount: number) =>
  (currentIndex + direction + imageCount) % imageCount

export const formatAmenityDistance = (distanceInMeters: number) =>
  distanceInMeters >= 1000
    ? `${(distanceInMeters / 1000).toFixed(1)} km away`
    : `${Math.max(50, Math.round(distanceInMeters / 10) * 10)} m away`

const earthRadiusInMeters = 6371000
const toRadians = (value: number) => (value * Math.PI) / 180

export const haversineDistanceInMeters = (
  start: ListingMapPosition,
  destination: ListingMapPosition,
) => {
  const latitudeDelta = toRadians(destination.lat - start.lat)
  const longitudeDelta = toRadians(destination.lng - start.lng)
  const startLatitude = toRadians(start.lat)
  const destinationLatitude = toRadians(destination.lat)
  const distanceFactor =
    Math.sin(latitudeDelta / 2) ** 2 +
    Math.cos(startLatitude) * Math.cos(destinationLatitude) * Math.sin(longitudeDelta / 2) ** 2

  return 2 * earthRadiusInMeters * Math.atan2(Math.sqrt(distanceFactor), Math.sqrt(1 - distanceFactor))
}
