import { useCallback, useMemo, useState } from 'react'

import { AmenitiesCategorySelector } from '@/pages/ListingDetailPage/components/AmenitiesPanel/AmenitiesCategorySelector'
import { AmenitiesResultsList } from '@/pages/ListingDetailPage/components/AmenitiesPanel/AmenitiesResultsList'
import {
  ConfigurationState,
  LoadingState,
} from '@/pages/ListingDetailPage/components/AmenitiesPanel/AmenitiesStates'
import { markerStyleSheet } from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'
import { CATEGORIES, findAmenityCategory } from '@/pages/ListingDetailPage/functions/amenity-categories'
import type { ListingMapLocationState } from '@/pages/ListingDetailPage/functions/listing-detail'
import { useAmenityRouteLine } from '@/pages/ListingDetailPage/hooks/use-amenity-route-line'
import { useAmenitiesMarkers } from '@/pages/ListingDetailPage/hooks/use-amenities-markers'
import { useAmenitiesPlaces } from '@/pages/ListingDetailPage/hooks/use-amenities-places'
import { useSelectedAmenityDetails } from '@/pages/ListingDetailPage/hooks/use-selected-amenity-details'
import { recordListingAnalyticsEvent } from '@/pages/shared/analytics/record-listing-analytics'

type ListingAmenitiesPanelProps = {
  listingId: string
  locationState: ListingMapLocationState
}

export const ListingAmenitiesPanel = ({ listingId, locationState }: ListingAmenitiesPanelProps) => {
  const [activeCategoryId, setActiveCategoryId] = useState(CATEGORIES[0].id)
  const [hoveredCategoryId, setHoveredCategoryId] = useState<string>()
  const [activeSubcategoryId, setActiveSubcategoryId] = useState('supermarkets')
  const [selectedPlaceId, setSelectedPlaceId] = useState<string>()
  const [error, setError] = useState<string>()

  const activeCategory = useMemo(() => findAmenityCategory(activeCategoryId), [activeCategoryId])
  const activeSubcategory = useMemo(
    () =>
      activeCategory.subcategories.find((subcategory) => subcategory.id === activeSubcategoryId) ??
      activeCategory.subcategories[0],
    [activeCategory, activeSubcategoryId],
  )
  const locationKey =
    locationState.status === 'ready'
      ? `${locationState.position.lat}:${locationState.position.lng}`
      : locationState.status
  const mapPosition = locationState.status === 'ready' ? locationState.position : undefined

  const handleError = useCallback((message?: string) => setError(message), [])

  const {
    hasLoadedPlaces,
    isLoading,
    places,
  } = useAmenitiesPlaces({
    activeSubcategory,
    isMapReady: locationState.status === 'ready',
    locationKey,
    mapPosition,
    onError: handleError,
  })

  const {
    isMapReady,
    mapContainerRef,
    mapRef,
    resetMapCamera,
    hideAllMarkers,
    findMarkerByPlaceId,
    showActiveSubcategoryMarkers,
    showOnlyPlaceMarker,
  } = useAmenitiesMarkers({
    activeSubcategory,
    activeSubcategoryIdKey: activeSubcategory.id,
    locationKey,
    mapPosition,
    currentPlaces: places,
    hasLoadedCurrentPlaces: hasLoadedPlaces,
    selectedPlaceId,
    setSelectedPlaceId,
    onError: handleError,
  })

  const selectedPlace = places.find((place) => place.id === selectedPlaceId)
  const selectedPlaceResource = useSelectedAmenityDetails({
    origin: mapPosition,
    selectedPlace,
  })
  const walkingRoute =
    selectedPlaceResource.status === 'ready'
      ? selectedPlaceResource.routes.find((route) => route.mode === 'walking')
      : undefined

  useAmenityRouteLine({
    destination: selectedPlace?.location,
    mapRef,
    origin: mapPosition,
    path: walkingRoute?.polyline,
  })

  const handleCategorySelect = (categoryId: string, firstSubcategoryId: string) => {
    const category = findAmenityCategory(categoryId)

    setActiveCategoryId(categoryId)
    setActiveSubcategoryId(firstSubcategoryId)
    setSelectedPlaceId(undefined)
    hideAllMarkers()
    recordListingAnalyticsEvent(listingId, 'amenity_interest', {
      amenity: {
        category: category.label,
        label: category.label,
      },
    })
  }

  const handleSubcategorySelect = (subcategoryId: string) => {
    setActiveSubcategoryId(subcategoryId)
    setSelectedPlaceId(undefined)
    recordListingAnalyticsEvent(listingId, 'amenity_interest', {
      amenity: {
        category: activeCategory.label,
        label: activeCategory.subcategories.find((subcategory) => subcategory.id === subcategoryId)?.label ?? activeCategory.label,
      },
    })
  }

  const handlePlaceSelect = (placeId: string) => {
    const place = places.find((item) => item.id === placeId)

    recordListingAnalyticsEvent(listingId, 'amenity_interest', {
      amenity: {
        category: activeCategory.label,
        label: place?.name ?? activeSubcategory.label,
      },
    })

    const markerRecord = findMarkerByPlaceId(activeSubcategory.id, placeId)

    if (markerRecord) {
      showOnlyPlaceMarker(placeId)
      return
    }

    hideAllMarkers()
    setSelectedPlaceId(placeId)
  }

  const handleBackToResults = () => {
    setSelectedPlaceId(undefined)
    showActiveSubcategoryMarkers()
    resetMapCamera()
  }

  if (locationState.status === 'missing-config' || locationState.status === 'error') {
    return <ConfigurationState message={locationState.message} />
  }

  if (locationState.status === 'idle' || locationState.status === 'loading') {
    return <LoadingState label="Locating the property on the map..." />
  }

  return (
    <div className="flex h-full min-h-0 flex-col gap-4 xl:flex-row">
      <style>{markerStyleSheet}</style>

      <div className="relative aspect-square min-h-[22rem] overflow-hidden rounded-xl border border-slate-200/50 bg-white shadow-lg xl:h-full xl:shrink-0">
        <div className="absolute inset-0" ref={mapContainerRef} />
      </div>

      <AmenitiesCategorySelector
        activeCategoryId={activeCategory.id}
        activeSubcategoryId={activeSubcategory.id}
        hoveredCategoryId={hoveredCategoryId}
        onCategorySelect={handleCategorySelect}
        onHoverCategory={setHoveredCategoryId}
        onSubcategorySelect={handleSubcategorySelect}
      />

      <AmenitiesResultsList
        error={error}
        loading={isLoading || !isMapReady}
        onBackToResults={handleBackToResults}
        onPlaceSelect={handlePlaceSelect}
        places={places}
        selectedPlace={selectedPlace}
        selectedPlaceResource={selectedPlaceResource}
      />
    </div>
  )
}
