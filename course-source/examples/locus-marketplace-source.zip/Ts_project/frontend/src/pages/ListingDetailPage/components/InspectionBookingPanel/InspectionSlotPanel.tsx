import { CalendarCheck } from 'lucide-react'
import { Link } from 'react-router-dom'

import type { PublicInspectionSlot } from '@/objects/inspections'
import {
  inspectionFullDateFormatter,
  inspectionTimeFormatter,
} from '@/pages/ListingDetailPage/functions/inspection-booking-calendar'
import { cn } from '@/utils/class-names'

type InspectionSlotPanelProps = {
  bookedSlot?: PublicInspectionSlot
  isBooking: boolean
  onBookSelectedSlot: () => void
  onCancelDialogOpen: () => void
  onSlotSelect: (slotId: string) => void
  selectedBookedSlot?: PublicInspectionSlot
  selectedDate?: Date
  selectedDateIsToday: boolean
  selectedDateSlots: PublicInspectionSlot[]
  selectedSlot?: PublicInspectionSlot
  selectedSlotId?: string
  isAuthenticated: boolean
}

export const InspectionSlotPanel = ({
  bookedSlot,
  isBooking,
  onBookSelectedSlot,
  onCancelDialogOpen,
  onSlotSelect,
  selectedBookedSlot,
  selectedDate,
  selectedDateIsToday,
  selectedDateSlots,
  selectedSlot,
  selectedSlotId,
  isAuthenticated,
}: InspectionSlotPanelProps) => (
  <aside className="flex min-h-0 flex-col border-t border-slate-200/80 bg-[linear-gradient(180deg,#f8fafc_0%,#ffffff_48%)] lg:border-l lg:border-t-0">
    <div className="flex h-[64px] shrink-0 items-center gap-3.5 border-b border-slate-200/80 px-5">
      <div className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-[13px] bg-slate-950 text-white shadow-[0_10px_22px_rgba(15,23,42,0.14)]">
        <CalendarCheck className="h-[18px] w-[18px]" />
      </div>
      <div className="min-w-0">
        <p className="truncate text-base font-semibold tracking-tight text-slate-950">
          {selectedDate ? inspectionFullDateFormatter.format(selectedDate) : 'Select a date'}
        </p>
      </div>
    </div>

    <div className="flex min-h-0 flex-1 flex-col px-5 pb-4 pt-3">
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto pr-1">
        {selectedDateSlots.map((slot) => (
          slot.isBookedByCurrentUser ? (
            <BookedSlot key={slot.id} slot={slot} />
          ) : (
            <AvailableSlot
              bookedSlot={bookedSlot}
              key={slot.id}
              onSelect={() => onSlotSelect(slot.id)}
              selectedDateIsToday={selectedDateIsToday}
              selectedSlotId={selectedSlotId}
              slot={slot}
            />
          )
        ))}
        {selectedDateSlots.length === 0 ? <NoSlots /> : null}
      </div>

      {isAuthenticated && !bookedSlot && selectedSlot ? (
        <button
          className="mt-5 inline-flex h-12 items-center justify-center rounded-full bg-slate-950 px-5 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(15,23,42,0.18)] transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:shadow-none"
          disabled={isBooking}
          onClick={onBookSelectedSlot}
          type="button"
        >
          Book {inspectionTimeFormatter.format(new Date(selectedSlot.startsAt))}
        </button>
      ) : null}
      {isAuthenticated && !bookedSlot && !selectedSlot && selectedDateSlots.some((slot) => !slot.isBooked) ? (
        <button
          className="mt-5 inline-flex h-12 items-center justify-center rounded-full bg-slate-300 px-5 text-sm font-semibold text-white shadow-none"
          disabled
          type="button"
        >
          Pick a time
        </button>
      ) : null}
      {isAuthenticated && selectedBookedSlot ? (
        <button
          className="mt-5 inline-flex h-12 items-center justify-center rounded-full bg-slate-950 px-5 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(15,23,42,0.18)] transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:shadow-none"
          disabled={isBooking}
          onClick={onCancelDialogOpen}
          type="button"
        >
          Cancel booking
        </button>
      ) : null}
      {!isAuthenticated ? (
        <Link className="mt-5 inline-flex h-12 items-center justify-center rounded-full bg-slate-950 px-5 text-sm font-semibold text-white shadow-[0_16px_34px_rgba(15,23,42,0.18)] transition hover:bg-slate-800" to="/sign-in">
          Sign in
        </Link>
      ) : null}
    </div>
  </aside>
)

const BookedSlot = ({ slot }: { slot: PublicInspectionSlot }) => (
  <div className="flex h-[50px] w-full items-center justify-between rounded-[20px] border border-violet-400 bg-violet-50 px-4 text-violet-950 shadow-[0_14px_30px_rgba(124,58,237,0.08)] ring-1 ring-inset ring-violet-300">
    <span className="text-[15px] font-semibold tracking-tight">
      {inspectionTimeFormatter.format(new Date(slot.startsAt))} - {inspectionTimeFormatter.format(new Date(slot.endsAt))}
    </span>
    <span className="rounded-full bg-violet-100 px-2.5 py-1 text-[11px] font-semibold text-violet-700">Booked</span>
  </div>
)

const AvailableSlot = ({
  bookedSlot,
  onSelect,
  selectedDateIsToday,
  selectedSlotId,
  slot,
}: {
  bookedSlot?: PublicInspectionSlot
  onSelect: () => void
  selectedDateIsToday: boolean
  selectedSlotId?: string
  slot: PublicInspectionSlot
}) => (
  <button
    className={cn(
      'flex h-[50px] w-full items-center justify-between rounded-[20px] border px-4 text-left transition',
      bookedSlot && 'cursor-default',
      selectedSlotId === slot.id
        ? selectedDateIsToday
          ? 'border-sky-300 bg-sky-50 text-sky-950 shadow-[0_14px_30px_rgba(14,165,233,0.10)] ring-1 ring-inset ring-sky-200'
          : 'border-emerald-300 bg-emerald-50 text-emerald-950 shadow-[0_14px_30px_rgba(16,185,129,0.10)] ring-1 ring-inset ring-emerald-200'
        : selectedDateIsToday
          ? 'border-slate-200 bg-white/80 text-slate-700 hover:-translate-y-0.5 hover:border-sky-200 hover:bg-sky-50/50 hover:shadow-sm'
          : 'border-slate-200 bg-white/80 text-slate-700 hover:-translate-y-0.5 hover:border-slate-300 hover:bg-white hover:shadow-sm',
    )}
    disabled={Boolean(bookedSlot)}
    onClick={onSelect}
    type="button"
  >
    <span className="text-[15px] font-semibold tracking-tight">
      {inspectionTimeFormatter.format(new Date(slot.startsAt))} - {inspectionTimeFormatter.format(new Date(slot.endsAt))}
    </span>
    <span
      className={cn(
        'inline-flex h-5 w-5 items-center justify-center rounded-full border',
        selectedSlotId === slot.id
          ? selectedDateIsToday
            ? 'border-sky-600 bg-sky-600'
            : 'border-emerald-600 bg-emerald-600'
          : 'border-slate-300',
      )}
    >
      {selectedSlotId === slot.id ? <span className="h-2 w-2 rounded-full bg-white" /> : null}
    </span>
  </button>
)

const NoSlots = () => (
  <div className="grid min-h-full grid-rows-[1fr_auto_2fr] rounded-[24px] border border-dashed border-slate-200 bg-white/70 p-8 text-center">
    <span aria-hidden="true" />
    <p className="text-sm font-semibold text-slate-600">No slots available</p>
    <span aria-hidden="true" />
  </div>
)
