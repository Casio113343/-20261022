import type {
  AdvancedMarkerElementInstance,
  MapInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'
import {
  failure,
  success,
  type Result,
} from '@/utils/result'
import {
  formatAmenityDistance,
  type NearbyAmenity,
} from '@/pages/ListingDetailPage/functions/listing-detail'

export type MarkerView = {
  container: HTMLDivElement
  label: HTMLDivElement
  closeButton: HTMLButtonElement
  path: SVGPathElement
}

export type MarkerRecord = {
  marker: AdvancedMarkerElementInstance
  placeId: string
  view: MarkerView
}

export const markerStyleSheet = `
  .amenity-marker-container { position: relative; display: inline-block; transform: translateY(0); cursor: pointer; }
  .amenity-marker-label {
    position: absolute;
    left: 50%;
    top: 4px;
    transform: translate(-50%, -8px) translateY(-100%);
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 8px;
    background: rgba(255,255,255,0.96);
    border-radius: 999px;
    box-shadow: 0 4px 10px rgba(2,6,23,0.08);
    border: 1px solid rgba(15,23,42,0.06);
    font-size: 12px;
    color: #111827;
    max-width: 220px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    opacity: 0;
    pointer-events: none;
    transition: opacity 120ms ease, transform 140ms ease;
    z-index: 1000;
  }
  .amenity-marker-label-visible {
    opacity: 1;
    pointer-events: auto;
    transform: translate(-50%, -14px) translateY(-100%);
  }
  .amenity-marker-label-text { max-width: 160px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .amenity-marker-close {
    border: none;
    background: transparent;
    font-size: 12px;
    padding: 2px;
    line-height: 1;
    cursor: pointer;
    color: #6b7280;
  }
  .amenity-marker-svg { display: block; transform-origin: 50% 50%; z-index: 2; }
  .amenity-marker-hover .amenity-marker-svg { transform: translateY(-2px) scale(1.03); }
  .amenity-marker-selected .amenity-marker-svg { transform: translateY(-2px) scale(1.03); }
`

const svgNamespace = 'http://www.w3.org/2000/svg'

const createSvgElement = <T extends keyof SVGElementTagNameMap>(tag: T) =>
  document.createElementNS(svgNamespace, tag)

const sanitizeSvgId = (value: string) => value.replace(/[^a-zA-Z0-9_-]/g, '_')

const buildMarkerSvg = (emoji: string, idSuffix: string): SVGSVGElement => {
  const filterId = `marker-glow-${sanitizeSvgId(idSuffix)}`

  const svg = createSvgElement('svg')
  svg.setAttribute('width', '44')
  svg.setAttribute('height', '56')
  svg.setAttribute('viewBox', '0 0 44 56')
  svg.setAttribute('aria-hidden', 'true')
  svg.setAttribute('style', 'display:block;overflow:visible')
  svg.dataset.filterId = filterId

  const defs = createSvgElement('defs')
  const filter = createSvgElement('filter')
  filter.setAttribute('id', filterId)
  filter.setAttribute('x', '-60%')
  filter.setAttribute('y', '-60%')
  filter.setAttribute('width', '220%')
  filter.setAttribute('height', '220%')

  const gaussianBlur = createSvgElement('feGaussianBlur')
  gaussianBlur.setAttribute('in', 'SourceAlpha')
  gaussianBlur.setAttribute('stdDeviation', '3.6')
  gaussianBlur.setAttribute('result', 'blurredAlpha')

  const flood = createSvgElement('feFlood')
  flood.setAttribute('flood-color', '#2563eb')
  flood.setAttribute('flood-opacity', '0.98')
  flood.setAttribute('result', 'coloredFlood')

  const composite = createSvgElement('feComposite')
  composite.setAttribute('in', 'coloredFlood')
  composite.setAttribute('in2', 'blurredAlpha')
  composite.setAttribute('operator', 'in')
  composite.setAttribute('result', 'coloredBlur')

  const merge = createSvgElement('feMerge')
  const mergeNodeGlow = createSvgElement('feMergeNode')
  mergeNodeGlow.setAttribute('in', 'coloredBlur')
  const mergeNodeSource = createSvgElement('feMergeNode')
  mergeNodeSource.setAttribute('in', 'SourceGraphic')

  merge.append(mergeNodeGlow, mergeNodeSource)
  filter.append(gaussianBlur, flood, composite, merge)
  defs.append(filter)

  const path = createSvgElement('path')
  path.setAttribute('d', 'M22 2C14 2 8 8.5 8 16.5c0 9 12 26.5 13.5 28.8.3.4.9.4 1.2 0C24 43 36 25.5 36 16.5 36 8.5 30 2 22 2z')
  path.setAttribute('fill', '#ffffff')

  const text = createSvgElement('text')
  text.setAttribute('x', '22')
  text.setAttribute('y', '20')
  text.setAttribute('text-anchor', 'middle')
  text.setAttribute('font-size', '16')
  text.setAttribute('dominant-baseline', 'middle')
  text.textContent = emoji

  svg.append(defs, path, text)
  return svg
}

export const createMarkerView = (place: NearbyAmenity, emoji: string): Result<MarkerView> => {
  const container = document.createElement('div')
  container.className = 'amenity-marker-container'
  container.dataset.placeId = place.id

  const label = document.createElement('div')
  label.className = 'amenity-marker-label'

  const labelText = document.createElement('div')
  labelText.className = 'amenity-marker-label-text'
  labelText.textContent = place.name.slice(0, 40)

  const closeButton = document.createElement('button')
  closeButton.type = 'button'
  closeButton.className = 'amenity-marker-close'
  closeButton.setAttribute('aria-label', 'Close label')
  closeButton.textContent = '✕'

  label.append(labelText, closeButton)

  const icon = document.createElement('div')
  icon.className = 'amenity-marker-svg'
  const svg = buildMarkerSvg(emoji, place.id)
  const path = svg.querySelector('path')

  if (!(path instanceof SVGPathElement)) {
    return failure('decode', 'Marker SVG path could not be created')
  }

  icon.append(svg)
  container.append(label, icon)

  return success({
    container,
    label,
    closeButton,
    path,
  })
}

export const mergePlaces = (places: NearbyAmenity[]) =>
  Object.values(
    places.reduce<Record<string, NearbyAmenity>>(
      (accumulator, place) => ({
        ...accumulator,
        [place.id]: accumulator[place.id] ?? place,
      }),
      {},
    ),
  )
    .sort((left, right) => left.distanceInMeters - right.distanceInMeters)
    .slice(0, 20)

export const setMarkerMap = (marker: AdvancedMarkerElementInstance, map?: MapInstance) => {
  // Google Maps detaches markers with null at the library boundary; keep that conversion here.
  const nextMap = map ?? null

  if (typeof marker.setMap === 'function') {
    marker.setMap(nextMap)
  } else {
    marker.map = nextMap
  }
}

export { formatAmenityDistance }
