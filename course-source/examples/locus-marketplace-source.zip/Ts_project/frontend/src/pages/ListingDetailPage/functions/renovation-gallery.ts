import type { ListingDetail, ListingImage } from '@/objects/listings'
import type { ListingRenovation, RenovationStatus } from '@/objects/renovations'
import { listingImageGallery } from '@/pages/ListingDetailPage/functions/listing-detail'

export type RenovationImagePair = {
  id: string
  label: string
  original: Pick<ListingImage, 'altText' | 'url'>
  renovated: {
    altText: string
    url?: string
  }
  status: RenovationStatus
  errorMessage?: string
}

export const hasRenovationGallery = (listing: ListingDetail) =>
  listing.renovateWithAi && listingImageGallery(listing).length > 0

export const renovationImagePairs = (
  listing: ListingDetail,
  renovations: ListingRenovation[],
): RenovationImagePair[] => {
  const renovationsByImageId = new Map(
    renovations.map((renovation) => [renovation.originalImageId, renovation]),
  )
  const gallery = listingImageGallery(listing)

  return gallery.map((original, index) => {
    const renovation = renovationsByImageId.get(original.id)

    return {
      id: `${listing.id}-renovation-${original.id}`,
      label: `${index + 1} of ${gallery.length}`,
      original,
      renovated: {
        altText: `AI renovated concept ${index + 1} for ${listing.addressLine}`,
        url: renovation?.renovatedImageUrl ?? undefined,
      },
      status: renovation?.status ?? 'pending',
      errorMessage: renovation?.errorMessage ?? undefined,
    }
  })
}
