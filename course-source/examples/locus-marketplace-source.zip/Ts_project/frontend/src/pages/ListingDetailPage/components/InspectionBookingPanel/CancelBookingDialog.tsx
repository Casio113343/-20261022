import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import type { PublicInspectionSlot } from '@/objects/inspections'
import {
  inspectionFullDateFormatter,
  inspectionTimeFormatter,
} from '@/pages/ListingDetailPage/functions/inspection-booking-calendar'

type CancelBookingDialogProps = {
  bookedSlot?: PublicInspectionSlot
  cancelError?: string
  isBooking: boolean
  isOpen: boolean
  onCancelBooking: () => void
  onCancelErrorClear: () => void
  onOpenChange: (open: boolean) => void
}

export const CancelBookingDialog = ({
  bookedSlot,
  cancelError,
  isBooking,
  isOpen,
  onCancelBooking,
  onCancelErrorClear,
  onOpenChange,
}: CancelBookingDialogProps) => (
  <AlertDialog
    onOpenChange={(open) => {
      onOpenChange(open)

      if (!open) {
        onCancelErrorClear()
      }
    }}
    open={isOpen}
  >
    <AlertDialogContent className="w-[25rem] max-w-[calc(100%-2rem)] gap-0 overflow-hidden rounded-xl border border-slate-200/60 bg-white p-0 shadow-[0_26px_80px_rgba(15,23,42,0.16)] sm:max-w-[25rem]">
      <AlertDialogHeader className="flex h-[64px] justify-center border-b border-slate-200/80 px-5 text-left">
        <AlertDialogTitle className="text-lg font-semibold tracking-tight text-slate-950">
          Cancel inspection?
        </AlertDialogTitle>
      </AlertDialogHeader>
      <div className="px-5 py-5">
        <AlertDialogDescription className="text-sm leading-6 text-slate-500">
          This will release your inspection slot:
        </AlertDialogDescription>
        {bookedSlot ? (
          <div className="mt-4 flex items-center justify-between gap-3 rounded-[20px] border border-violet-200 bg-violet-50 px-4 py-3.5">
            <p className="text-sm font-semibold tracking-tight text-violet-950">
              {inspectionFullDateFormatter.format(new Date(bookedSlot.startsAt))}, {inspectionTimeFormatter.format(new Date(bookedSlot.startsAt))} -{' '}
              {inspectionTimeFormatter.format(new Date(bookedSlot.endsAt))}
            </p>
            <span className="shrink-0 rounded-full bg-violet-100 px-2.5 py-1 text-[11px] font-semibold text-violet-700">
              Booked
            </span>
          </div>
        ) : null}
        {cancelError ? <p className="mt-3 text-sm font-medium text-rose-600">{cancelError}</p> : null}
      </div>
      <AlertDialogFooter className="flex-row justify-end gap-2.5 border-t border-slate-200/80 px-5 py-3">
        <AlertDialogCancel className="mt-0 inline-flex h-10 items-center justify-center rounded-full border border-slate-200 bg-white px-4 text-sm font-medium leading-none text-slate-700 shadow-sm transition hover:bg-slate-50 hover:text-slate-950">
          Keep
        </AlertDialogCancel>
        <button
          className="inline-flex h-10 items-center justify-center rounded-full border border-rose-200 bg-rose-50 px-4 text-sm font-medium leading-none text-rose-700 shadow-sm transition hover:border-rose-300 hover:bg-rose-100 disabled:cursor-not-allowed disabled:opacity-50"
          disabled={isBooking}
          onClick={onCancelBooking}
          type="button"
        >
          Confirm
        </button>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
)
