import { forwardRef } from 'react'

import {
  AmenityPhoto,
  InlineMessage,
  LoadingState,
} from '@/pages/ListingDetailPage/components/AmenitiesPanel/AmenitiesStates'
import { formatAmenityDistance } from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'
import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'

type AmenityResultsPanelProps = {
  error?: string
  loading: boolean
  onPlaceSelect: (placeId: string) => void
  onScrollTopChange: (scrollTop: number) => void
  places: NearbyAmenity[]
}

export const AmenityResultsPanel = forwardRef<HTMLDivElement, AmenityResultsPanelProps>(
  ({ error, loading, onPlaceSelect, onScrollTopChange, places }, ref) => (
    <>
      <div className="sticky top-0 z-10 border-b border-slate-200 bg-white/98 px-4 py-3 backdrop-blur">
        <h3 className="text-base font-medium text-slate-800">Results</h3>
      </div>

      <div
        className="flex-1 overflow-y-auto px-4 py-4"
        onScroll={(event) => onScrollTopChange(event.currentTarget.scrollTop)}
        ref={ref}
      >
        <div className="space-y-3">
          {loading ? <LoadingState label="Loading places..." compact /> : null}
          {!loading && error ? <InlineMessage message={error} tone="error" /> : null}
          {!loading && !error && places.length === 0 ? (
            <InlineMessage
              message="No places found for this subcategory near the selected listing."
              tone="neutral"
            />
          ) : null}
          {!loading && !error
            ? places.map((place) => (
                <button
                  key={place.id}
                  className="w-full rounded-lg border border-transparent p-2 text-left transition hover:-translate-y-0.5 hover:border-slate-200 hover:bg-slate-50 hover:shadow-sm"
                  onClick={() => onPlaceSelect(place.id)}
                  type="button"
                >
                  <div className="h-40 w-full overflow-hidden rounded-md bg-slate-100">
                    <AmenityPhoto key={`${place.id}-${place.photoUrl ?? 'fallback'}`} place={place} />
                  </div>
                  <div className="mt-3">
                    <div className="truncate text-sm font-medium text-slate-900">{place.name}</div>
                    <div className="mt-1 line-clamp-2 text-xs text-slate-600">{place.address}</div>
                    <div className="mt-2 flex items-center space-x-3 text-xs">
                      {place.rating ? (
                        <div className="flex items-center space-x-1 text-slate-700">
                          <span className="text-amber-500">★</span>
                          <span>{place.rating.toFixed(1)}</span>
                          {place.userRatingCount ? (
                            <span className="text-slate-400">({place.userRatingCount})</span>
                          ) : null}
                        </div>
                      ) : (
                        <div className="text-slate-400">No rating</div>
                      )}
                      <div className="font-medium text-slate-500">{formatAmenityDistance(place.distanceInMeters)}</div>
                    </div>
                  </div>
                </button>
              ))
            : null}
        </div>
      </div>
    </>
  ),
)

AmenityResultsPanel.displayName = 'AmenityResultsPanel'
