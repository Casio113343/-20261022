import type { ListingDetail } from '@/objects/listings'

type FloorPlanPreviewPanelProps = {
  floorPlanImage?: ListingDetail['images'][number]
  listing: ListingDetail
}

export const FloorPlanPreviewPanel = ({ floorPlanImage, listing }: FloorPlanPreviewPanelProps) => (
  <section className="flex min-h-[30rem] min-w-0 flex-1 overflow-hidden rounded-xl border border-slate-200/60 bg-white shadow-lg">
    <div className="flex min-h-0 w-full items-center justify-center bg-slate-50/60 p-5">
      <div className="relative flex h-full min-h-[26rem] w-full items-center justify-center overflow-hidden rounded-[22px] border border-slate-200/70 bg-white">
        {floorPlanImage ? (
          <img
            alt={floorPlanImage.altText ?? `Floor plan for ${listing.addressLine}`}
            className="h-full w-full object-contain p-5"
            src={floorPlanImage.url}
          />
        ) : (
          <p className="px-8 text-center text-sm text-slate-500">
            No floor plan has been nominated for this listing.
          </p>
        )}
      </div>
    </div>
  </section>
)
