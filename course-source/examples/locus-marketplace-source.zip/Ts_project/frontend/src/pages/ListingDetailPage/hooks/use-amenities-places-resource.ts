import { useEffect, useState } from 'react'

import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'

export type AmenitySubcategory = {
  id: string
  types: string[]
}

export type PlacesResource =
  | { status: 'loading' }
  | { status: 'ready'; places: NearbyAmenity[] }
  | { status: 'error'; message: string; places: NearbyAmenity[] }

type UseAmenitiesPlacesResourceArgs = {
  isMapReady: boolean
  locationKey: string
  activeSubcategory: AmenitySubcategory
  mapPosition?: { lat: number; lng: number }
  onError: (message?: string) => void
}

export const useAmenitiesPlacesResource = ({
  isMapReady,
  locationKey,
  activeSubcategory,
  mapPosition,
  onError,
}: UseAmenitiesPlacesResourceArgs) => {
  const resourceKey = `${locationKey}:${activeSubcategory.id}`
  const [resourcesByKey, setResourcesByKey] = useState<Record<string, PlacesResource>>({})
  const resource = resourcesByKey[resourceKey]

  useEffect(() => {
    if (!mapPosition || !isMapReady || resource !== undefined) {
      return
    }

    queueMicrotask(() => {
      onError(undefined)
      setResourcesByKey((current) => ({
        ...current,
        [resourceKey]: { status: 'loading' },
      }))
    })
  }, [isMapReady, mapPosition, onError, resource, resourceKey])

  return {
    resource,
    resourceKey,
    setResourcesByKey,
  }
}
