import { useCallback, useEffect, useRef, useState } from 'react'

import { api } from '@/apis'
import type { PublicInspectionSlot } from '@/objects/inspections'

type UseInspectionSlotsArgs = {
  listingId: string
  onSlotsLoaded: (
    slots: PublicInspectionSlot[],
    isDifferentListing: boolean,
  ) => void
}

export const useInspectionSlots = ({
  listingId,
  onSlotsLoaded,
}: UseInspectionSlotsArgs) => {
  const [slots, setSlots] = useState<PublicInspectionSlot[]>([])
  const latestRequestRef = useRef(0)
  const loadedListingIdRef = useRef<string | undefined>(undefined)

  const refreshSlots = useCallback(async () => {
    const requestId = latestRequestRef.current + 1
    latestRequestRef.current = requestId
    const response = await api.listPublicInspectionSlots(listingId)

    if (requestId !== latestRequestRef.current || !response.ok) {
      return
    }

    const isDifferentListing = loadedListingIdRef.current !== listingId
    loadedListingIdRef.current = listingId
    setSlots(response.data)
    onSlotsLoaded(response.data, isDifferentListing)
  }, [listingId, onSlotsLoaded])

  useEffect(() => {
    const initialRefreshId = window.setTimeout(() => void refreshSlots(), 0)
    const intervalId = window.setInterval(() => void refreshSlots(), 60_000)
    const refreshOnFocus = () => void refreshSlots()
    const refreshWhenVisible = () =>
      document.visibilityState === 'visible' && void refreshSlots()

    window.addEventListener('focus', refreshOnFocus)
    document.addEventListener('visibilitychange', refreshWhenVisible)

    return () => {
      window.clearTimeout(initialRefreshId)
      window.clearInterval(intervalId)
      window.removeEventListener('focus', refreshOnFocus)
      document.removeEventListener('visibilitychange', refreshWhenVisible)
    }
  }, [refreshSlots])

  const replaceSlot = useCallback((replacement: PublicInspectionSlot) => {
    setSlots((current) =>
      current.map((slot) => (slot.id === replacement.id ? replacement : slot)),
    )
  }, [])

  return {
    replaceSlot,
    slots,
  }
}
