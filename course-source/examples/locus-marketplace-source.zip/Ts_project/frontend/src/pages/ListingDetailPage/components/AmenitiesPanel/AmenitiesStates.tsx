import { useState } from 'react'

import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'
import { cn } from '@/utils/class-names'

const propertyLocationFallbackImageUrl = '/fallbacks/property-location.jpg'

const photoUrlWithRetry = (photoUrl: string, retryAttempt: number) =>
  retryAttempt === 0
    ? photoUrl
    : `${photoUrl}${photoUrl.includes('?') ? '&' : '?'}retry=${retryAttempt}`

export const AmenityPhoto = ({ place }: { place: NearbyAmenity }) => {
  const [imageState, setImageState] = useState({
    photoUrl: place.photoUrl,
    retryAttempt: 0,
    showFallback: false,
  })
  const activeImageState =
    imageState.photoUrl === place.photoUrl
      ? imageState
      : {
          photoUrl: place.photoUrl,
          retryAttempt: 0,
          showFallback: false,
        }
  const currentSrc =
    place.photoUrl && !activeImageState.showFallback
      ? photoUrlWithRetry(place.photoUrl, activeImageState.retryAttempt)
      : propertyLocationFallbackImageUrl

  return (
    <img
      alt={place.name}
      className="h-full w-full object-cover"
      onError={() => {
        if (!place.photoUrl || activeImageState.showFallback) {
          return
        }

        setImageState(
          activeImageState.retryAttempt === 0
            ? {
                photoUrl: place.photoUrl,
                retryAttempt: 1,
                showFallback: false,
              }
            : {
                photoUrl: place.photoUrl,
                retryAttempt: activeImageState.retryAttempt,
                showFallback: true,
              },
        )
      }}
      src={currentSrc}
    />
  )
}

export const LoadingState = ({ label, compact = false }: { label: string; compact?: boolean }) => (
  <div
    className={cn(
      'rounded-[24px] border border-dashed border-slate-200 bg-white/70 text-sm text-slate-500',
      compact ? 'px-4 py-4' : 'p-8',
    )}
  >
    {label}
  </div>
)

export const ConfigurationState = ({ message }: { message: string }) => (
  <section className="rounded-xl border border-slate-200/50 bg-white p-8 shadow-lg">
    <InlineMessage message={message} tone="error" />
  </section>
)

export const InlineMessage = ({
  message,
  tone,
}: {
  message: string
  tone: 'error' | 'neutral'
}) => (
  <div
    className={cn(
      'rounded-[20px] border px-4 py-4 text-sm',
      tone === 'error'
        ? 'border-rose-200 bg-rose-50 text-rose-700'
        : 'border-slate-200 bg-slate-50 text-slate-500',
    )}
  >
    {message}
  </div>
)
