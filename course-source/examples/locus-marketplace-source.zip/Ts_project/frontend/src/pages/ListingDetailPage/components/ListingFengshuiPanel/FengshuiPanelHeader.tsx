import type { ReactNode } from 'react'

export const FengshuiPanelHeader = ({ children }: { children: ReactNode }) => (
  <header className="flex h-[64px] shrink-0 items-center border-b border-slate-200/80 bg-white/60 px-5 backdrop-blur">
    {children}
  </header>
)
