import { useEffect, useState } from 'react'

import { loadGoogleMaps } from '@/pages/ListingDetailPage/integrations/google-maps/google-maps-loader'
import type { GeocoderResult, GoogleMapsApi } from '@/pages/ListingDetailPage/objects/google-maps-types'
import type { ListingMapLocationState, ListingMapPosition } from '@/pages/ListingDetailPage/functions/listing-detail'
import { failure, failureFromUnknown, success, type Result } from '@/utils/result'
import type { GoogleMapsEnv } from '@/pages/ListingDetailPage/functions/google-maps-env'

const geocodeListing = (
  mapsApi: GoogleMapsApi,
  address: string,
): Promise<Result<ListingMapPosition>> =>
  new Promise<Result<ListingMapPosition>>((resolve) => {
    const GeocoderConstructor = mapsApi.maps.Geocoder

    if (typeof GeocoderConstructor !== 'function') {
      resolve(failure('library', 'Google Maps geocoder is unavailable'))
      return
    }

    const geocoder = new GeocoderConstructor()

    geocoder.geocode({ address }, (results: GeocoderResult[] | undefined, status: string) => {
      const primaryResult = results?.[0]
      const location = primaryResult?.geometry?.location

      if (status !== 'OK' || !location) {
        resolve(failure('not_found', 'Unable to locate this listing on the map'))
        return
      }

      resolve(success({
        lat: location.lat(),
        lng: location.lng(),
      }))
    })
  })

type UseGeocodedListingPositionArgs = {
  address?: string
  env?: GoogleMapsEnv
  enabled: boolean
}

export const useGeocodedListingPosition = ({
  address,
  env,
  enabled,
}: UseGeocodedListingPositionArgs): ListingMapLocationState => {
  const [state, setState] = useState<ListingMapLocationState>({ status: 'idle' })
  const [geocodedPositions, setGeocodedPositions] = useState<Record<string, ListingMapPosition>>({})
  const cachedPosition = address ? geocodedPositions[address] : undefined

  useEffect(() => {
    if (!enabled || address === undefined || cachedPosition === undefined) {
      return
    }

    queueMicrotask(() =>
      setState({
        status: 'ready',
        position: cachedPosition,
      }),
    )
  }, [address, cachedPosition, enabled])

  useEffect(() => {
    if (!enabled || address === undefined || env === undefined || cachedPosition !== undefined) {
      return
    }

    queueMicrotask(() => setState({ status: 'loading' }))
  }, [address, cachedPosition, enabled, env])

  useEffect(() => {
    if (!enabled || address === undefined || env === undefined || cachedPosition !== undefined) {
      return
    }

    let cancelled = false

    loadGoogleMaps(env)
      .then((mapsApi) => geocodeListing(mapsApi, address))
      .catch((error: unknown) => failureFromUnknown(error, 'library', 'Unable to load map location'))
      .then((result) => {
        if (cancelled) {
          return
        }

        if (!result.ok) {
          setState({
            status: 'error',
            message: result.error.message,
          })
          return
        }

        setGeocodedPositions((current) => ({
          ...current,
          [address]: result.data,
        }))
        setState({
          status: 'ready',
          position: result.data,
        })
      })

    return () => {
      cancelled = true
    }
  }, [address, cachedPosition, enabled, env])

  return state
}
