import type { GoogleMapsEnv } from '@/pages/ListingDetailPage/functions/google-maps-env'
import type {
  GeocodingLibrary,
  GoogleMapsApi,
  MarkerLibrary,
} from '@/pages/ListingDetailPage/objects/google-maps-types'

const buildScriptUrl = ({ apiKey, mapId }: GoogleMapsEnv) => {
  const params = new URLSearchParams({
    key: apiKey,
    libraries: 'places,marker,geocoding',
    loading: 'async',
  })

  if (mapId) {
    params.set('map_ids', mapId)
  }

  return `https://maps.googleapis.com/maps/api/js?${params.toString()}`
}

const waitForConstructor = async <T>(
  resolveConstructor: () => T | undefined | Promise<T | undefined>,
  errorMessage: string,
): Promise<T> => {
  const maxAttempts = 60
  const retryDelayInMs = 100

  const attempt = async (remainingAttempts: number): Promise<T> => {
    const constructor = await resolveConstructor()

    if (constructor !== undefined) {
      return constructor
    }

    if (remainingAttempts <= 1) {
      throw new Error(errorMessage)
    }

    await new Promise<void>((resolve) => {
      window.setTimeout(resolve, retryDelayInMs)
    })

    return attempt(remainingAttempts - 1)
  }

  return attempt(maxAttempts)
}

export const ensureGeocodingLibrary = async (
  googleApi: GoogleMapsApi,
): Promise<GeocodingLibrary | undefined> =>
  googleApi.geocoding ??
  (typeof googleApi.maps.importLibrary === 'function'
    ? ((await googleApi.maps.importLibrary('geocoding')) as GeocodingLibrary | undefined)
    : undefined)

export const ensureMarkerLibrary = async (
  googleApi: GoogleMapsApi,
): Promise<MarkerLibrary | undefined> =>
  googleApi.marker ??
  googleApi.maps.marker ??
  (typeof googleApi.maps.importLibrary === 'function'
    ? ((await googleApi.maps.importLibrary('marker')) as MarkerLibrary | undefined)
    : undefined)

const ensureGeocoderConstructor = (googleApi: GoogleMapsApi) =>
  waitForConstructor(
    async () => {
      try {
        const geocodingLibrary = await ensureGeocodingLibrary(googleApi)
        return geocodingLibrary?.Geocoder ?? googleApi.maps.Geocoder
      } catch {
        return googleApi.maps.Geocoder
      }
    },
    'Google Maps geocoder is unavailable',
  )

const enrichGoogleMapsApi = async (googleApi: GoogleMapsApi): Promise<GoogleMapsApi> => {
  if (typeof googleApi.maps.importLibrary === 'function') {
    await googleApi.maps.importLibrary('maps')
  }

  const geocodingLibrary = await ensureGeocodingLibrary(googleApi)
  const markerLibrary = await ensureMarkerLibrary(googleApi)
  const GeocoderConstructor = await ensureGeocoderConstructor(googleApi)

  return {
    ...googleApi,
    maps: {
      ...googleApi.maps,
      Geocoder: GeocoderConstructor,
    },
    geocoding: geocodingLibrary,
    marker: markerLibrary,
  }
}

const resolveLoadedGoogleMapsApi = () =>
  window.google?.maps
    ? enrichGoogleMapsApi(window.google)
    : Promise.reject(new Error('Google Maps loaded without an API object'))

export const loadGoogleMaps = (env: GoogleMapsEnv): Promise<GoogleMapsApi> => {
  if (window.__harbouredGoogleMapsPromise__) {
    return window.__harbouredGoogleMapsPromise__
  }

  if (window.google?.maps) {
    const mapsPromise = resolveLoadedGoogleMapsApi()
    window.__harbouredGoogleMapsPromise__ = mapsPromise
    return mapsPromise
  }

  const pendingPromise = new Promise<GoogleMapsApi>((resolve, reject) => {
    const existingScript = document.querySelector<HTMLScriptElement>('script[data-google-maps-loader="harboured"]')

    if (existingScript) {
      if (window.google?.maps) {
        resolveLoadedGoogleMapsApi().then(resolve).catch(reject)
        return
      }

      existingScript.addEventListener('load', () => {
        resolveLoadedGoogleMapsApi().then(resolve).catch(reject)
      })

      existingScript.addEventListener('error', () => reject(new Error('Unable to load Google Maps')))
      return
    }

    const script = document.createElement('script')
    script.async = true
    script.defer = true
    script.src = buildScriptUrl(env)
    script.dataset.googleMapsLoader = 'harboured'
    script.onload = () => {
      resolveLoadedGoogleMapsApi().then(resolve).catch(reject)
    }
    script.onerror = () => reject(new Error('Unable to load Google Maps'))
    document.head.appendChild(script)
  })

  window.__harbouredGoogleMapsPromise__ = pendingPromise.catch((error) => {
    window.__harbouredGoogleMapsPromise__ = undefined
    throw error
  })

  return window.__harbouredGoogleMapsPromise__
}
