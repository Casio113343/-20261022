export type GoogleMapsEnv = {
  apiKey: string
  mapId?: string
}

const normalizeEnvValue = (value?: string) => value?.trim() || undefined

export const googleMapsConfigMessage =
  'Google Maps is not configured. Add the Vite Google Maps variables to frontend/.env and restart the dev server.'

export const getGoogleMapsEnv = (): GoogleMapsEnv | undefined => {
  const apiKey = normalizeEnvValue(import.meta.env.VITE_GOOGLE_MAPS_API_KEY)
  const mapId = normalizeEnvValue(import.meta.env.VITE_GOOGLE_VECTOR_MAP_ID_EXCLUDE_POI)

  return apiKey
    ? {
        apiKey,
        mapId,
      }
    : undefined
}
