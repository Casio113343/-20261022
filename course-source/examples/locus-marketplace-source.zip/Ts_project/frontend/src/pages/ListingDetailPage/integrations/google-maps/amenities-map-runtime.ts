import type { MutableRefObject } from 'react'

import type {
  AdvancedMarkerElementInstance,
  GoogleMapsApi,
  MapInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'
import type { GoogleMapsEnv } from '@/pages/ListingDetailPage/functions/google-maps-env'
import { ensureMarkerLibrary, loadGoogleMaps } from '@/pages/ListingDetailPage/integrations/google-maps/google-maps-loader'
import { failure, failureFromUnknown, success, type Result } from '@/utils/result'

import { setMarkerMap } from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'

type MapPosition = { lat: number; lng: number }

export const AMENITIES_INITIAL_ZOOM = 14

type InitializeAmenitiesMapArgs = {
  clearSelectedMarker: () => void
  env: GoogleMapsEnv
  hasRegisteredMapClickRef: MutableRefObject<boolean>
  listingMarkerRef: MutableRefObject<AdvancedMarkerElementInstance | undefined>
  mapContainer: HTMLDivElement
  mapPosition: MapPosition
  mapRef: MutableRefObject<MapInstance | undefined>
}

export const initializeAmenitiesMap = async ({
  clearSelectedMarker,
  env,
  hasRegisteredMapClickRef,
  listingMarkerRef,
  mapContainer,
  mapPosition,
  mapRef,
}: InitializeAmenitiesMapArgs): Promise<Result<AdvancedMarkerElementInstance>> => {
  let mapsApi: GoogleMapsApi

  try {
    mapsApi = await loadGoogleMaps(env)
  } catch (error: unknown) {
    return failureFromUnknown(error, 'library', 'Unable to initialise the map')
  }

  const markerLibrary = await ensureMarkerLibrary(mapsApi)

  if (!markerLibrary?.AdvancedMarkerElement || !markerLibrary.PinElement) {
    return failure('library', 'Google Maps marker library is unavailable')
  }

  const map =
    mapRef.current ??
    new mapsApi.maps.Map(mapContainer, {
      center: mapPosition,
      zoom: AMENITIES_INITIAL_ZOOM,
      mapId: env.mapId,
      disableDefaultUI: true,
      gestureHandling: 'greedy',
    })

  mapRef.current = map
  map.panTo(mapPosition)

  if (listingMarkerRef.current) {
    setMarkerMap(listingMarkerRef.current, undefined)
  }

  const listingMarker = new markerLibrary.AdvancedMarkerElement({
    map,
    position: mapPosition,
    content: new markerLibrary.PinElement({
      background: '#ef4444',
      borderColor: '#dc2626',
      glyphColor: '#ffffff',
      scale: 1.2,
    }).element,
    zIndex: 10,
  })
  listingMarkerRef.current = listingMarker

  if (!hasRegisteredMapClickRef.current) {
    hasRegisteredMapClickRef.current = true
    map.addListener('click', clearSelectedMarker)
  }

  return success(listingMarker)
}
