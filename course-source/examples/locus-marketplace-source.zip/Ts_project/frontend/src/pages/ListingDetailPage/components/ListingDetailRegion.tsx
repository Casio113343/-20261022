import { ListingAmenitiesPanel } from '@/pages/ListingDetailPage/components/AmenitiesPanel'
import { InspectionBookingPanel } from '@/pages/ListingDetailPage/components/InspectionBookingPanel'
import { ListingFengshuiPanel } from '@/pages/ListingDetailPage/components/ListingFengshuiPanel'
import { ListingOverviewPanel } from '@/pages/ListingDetailPage/components/ListingOverviewPanel'
import { ListingStreetViewPanel } from '@/pages/ListingDetailPage/components/ListingStreetViewPanel'
import type { ListingDetailSectionId, ListingMapLocationState } from '@/pages/ListingDetailPage/functions/listing-detail'
import { MessagingSurface } from '@/pages/shared/messaging/MessagingSurface'
import type { ListingDetail } from '@/objects/listings'
import type { User } from '@/objects/identity'
import type { useMessagingSession } from '@/pages/shared/hooks/use-messaging-session'
import { recordListingAnalyticsEvent } from '@/pages/shared/analytics/record-listing-analytics'

type ListingDetailRegionProps = {
  activeImageIndex: number
  activeSection: ListingDetailSectionId
  handleTypingChange: (conversationId: string, isTyping: boolean) => void
  listing: ListingDetail
  locationState: ListingMapLocationState
  messaging: ReturnType<typeof useMessagingSession>
  onImageChange: (index: number) => void
  onToggleSave: (listingId: string) => void
  savedIds: string[]
  isAuthenticated: boolean
  user: User | undefined
}

export const ListingDetailRegion = ({
  activeImageIndex,
  activeSection,
  handleTypingChange,
  listing,
  locationState,
  messaging,
  onImageChange,
  onToggleSave,
  savedIds,
  isAuthenticated,
  user,
}: ListingDetailRegionProps) => {
  const isSaved = savedIds.includes(listing.id)
  const listingConversations = messaging.conversations.filter((conversation) => conversation.listing.id === listing.id)
  const selectedListingConversationId =
    listingConversations.some((conversation) => conversation.id === messaging.selectedConversationId)
      ? messaging.selectedConversationId
      : undefined

  if (activeSection === 'overview') {
    return (
      <ListingOverviewPanel
        activeImageIndex={activeImageIndex}
        isSaved={isSaved}
        listing={listing}
        onImageChange={onImageChange}
        onToggleSave={onToggleSave}
      />
    )
  }

  if (activeSection === 'amenities') {
    return (
      <ListingAmenitiesPanel
        key={`amenities-${listing.id}`}
        listingId={listing.id}
        locationState={locationState}
      />
    )
  }

  if (activeSection === 'street-view') {
    return (
      <ListingStreetViewPanel
        key={`street-view-${listing.id}`}
        listing={listing}
        locationState={locationState}
      />
    )
  }

  if (activeSection === 'messages') {
    return user && isAuthenticated ? (
      <MessagingSurface
        connectionState={messaging.connectionState}
        conversations={listingConversations}
        currentUserId={user.id}
        isListingSaved={isSaved}
        listingContext={listing}
        messages={messaging.selectedMessages}
        onQueueFiles={messaging.queueFiles}
        onSelectConversation={messaging.selectConversation}
        onSendMessage={async (body, pendingAttachments) => {
          const conversationId =
            selectedListingConversationId ??
            (user.role === 'buyer_renter'
                ? (await messaging.startConversation(listing.id).then((conversation) => {
                  if (conversation) {
                    recordListingAnalyticsEvent(listing.id, 'message_start', { action: 'conversation_started' })
                  }

                  return conversation
                }))?.id
              : undefined)

          if (!conversationId) {
            return { ok: false, message: 'Conversation is not ready yet.' }
          }

          return messaging.sendMessage(conversationId, body, pendingAttachments)
        }}
        onToggleListingSave={onToggleSave}
        onTypingChange={handleTypingChange}
        selectedConversationId={selectedListingConversationId}
        typingUserIds={selectedListingConversationId ? (messaging.typingUserIds[selectedListingConversationId] ?? []) : []}
        variant="listing"
      />
    ) : (
      <div className="flex h-full items-center justify-center rounded-xl border border-slate-200 bg-white text-sm text-slate-500 shadow-lg">
        Sign in to message the agent.
      </div>
    )
  }

  if (activeSection === 'inspections') {
    return <InspectionBookingPanel listing={listing} isAuthenticated={isAuthenticated} />
  }

  return <ListingFengshuiPanel listing={listing} />
}
