import { useLayoutEffect, useRef } from 'react'

import { AmenityDetailPage } from '@/pages/ListingDetailPage/components/AmenitiesPanel/AmenityDetailPage'
import { AmenityResultsPanel } from '@/pages/ListingDetailPage/components/AmenitiesPanel/AmenityResultsPanel'
import type { AmenityDetailResource } from '@/pages/ListingDetailPage/functions/amenity-details'
import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'

type AmenitiesResultsListProps = {
  places: NearbyAmenity[]
  selectedPlace?: NearbyAmenity
  selectedPlaceResource: AmenityDetailResource
  loading: boolean
  error?: string
  onBackToResults: () => void
  onPlaceSelect: (placeId: string) => void
}

export const AmenitiesResultsList = ({
  places,
  selectedPlace,
  selectedPlaceResource,
  loading,
  error,
  onBackToResults,
  onPlaceSelect,
}: AmenitiesResultsListProps) => {
  const resultsScrollContainerRef = useRef<HTMLDivElement>(null)
  const resultsScrollTopRef = useRef(0)

  useLayoutEffect(() => {
    if (!selectedPlace && resultsScrollContainerRef.current) {
      resultsScrollContainerRef.current.scrollTop = resultsScrollTopRef.current
    }
  }, [selectedPlace])

  const handlePlaceSelect = (placeId: string) => {
    resultsScrollTopRef.current =
      resultsScrollContainerRef.current?.scrollTop ?? resultsScrollTopRef.current
    onPlaceSelect(placeId)
  }

  return (
    <div className="flex min-h-[18rem] min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-slate-200/50 bg-white/92 shadow-lg">
      {selectedPlace ? (
        <AmenityDetailPage
          onExit={onBackToResults}
          place={selectedPlace}
          resource={selectedPlaceResource}
        />
      ) : (
        <AmenityResultsPanel
          error={error}
          loading={loading}
          onPlaceSelect={handlePlaceSelect}
          onScrollTopChange={(scrollTop) => {
            resultsScrollTopRef.current = scrollTop
          }}
          places={places}
          ref={resultsScrollContainerRef}
        />
      )}
    </div>
  )
}
