import { ListingDetailRegion } from '@/pages/ListingDetailPage/components/ListingDetailRegion'
import { ListingDetailSectionRail } from '@/pages/ListingDetailPage/components/ListingDetailSectionRail'
import { useListingDetailPage } from '@/pages/ListingDetailPage/hooks/use-listing-detail-page'

export default function ListingDetailPage() {
  const page = useListingDetailPage()

  if (page.error) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="rounded-[32px] bg-white p-8 text-center text-sm text-slate-500 shadow-[0_20px_60px_rgba(15,23,42,0.05)] ring-1 ring-slate-200/80">
          {page.error}
        </div>
      </div>
    )
  }

  if (page.isLoading || !page.listing) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 text-sm text-slate-500 sm:px-6 lg:px-8">
        Loading property details...
      </div>
    )
  }

  return (
    <div className="min-h-[calc(100vh-81px)] bg-[radial-gradient(circle_at_18%_12%,rgba(147,197,253,0.36),transparent_34%),radial-gradient(circle_at_82%_8%,rgba(186,230,253,0.42),transparent_30%),linear-gradient(180deg,#eff6ff_0%,#eaf3ff_48%,#f5f9ff_100%)] px-4 pt-4 pb-4 sm:px-6 lg:px-8">
      <div className="flex min-h-0 flex-col gap-4 pt-9 pb-1 lg:h-[calc(100vh-8.5rem)] lg:flex-row">
        <aside className="shrink-0">
          <ListingDetailSectionRail
            activeSection={page.activeSection}
            onSelect={page.setActiveSection}
          />
        </aside>

        <main className="min-w-0 flex-1">
          <ListingDetailRegion
            activeImageIndex={page.activeImageIndex}
            activeSection={page.activeSection}
            handleTypingChange={page.handleTypingChange}
            listing={page.listing}
            locationState={page.locationState}
            messaging={page.messaging}
            onImageChange={page.setActiveImageIndex}
            onToggleSave={page.toggleSaved}
            savedIds={page.savedIds}
            isAuthenticated={page.isAuthenticated}
            user={page.user}
          />
        </main>
      </div>
    </div>
  )
}
