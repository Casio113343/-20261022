import { Navigation } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'

import type { ListingDetail } from '@/objects/listings'
import { getGoogleMapsEnv } from '@/pages/ListingDetailPage/functions/google-maps-env'
import { loadGoogleMaps } from '@/pages/ListingDetailPage/integrations/google-maps/google-maps-loader'
import type { StreetViewPanoramaInstance } from '@/pages/ListingDetailPage/objects/google-maps-types'
import type { ListingMapLocationState } from '@/pages/ListingDetailPage/functions/listing-detail'
import { listingAddress } from '@/pages/ListingDetailPage/functions/listing-detail'

type ListingStreetViewPanelProps = {
  listing: ListingDetail
  locationState: ListingMapLocationState
}

export const ListingStreetViewPanel = ({
  listing,
  locationState,
}: ListingStreetViewPanelProps) => {
  // React DOM refs are nullable until the element mounts; keep null at this boundary only.
  const streetViewRef = useRef<HTMLDivElement>(null)
  const panoramaRef = useRef<StreetViewPanoramaInstance | undefined>(undefined)
  const [statusMessage, setStatusMessage] = useState<string>()
  const locationKey =
    locationState.status === 'ready'
      ? `${locationState.position.lat}:${locationState.position.lng}`
      : locationState.status
  const position = locationState.status === 'ready' ? locationState.position : undefined

  useEffect(() => {
    if (!position || !streetViewRef.current) {
      return
    }

    const env = getGoogleMapsEnv()

    if (!env) {
      return
    }

    let cancelled = false

    loadGoogleMaps(env)
      .then((mapsApi) => {
        if (cancelled || !streetViewRef.current) {
          return
        }

        panoramaRef.current =
          panoramaRef.current ??
          new mapsApi.maps.StreetViewPanorama(streetViewRef.current, {
            position,
            pov: { heading: 140, pitch: 0 },
            zoom: 1,
            addressControl: true,
            fullscreenControl: true,
            linksControl: true,
            motionTracking: false,
            showRoadLabels: true,
          })

        panoramaRef.current.setPosition(position)
        panoramaRef.current.addListener('status_changed', () => {
          const nextStatus = panoramaRef.current?.getStatus?.()
          setStatusMessage(
            nextStatus === 'OK'
              ? undefined
              : 'Street View is not available for the exact frontage of this listing.',
          )
        })
      })
      .catch((loadError: unknown) => {
        if (!cancelled) {
          setStatusMessage(
            loadError instanceof Error ? loadError.message : 'Unable to load Street View',
          )
        }
      })

    return () => {
      cancelled = true
    }
  }, [locationKey, position])

  if (locationState.status === 'missing-config' || locationState.status === 'error') {
    return (
      <section className="rounded-xl border border-slate-200/50 bg-white p-8 shadow-lg">
        <p className="rounded-[22px] border border-rose-200 bg-rose-50 px-4 py-4 text-sm text-rose-700">
          {locationState.message}
        </p>
      </section>
    )
  }

  if (locationState.status === 'idle' || locationState.status === 'loading') {
    return (
      <section className="h-full rounded-xl border border-slate-200/50 bg-white p-8 shadow-lg">
        <p className="rounded-[22px] border border-slate-200 bg-slate-50 px-4 py-4 text-sm text-slate-500">
          Preparing Street View...
        </p>
      </section>
    )
  }

  return (
    <div className="h-full overflow-hidden rounded-xl border border-slate-200/50 bg-white shadow-lg">
      <div className="relative h-full min-h-[420px] bg-slate-100">
        <div className="absolute inset-0" ref={streetViewRef} />
        <div className="pointer-events-none absolute left-5 top-5 rounded-full bg-white/92 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-slate-700 shadow-sm">
          Street View
        </div>
        <div className="pointer-events-none absolute bottom-5 left-5 max-w-md rounded-[26px] border border-white/70 bg-white/92 p-5 shadow-[0_18px_40px_rgba(15,23,42,0.12)] backdrop-blur">
          <div className="flex items-center gap-3 text-slate-900">
            <Navigation className="h-4 w-4" />
            <p className="text-sm font-semibold tracking-tight">{listingAddress(listing)}</p>
          </div>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            Use Street View to inspect the immediate frontage and surrounding streetscape.
          </p>
          {statusMessage ? (
            <p className="mt-4 rounded-[18px] border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
              {statusMessage}
            </p>
          ) : null}
        </div>
      </div>
    </div>
  )
}
