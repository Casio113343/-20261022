import { useEffect, useRef, useState } from 'react'

import {
  amenityDetailsTimeoutInMs,
  fetchAmenityDetailResource,
  type AmenityDetailResource,
} from '@/pages/ListingDetailPage/functions/amenity-details'
import type { ListingMapPosition, NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'

type UseSelectedAmenityDetailsArgs = {
  origin?: ListingMapPosition
  selectedPlace?: NearbyAmenity
}

export const useSelectedAmenityDetails = ({
  origin,
  selectedPlace,
}: UseSelectedAmenityDetailsArgs) => {
  const [resourcesByPlaceId, setResourcesByPlaceId] = useState<Record<string, AmenityDetailResource>>({})
  const requestedPlaceIdsRef = useRef<Set<string>>(new Set())
  const resource = selectedPlace ? resourcesByPlaceId[selectedPlace.id] : undefined

  useEffect(() => {
    if (!origin || !selectedPlace || requestedPlaceIdsRef.current.has(selectedPlace.id)) {
      return
    }

    const placeId = selectedPlace.id
    requestedPlaceIdsRef.current.add(placeId)
    const watchdogId = window.setTimeout(() => {
      setResourcesByPlaceId((current) => (
        current[placeId] === undefined
          ? {
              ...current,
              [placeId]: {
                status: 'error',
                message: 'Place details are taking too long to load.',
              },
            }
          : current
      ))
    }, amenityDetailsTimeoutInMs * 2 + 1000)

    fetchAmenityDetailResource(origin, selectedPlace)
      .then((nextResource) => {
        window.clearTimeout(watchdogId)
        setResourcesByPlaceId((current) => ({
          ...current,
          [placeId]: nextResource,
        }))
      })
      .catch(() => {
        window.clearTimeout(watchdogId)
        setResourcesByPlaceId((current) => ({
          ...current,
          [placeId]: {
            status: 'error',
            message: 'Unable to load place details and travel times.',
          },
        }))
      })

    return () => {
      window.clearTimeout(watchdogId)
    }
  }, [origin, selectedPlace])

  return resource ?? (selectedPlace ? { status: 'loading' as const } : { status: 'idle' as const })
}
