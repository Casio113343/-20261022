import { useEffect, useState } from 'react'

import { api } from '@/apis'
import type { FengshuiAnalysis } from '@/objects/fengshui'
import {
  readCachedFengshuiAnalysis,
  writeCachedFengshuiAnalysis,
} from '@/pages/ListingDetailPage/storage/fengshui-analysis-cache'
import { useSession } from '@/pages/shared/auth/session-store'

export type AnalysisState =
  | { status: 'idle' | 'loading' }
  | { status: 'result'; analysis: FengshuiAnalysis }
  | { status: 'error'; message: string }

export const useFengshuiAnalysis = (listingId: string, enabled: boolean) => {
  const isAuthenticated = useSession((session) => session.isAuthenticated)
  const [analysisState, setAnalysisState] = useState<AnalysisState>({ status: 'idle' })

  useEffect(() => {
    let active = true

    const loadAnalysis = async () => {
      await Promise.resolve()

      if (!active) {
        return
      }

      if (!enabled) {
        setAnalysisState({ status: 'idle' })
        return
      }

      const cachedAnalysis = readCachedFengshuiAnalysis(listingId)

      if (cachedAnalysis) {
        setAnalysisState({ status: 'result', analysis: cachedAnalysis.analysis })

        if (!isAuthenticated) {
          return
        }
      } else {
        setAnalysisState({ status: 'loading' })
      }

      if (isAuthenticated) {
        const savedResponse = await api.getSavedFloorPlanAnalysis({ listingId })

        if (!active) {
          return
        }

        if (savedResponse.ok && savedResponse.data.savedAnalysis) {
          const savedAnalysis = savedResponse.data.savedAnalysis.analysis
          writeCachedFengshuiAnalysis(listingId, { analysis: savedAnalysis })
          setAnalysisState({ status: 'result', analysis: savedAnalysis })
          return
        }
      }

      if (cachedAnalysis) {
        return
      }

      if (!isAuthenticated) {
        setAnalysisState({
          status: 'error',
          message: 'Sign in to generate Feng Shui analysis for this floor plan.',
        })
        return
      }

      const analysisResponse = await api.analyseFloorPlan({ listingId })

      if (!active) {
        return
      }

      if (analysisResponse.ok) {
        const analysis = analysisResponse.data
        writeCachedFengshuiAnalysis(listingId, { analysis })
        setAnalysisState({ status: 'result', analysis })
        return
      }

      setAnalysisState({ status: 'error', message: analysisResponse.error.message })
    }

    void loadAnalysis()

    return () => {
      active = false
    }
  }, [enabled, listingId, isAuthenticated])

  return {
    analysisState,
  }
}
