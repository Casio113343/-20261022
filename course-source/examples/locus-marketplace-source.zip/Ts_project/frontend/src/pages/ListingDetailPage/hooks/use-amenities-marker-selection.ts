import { useCallback, useRef } from 'react'

import type {
  AdvancedMarkerElementInstance,
  MapInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'
import type {
  MarkerView,
} from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'
import { setMarkerMap } from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'

type UseAmenitiesMarkerSelectionArgs = {
  mapRef: { current: MapInstance | undefined }
  markerViewsRef: { current: WeakMap<AdvancedMarkerElementInstance, MarkerView> }
  setSelectedPlaceId: (value: string | undefined) => void
}

export const useAmenitiesMarkerSelection = ({
  mapRef,
  markerViewsRef,
  setSelectedPlaceId,
}: UseAmenitiesMarkerSelectionArgs) => {
  const selectedMarkerRef = useRef<AdvancedMarkerElementInstance | undefined>(undefined)

  const applyGlow = useCallback((marker: AdvancedMarkerElementInstance) => {
    const view = markerViewsRef.current.get(marker)

    if (!view) {
      return
    }

    view.container.classList.add('amenity-marker-hover')
    const filterId = view.path.ownerSVGElement?.dataset.filterId

    if (filterId) {
      view.path.setAttribute('filter', `url(#${filterId})`)
    }

    marker.zIndex = 100
  }, [markerViewsRef])

  const removeGlow = useCallback((marker: AdvancedMarkerElementInstance) => {
    const view = markerViewsRef.current.get(marker)

    if (!view) {
      return
    }

    view.container.classList.remove('amenity-marker-hover')
    view.path.removeAttribute('filter')
    marker.zIndex = view.container.classList.contains('amenity-marker-selected') ? 50 : 10
  }, [markerViewsRef])

  const applySelected = useCallback((marker: AdvancedMarkerElementInstance) => {
    const view = markerViewsRef.current.get(marker)

    if (!view) {
      return
    }

    view.container.classList.add('amenity-marker-selected')
    view.label.classList.add('amenity-marker-label-visible')
    applyGlow(marker)
    marker.zIndex = 50
  }, [applyGlow, markerViewsRef])

  const removeSelected = useCallback((marker: AdvancedMarkerElementInstance) => {
    const view = markerViewsRef.current.get(marker)

    if (!view) {
      return
    }

    view.container.classList.remove('amenity-marker-selected')
    view.label.classList.remove('amenity-marker-label-visible')
    view.path.removeAttribute('filter')
    marker.zIndex = 10
  }, [markerViewsRef])

  const clearSelectedMarker = useCallback(() => {
    const selectedMarker = selectedMarkerRef.current

    if (selectedMarker) {
      removeSelected(selectedMarker)
      selectedMarkerRef.current = undefined
    }

    setSelectedPlaceId(undefined)
  }, [removeSelected, setSelectedPlaceId])

  const hideMarker = useCallback((marker: AdvancedMarkerElementInstance) => {
    setMarkerMap(marker, undefined)
    removeGlow(marker)
    removeSelected(marker)
  }, [removeGlow, removeSelected])

  const openMarker = useCallback((marker: AdvancedMarkerElementInstance, placeId: string) => {
    if (selectedMarkerRef.current && selectedMarkerRef.current !== marker) {
      removeSelected(selectedMarkerRef.current)
    }

    const map = mapRef.current

    if (map) {
      setMarkerMap(marker, map)
    }

    selectedMarkerRef.current = marker
    setSelectedPlaceId(placeId)
    applySelected(marker)
    if (marker.position !== undefined) {
      mapRef.current?.panTo(marker.position)
    }
  }, [applySelected, mapRef, removeSelected, setSelectedPlaceId])

  return {
    applyGlow,
    clearSelectedMarker,
    hideMarker,
    openMarker,
    removeGlow,
    removeSelected,
    selectedMarkerRef,
  }
}
