import type { FengshuiAnalysis } from '@/objects/fengshui'

export type CachedFengshuiAnalysis = {
  analysis: FengshuiAnalysis
  savedAt: string
}

type CachedFengshuiAnalyses = Record<string, CachedFengshuiAnalysis>

const storageKey = 'au-property-marketplace-fengshui-analyses'

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value)

const isCachedAnalysis = (value: unknown): value is CachedFengshuiAnalysis =>
  isRecord(value) &&
  isRecord(value.analysis) &&
  typeof value.savedAt === 'string'

const parseCache = (rawValue: string | null): CachedFengshuiAnalyses => {
  if (!rawValue) {
    return {}
  }

  try {
    const parsed = JSON.parse(rawValue)

    return isRecord(parsed)
      ? Object.fromEntries(
          Object.entries(parsed).filter((entry): entry is [string, CachedFengshuiAnalysis] =>
            isCachedAnalysis(entry[1]),
          ),
        )
      : {}
  } catch {
    return {}
  }
}

const readCache = (): CachedFengshuiAnalyses =>
  typeof window === 'undefined' ? {} : parseCache(window.localStorage.getItem(storageKey))

export const readCachedFengshuiAnalysis = (listingId: string): CachedFengshuiAnalysis | undefined =>
  readCache()[listingId]

export const writeCachedFengshuiAnalysis = (
  listingId: string,
  cachedAnalysis: Omit<CachedFengshuiAnalysis, 'savedAt'>,
) => {
  if (typeof window === 'undefined') {
    return
  }

  const nextCache = {
    ...readCache(),
    [listingId]: {
      ...cachedAnalysis,
      savedAt: new Date().toISOString(),
    },
  }

  window.localStorage.setItem(storageKey, JSON.stringify(nextCache))
}
