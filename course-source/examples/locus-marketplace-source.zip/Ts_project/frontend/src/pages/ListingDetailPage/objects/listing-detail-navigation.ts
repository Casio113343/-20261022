import type { ListingViewSource } from '@/pages/shared/analytics/record-listing-analytics'

export type ListingDetailLocationState = {
  listingViewSource?: ListingViewSource
}

export const listingDetailState = (
  listingViewSource: ListingViewSource,
): ListingDetailLocationState => ({
  listingViewSource,
})

export const listingViewSourceFromState = (state: unknown): ListingViewSource =>
  typeof state === 'object' &&
  state !== null &&
  'listingViewSource' in state
    ? ((state as ListingDetailLocationState).listingViewSource ?? 'direct_link')
    : 'direct_link'
