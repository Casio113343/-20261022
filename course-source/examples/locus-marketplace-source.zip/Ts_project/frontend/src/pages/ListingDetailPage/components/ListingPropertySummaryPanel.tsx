import { Heart } from 'lucide-react'

import { PropertyFacts } from '@/pages/shared/marketplace/components/PropertyFacts'
import type { ListingDetail } from '@/objects/listings'
import { listingPropertyDescription } from '@/pages/ListingDetailPage/functions/listing-detail'
import { formatPrice, formatPropertyLabel } from '@/pages/shared/marketplace/functions/marketplace-format'

type ListingPropertySummaryPanelProps = {
  isSaved?: boolean
  listing: ListingDetail
  onToggleSave?: (listingId: string) => void
}

export const ListingPropertySummaryPanel = ({
  isSaved = false,
  listing,
  onToggleSave,
}: ListingPropertySummaryPanelProps) => {
  const propertyDescription = listingPropertyDescription(listing)
  const propertyLabel = formatPropertyLabel(
    listing.propertyType,
    listing.houseSubtype ?? listing.apartmentSubtype,
  )

  return (
    <div className="flex min-h-[22rem] min-w-0 flex-col overflow-hidden rounded-xl border border-slate-200/60 bg-white/96 shadow-lg xl:w-[34%] xl:max-w-[34%]">
      <div className="min-h-0 flex-1 overflow-y-auto p-6">
        <div className="space-y-6">
          <div className="flex items-start justify-between gap-4 border-b border-slate-200/80 pb-5">
            <div className="min-w-0 flex-1">
              <p className="text-4xl font-semibold tracking-tight text-slate-950">
                {formatPrice(listing.price, listing.transactionType)}
              </p>
            </div>

            {onToggleSave ? (
              <button
                aria-label="Save listing"
                className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-700 shadow-sm hover:border-slate-300"
                onClick={() => onToggleSave(listing.id)}
                type="button"
              >
                <Heart className={`h-4 w-4 ${isSaved ? 'fill-current text-rose-600' : ''}`} />
              </button>
            ) : null}
          </div>

          <div>
            <div className="space-y-1">
              <h1 className="text-[2rem] font-semibold leading-tight tracking-tight text-slate-950">
                {`${listing.addressLine},`}
              </h1>
              <p className="text-[2rem] font-semibold leading-tight tracking-tight text-slate-950">
                {[listing.suburb, listing.state, listing.postcode].filter(Boolean).join(', ')}
              </p>
            </div>
            <div className="mt-4 border-y border-slate-200/80 py-4">
              <p className="text-[2rem] font-semibold leading-tight tracking-tight text-slate-900">
                {propertyLabel}
              </p>
            </div>
          </div>

          <PropertyFacts
            propertyType={listing.propertyType}
            bathrooms={listing.bathrooms}
            bedrooms={listing.bedrooms}
            buildingSize={listing.buildingSize}
            carSpaces={listing.carSpaces}
            landSize={listing.landSize}
          />

          <div className="rounded-[26px] border border-slate-200/80 bg-[linear-gradient(180deg,rgba(250,251,253,0.94),rgba(245,247,250,0.94))] p-4">
            <div className="mb-3">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">
                Property Description
              </p>
            </div>
            <p className="whitespace-pre-wrap text-base leading-8 text-slate-700">{propertyDescription}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
