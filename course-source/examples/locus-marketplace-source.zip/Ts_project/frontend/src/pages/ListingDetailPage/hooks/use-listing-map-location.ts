import { useMemo } from 'react'

import type { ListingDetail } from '@/objects/listings'
import { getGoogleMapsEnv, googleMapsConfigMessage } from '@/pages/ListingDetailPage/functions/google-maps-env'
import type { ListingMapLocationState } from '@/pages/ListingDetailPage/functions/listing-detail'
import { listingAddress } from '@/pages/ListingDetailPage/functions/listing-detail'
import { useGeocodedListingPosition } from '@/pages/ListingDetailPage/hooks/use-geocoded-listing-position'

export const useListingMapLocation = (
  listing?: ListingDetail,
  enabled = true,
): ListingMapLocationState => {
  const address = useMemo(
    () => (listing ? listingAddress(listing) : undefined),
    [listing],
  )
  const env = useMemo(
    () => (listing && enabled ? getGoogleMapsEnv() : undefined),
    [enabled, listing],
  )
  const staticState =
    listing === undefined || !enabled
      ? ({ status: 'idle' } as const)
      : env === undefined
        ? ({ status: 'missing-config', message: googleMapsConfigMessage } as const)
        : undefined
  const geocodedState = useGeocodedListingPosition({
    address,
    env,
    enabled: staticState === undefined,
  })

  return staticState ?? geocodedState
}
