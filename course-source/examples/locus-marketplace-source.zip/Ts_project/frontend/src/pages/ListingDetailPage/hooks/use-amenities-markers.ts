import { useCallback, useEffect, useRef } from 'react'

import type {
  AdvancedMarkerElementInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'
import type { NearbyAmenity } from '@/pages/ListingDetailPage/functions/listing-detail'

import {
  type MarkerView,
} from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'
import {
  type AmenitySubcategory,
} from '@/pages/ListingDetailPage/integrations/google-maps/amenities-marker-records'
import { useAmenitiesMapInstance } from '@/pages/ListingDetailPage/hooks/use-amenities-map-instance'
import { useAmenitiesMarkerRegistry } from '@/pages/ListingDetailPage/hooks/use-amenities-marker-registry'
import { useAmenitiesMarkerSelection } from '@/pages/ListingDetailPage/hooks/use-amenities-marker-selection'

type UseAmenitiesMarkersArgs = {
  activeSubcategory: AmenitySubcategory
  activeSubcategoryIdKey: string
  locationKey: string
  mapPosition?: { lat: number; lng: number }
  currentPlaces: NearbyAmenity[]
  hasLoadedCurrentPlaces: boolean
  selectedPlaceId?: string
  setSelectedPlaceId: (value: string | undefined) => void
  onError: (message?: string) => void
}

export const useAmenitiesMarkers = ({
  activeSubcategory,
  activeSubcategoryIdKey,
  locationKey,
  mapPosition,
  currentPlaces,
  hasLoadedCurrentPlaces,
  selectedPlaceId,
  setSelectedPlaceId,
  onError,
}: UseAmenitiesMarkersArgs) => {
  const markerViewsRef = useRef(new WeakMap<AdvancedMarkerElementInstance, MarkerView>())
  const clearSelectedMarkerRef = useRef<() => void>(() => undefined)
  const restoreActiveMarkersRef = useRef<() => void>(() => undefined)
  const handleMapClearSelection = useCallback(() => {
    clearSelectedMarkerRef.current()
    restoreActiveMarkersRef.current()
  }, [])

  const { isMapReady, mapContainerRef, mapRef, resetMapCamera } = useAmenitiesMapInstance({
    clearSelectedMarker: handleMapClearSelection,
    locationKey,
    mapPosition,
    onError,
  })
  const selection = useAmenitiesMarkerSelection({
    mapRef,
    markerViewsRef,
    setSelectedPlaceId,
  })

  useEffect(() => {
    clearSelectedMarkerRef.current = selection.clearSelectedMarker
  }, [selection.clearSelectedMarker])

  const {
    findMarkerByPlaceId,
    hideAllMarkers,
    showActiveSubcategoryMarkers,
    showOnlyPlaceMarker,
  } = useAmenitiesMarkerRegistry({
    activeSubcategory,
    activeSubcategoryIdKey,
    applyGlow: selection.applyGlow,
    currentPlaces,
    hasLoadedCurrentPlaces,
    hideMarker: selection.hideMarker,
    isMapReady,
    locationKey,
    mapPosition,
    mapRef,
    markerViewsRef,
    onError,
    openMarker: selection.openMarker,
    removeGlow: selection.removeGlow,
    removeSelected: selection.removeSelected,
    selectedMarkerRef: selection.selectedMarkerRef,
    selectedPlaceId,
    setSelectedPlaceId,
  })

  useEffect(() => {
    restoreActiveMarkersRef.current = showActiveSubcategoryMarkers
  }, [showActiveSubcategoryMarkers])

  return {
    isMapReady,
    mapContainerRef,
    mapRef,
    resetMapCamera,
    hideAllMarkers,
    showActiveSubcategoryMarkers,
    showOnlyPlaceMarker,
    openMarker: selection.openMarker,
    findMarkerByPlaceId,
  }
}
