import { useCallback, useRef } from 'react'

import {
  type MarkerRecord,
  setMarkerMap,
} from '@/pages/ListingDetailPage/integrations/google-maps/amenities-support'
import type {
  AdvancedMarkerElementInstance,
  MapInstance,
} from '@/pages/ListingDetailPage/objects/google-maps-types'

type UseAmenitiesMarkerRegistryActionsArgs = {
  activeSubcategoryIdKey: string
  hideMarker: (marker: AdvancedMarkerElementInstance) => void
  mapRef: { current: MapInstance | undefined }
  openMarker: (marker: AdvancedMarkerElementInstance, placeId: string) => void
  selectedMarkerRef: { current: AdvancedMarkerElementInstance | undefined }
}

export const useAmenitiesMarkerRegistryActions = ({
  activeSubcategoryIdKey,
  hideMarker,
  mapRef,
  openMarker,
  selectedMarkerRef,
}: UseAmenitiesMarkerRegistryActionsArgs) => {
  const markersBySubcategoryRef = useRef<Record<string, MarkerRecord[]>>({})

  const hideAllMarkers = useCallback(() => {
    Object.values(markersBySubcategoryRef.current)
      .flat()
      .forEach(({ marker }) => hideMarker(marker))

    selectedMarkerRef.current = undefined
  }, [hideMarker, selectedMarkerRef])

  const showActiveSubcategoryMarkers = useCallback(() => {
    const map = mapRef.current

    if (!map) {
      return
    }

    hideAllMarkers()
    markersBySubcategoryRef.current[activeSubcategoryIdKey]?.forEach(({ marker }) => {
      setMarkerMap(marker, map)
    })
  }, [activeSubcategoryIdKey, hideAllMarkers, mapRef])

  const showOnlyPlaceMarker = useCallback(
    (placeId: string) => {
      const map = mapRef.current
      const markerRecord = markersBySubcategoryRef.current[activeSubcategoryIdKey]?.find(
        (record) => record.placeId === placeId,
      )

      if (!map || !markerRecord) {
        return
      }

      hideAllMarkers()
      setMarkerMap(markerRecord.marker, map)
      openMarker(markerRecord.marker, placeId)
    },
    [activeSubcategoryIdKey, hideAllMarkers, mapRef, openMarker],
  )

  const findMarkerByPlaceId = useCallback(
    (subcategoryId: string, placeId: string) =>
      markersBySubcategoryRef.current[subcategoryId]?.find((record) => record.placeId === placeId),
    [],
  )

  return {
    findMarkerByPlaceId,
    hideAllMarkers,
    markersBySubcategoryRef,
    showActiveSubcategoryMarkers,
    showOnlyPlaceMarker,
  }
}
