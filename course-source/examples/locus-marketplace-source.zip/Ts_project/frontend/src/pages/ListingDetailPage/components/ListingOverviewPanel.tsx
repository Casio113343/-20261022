import { useCallback, useEffect, useMemo, useState } from 'react'

import { api } from '@/apis'
import type { ListingDetail } from '@/objects/listings'
import type { ListingRenovation } from '@/objects/renovations'
import { ListingOverviewGallery } from '@/pages/ListingDetailPage/components/ListingOverviewGallery'
import { ListingPropertySummaryPanel } from '@/pages/ListingDetailPage/components/ListingPropertySummaryPanel'
import { ListingRenovationViewer } from '@/pages/ListingDetailPage/components/ListingRenovationViewer'
import { listingImageGallery } from '@/pages/ListingDetailPage/functions/listing-detail'
import {
  hasRenovationGallery,
  renovationImagePairs,
} from '@/pages/ListingDetailPage/functions/renovation-gallery'

type ListingOverviewPanelProps = {
  listing: ListingDetail
  activeImageIndex: number
  isSaved: boolean
  onImageChange: (index: number) => void
  onToggleSave: (listingId: string) => void
}

export const ListingOverviewPanel = ({
  listing,
  activeImageIndex,
  isSaved,
  onImageChange,
  onToggleSave,
}: ListingOverviewPanelProps) => {
  const [isRenovationViewerOpen, setIsRenovationViewerOpen] = useState(false)
  const [activeRenovationIndex, setActiveRenovationIndex] = useState(0)
  const [renovations, setRenovations] = useState<ListingRenovation[]>([])
  const [renovationLoadFailed, setRenovationLoadFailed] = useState(false)
  const canRenovateWithAi = hasRenovationGallery(listing)
  const renovationPairs = useMemo(
    () => renovationImagePairs(listing, renovations),
    [listing, renovations],
  )
  const hasActiveRenovations = renovationPairs.some(
    (pair) => pair.status === 'pending' || pair.status === 'processing',
  )

  const loadRenovations = useCallback(async () => {
    const response = await api.listListingRenovations(listing.id)

    if (response.ok) {
      setRenovations(response.data)
      setRenovationLoadFailed(false)
      return
    }

    setRenovations(
      listingImageGallery(listing).map((image) => ({
        originalImageId: image.id,
        status: 'failed',
        errorMessage: response.error.message,
      })),
    )
    setRenovationLoadFailed(true)
  }, [listing])

  const openRenovationViewer = () => {
    setActiveRenovationIndex(0)
    setIsRenovationViewerOpen(true)
    void loadRenovations()
  }

  useEffect(() => {
    if (
      !isRenovationViewerOpen ||
      !canRenovateWithAi ||
      renovationLoadFailed ||
      !hasActiveRenovations
    ) {
      return
    }

    const intervalId = window.setInterval(() => {
      void loadRenovations()
    }, 3000)

    return () => window.clearInterval(intervalId)
  }, [
    canRenovateWithAi,
    hasActiveRenovations,
    isRenovationViewerOpen,
    loadRenovations,
    renovationLoadFailed,
  ])

  return (
    <>
      <div className="flex h-full min-h-0 flex-col gap-4 xl:flex-row">
        <ListingOverviewGallery
          activeImageIndex={activeImageIndex}
          canRenovateWithAi={canRenovateWithAi}
          listing={listing}
          onImageChange={onImageChange}
          onOpenRenovationViewer={openRenovationViewer}
        />

        <ListingPropertySummaryPanel
          isSaved={isSaved}
          listing={listing}
          onToggleSave={onToggleSave}
        />
      </div>

      {isRenovationViewerOpen && canRenovateWithAi ? (
        <ListingRenovationViewer
          activeIndex={activeRenovationIndex}
          listing={listing}
          onClose={() => setIsRenovationViewerOpen(false)}
          onIndexChange={setActiveRenovationIndex}
          pairs={renovationPairs}
        />
      ) : null}
    </>
  )
}
