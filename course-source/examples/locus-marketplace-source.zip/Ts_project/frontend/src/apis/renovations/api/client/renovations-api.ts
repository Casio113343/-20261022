import { ListListingRenovationsApi } from '@/apis/renovations/api/messages/ListListingRenovationsApi'

export const renovationsApi = {
  listListingRenovations: async (listingId: string) => {
    const response = await new ListListingRenovationsApi({ listingId }).send()

    return response.ok
      ? { ...response, data: response.data.renovations }
      : response
  },
}
