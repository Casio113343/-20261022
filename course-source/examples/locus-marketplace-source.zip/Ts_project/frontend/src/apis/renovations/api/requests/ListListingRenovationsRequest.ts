export type ListListingRenovationsRequest = {
  listingId: string
}
