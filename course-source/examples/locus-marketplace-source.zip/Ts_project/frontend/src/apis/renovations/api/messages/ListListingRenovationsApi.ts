import { apiMessagePath } from '@/apis/message-route'
import type {
  ListListingRenovationsRequest,
  ListListingRenovationsResponse,
} from '@/apis/renovations/RenovationsApi'
import { request } from '@/apis/send'

export class ListListingRenovationsApi {
  readonly payload: ListListingRenovationsRequest

  constructor(payload: ListListingRenovationsRequest) {
    this.payload = payload
  }

  send() {
    return request<ListListingRenovationsResponse>(
      apiMessagePath('renovations', 'ListListingRenovationsApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
