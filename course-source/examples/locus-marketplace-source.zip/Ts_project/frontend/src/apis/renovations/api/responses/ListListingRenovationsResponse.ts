import type { ListingRenovation } from '@/objects/renovations'

export type ListListingRenovationsResponse = {
  renovations: ListingRenovation[]
}
