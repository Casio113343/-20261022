import type { ListingSummary } from '@/objects/listings'

export type ListFavouriteListingsResponse = {
  listings: ListingSummary[]
}
