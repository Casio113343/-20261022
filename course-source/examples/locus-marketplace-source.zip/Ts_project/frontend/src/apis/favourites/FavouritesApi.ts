export type { SetFavouriteListingRequest } from '@/apis/favourites/api/requests/SetFavouriteListingRequest'
export type { ListFavouriteListingsResponse } from '@/apis/favourites/api/responses/ListFavouriteListingsResponse'
export type { SetFavouriteListingResponse } from '@/apis/favourites/api/responses/SetFavouriteListingResponse'
