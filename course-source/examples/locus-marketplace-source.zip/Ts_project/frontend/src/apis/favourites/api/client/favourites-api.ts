import { ListFavouriteListingsApi } from '@/apis/favourites/api/messages/ListFavouriteListingsApi'
import { SetFavouriteListingApi } from '@/apis/favourites/api/messages/SetFavouriteListingApi'

const favouritesApi = {
  listFavourites: async () => {
    const response = await new ListFavouriteListingsApi().send()

    if (!response.ok) {
      return response
    }

    return {
      ...response,
      data: response.data.listings,
    }
  },
  saveFavourite: (listingId: string) =>
    new SetFavouriteListingApi({ listingId, saved: true }).send(),
  removeFavourite: (listingId: string) =>
    new SetFavouriteListingApi({ listingId, saved: false }).send(),
}

export { favouritesApi }
