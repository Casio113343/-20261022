import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type {
  SetFavouriteListingRequest,
  SetFavouriteListingResponse,
} from '@/apis/favourites/FavouritesApi'

export class SetFavouriteListingApi {
  readonly payload: SetFavouriteListingRequest

  constructor(payload: SetFavouriteListingRequest) {
    this.payload = payload
  }

  send() {
    return request<SetFavouriteListingResponse>(
      apiMessagePath('favourites', 'SetFavouriteListingApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
