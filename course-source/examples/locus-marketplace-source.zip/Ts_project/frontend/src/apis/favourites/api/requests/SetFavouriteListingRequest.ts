export type SetFavouriteListingRequest = {
  listingId: string
  saved: boolean
}
