export type SetFavouriteListingResponse = {
  listingId: string
  saved: boolean
}
