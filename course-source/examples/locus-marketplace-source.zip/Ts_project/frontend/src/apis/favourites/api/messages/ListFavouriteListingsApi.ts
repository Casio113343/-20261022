import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { ListFavouriteListingsResponse } from '@/apis/favourites/FavouritesApi'

export class ListFavouriteListingsApi {
  send() {
    return request<ListFavouriteListingsResponse>(
      apiMessagePath('favourites', 'ListFavouriteListingsApi'),
      {
        method: 'POST',
      },
    )
  }
}
