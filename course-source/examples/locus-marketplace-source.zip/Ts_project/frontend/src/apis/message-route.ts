type ApiServiceName =
  | 'analytics'
  | 'amenities'
  | 'favourites'
  | 'fengshui'
  | 'identity'
  | 'inspections'
  | 'listings'
  | 'media'
  | 'messaging'
  | 'renovations'

const apiMessageName = (apiClassName: string) =>
  apiClassName
    .replace(/(?:ApiMessage|Api)$/, '')
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .toLowerCase()

export const apiMessagePath = (service: ApiServiceName, apiClassName: string) =>
  `/api/messages/${service}/requests/${apiMessageName(apiClassName)}` as const
