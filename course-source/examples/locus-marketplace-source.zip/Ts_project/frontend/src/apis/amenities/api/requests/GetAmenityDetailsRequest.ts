import type { ListingMapPosition, NearbyAmenity } from '@/objects/amenities'

export type GetAmenityDetailsRequest = {
  origin: ListingMapPosition
  place: NearbyAmenity
}
