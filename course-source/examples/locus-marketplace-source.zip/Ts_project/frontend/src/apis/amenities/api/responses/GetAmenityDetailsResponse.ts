import type { AmenityDetails, TravelSummary } from '@/objects/amenities'

export type GetAmenityDetailsResponse = {
  details: AmenityDetails
  routes: TravelSummary[]
}
