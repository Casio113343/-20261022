import type { ListingMapPosition } from '@/objects/amenities'

export type SearchNearbyAmenitiesRequest = {
  location: ListingMapPosition
  includedTypes: string[]
}
