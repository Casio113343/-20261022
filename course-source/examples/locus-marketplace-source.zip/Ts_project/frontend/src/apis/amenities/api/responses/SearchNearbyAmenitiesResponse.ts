import type { NearbyAmenity } from '@/objects/amenities'

export type SearchNearbyAmenitiesResponse = {
  places: NearbyAmenity[]
}
