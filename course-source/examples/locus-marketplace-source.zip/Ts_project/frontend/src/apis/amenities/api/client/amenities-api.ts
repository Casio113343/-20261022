import type { GetAmenityDetailsRequest, SearchNearbyAmenitiesRequest } from '@/apis/amenities/AmenitiesApi'
import { GetAmenityDetailsApi } from '@/apis/amenities/api/messages/GetAmenityDetailsApi'
import { SearchNearbyAmenitiesApi } from '@/apis/amenities/api/messages/SearchNearbyAmenitiesApi'

const amenitiesApi = {
  getAmenityDetails: (params: GetAmenityDetailsRequest) => new GetAmenityDetailsApi(params).send(),
  searchNearbyAmenities: (params: SearchNearbyAmenitiesRequest) => new SearchNearbyAmenitiesApi(params).send(),
}

export { amenitiesApi }
