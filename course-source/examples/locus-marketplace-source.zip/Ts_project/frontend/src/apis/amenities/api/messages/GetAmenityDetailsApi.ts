import { apiMessagePath } from '@/apis/message-route'
import { request } from '@/apis/send'
import type { GetAmenityDetailsRequest, GetAmenityDetailsResponse } from '@/apis/amenities/AmenitiesApi'

export class GetAmenityDetailsApi {
  readonly payload: GetAmenityDetailsRequest

  constructor(payload: GetAmenityDetailsRequest) {
    this.payload = payload
  }

  send() {
    return request<GetAmenityDetailsResponse>(apiMessagePath('amenities', 'GetAmenityDetailsApi'), {
      method: 'POST',
      body: JSON.stringify(this.payload),
    })
  }
}
