import { apiMessagePath } from '@/apis/message-route'
import { request } from '@/apis/send'
import type { SearchNearbyAmenitiesRequest, SearchNearbyAmenitiesResponse } from '@/apis/amenities/AmenitiesApi'

export class SearchNearbyAmenitiesApi {
  readonly payload: SearchNearbyAmenitiesRequest

  constructor(payload: SearchNearbyAmenitiesRequest) {
    this.payload = payload
  }

  send() {
    return request<SearchNearbyAmenitiesResponse>(apiMessagePath('amenities', 'SearchNearbyAmenitiesApi'), {
      method: 'POST',
      body: JSON.stringify(this.payload),
    })
  }
}
