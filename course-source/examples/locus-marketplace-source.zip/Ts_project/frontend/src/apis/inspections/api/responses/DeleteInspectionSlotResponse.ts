export type DeleteInspectionSlotResponse = Record<string, never>
