import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { BookInspectionSlotRequest, BookInspectionSlotResponse } from '@/apis/inspections/InspectionsApi'

export class BookInspectionSlotApi {
  readonly payload: BookInspectionSlotRequest

  constructor(payload: BookInspectionSlotRequest) {
    this.payload = payload
  }

  send() {
    return request<BookInspectionSlotResponse>(
      apiMessagePath('inspections', 'BookInspectionSlotApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
