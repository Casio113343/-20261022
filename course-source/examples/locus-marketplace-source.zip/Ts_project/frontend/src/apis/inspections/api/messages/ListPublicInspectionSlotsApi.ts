import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type {
  ListPublicInspectionSlotsRequest,
  ListPublicInspectionSlotsResponse,
} from '@/apis/inspections/InspectionsApi'

export class ListPublicInspectionSlotsApi {
  readonly payload: ListPublicInspectionSlotsRequest

  constructor(payload: ListPublicInspectionSlotsRequest) {
    this.payload = payload
  }

  send() {
    return request<ListPublicInspectionSlotsResponse>(
      apiMessagePath('inspections', 'ListPublicInspectionSlotsApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
