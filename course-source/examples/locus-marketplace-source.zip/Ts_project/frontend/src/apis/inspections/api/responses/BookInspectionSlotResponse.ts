import type { PublicInspectionSlot } from '@/objects/inspections'

export type BookInspectionSlotResponse = {
  slot: PublicInspectionSlot
}
