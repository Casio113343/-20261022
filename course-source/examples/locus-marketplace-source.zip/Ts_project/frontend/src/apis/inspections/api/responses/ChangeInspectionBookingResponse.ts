import type { PublicInspectionSlot } from '@/objects/inspections'

export type ChangeInspectionBookingResponse = {
  previousSlot: PublicInspectionSlot
  slot: PublicInspectionSlot
}
