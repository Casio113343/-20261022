export type ChangeInspectionBookingRequest = {
  currentSlotId: string
  nextSlotId: string
}
