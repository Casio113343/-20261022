import type { PublicInspectionSlot } from '@/objects/inspections'

export type ListPublicInspectionSlotsResponse = {
  slots: PublicInspectionSlot[]
}
