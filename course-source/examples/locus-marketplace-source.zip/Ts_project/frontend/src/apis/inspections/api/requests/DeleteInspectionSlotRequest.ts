export type DeleteInspectionSlotRequest = {
  slotId: string
}
