import type { PublicInspectionSlot } from '@/objects/inspections'

export type CancelInspectionBookingResponse = {
  slot: PublicInspectionSlot
}
