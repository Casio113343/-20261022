export type OpenBookedInspectionConversationRequest = {
  slotId: string
}
