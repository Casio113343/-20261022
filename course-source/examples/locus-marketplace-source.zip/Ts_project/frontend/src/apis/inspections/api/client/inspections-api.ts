import type { CreateInspectionSlotRequest } from '@/apis/inspections/InspectionsApi'
import { BookInspectionSlotApi } from '@/apis/inspections/api/messages/BookInspectionSlotApi'
import { CancelInspectionBookingApi } from '@/apis/inspections/api/messages/CancelInspectionBookingApi'
import { ChangeInspectionBookingApi } from '@/apis/inspections/api/messages/ChangeInspectionBookingApi'
import { CreateInspectionSlotApi } from '@/apis/inspections/api/messages/CreateInspectionSlotApi'
import { DeleteInspectionSlotApi } from '@/apis/inspections/api/messages/DeleteInspectionSlotApi'
import { ListAgentInspectionsApi } from '@/apis/inspections/api/messages/ListAgentInspectionsApi'
import { ListPublicInspectionSlotsApi } from '@/apis/inspections/api/messages/ListPublicInspectionSlotsApi'
import { OpenBookedInspectionConversationApi } from '@/apis/inspections/api/messages/OpenBookedInspectionConversationApi'

export const inspectionsApi = {
  listPublicInspectionSlots: async (listingId: string) => {
    const response = await new ListPublicInspectionSlotsApi({ listingId }).send()

    return response.ok ? { ...response, data: response.data.slots } : response
  },
  bookInspectionSlot: async (slotId: string) => {
    const response = await new BookInspectionSlotApi({ slotId }).send()

    return response.ok ? { ...response, data: response.data.slot } : response
  },
  changeInspectionBooking: async (currentSlotId: string, nextSlotId: string) => {
    const response = await new ChangeInspectionBookingApi({ currentSlotId, nextSlotId }).send()

    return response.ok ? { ...response, data: response.data } : response
  },
  cancelInspectionBooking: async (slotId: string) => {
    const response = await new CancelInspectionBookingApi({ slotId }).send()

    return response.ok ? { ...response, data: response.data.slot } : response
  },
  listAgentInspections: async () => {
    const response = await new ListAgentInspectionsApi().send()

    return response.ok ? { ...response, data: response.data.slots } : response
  },
  createInspectionSlot: async (payload: CreateInspectionSlotRequest) => {
    const response = await new CreateInspectionSlotApi(payload).send()

    return response.ok ? { ...response, data: response.data.slot } : response
  },
  deleteInspectionSlot: (slotId: string) =>
    new DeleteInspectionSlotApi({ slotId }).send(),
  openBookedInspectionConversation: (slotId: string) =>
    new OpenBookedInspectionConversationApi({ slotId }).send(),
}
