export type CancelInspectionBookingRequest = {
  slotId: string
}
