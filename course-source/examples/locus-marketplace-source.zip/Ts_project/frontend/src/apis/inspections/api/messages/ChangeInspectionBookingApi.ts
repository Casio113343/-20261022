import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type {
  ChangeInspectionBookingRequest,
  ChangeInspectionBookingResponse,
} from '@/apis/inspections/InspectionsApi'

export class ChangeInspectionBookingApi {
  readonly payload: ChangeInspectionBookingRequest

  constructor(payload: ChangeInspectionBookingRequest) {
    this.payload = payload
  }

  send() {
    return request<ChangeInspectionBookingResponse>(
      apiMessagePath('inspections', 'ChangeInspectionBookingApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
