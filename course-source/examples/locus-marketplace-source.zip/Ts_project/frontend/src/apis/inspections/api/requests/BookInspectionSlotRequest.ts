export type BookInspectionSlotRequest = {
  slotId: string
}
