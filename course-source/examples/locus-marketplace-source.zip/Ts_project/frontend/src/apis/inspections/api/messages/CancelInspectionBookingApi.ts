import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type {
  CancelInspectionBookingRequest,
  CancelInspectionBookingResponse,
} from '@/apis/inspections/InspectionsApi'

export class CancelInspectionBookingApi {
  readonly payload: CancelInspectionBookingRequest

  constructor(payload: CancelInspectionBookingRequest) {
    this.payload = payload
  }

  send() {
    return request<CancelInspectionBookingResponse>(
      apiMessagePath('inspections', 'CancelInspectionBookingApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
