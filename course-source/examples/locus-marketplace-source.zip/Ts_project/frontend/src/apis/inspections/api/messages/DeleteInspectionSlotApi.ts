import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { DeleteInspectionSlotRequest, DeleteInspectionSlotResponse } from '@/apis/inspections/InspectionsApi'

export class DeleteInspectionSlotApi {
  readonly payload: DeleteInspectionSlotRequest

  constructor(payload: DeleteInspectionSlotRequest) {
    this.payload = payload
  }

  send() {
    return request<DeleteInspectionSlotResponse>(
      apiMessagePath('inspections', 'DeleteInspectionSlotApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
