export type ListPublicInspectionSlotsRequest = {
  listingId: string
}
