export type OpenBookedInspectionConversationResponse = {
  conversationId: string
}
