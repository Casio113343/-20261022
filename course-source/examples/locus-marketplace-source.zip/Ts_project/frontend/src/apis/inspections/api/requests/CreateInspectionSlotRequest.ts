export type CreateInspectionSlotRequest = {
  listingId: string
  startsAt: string
  endsAt: string
}
