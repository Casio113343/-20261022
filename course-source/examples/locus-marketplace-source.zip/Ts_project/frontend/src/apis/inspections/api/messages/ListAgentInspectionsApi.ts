import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { ListAgentInspectionsResponse } from '@/apis/inspections/InspectionsApi'

export class ListAgentInspectionsApi {
  send() {
    return request<ListAgentInspectionsResponse>(
      apiMessagePath('inspections', 'ListAgentInspectionsApi'),
      {
        method: 'POST',
      },
    )
  }
}
