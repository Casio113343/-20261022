import type { AgentInspectionSlot } from '@/objects/inspections'

export type ListAgentInspectionsResponse = {
  slots: AgentInspectionSlot[]
}
