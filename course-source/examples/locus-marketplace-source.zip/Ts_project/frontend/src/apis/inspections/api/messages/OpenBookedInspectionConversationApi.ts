import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type {
  OpenBookedInspectionConversationRequest,
  OpenBookedInspectionConversationResponse,
} from '@/apis/inspections/InspectionsApi'

export class OpenBookedInspectionConversationApi {
  readonly payload: OpenBookedInspectionConversationRequest

  constructor(payload: OpenBookedInspectionConversationRequest) {
    this.payload = payload
  }

  send() {
    return request<OpenBookedInspectionConversationResponse>(
      apiMessagePath('inspections', 'OpenBookedInspectionConversationApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
