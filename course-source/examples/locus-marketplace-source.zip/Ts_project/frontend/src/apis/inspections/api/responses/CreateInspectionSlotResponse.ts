import type { AgentInspectionSlot } from '@/objects/inspections'

export type CreateInspectionSlotResponse = {
  slot: AgentInspectionSlot
}
