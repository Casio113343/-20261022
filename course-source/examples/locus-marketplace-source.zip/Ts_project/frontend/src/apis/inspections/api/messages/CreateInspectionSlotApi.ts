import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { CreateInspectionSlotRequest, CreateInspectionSlotResponse } from '@/apis/inspections/InspectionsApi'

export class CreateInspectionSlotApi {
  readonly payload: CreateInspectionSlotRequest

  constructor(payload: CreateInspectionSlotRequest) {
    this.payload = payload
  }

  send() {
    return request<CreateInspectionSlotResponse>(
      apiMessagePath('inspections', 'CreateInspectionSlotApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
