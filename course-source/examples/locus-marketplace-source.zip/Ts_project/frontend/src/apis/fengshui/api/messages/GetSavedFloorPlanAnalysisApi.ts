import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type {
  GetSavedFloorPlanAnalysisRequest,
  GetSavedFloorPlanAnalysisResponse,
} from '@/apis/fengshui/FengshuiApi'

export class GetSavedFloorPlanAnalysisApi {
  readonly payload: GetSavedFloorPlanAnalysisRequest

  constructor(payload: GetSavedFloorPlanAnalysisRequest) {
    this.payload = payload
  }

  send() {
    return request<GetSavedFloorPlanAnalysisResponse>(
      apiMessagePath('fengshui', 'GetSavedFloorPlanAnalysisApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
