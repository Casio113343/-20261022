import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { AnalyseFloorPlanRequest, AnalyseFloorPlanResponse } from '@/apis/fengshui/FengshuiApi'

export class AnalyseFloorPlanApi {
  readonly payload: AnalyseFloorPlanRequest

  constructor(payload: AnalyseFloorPlanRequest) {
    this.payload = payload
  }

  send() {
    return request<AnalyseFloorPlanResponse>(
      apiMessagePath('fengshui', 'AnalyseFloorPlanApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
