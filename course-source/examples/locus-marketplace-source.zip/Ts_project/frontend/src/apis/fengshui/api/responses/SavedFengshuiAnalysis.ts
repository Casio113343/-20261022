import type { FengshuiAnalysis } from '@/objects/fengshui'

export type SavedFengshuiAnalysis = {
  analysis: FengshuiAnalysis
}
