import type { AnalyseFloorPlanRequest, GetSavedFloorPlanAnalysisRequest } from '@/apis/fengshui/FengshuiApi'
import { AnalyseFloorPlanApi } from '@/apis/fengshui/api/messages/AnalyseFloorPlanApi'
import { GetSavedFloorPlanAnalysisApi } from '@/apis/fengshui/api/messages/GetSavedFloorPlanAnalysisApi'

export const fengshuiApi = {
  analyseFloorPlan: async (payload: AnalyseFloorPlanRequest) => {
    const response = await new AnalyseFloorPlanApi(payload).send()

    return response.ok ? { ...response, data: response.data.analysis } : response
  },
  getSavedFloorPlanAnalysis: async (payload: GetSavedFloorPlanAnalysisRequest) =>
    new GetSavedFloorPlanAnalysisApi(payload).send(),
}
