export type GetSavedFloorPlanAnalysisRequest = {
  listingId: string
}
