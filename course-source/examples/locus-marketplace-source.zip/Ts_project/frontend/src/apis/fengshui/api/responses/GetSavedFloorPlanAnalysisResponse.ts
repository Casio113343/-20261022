import type { SavedFengshuiAnalysis } from '@/apis/fengshui/api/responses/SavedFengshuiAnalysis'

export type GetSavedFloorPlanAnalysisResponse = {
  savedAnalysis?: SavedFengshuiAnalysis | null
}
