import type { FengshuiAnalysis } from '@/objects/fengshui'

export type AnalyseFloorPlanResponse = {
  analysis: FengshuiAnalysis
}
