export type AnalyseFloorPlanRequest = {
  listingId: string
}
