import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { EndSessionResponse } from '@/apis/identity/IdentityApi'

export class EndSessionApi {
  send() {
    return request<EndSessionResponse>(
      apiMessagePath('identity', 'EndSessionApi'),
      {
        method: 'POST',
      },
    )
  }
}
