import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { AuthenticateIdentityRequest, AuthenticateIdentityResponse } from '@/apis/identity/IdentityApi'

export class AuthenticateIdentityApi {
  readonly payload: AuthenticateIdentityRequest

  constructor(payload: AuthenticateIdentityRequest) {
    this.payload = payload
  }

  send() {
    return request<AuthenticateIdentityResponse>(apiMessagePath('identity', 'AuthenticateIdentityApi'), {
      method: 'POST',
      body: JSON.stringify(this.payload),
    })
  }
}
