export type EndSessionResponse = {
  ended: boolean
}
