export type AuthenticateIdentityRequest = {
  email: string
  password: string
}
