import type { AuthenticateIdentityRequest, RegisterIdentityRequest } from '@/apis/identity/IdentityApi'
import { AuthenticateIdentityApi } from '@/apis/identity/api/messages/AuthenticateIdentityApi'
import { EndSessionApi } from '@/apis/identity/api/messages/EndSessionApi'
import { GetSessionUserApi } from '@/apis/identity/api/messages/GetSessionUserApi'
import { RegisterIdentityApi } from '@/apis/identity/api/messages/RegisterIdentityApi'
import { RegisterWithProfilePictureApi } from '@/apis/identity/api/messages/RegisterWithProfilePictureApi'
import { UploadProfilePictureApi } from '@/apis/identity/api/messages/UploadProfilePictureApi'
import type { User } from '@/objects/identity'

const authApi = {
  signIn: (payload: AuthenticateIdentityRequest) => new AuthenticateIdentityApi(payload).send(),
  signUp: (payload: RegisterIdentityRequest) => new RegisterIdentityApi(payload).send(),
  signUpWithProfilePicture: (payload: RegisterIdentityRequest, file: File) =>
    new RegisterWithProfilePictureApi(payload, file).send(),
  uploadProfilePicture: async (file: File) => {
    const response = await new UploadProfilePictureApi(file).send()

    return response.ok ? { ...response, data: response.data.user } : response
  },
  currentUser: async () => {
    const response = await new GetSessionUserApi().send()

    if (!response.ok) {
      return response
    }

    return {
      ...response,
      data: response.data.user satisfies User,
    }
  },
  signOut: () => new EndSessionApi().send(),
}

export { authApi }
