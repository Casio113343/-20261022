import type { User } from '@/objects/identity'

export type UploadProfilePictureResponse = {
  user: User
}
