import type { User } from '@/objects/identity'

export type RegisterIdentityResponse = {
  user: User
}
