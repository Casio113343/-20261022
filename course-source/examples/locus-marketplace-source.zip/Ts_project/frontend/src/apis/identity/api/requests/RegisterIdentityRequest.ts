import type { UserRole } from '@/objects/identity'

export type RegisterIdentityRequest = {
  fullName: string
  email: string
  password: string
  role: UserRole
  agencyName?: string
  phone?: string
}
