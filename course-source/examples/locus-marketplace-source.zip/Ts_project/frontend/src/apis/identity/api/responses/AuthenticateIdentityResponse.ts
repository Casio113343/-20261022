import type { User } from '@/objects/identity'

export type AuthenticateIdentityResponse = {
  user: User
}
