import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { GetSessionUserResponse } from '@/apis/identity/IdentityApi'

export class GetSessionUserApi {
  send() {
    return request<GetSessionUserResponse>(
      apiMessagePath('identity', 'GetSessionUserApi'),
      {
        method: 'POST',
      },
    )
  }
}
