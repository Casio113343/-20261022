import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { RegisterIdentityRequest, RegisterIdentityResponse } from '@/apis/identity/IdentityApi'

export class RegisterIdentityApi {
  readonly payload: RegisterIdentityRequest

  constructor(payload: RegisterIdentityRequest) {
    this.payload = payload
  }

  send() {
    return request<RegisterIdentityResponse>(apiMessagePath('identity', 'RegisterIdentityApi'), {
      method: 'POST',
      body: JSON.stringify(this.payload),
    })
  }
}
