import type { User } from '@/objects/identity'

export type GetSessionUserResponse = {
  user: User
}
