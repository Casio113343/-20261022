import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { RegisterIdentityRequest, RegisterIdentityResponse } from '@/apis/identity/IdentityApi'

const profilePictureRegistrationForm = (payload: RegisterIdentityRequest, file: File) => {
  const formData = new FormData()
  formData.set('fullName', payload.fullName)
  formData.set('email', payload.email)
  formData.set('password', payload.password)
  formData.set('role', payload.role)
  formData.set('agencyName', payload.agencyName ?? '')
  formData.set('phone', payload.phone ?? '')
  formData.set('file', file)
  return formData
}

export class RegisterWithProfilePictureApi {
  readonly payload: RegisterIdentityRequest
  readonly file: File

  constructor(payload: RegisterIdentityRequest, file: File) {
    this.payload = payload
    this.file = file
  }

  send() {
    return request<RegisterIdentityResponse>(apiMessagePath('identity', 'RegisterWithProfilePictureApi'), {
      method: 'POST',
      body: profilePictureRegistrationForm(this.payload, this.file),
    })
  }
}
