import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { UploadProfilePictureResponse } from '@/apis/identity/IdentityApi'

export class UploadProfilePictureApi {
  readonly file: File

  constructor(file: File) {
    this.file = file
  }

  send() {
    const formData = new FormData()
    formData.set('file', this.file)

    return request<UploadProfilePictureResponse>(
      apiMessagePath('identity', 'UploadProfilePictureApi'),
      {
        method: 'POST',
        body: formData,
      },
    )
  }
}
