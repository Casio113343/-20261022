export type UploadProfilePictureRequest = FormData
