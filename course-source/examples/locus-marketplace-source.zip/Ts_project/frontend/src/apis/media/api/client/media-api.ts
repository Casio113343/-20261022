import { DeleteManagedListingImageApi } from '@/apis/media/api/messages/DeleteManagedListingImageApi'
import { UploadManagedListingImageApi } from '@/apis/media/api/messages/UploadManagedListingImageApi'

const mediaApi = {
  uploadListingImage: async (file: File) => {
    const response = await new UploadManagedListingImageApi(file).send()

    return response.ok ? { ...response, data: response.data.image } : response
  },
  deleteListingImageUpload: async (imageId: string) => {
    const response = await new DeleteManagedListingImageApi({ imageId }).send()

    return response.ok ? { ...response, data: undefined } : response
  },
}

export { mediaApi }
