import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { DeleteManagedListingImageRequest, DeleteManagedListingImageResponse } from '@/apis/media/MediaApi'

export class DeleteManagedListingImageApi {
  readonly payload: DeleteManagedListingImageRequest

  constructor(payload: DeleteManagedListingImageRequest) {
    this.payload = payload
  }

  send() {
    return request<DeleteManagedListingImageResponse>(
      apiMessagePath('media', 'DeleteManagedListingImageApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
