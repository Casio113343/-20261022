import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { UploadManagedListingImageResponse } from '@/apis/media/MediaApi'

export class UploadManagedListingImageApi {
  readonly file: File

  constructor(file: File) {
    this.file = file
  }

  send() {
    const formData = new FormData()
    formData.set('file', this.file)

    return request<UploadManagedListingImageResponse>(
      apiMessagePath('media', 'UploadManagedListingImageApi'),
      {
        method: 'POST',
        body: formData,
      },
    )
  }
}
