export type DeleteManagedListingImageRequest = {
  imageId: string
}
