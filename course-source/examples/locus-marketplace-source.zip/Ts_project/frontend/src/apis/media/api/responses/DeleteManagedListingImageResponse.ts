export type DeleteManagedListingImageResponse = {
  deleted: boolean
}
