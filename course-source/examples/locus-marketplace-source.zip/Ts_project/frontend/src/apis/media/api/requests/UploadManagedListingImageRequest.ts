export type UploadManagedListingImageRequest = {
  fileName: string
  contentType: string
  bytes: Uint8Array
}
