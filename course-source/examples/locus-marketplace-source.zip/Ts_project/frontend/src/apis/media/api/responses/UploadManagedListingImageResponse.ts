import type { UploadedPropertyImage } from '@/objects/media'

export type UploadManagedListingImageResponse = {
  image: UploadedPropertyImage
}
