import { analyticsApi } from '@/apis/analytics/api/client/analytics-api'
import { amenitiesApi } from '@/apis/amenities/api/client/amenities-api'
import { agentListingApi } from '@/apis/listings/api/client/agent-listings-api'
import { authApi } from '@/apis/identity/api/client/identity-api'
import { favouritesApi } from '@/apis/favourites/api/client/favourites-api'
import { fengshuiApi } from '@/apis/fengshui/api/client/fengshui-api'
import { inspectionsApi } from '@/apis/inspections/api/client/inspections-api'
import { listingApi } from '@/apis/listings/api/client/public-listings-api'
import { mediaApi } from '@/apis/media/api/client/media-api'
import { messagingApi } from '@/apis/messaging/api/client/messaging-api'
import { renovationsApi } from '@/apis/renovations/api/client/renovations-api'

export const api = {
  ...analyticsApi,
  ...amenitiesApi,
  ...authApi,
  ...listingApi,
  ...favouritesApi,
  ...fengshuiApi,
  ...agentListingApi,
  ...mediaApi,
  ...inspectionsApi,
  ...messagingApi,
  ...renovationsApi,
}
export type { GetAmenityDetailsRequest } from '@/apis/amenities/api/requests/GetAmenityDetailsRequest'
export type { SearchNearbyAmenitiesRequest } from '@/apis/amenities/api/requests/SearchNearbyAmenitiesRequest'
export type { GetAmenityDetailsResponse } from '@/apis/amenities/api/responses/GetAmenityDetailsResponse'
export type { SearchNearbyAmenitiesResponse } from '@/apis/amenities/api/responses/SearchNearbyAmenitiesResponse'
