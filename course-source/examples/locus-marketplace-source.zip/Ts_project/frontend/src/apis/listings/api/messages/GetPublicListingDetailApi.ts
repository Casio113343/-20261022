import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { GetPublicListingDetailRequest, GetPublicListingDetailResponse } from '@/apis/listings/ListingsApi'

export class GetPublicListingDetailApi {
  readonly payload: GetPublicListingDetailRequest

  constructor(payload: GetPublicListingDetailRequest) {
    this.payload = payload
  }

  send() {
    return request<GetPublicListingDetailResponse>(apiMessagePath('listings', 'GetPublicListingDetailApi'), {
      method: 'POST',
      body: JSON.stringify(this.payload),
    })
  }
}
