export type GetPublicListingDetailRequest = {
  listingId: string
}
