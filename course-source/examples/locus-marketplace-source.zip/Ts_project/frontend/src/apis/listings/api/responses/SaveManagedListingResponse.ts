import type { ListingDetail } from '@/objects/listings'

export type SaveManagedListingResponse = {
  listing: ListingDetail
}
