export type ArchiveManagedListingRequest = {
  listingId: string
}
