import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { ListManagedListingsResponse } from '@/apis/listings/ListingsApi'

export class ListManagedListingsApi {
  send() {
    return request<ListManagedListingsResponse>(
      apiMessagePath('listings', 'ListManagedListingsApi'),
      {
        method: 'POST',
      },
    )
  }
}
