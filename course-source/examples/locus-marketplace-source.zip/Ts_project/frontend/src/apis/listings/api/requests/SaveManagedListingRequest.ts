import type {
  ApartmentSubtype,
  HouseSubtype,
  ListingFaq,
  ListingImageInput,
  ListingStatus,
  TransactionType,
} from '@/objects/listings'

type SaveManagedListingPayloadBase = {
  title: string
  description: string
  transactionType: TransactionType
  price: number
  addressLine: string
  suburb: string
  state: string
  postcode: string
  bedrooms: number
  bathrooms: number
  carSpaces: number
  landSize?: number
  buildingSize?: number
  listingStatus: ListingStatus
  renovateWithAi: boolean
  images: ListingImageInput[]
  faqs: ListingFaq[]
}

export type HouseManagedListingPayload = SaveManagedListingPayloadBase & {
  propertyType: 'house'
  houseSubtype: HouseSubtype
}

export type ApartmentManagedListingPayload = SaveManagedListingPayloadBase & {
  propertyType: 'apartment'
  apartmentSubtype: ApartmentSubtype
}

export type VacantLandManagedListingPayload = SaveManagedListingPayloadBase & {
  propertyType: 'vacant_land'
}

export type ManagedListingWritePayload =
  | HouseManagedListingPayload
  | ApartmentManagedListingPayload
  | VacantLandManagedListingPayload

export type SaveManagedListingRequest = {
  listingId?: string
  listing: ManagedListingWritePayload
}
