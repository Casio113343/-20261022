import type { ListingDetail } from '@/objects/listings'

export type GetPublicListingDetailResponse = {
  listing: ListingDetail
}
