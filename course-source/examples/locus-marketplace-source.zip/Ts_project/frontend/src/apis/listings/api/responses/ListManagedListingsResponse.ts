import type { ListingSummary } from '@/objects/listings'

export type ListManagedListingsResponse = {
  listings: ListingSummary[]
}
