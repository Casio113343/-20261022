import type { SearchPublicListingsRequest } from '@/apis/listings/ListingsApi'
import { GetPublicListingDetailApi } from '@/apis/listings/api/messages/GetPublicListingDetailApi'
import { SearchPublicListingsApi } from '@/apis/listings/api/messages/SearchPublicListingsApi'

const listingApi = {
  searchListings: (params: SearchPublicListingsRequest) => new SearchPublicListingsApi(params).send(),
  getListing: async (listingId: string) => {
    const response = await new GetPublicListingDetailApi({ listingId }).send()

    if (!response.ok) {
      return response
    }

    return {
      ...response,
      data: response.data.listing,
    }
  },
}

export { listingApi }
