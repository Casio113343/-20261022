import type { ListingSummary } from '@/objects/listings'

export type SearchPublicListingsResponse = {
  listings: ListingSummary[]
  total: number
}
