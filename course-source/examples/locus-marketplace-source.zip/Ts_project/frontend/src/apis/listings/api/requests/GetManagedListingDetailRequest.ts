export type GetManagedListingDetailRequest = {
  listingId: string
}
