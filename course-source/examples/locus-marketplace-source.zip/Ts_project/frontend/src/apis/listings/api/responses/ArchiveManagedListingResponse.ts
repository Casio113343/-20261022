import type { ListingStatus } from '@/objects/listings'

export type ArchiveManagedListingResponse = {
  listingId: string
  listingStatus: ListingStatus
}
