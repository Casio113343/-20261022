import type {
  ApartmentSubtype,
  HouseSubtype,
  ListingSort,
  ListingStatus,
  PropertyType,
  TransactionType,
} from '@/objects/listings'

export type SearchPublicListingsRequest = {
  query?: string
  transactionType?: TransactionType
  listingStatuses: ListingStatus[]
  propertyTypes: PropertyType[]
  houseSubtypes: HouseSubtype[]
  apartmentSubtypes: ApartmentSubtype[]
  minPrice?: number
  maxPrice?: number
  minFloorSize?: number
  maxFloorSize?: number
  minLandSize?: number
  maxLandSize?: number
  bedrooms?: number
  bathrooms?: number
  carSpaces?: number
  sort?: ListingSort
  limit?: number
}
