import type { ListingDetail } from '@/objects/listings'

export type GetManagedListingDetailResponse = {
  listing: ListingDetail
}
