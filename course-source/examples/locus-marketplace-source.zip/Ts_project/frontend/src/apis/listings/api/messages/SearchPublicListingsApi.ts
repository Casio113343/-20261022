import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { SearchPublicListingsRequest, SearchPublicListingsResponse } from '@/apis/listings/ListingsApi'

export class SearchPublicListingsApi {
  readonly payload: SearchPublicListingsRequest

  constructor(payload: SearchPublicListingsRequest) {
    this.payload = payload
  }

  send() {
    return request<SearchPublicListingsResponse>(apiMessagePath('listings', 'SearchPublicListingsApi'), {
      method: 'POST',
      body: JSON.stringify(this.payload),
    })
  }
}
