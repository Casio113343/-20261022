import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { ArchiveManagedListingRequest, ArchiveManagedListingResponse } from '@/apis/listings/ListingsApi'

export class ArchiveManagedListingApi {
  readonly payload: ArchiveManagedListingRequest

  constructor(payload: ArchiveManagedListingRequest) {
    this.payload = payload
  }

  send() {
    return request<ArchiveManagedListingResponse>(
      apiMessagePath('listings', 'ArchiveManagedListingApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
