import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { GetManagedListingDetailRequest, GetManagedListingDetailResponse } from '@/apis/listings/ListingsApi'

export class GetManagedListingDetailApi {
  readonly payload: GetManagedListingDetailRequest

  constructor(payload: GetManagedListingDetailRequest) {
    this.payload = payload
  }

  send() {
    return request<GetManagedListingDetailResponse>(
      apiMessagePath('listings', 'GetManagedListingDetailApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
