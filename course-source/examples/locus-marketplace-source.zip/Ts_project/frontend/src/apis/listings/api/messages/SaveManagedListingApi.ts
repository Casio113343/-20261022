import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { SaveManagedListingRequest, SaveManagedListingResponse } from '@/apis/listings/ListingsApi'

export class SaveManagedListingApi {
  readonly payload: SaveManagedListingRequest

  constructor(payload: SaveManagedListingRequest) {
    this.payload = payload
  }

  send() {
    return request<SaveManagedListingResponse>(
      apiMessagePath('listings', 'SaveManagedListingApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
