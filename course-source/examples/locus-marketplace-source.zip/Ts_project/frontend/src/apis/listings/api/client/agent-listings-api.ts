import type { ManagedListingWritePayload } from '@/apis/listings/ListingsApi'
import { ArchiveManagedListingApi } from '@/apis/listings/api/messages/ArchiveManagedListingApi'
import { GetManagedListingDetailApi } from '@/apis/listings/api/messages/GetManagedListingDetailApi'
import { ListManagedListingsApi } from '@/apis/listings/api/messages/ListManagedListingsApi'
import { SaveManagedListingApi } from '@/apis/listings/api/messages/SaveManagedListingApi'

const agentListingApi = {
  listAgentListings: async () => {
    const response = await new ListManagedListingsApi().send()

    if (!response.ok) {
      return response
    }

    return {
      ...response,
      data: response.data.listings,
    }
  },
  getAgentListing: async (listingId: string) => {
    const response = await new GetManagedListingDetailApi({ listingId }).send()

    if (!response.ok) {
      return response
    }

    return {
      ...response,
      data: response.data.listing,
    }
  },
  createListing: async (payload: ManagedListingWritePayload) => {
    const response = await new SaveManagedListingApi({ listing: payload }).send()

    if (!response.ok) {
      return response
    }

    return {
      ...response,
      data: response.data.listing,
    }
  },
  updateListing: async (listingId: string, payload: ManagedListingWritePayload) => {
    const response = await new SaveManagedListingApi({ listingId, listing: payload }).send()

    if (!response.ok) {
      return response
    }

    return {
      ...response,
      data: response.data.listing,
    }
  },
  archiveListing: (listingId: string) =>
    new ArchiveManagedListingApi({ listingId }).send(),
}

export { agentListingApi }
