import { failure, success, type Result } from '@/utils/result'

const csrfCookieName = 'locus_csrf'

const isJsonObject = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value)

const cookieValue = (name: string) =>
  typeof document === 'undefined'
    ? undefined
    : document.cookie
        .split(';')
        .map((cookie) => cookie.trim())
        .find((cookie) => cookie.startsWith(`${name}=`))
        ?.slice(name.length + 1)

const httpErrorMessage = async (response: Response, fallbackMessage: string) => {
  try {
    const payload: unknown = await response.json()

    if (!isJsonObject(payload)) {
      return fallbackMessage
    }

    const error = payload.error
    const message = payload.message

    if (typeof error === 'string' && error.trim()) {
      return error
    }

    if (typeof message === 'string' && message.trim()) {
      return message
    }

    return fallbackMessage
  } catch {
    return fallbackMessage
  }
}

const fetchResult = async (path: string, init: RequestInit): Promise<Result<Response>> => {
  try {
    return success(await fetch(path, init))
  } catch {
    return failure('network', 'Network request failed')
  }
}

const request = async <T>(
  path: string,
  init: RequestInit = {},
): Promise<Result<T>> => {
  const headers = new Headers(init.headers)
  const hasBody = init.body !== undefined
  const isFormDataBody = typeof FormData !== 'undefined' && init.body instanceof FormData
  const csrfToken = cookieValue(csrfCookieName)

  if (hasBody && !isFormDataBody && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }

  if (csrfToken && !headers.has('X-CSRF-Token')) {
    headers.set('X-CSRF-Token', decodeURIComponent(csrfToken))
  }

  const fetched = await fetchResult(path, {
    ...init,
    credentials: 'same-origin',
    headers,
  })

  if (!fetched.ok) {
    return fetched
  }

  const response = fetched.data

  if (!response.ok) {
    const fallbackMessage = `Request failed with status ${response.status}`
    return failure('http', await httpErrorMessage(response, fallbackMessage), response.status)
  }

  if (response.status === 204) {
    return success(undefined as T, response.status)
  }

  try {
    return success((await response.json()) as T, response.status)
  } catch {
    return failure('decode', 'Unable to read server response', response.status)
  }
}

export { request }
