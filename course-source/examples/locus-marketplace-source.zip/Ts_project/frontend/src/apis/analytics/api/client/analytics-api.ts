import type { ListingAnalyticsDateRange, ListingAnalyticsEventInput } from '@/objects/analytics'
import { GetManagedListingAnalyticsApi } from '@/apis/analytics/api/messages/GetManagedListingAnalyticsApi'
import { RecordListingAnalyticsEventsApi } from '@/apis/analytics/api/messages/RecordListingAnalyticsEventsApi'

const analyticsApi = {
  getManagedListingAnalytics: async (listingId: string, range: ListingAnalyticsDateRange = '30d') => {
    const response = await new GetManagedListingAnalyticsApi({ listingId, range }).send()

    if (!response.ok) {
      return response
    }

    return {
      ...response,
      data: response.data.analytics,
    }
  },
  recordListingAnalyticsEvents: (events: ListingAnalyticsEventInput[]) =>
    new RecordListingAnalyticsEventsApi({ events }).send(),
}

export { analyticsApi }
