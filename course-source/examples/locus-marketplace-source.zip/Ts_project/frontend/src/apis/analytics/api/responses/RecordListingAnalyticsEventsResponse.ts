export type RecordListingAnalyticsEventsResponse = {
  recorded: number
}
