import type { ListingAnalyticsDashboard } from '@/objects/analytics'

export type GetManagedListingAnalyticsResponse = {
  analytics: ListingAnalyticsDashboard
}
