import type { ListingAnalyticsDateRange } from '@/objects/analytics'

export type GetManagedListingAnalyticsRequest = {
  listingId: string
  range: ListingAnalyticsDateRange
}
