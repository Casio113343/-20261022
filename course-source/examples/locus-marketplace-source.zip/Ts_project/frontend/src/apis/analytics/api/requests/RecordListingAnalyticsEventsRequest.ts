import type { ListingAnalyticsEventInput } from '@/objects/analytics'

export type RecordListingAnalyticsEventsRequest = {
  events: ListingAnalyticsEventInput[]
}
