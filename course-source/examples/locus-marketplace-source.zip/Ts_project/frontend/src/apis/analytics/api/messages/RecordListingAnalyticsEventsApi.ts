import { apiMessagePath } from '@/apis/message-route'
import { request } from '@/apis/send'
import type { RecordListingAnalyticsEventsRequest } from '@/apis/analytics/api/requests/RecordListingAnalyticsEventsRequest'
import type { RecordListingAnalyticsEventsResponse } from '@/apis/analytics/api/responses/RecordListingAnalyticsEventsResponse'

export class RecordListingAnalyticsEventsApi {
  readonly payload: RecordListingAnalyticsEventsRequest

  constructor(payload: RecordListingAnalyticsEventsRequest) {
    this.payload = payload
  }

  send() {
    return request<RecordListingAnalyticsEventsResponse>(
      apiMessagePath('analytics', 'RecordListingAnalyticsEventsApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
