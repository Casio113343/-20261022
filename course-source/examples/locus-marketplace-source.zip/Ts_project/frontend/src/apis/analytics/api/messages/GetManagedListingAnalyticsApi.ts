import { apiMessagePath } from '@/apis/message-route'
import { request } from '@/apis/send'
import type { GetManagedListingAnalyticsRequest } from '@/apis/analytics/api/requests/GetManagedListingAnalyticsRequest'
import type { GetManagedListingAnalyticsResponse } from '@/apis/analytics/api/responses/GetManagedListingAnalyticsResponse'

export class GetManagedListingAnalyticsApi {
  readonly payload: GetManagedListingAnalyticsRequest

  constructor(payload: GetManagedListingAnalyticsRequest) {
    this.payload = payload
  }

  send() {
    return request<GetManagedListingAnalyticsResponse>(
      apiMessagePath('analytics', 'GetManagedListingAnalyticsApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
