import { GetConversationMessagesApi } from '@/apis/messaging/api/messages/GetConversationMessagesApi'
import { ListConversationsApi } from '@/apis/messaging/api/messages/ListConversationsApi'
import { StartConversationApi } from '@/apis/messaging/api/messages/StartConversationApi'
import { UploadMessageAttachmentApi } from '@/apis/messaging/api/messages/UploadMessageAttachmentApi'

const messagingApi = {
  startConversation: async (listingId: string) => {
    const response = await new StartConversationApi({ listingId }).send()

    return response.ok ? { ...response, data: response.data.conversation } : response
  },
  listConversations: async () => {
    const response = await new ListConversationsApi().send()

    return response.ok ? { ...response, data: response.data.conversations } : response
  },
  getConversationMessages: async (conversationId: string) => {
    const response = await new GetConversationMessagesApi({ conversationId }).send()

    return response.ok ? { ...response, data: response.data.messages } : response
  },
  uploadMessageAttachment: async (file: File) => {
    const response = await new UploadMessageAttachmentApi(file).send()

    return response.ok ? { ...response, data: response.data.attachment } : response
  },
}

export { messagingApi }
