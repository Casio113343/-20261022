import type { MessageAttachment } from '@/objects/messaging'

export type UploadMessageAttachmentResponse = {
  attachment: MessageAttachment
}
