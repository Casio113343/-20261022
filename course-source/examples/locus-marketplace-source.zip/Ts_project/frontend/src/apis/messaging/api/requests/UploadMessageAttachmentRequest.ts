export type UploadMessageAttachmentRequest = FormData
