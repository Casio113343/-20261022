import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type {
  GetConversationMessagesRequest,
  GetConversationMessagesResponse,
} from '@/apis/messaging/MessagingApi'

export class GetConversationMessagesApi {
  readonly payload: GetConversationMessagesRequest

  constructor(payload: GetConversationMessagesRequest) {
    this.payload = payload
  }

  send() {
    return request<GetConversationMessagesResponse>(
      apiMessagePath('messaging', 'GetConversationMessagesApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
