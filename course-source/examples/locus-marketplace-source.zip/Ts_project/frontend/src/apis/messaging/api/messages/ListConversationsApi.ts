import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { ListConversationsResponse } from '@/apis/messaging/MessagingApi'

export class ListConversationsApi {
  send() {
    return request<ListConversationsResponse>(
      apiMessagePath('messaging', 'ListConversationsApi'),
      {
        method: 'POST',
      },
    )
  }
}
