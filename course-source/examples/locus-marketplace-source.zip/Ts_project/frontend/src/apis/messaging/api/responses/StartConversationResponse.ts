import type { ConversationSummary } from '@/objects/messaging'

export type StartConversationResponse = {
  conversation: ConversationSummary
}
