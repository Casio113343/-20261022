export const messagingPaths = {
  websocket: '/api/ws/listing-conversations',
} as const
