import type { ConversationMessage } from '@/objects/messaging'

export type GetConversationMessagesResponse = {
  messages: ConversationMessage[]
}
