import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { StartConversationRequest, StartConversationResponse } from '@/apis/messaging/MessagingApi'

export class StartConversationApi {
  readonly payload: StartConversationRequest

  constructor(payload: StartConversationRequest) {
    this.payload = payload
  }

  send() {
    return request<StartConversationResponse>(
      apiMessagePath('messaging', 'StartConversationApi'),
      {
        method: 'POST',
        body: JSON.stringify(this.payload),
      },
    )
  }
}
