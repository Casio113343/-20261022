import { request } from '@/apis/send'
import { apiMessagePath } from '@/apis/message-route'
import type { UploadMessageAttachmentResponse } from '@/apis/messaging/MessagingApi'

export class UploadMessageAttachmentApi {
  readonly file: File

  constructor(file: File) {
    this.file = file
  }

  send() {
    const formData = new FormData()
    formData.set('file', this.file)

    return request<UploadMessageAttachmentResponse>(
      apiMessagePath('messaging', 'UploadMessageAttachmentApi'),
      {
        method: 'POST',
        body: formData,
      },
    )
  }
}
