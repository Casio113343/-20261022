export type GetConversationMessagesRequest = {
  conversationId: string
}
