import type { ConversationSummary } from '@/objects/messaging'

export type ListConversationsResponse = {
  conversations: ConversationSummary[]
}
