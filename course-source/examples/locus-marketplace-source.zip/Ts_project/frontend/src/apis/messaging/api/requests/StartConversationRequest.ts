export type StartConversationRequest = {
  listingId: string
}
