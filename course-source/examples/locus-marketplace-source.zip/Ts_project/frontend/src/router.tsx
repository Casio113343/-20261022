import { createBrowserRouter, Navigate } from 'react-router-dom'

import { MarketplaceLayout } from '@/pages/shared/layout/MarketplaceLayout'
import { RequireAgent, RequireAuth } from '@/pages/shared/layout/RouteGuards'
import AgentInspectionsPage from '@/pages/AgentInspectionsPage'
import AgentListingAnalyticsPage from '@/pages/AgentListingAnalyticsPage'
import AgentListingEditorPage from '@/pages/AgentListingEditorPage'
import AgentListingsPage from '@/pages/AgentListingsPage'
import HomePage from '@/pages/HomePage'
import ListingDetailPage from '@/pages/ListingDetailPage'
import ListingsPage from '@/pages/ListingsPage'
import MessagesPage from '@/pages/MessagesPage'
import SavedListingsPage from '@/pages/SavedListingsPage'
import SignInPage from '@/pages/SignInPage'
import SignUpPage from '@/pages/SignUpPage'

export const router = createBrowserRouter([
  {
    path: '/',
    element: <MarketplaceLayout />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: 'listings',
        element: <ListingsPage />,
      },
      {
        path: 'listings/:listingId',
        element: <ListingDetailPage />,
      },
      {
        element: <RequireAuth />,
        children: [
          {
            path: 'saved',
            element: <SavedListingsPage />,
          },
          {
            path: 'messages',
            element: <MessagesPage />,
          },
        ],
      },
      {
        element: <RequireAgent />,
        children: [
          {
            path: 'agent/listings',
            element: <AgentListingsPage />,
          },
          {
            path: 'agent/inspections',
            element: <AgentInspectionsPage />,
          },
          {
            path: 'agent/listings/new',
            element: <AgentListingEditorPage />,
          },
          {
            path: 'agent/listings/preview',
            element: <ListingDetailPage />,
          },
          {
            path: 'agent/listings/:listingId/edit',
            element: <AgentListingEditorPage />,
          },
          {
            path: 'agent/listings/:listingId/analytics',
            element: <AgentListingAnalyticsPage />,
          },
        ],
      },
      {
        path: 'sign-in',
        element: <SignInPage />,
      },
      {
        path: 'sign-up',
        element: <SignUpPage />,
      },
      {
        path: '*',
        element: <Navigate replace to="/" />,
      },
    ],
  },
])
