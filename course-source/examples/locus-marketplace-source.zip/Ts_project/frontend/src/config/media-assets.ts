const minioPublicBaseUrl =
  import.meta.env.VITE_MINIO_PUBLIC_BASE_URL ?? 'http://127.0.0.1:9000'

const minioBucketName = import.meta.env.VITE_MINIO_BUCKET ?? 'listing-media'

const mediaAssetUrl = (objectKey: string) =>
  `${minioPublicBaseUrl.replace(/\/$/, '')}/${minioBucketName}/${objectKey}`

export const mediaAssets = {
  authenticationBackgroundVideo: mediaAssetUrl('backgrounds/authentication.mp4'),
  homeHeroVideo: mediaAssetUrl('backgrounds/home-hero.mp4'),
} as const
