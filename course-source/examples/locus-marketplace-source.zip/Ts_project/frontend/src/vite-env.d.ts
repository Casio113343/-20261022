/// <reference types="vite/client" />

type GoogleMapsApiSurface = import('@/pages/ListingDetailPage/objects/google-maps-types').GoogleMapsApi

interface ImportMetaEnv {
  readonly VITE_GOOGLE_MAPS_API_KEY?: string
  readonly VITE_GOOGLE_VECTOR_MAP_ID_EXCLUDE_POI?: string
  readonly VITE_MINIO_BUCKET?: string
  readonly VITE_MINIO_PUBLIC_BASE_URL?: string
}

declare global {
  interface Window {
    google?: GoogleMapsApiSurface
    __harbouredGoogleMapsPromise__?: Promise<GoogleMapsApiSurface>
  }
}

export {}
