package fengshui.tables
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import _root_.fengshui.tables.fengshui_analyses.FengshuiAnalysesTable

import java.sql.Connection

object FengshuiSchema:

  def initialize(connection: Connection): IO[Unit] =
    FengshuiAnalysesTable.initialize(connection)
