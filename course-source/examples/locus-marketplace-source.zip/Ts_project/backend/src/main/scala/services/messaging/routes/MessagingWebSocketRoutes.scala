package messaging.routes

import cats.effect.IO
import cats.effect.std.Queue
import database.DatabaseSession
import fs2.Pipe
import identity.api.IdentityPublicApi
import identity.model.UserId
import io.circe.parser.decode
import io.circe.syntax.*
import messaging.application.MessagingWebSocketEventHandler
import messaging.model.{ClientMessagingEvent, ConversationId, ServerMessagingEvent}
import org.http4s.*
import org.http4s.dsl.io.*
import org.http4s.server.websocket.WebSocketBuilder2
import org.http4s.websocket.WebSocketFrame
import shared.{ListingMediaStorage, RuntimeValues}

object MessagingWebSocketRoutes:

  def routes(
    databaseSession: DatabaseSession,
    storage: ListingMediaStorage,
    hub: MessagingWebSocketHub,
    webSocketBuilder: WebSocketBuilder2[IO]
  ): HttpRoutes[IO] = HttpRoutes.of[IO] {
    case req @ GET -> Root / "api" / "ws" / "listing-conversations" =>
      sessionToken(req) match
        case None => Forbidden()
        case Some(sessionToken) =>
          databaseSession.withConnection { connection =>
            IdentityPublicApi.resolveOptionalPrincipal(connection, Some(sessionToken)).flatMap {
              case Right(Some(principal)) =>
                Queue.unbounded[IO, WebSocketFrame].flatMap { queue =>
                  val send = hub.stream(queue).onFinalize(hub.remove(queue))
                  val receive: Pipe[IO, WebSocketFrame, Unit] = _.evalMap {
                    case WebSocketFrame.Text(text, _) =>
                      decode[ClientMessagingEvent](text) match
                        case Left(error) =>
                          for
                            conversationId <- RuntimeValues.uuid.map(ConversationId(_))
                            now <- RuntimeValues.now
                            event = ServerMessagingEvent.ErrorEvent(conversationId, error.getMessage, now)
                            _ <- queue.offer(WebSocketFrame.Text((event: ServerMessagingEvent).asJson.noSpaces))
                          yield ()
                        case Right(ClientMessagingEvent.SubscribeConversation(conversationId)) =>
                          databaseSession.withTransactionConnection { connection =>
                            MessagingWebSocketEventHandler.handleWebSocketEvent(
                              connection,
                              storage,
                              principal.userId,
                              ClientMessagingEvent.SubscribeConversation(conversationId)
                            )
                          }.flatMap {
                            case Right(_) => hub.subscribe(conversationId, queue)
                            case Left(error) =>
                              RuntimeValues.now.flatMap { now =>
                                val event = ServerMessagingEvent.ErrorEvent(conversationId, error.getMessage, now)
                                queue.offer(WebSocketFrame.Text((event: ServerMessagingEvent).asJson.noSpaces))
                              }
                          }
                        case Right(event) =>
                          handleWebSocketEvent(databaseSession, storage, hub, principal.userId, event)
                    case WebSocketFrame.Close(_) => hub.remove(queue)
                    case _ => IO.unit
                  }
                  webSocketBuilder.build(send, receive)
                }
              case Right(None) => Forbidden()
              case Left(_) => Forbidden()
            }
          }
  }

  private def sessionToken(req: Request[IO]): Option[String] =
    req.cookies.find(_.name == "locus_session").map(_.content.trim).filter(_.nonEmpty)

  private def handleWebSocketEvent(
    databaseSession: DatabaseSession,
    storage: ListingMediaStorage,
    hub: MessagingWebSocketHub,
    userId: UserId,
    event: ClientMessagingEvent
  ): IO[Unit] =
    databaseSession.withTransactionConnection { connection =>
      MessagingWebSocketEventHandler.handleWebSocketEvent(connection, storage, userId, event)
    }.flatMap {
      case Right(Some(serverEvent)) => hub.publish(serverEvent)
      case Right(None) => IO.unit
      case Left(error) =>
        RuntimeValues.now.flatMap(now =>
          hub.publish(ServerMessagingEvent.ErrorEvent(conversationIdOf(event), error.getMessage, now))
        )
    }

  private def conversationIdOf(event: ClientMessagingEvent): ConversationId =
    event match
      case ClientMessagingEvent.SendMessage(conversationId, _, _) => conversationId
      case ClientMessagingEvent.TypingStarted(conversationId) => conversationId
      case ClientMessagingEvent.TypingStopped(conversationId) => conversationId
      case ClientMessagingEvent.MarkSeen(conversationId) => conversationId
      case ClientMessagingEvent.SubscribeConversation(conversationId) => conversationId
