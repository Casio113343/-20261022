package identity.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class AgentSummary(
  id: UserId,
  fullName: String,
  agencyName: String,
  phone: String,
  avatarUrl: Option[String]
)

object AgentSummary:
  given Encoder[AgentSummary] = deriveEncoder[AgentSummary]
  given Decoder[AgentSummary] = deriveDecoder[AgentSummary]
