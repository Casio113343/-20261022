package amenities.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class NearbyAmenity(
  id: String,
  placeResourceName: Option[String],
  name: String,
  address: String,
  photoUrl: Option[String],
  rating: Option[Double],
  userRatingCount: Option[Int],
  types: List[String],
  location: ListingMapPosition,
  distanceInMeters: Double
)

object NearbyAmenity:
  given Encoder[NearbyAmenity] = deriveEncoder[NearbyAmenity]
  given Decoder[NearbyAmenity] = deriveDecoder[NearbyAmenity]
