package listings.routes
import identity.model.*
import listings.model.*
import media.model.*


import shared.ApiServiceMessages
import shared.ListingMediaStorage
import renovations.api.RenovationScheduler

object ListingsRoutes:

  def apiMessages(storage: ListingMediaStorage, renovationScheduler: RenovationScheduler): ApiServiceMessages =
    ApiServiceMessages(
      "listings",
      PublicListingRoutes.apiMessages(storage) ++ AgentListingRoutes.apiMessages(storage, renovationScheduler)
    )
