package identity.routes
import identity.model.*


import shared.ApiServiceMessages
import identity.api.messages.*
import shared.ListingMediaStorage

object AuthRoutes:

  def apiMessages(storage: ListingMediaStorage): ApiServiceMessages =
    ApiServiceMessages("identity", List(
      RegisterIdentityApiMessage(storage),
      RegisterWithProfilePictureApiMessage(storage),
      AuthenticateIdentityApiMessage(storage),
      EndSessionApiMessage,
      GetSessionUserApiMessage(storage),
      UploadProfilePictureApiMessage(storage)
    ))
