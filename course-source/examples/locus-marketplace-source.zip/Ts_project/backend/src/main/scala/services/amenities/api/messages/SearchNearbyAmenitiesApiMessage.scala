package amenities.api.messages

import amenities.api.requests.SearchNearbyAmenitiesRequest
import amenities.api.responses.SearchNearbyAmenitiesResponse
import amenities.clients.GoogleAmenitiesClient
import cats.effect.IO
import shared.{ApiTransaction, AppError, AppResult, JsonApiMessage}

import java.sql.Connection

final case class SearchNearbyAmenitiesApiMessage(
  googleAmenitiesClient: Option[GoogleAmenitiesClient]
) extends JsonApiMessage[SearchNearbyAmenitiesRequest, SearchNearbyAmenitiesResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(
    request: SearchNearbyAmenitiesRequest,
    connection: Connection
  ): IO[AppResult[SearchNearbyAmenitiesResponse]] =
    val includedTypes = request.includedTypes.map(_.trim).filter(_.nonEmpty).distinct

    googleAmenitiesClient match
      case None => IO.pure(Left(AppError.Validation("Amenities search is not configured.")))
      case Some(_) if includedTypes.isEmpty =>
        IO.pure(Left(AppError.Validation("Choose at least one amenity type.")))
      case Some(client) =>
        client
          .searchNearby(
            location = request.location,
            includedTypes = includedTypes
          )
          .map(_.map(SearchNearbyAmenitiesResponse.apply))
