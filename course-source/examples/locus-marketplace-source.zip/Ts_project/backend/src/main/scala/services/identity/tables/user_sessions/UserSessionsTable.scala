package identity.tables.user_sessions
import identity.model.*


import cats.effect.IO
import identity.security.Security
import shared.*

import java.sql.Connection
import java.sql.Timestamp
import java.time.temporal.ChronoUnit
import java.util.UUID

private[identity] object UserSessionsTable:

  private val createSql: String =
    """
      |create table if not exists user_sessions (
      |  id uuid primary key,
      |  user_id uuid not null references users(id) on delete cascade,
      |  token_hash text not null unique,
      |  csrf_token text not null default '',
      |  created_at timestamptz not null,
      |  expires_at timestamptz not null
      |);
      |create index if not exists user_sessions_token_hash_idx on user_sessions(token_hash);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql, addCsrfTokenSql))

  private val addCsrfTokenSql: String =
    """
      |alter table user_sessions
      |add column if not exists csrf_token text not null default '';
      |""".stripMargin

  private val createSessionSql: String =
    """
      |insert into user_sessions (id, user_id, token_hash, csrf_token, created_at, expires_at)
      |values (?, ?, ?, ?, ?, ?)
      |""".stripMargin

  def createSession(connection: Connection, userId: UserId): IO[Security.SessionTokens] =
    for
      tokens <- Security.issueSessionTokens()
      createdAt <- RuntimeValues.now
      sessionId <- RuntimeValues.uuid
      expiresAt = createdAt.plus(30, ChronoUnit.DAYS)
      _ <- JdbcResources.update(connection, createSessionSql) { statement =>
        statement.setObject(1, sessionId)
        statement.setObject(2, userId.value)
        statement.setString(3, tokens.sessionTokenHash)
        statement.setString(4, tokens.csrfToken)
        statement.setTimestamp(5, Timestamp.from(createdAt))
        statement.setTimestamp(6, Timestamp.from(expiresAt))
        statement.executeUpdate()
      }
    yield tokens

  private val findActiveUserIdSql: String =
    """
      |select user_id
      |from user_sessions
      |where token_hash = ?
      |  and expires_at > ?
      |""".stripMargin

  def findActiveUserId(connection: Connection, token: String): IO[Option[UserId]] =
    for
      tokenHash <- Security.hashToken(token)
      timestamp <- RuntimeValues.now
      userIdOption <- JdbcResources.select(connection, findActiveUserIdSql) { statement =>
        statement.setString(1, tokenHash)
        statement.setTimestamp(2, Timestamp.from(timestamp))
      } { resultSet =>
        if resultSet.next() then Some(UserId(resultSet.getObject("user_id", classOf[UUID])))
        else None
      }
    yield userIdOption

  private val signOutSql: String =
    "delete from user_sessions where token_hash = ?"

  def signOut(connection: Connection, token: String): IO[AppResult[Unit]] =
    Security.hashToken(token).flatMap(tokenHash =>
      JdbcResources.update(connection, signOutSql) { statement =>
        statement.setString(1, tokenHash)
        statement.executeUpdate()
      }.as(Right(()))
    )
