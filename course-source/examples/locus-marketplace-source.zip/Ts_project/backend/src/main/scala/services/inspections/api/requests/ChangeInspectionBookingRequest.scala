package inspections.api.requests
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import inspections.model.InspectionSlotId
import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder

final case class ChangeInspectionBookingRequest(currentSlotId: InspectionSlotId, nextSlotId: InspectionSlotId)

object ChangeInspectionBookingRequest:
  given Decoder[ChangeInspectionBookingRequest] = deriveDecoder[ChangeInspectionBookingRequest]
