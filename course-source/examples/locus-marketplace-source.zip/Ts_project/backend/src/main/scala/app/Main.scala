import app.ServerConfig
import app.api.ApiRouter
import amenities.clients.GoogleAmenitiesClient
import cats.effect.{IO, IOApp}
import database.DatabaseSession
import fengshui.clients.GeminiFengshuiClient
import renovations.api.RenovationsPublicApi
import renovations.clients.GeminiRenovationClient
import messaging.routes.MessagingWebSocketHub
import shared.Schema
import org.http4s.ember.server.EmberServerBuilder
import org.http4s.server.Server
import org.http4s.server.middleware.Logger
import org.typelevel.log4cats.slf4j.Slf4jLogger
import shared.ApiRateLimiter
import shared.ListingMediaStorage

object Main extends IOApp.Simple:

  private val logger = Slf4jLogger.getLogger[IO]

  private val serverResource: cats.effect.Resource[IO, Server] =
    for
      serverConfig <- cats.effect.Resource.eval(ServerConfig.load)
      databaseSession <- DatabaseSession.initialize
      listingMediaStorage <- ListingMediaStorage.initialize
      rateLimiter <- cats.effect.Resource.eval(ApiRateLimiter.create)
      googleAmenitiesClient <- cats.effect.Resource.eval(GoogleAmenitiesClient.configured)
      fengshuiClient <- cats.effect.Resource.eval(GeminiFengshuiClient.configured)
      renovationClient <- cats.effect.Resource.eval(GeminiRenovationClient.configured)
      renovationScheduler <- RenovationsPublicApi.createScheduler(
        databaseSession,
        listingMediaStorage,
        renovationClient
      )
      messagingHub <- cats.effect.Resource.eval(MessagingWebSocketHub.create)
      _ <- cats.effect.Resource.eval(
        databaseSession.withTransactionConnection(connection => Schema.initialize(connection))
      )
      _ <- cats.effect.Resource.eval(renovationScheduler.resumePending)
      server <- EmberServerBuilder
        .default[IO]
        .withHost(serverConfig.host)
        .withPort(serverConfig.port)
        .withHttpWebSocketApp(webSocketBuilder =>
          Logger.httpApp(logHeaders = false, logBody = false)(
            ApiRouter.httpApp(
              databaseSession,
              listingMediaStorage,
              rateLimiter,
              googleAmenitiesClient,
              fengshuiClient,
              renovationScheduler,
              messagingHub,
              webSocketBuilder
            )
          )
        )
        .build
    yield server

  override def run: IO[Unit] =
    for
      serverConfig <- ServerConfig.load
      _ <- logger.info(s"Starting LOCUS backend on http://${serverConfig.address}")
      _ <- serverResource.useForever
    yield ()
