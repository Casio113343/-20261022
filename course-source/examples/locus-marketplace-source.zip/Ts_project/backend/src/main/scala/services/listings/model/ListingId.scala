package listings.model


import io.circe.{Decoder, Encoder}

import java.util.UUID
import scala.util.Try

final case class ListingId(value: UUID)

object ListingId:
  given Encoder[ListingId] = Encoder.encodeString.contramap(_.value.toString)
  given Decoder[ListingId] = Decoder.decodeString.emap(parseUuid(_, "listingId").map(ListingId(_)))

  private def parseUuid(value: String, label: String): Either[String, UUID] =
    Try(UUID.fromString(value)).toEither.left.map(_ => s"Invalid $label")
