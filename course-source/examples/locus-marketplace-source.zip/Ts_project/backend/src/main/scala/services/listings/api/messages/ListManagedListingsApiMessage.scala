package listings.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.{ApiTransaction, NoRequestWithTokenMessage}
import cats.effect.IO
import identity.api.IdentityPublicApi
import listings.api.responses.ListManagedListingsResponse
import listings.application.ListingApplication
import shared.AppResult
import shared.AuthenticatedPrincipal
import shared.ListingMediaStorage

import java.sql.Connection

final case class ListManagedListingsApiMessage(storage: ListingMediaStorage)
    extends NoRequestWithTokenMessage[ListManagedListingsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(principal: AuthenticatedPrincipal, connection: Connection): IO[AppResult[ListManagedListingsResponse]] =
    ListingApplication
      .listAgentListings(connection, storage, principal.userId)
      .map(_.map(ListManagedListingsResponse.apply))
