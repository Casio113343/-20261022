package listings.model

import io.circe.{Decoder, Encoder}

import java.util.UUID
import scala.util.Try

final case class ListingImageId(value: UUID)

object ListingImageId:
  given Encoder[ListingImageId] = Encoder.encodeString.contramap(_.value.toString)
  given Decoder[ListingImageId] = Decoder.decodeString.emap(parseUuid(_).map(ListingImageId(_)))

  private def parseUuid(value: String): Either[String, UUID] =
    Try(UUID.fromString(value)).toEither.left.map(_ => "Invalid listingImageId")
