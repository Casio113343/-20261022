package analytics.api.requests

import analytics.model.ListingAnalyticsEventInput
import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class RecordListingAnalyticsEventsRequest(
  events: List[ListingAnalyticsEventInput]
)

object RecordListingAnalyticsEventsRequest:
  given Encoder[RecordListingAnalyticsEventsRequest] = deriveEncoder[RecordListingAnalyticsEventsRequest]
  given Decoder[RecordListingAnalyticsEventsRequest] = deriveDecoder[RecordListingAnalyticsEventsRequest]
