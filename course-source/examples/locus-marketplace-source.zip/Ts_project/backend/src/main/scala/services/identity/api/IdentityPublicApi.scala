package identity.api
import identity.model.*


import shared.{ApiTokenResolver, AuthenticatedPrincipal}
import cats.effect.IO
import identity.application.IdentityApplication
import identity.tables.user_sessions.UserSessionsTable
import identity.tables.users.UsersTable
import shared.{AppError, AppResult}
import identity.model.{User, UserId, UserRole}
import shared.ListingMediaStorage

import java.sql.Connection

object IdentityPublicApi extends ApiTokenResolver:

  private final case class IdentityPrincipal(user: User) extends AuthenticatedPrincipal:
    override val userId: UserId = user.id

  override def resolveOptionalPrincipal(
    connection: Connection,
    token: Option[String]
  ): IO[AppResult[Option[AuthenticatedPrincipal]]] =
    token match
      case Some(sessionToken) =>
        UserSessionsTable.findActiveUserId(connection, sessionToken).flatMap(
          _.fold[IO[AppResult[Option[AuthenticatedPrincipal]]]](IO.pure(Right(None)))(
            UsersTable.loadUser(connection, _).map(_.map(_.map(IdentityPrincipal.apply)))
          )
        )
      case None => IO.pure(Right(None))

  def currentUser(principal: AuthenticatedPrincipal): AppResult[User] =
    principal match
      case IdentityPrincipal(user) => Right(user)
      case _ => Left(AppError.Unauthorized("Authenticated identity is not recognized"))

  def requireBuyer(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    currentUser(principal).flatMap(_.role match
      case UserRole.BuyerRenter => Right(principal)
      case UserRole.AgentAdmin => Left(AppError.Forbidden("Only buyer accounts can start conversations"))
    )

  def loadUsers(
    connection: Connection,
    storage: ListingMediaStorage,
    userIds: List[UserId]
  ): IO[AppResult[List[User]]] =
    userIds.distinct.foldLeft(IO.pure(Right(Nil): AppResult[List[User]])) { (acc, userId) =>
      for
        loaded <- acc
        next <- loaded match
          case Left(error) => IO.pure(Left(error))
          case Right(users) =>
            UsersTable.loadUser(connection, userId).map(
              _.map(_.map(IdentityApplication.resolveAvatarUrl(storage)))
            ).map(
              _.flatMap(_.toRight(AppError.NotFound("User not found")).map(user => users :+ user))
            )
      yield next
    }

  def loadRawUserMap(
    connection: Connection,
    userIds: List[UserId]
  ): IO[AppResult[Map[UserId, User]]] =
    userIds.distinct.foldLeft(IO.pure(Right(Map.empty): AppResult[Map[UserId, User]])) { (acc, userId) =>
      for
        loaded <- acc
        next <- loaded match
          case Left(error) => IO.pure(Left(error))
          case Right(users) =>
            UsersTable.loadUser(connection, userId).map(
              _.flatMap(_.toRight(AppError.NotFound("User not found")).map(user => users + (user.id -> user)))
            )
      yield next
    }

  def loadUserMap(
    connection: Connection,
    storage: ListingMediaStorage,
    userIds: List[UserId]
  ): IO[AppResult[Map[UserId, User]]] =
    loadUsers(connection, storage, userIds).map(_.map(_.map(user => user.id -> user).toMap))

  def loadAgentSummaryMap(
    connection: Connection,
    storage: ListingMediaStorage,
    userIds: List[UserId]
  ): IO[AppResult[Map[UserId, AgentSummary]]] =
    loadUserMap(connection, storage, userIds).map(
      _.map(_.view.mapValues(agentSummaryFrom).toMap)
    )

  def requireAgent(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    currentUser(principal).flatMap(_.role match
      case UserRole.AgentAdmin => Right(principal)
      case UserRole.BuyerRenter => Left(AppError.Forbidden("Agent or admin access is required"))
    )

  private def agentSummaryFrom(user: User): AgentSummary =
    AgentSummary(
      id = user.id,
      fullName = user.fullName,
      agencyName = user.agentProfile.map(_.agencyName).getOrElse(""),
      phone = user.agentProfile.map(_.phone).getOrElse(""),
      avatarUrl = user.avatarUrl
    )
