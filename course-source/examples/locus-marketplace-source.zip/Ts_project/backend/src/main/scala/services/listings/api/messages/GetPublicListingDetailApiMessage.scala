package listings.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.{ApiTransaction, JsonApiMessage}
import cats.data.EitherT
import cats.effect.IO
import listings.api.requests.GetPublicListingDetailRequest
import listings.api.responses.GetPublicListingDetailResponse
import listings.application.ListingApplication
import shared.{AppError, AppResult}
import shared.ListingMediaStorage

import java.sql.Connection

final case class GetPublicListingDetailApiMessage(storage: ListingMediaStorage)
    extends JsonApiMessage[GetPublicListingDetailRequest, GetPublicListingDetailResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(
    request: GetPublicListingDetailRequest,
    connection: Connection
  ): IO[AppResult[GetPublicListingDetailResponse]] =
    (
      for
        listingOption <- EitherT(ListingApplication.findPublicDetail(connection, storage, request.listingId))
        listing <- EitherT.fromOption[IO](listingOption, AppError.NotFound("Listing not found"))
      yield GetPublicListingDetailResponse(listing)
    ).value
