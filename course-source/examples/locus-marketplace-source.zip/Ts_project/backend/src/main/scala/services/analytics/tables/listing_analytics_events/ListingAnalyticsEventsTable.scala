package analytics.tables.listing_analytics_events

import analytics.model.*
import cats.effect.IO
import listings.model.ListingId
import shared.*

import java.sql.{Connection, Timestamp}
import java.time.Instant

private[analytics] object ListingAnalyticsEventsTable:

  // metadata is the typed event contract. category and label are derived display columns:
  // they keep common dashboard queries simple and preserve older rows recorded before metadata existed.
  private val createSql: String =
    """
      |create table if not exists listing_analytics_events (
      |  id uuid primary key,
      |  listing_id uuid not null references listings(id) on delete cascade,
      |  event_type varchar(40) not null check (
      |    event_type in (
      |      'listing_view',
      |      'search_impression',
      |      'search_click',
      |      'favourite',
      |      'message_start',
      |      'inspection_request',
      |      'photo_open',
      |      'amenity_interest'
      |    )
      |  ),
      |  category varchar(120),
      |  label varchar(220),
      |  metadata jsonb,
      |  occurred_at timestamptz not null
      |);
      |create index if not exists listing_analytics_events_listing_time_idx
      |  on listing_analytics_events(listing_id, occurred_at desc);
      |create index if not exists listing_analytics_events_type_idx
      |  on listing_analytics_events(event_type, occurred_at desc);
      |alter table listing_analytics_events
      |add column if not exists metadata jsonb;
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql))

  // Insert keeps both representations in sync: metadata stores structured meaning,
  // while category/label store reviewer-friendly labels for breakdown and activity rows.
  private val insertSql: String =
    """
      |insert into listing_analytics_events (id, listing_id, event_type, category, label, metadata, occurred_at)
      |values (?, ?, ?, ?, ?, ?::jsonb, ?)
      |""".stripMargin

  def insertEvents(
    connection: Connection,
    events: List[ListingAnalyticsEventInput],
    occurredAt: Instant
  ): IO[Int] =
    events.foldLeft(IO.pure(0)) { (program, event) =>
      for
        count <- program
        eventId <- RuntimeValues.uuid
        _ <- JdbcResources.update(connection, insertSql) { statement =>
          val metadata = event.metadata.getOrElse(ListingAnalyticsEventMetadata.empty)
          statement.setObject(1, eventId)
          statement.setObject(2, event.listingId.value)
          statement.setString(3, ListingAnalyticsEventType.toString(event.eventType))
          ListingAnalyticsEventDisplay.eventCategory(event.eventType, metadata).filter(_.trim.nonEmpty) match
            case Some(category) => statement.setString(4, category.trim.take(120))
            case None => statement.setNull(4, java.sql.Types.VARCHAR)
          ListingAnalyticsEventDisplay.eventLabel(event.eventType, metadata).filter(_.trim.nonEmpty) match
            case Some(label) => statement.setString(5, label.trim.take(220))
            case None => statement.setNull(5, java.sql.Types.VARCHAR)
          DbCodec.setJson(statement, 6, metadata)
          statement.setTimestamp(7, Timestamp.from(occurredAt))
          statement.executeUpdate()
        }
      yield count + 1
    }

  // The public dashboard is assembled from narrow persistence reads rather than one
  // monolithic SQL query, which makes each metric easier to inspect and adjust independently.
  def loadDashboard(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[AppResult[ListingAnalyticsDashboard]] =
    for
      counts <- ListingAnalyticsDashboardReads.loadCounts(connection, listingId, range)
      timeline <- ListingAnalyticsDashboardReads.loadTimeline(connection, listingId, range)
      amenities <- ListingAnalyticsDashboardReads.loadAmenities(connection, listingId, range)
      trafficSources <- ListingAnalyticsDashboardReads.loadTrafficSources(connection, listingId, range)
      deviceBreakdown <- ListingAnalyticsDashboardReads.loadDeviceBreakdown(connection, listingId, range)
      photos <- ListingAnalyticsDashboardReads.loadPhotos(connection, listingId, range)
      photoEngagementStats <- ListingAnalyticsDashboardReads.loadPhotoEngagementStats(connection, listingId, range)
      searchFilters <- ListingAnalyticsDashboardReads.loadSearchFilters(connection, listingId, range)
      peerAverages <- ListingAnalyticsDashboardReads.loadPeerAverages(connection, range)
      activity <- ListingAnalyticsDashboardReads.loadActivity(connection, listingId, range)
    yield activity.map(events =>
      ListingAnalyticsDashboardCalculations.build(
        range = range,
        counts = counts,
        timeline = timeline,
        trafficSources = trafficSources,
        deviceBreakdown = deviceBreakdown,
        searchFilters = searchFilters,
        amenities = amenities,
        photos = photos,
        photoEngagementStats = photoEngagementStats,
        peerAverages = peerAverages,
        activity = events
      )
    )
