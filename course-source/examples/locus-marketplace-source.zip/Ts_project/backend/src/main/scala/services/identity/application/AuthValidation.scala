package identity.application
import identity.model.*


import shared.{AppError, AppResult}

private[identity] object AuthValidation:

  private def invalid(message: String): AppResult[Unit] =
    Left(AppError.Validation(message))

  def validateAuthRequest(fullName: String, email: String, password: String): AppResult[Unit] =
    if fullName.trim.length < 2 then invalid("Full name is required")
    else if !email.contains("@") then invalid("A valid email is required")
    else if password.length < 8 then invalid("Password must be at least 8 characters")
    else Right(())
