package identity.api.messages
import identity.model.*


import shared.{ApiTransaction, AuthenticatedPrincipal, NoRequestWithTokenMessage}
import cats.effect.IO
import identity.api.IdentityPublicApi
import identity.api.responses.GetSessionUserResponse
import identity.application.IdentityApplication
import shared.AppResult
import shared.ListingMediaStorage

import java.sql.Connection

final case class GetSessionUserApiMessage(storage: ListingMediaStorage)
    extends NoRequestWithTokenMessage[GetSessionUserResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[GetSessionUserResponse]] =
    IO.pure(
      IdentityPublicApi
        .currentUser(principal)
        .map(user => GetSessionUserResponse(IdentityApplication.resolveAvatarUrl(storage)(user)))
    )
