package favourites.api.responses
import identity.model.*
import listings.model.*

import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import listings.model.ListingId

final case class SetFavouriteListingResponse(
  listingId: ListingId,
  saved: Boolean
)

object SetFavouriteListingResponse:
  given Encoder[SetFavouriteListingResponse] = deriveEncoder[SetFavouriteListingResponse]
