package renovations.model

import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import media.model.PropertyImageId

final case class ListingRenovation(
  originalImageId: PropertyImageId,
  status: RenovationStatus,
  renovatedImageUrl: Option[String],
  errorMessage: Option[String]
)

object ListingRenovation:
  given Encoder[ListingRenovation] = deriveEncoder[ListingRenovation]
