package inspections.api.messages
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import identity.api.IdentityPublicApi
import inspections.application.InspectionApplication
import inspections.api.requests.CreateInspectionSlotRequest
import inspections.api.responses.CreateInspectionSlotResponse
import inspections.model.{AgentInspectionSlot, InspectionBuyerSummary, InspectionListingSummary, InspectionSlotId}
import inspections.tables.inspection_slots.InspectionSlotsTable
import listings.api.ListingsPublicApi
import shared.{AppError, AppResult, AuthenticatedPrincipal, RuntimeValues}
import identity.model.UserId
import shared.ListingMediaStorage

import java.sql.Connection
import java.time.Instant
import java.time.temporal.ChronoUnit

final case class CreateInspectionSlotApiMessage(storage: ListingMediaStorage)
    extends ApiWithTokenMessage[CreateInspectionSlotRequest, CreateInspectionSlotResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(
    request: CreateInspectionSlotRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[CreateInspectionSlotResponse]] =
    (
      for
        now <- EitherT.right[AppError](RuntimeValues.now)
        _ <- validateSlot(request.startsAt, request.endsAt, now)
        existingSlot <- EitherT.right[AppError](InspectionSlotsTable.slotExistsAt(connection, request.listingId, request.startsAt))
        _ <- EitherT.cond[IO](!existingSlot, (), AppError.Validation("A slot already exists at this time."))
        listingOwnedByAgent <- EitherT.right[AppError](ListingsPublicApi.listingOwnedByAgent(connection, request.listingId, principal.userId))
        _ <- EitherT.cond[IO](listingOwnedByAgent, (), AppError.NotFound("Listing not found"))
        slotId <- EitherT.right[AppError](RuntimeValues.uuid.map(InspectionSlotId(_)))
        insertedRows <- EitherT.right[AppError](
          InspectionSlotsTable.createSlot(connection, slotId, principal.userId, request.listingId, request.startsAt, request.endsAt, now)
        )
        _ <- EitherT.cond[IO](insertedRows > 0, (), AppError.Unexpected("Inspection slot could not be created"))
        slots <- EitherT(InspectionApplication.listAgentSlots(connection, storage, principal.userId))
        slot <- EitherT.fromOption[IO](slots.find(_.id == slotId), AppError.NotFound("Listing not found"))
      yield CreateInspectionSlotResponse(slot)
    ).value

  private def validateSlot(startsAt: Instant, endsAt: Instant, now: Instant): EitherT[IO, AppError, Unit] =
    val durationMinutes = ChronoUnit.MINUTES.between(startsAt, endsAt)

    if !startsAt.isAfter(now) then
      EitherT.leftT(AppError.Validation("Inspection slots must be in the future."))
    else if durationMinutes < 10 || durationMinutes > 180 then
      EitherT.leftT(AppError.Validation("Inspection slots must be between 10 minutes and 3 hours."))
    else EitherT.rightT(())
