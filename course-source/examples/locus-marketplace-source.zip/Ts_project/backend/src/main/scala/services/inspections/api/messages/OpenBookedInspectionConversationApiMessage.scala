package inspections.api.messages
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import identity.api.IdentityPublicApi
import inspections.api.requests.OpenBookedInspectionConversationRequest
import inspections.api.responses.OpenBookedInspectionConversationResponse
import inspections.tables.inspection_slots.InspectionSlotsTable
import shared.{AppError, AppResult}
import shared.AuthenticatedPrincipal
import messaging.api.MessagingPublicApi
import shared.ListingMediaStorage

import java.sql.Connection

final case class OpenBookedInspectionConversationApiMessage(storage: ListingMediaStorage)
    extends ApiWithTokenMessage[OpenBookedInspectionConversationRequest, OpenBookedInspectionConversationResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(
    request: OpenBookedInspectionConversationRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[OpenBookedInspectionConversationResponse]] =
    (
      for
        targetOption <- EitherT(InspectionSlotsTable.bookedConversationTarget(connection, principal.userId, request.slotId))
        target <- EitherT.fromOption[IO](targetOption, AppError.NotFound("Booked inspection not found"))
        conversationId <- EitherT(
          MessagingPublicApi.findOrCreateInspectionConversation(connection, storage, target.listingId, target.buyerId)
        )
      yield OpenBookedInspectionConversationResponse(conversationId)
    ).value
