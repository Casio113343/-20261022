package media.api.requests
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import media.model.PropertyImageId

final case class DeleteManagedListingImageRequest(
  imageId: PropertyImageId
)

object DeleteManagedListingImageRequest:
  given Decoder[DeleteManagedListingImageRequest] = deriveDecoder[DeleteManagedListingImageRequest]
