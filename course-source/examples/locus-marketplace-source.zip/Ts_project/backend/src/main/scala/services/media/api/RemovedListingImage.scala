package media.api

final case class RemovedListingImage(objectKey: String)
