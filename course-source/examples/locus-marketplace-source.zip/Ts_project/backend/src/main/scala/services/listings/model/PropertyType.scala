package listings.model


import io.circe.{Decoder, Encoder}

enum PropertyType:
  case House
  case Apartment
  case VacantLand

object PropertyType:
  def fromString(value: String): Either[String, PropertyType] =
    value.trim.toLowerCase match
      case "house" => Right(PropertyType.House)
      case "apartment" => Right(PropertyType.Apartment)
      case "vacant_land" => Right(PropertyType.VacantLand)
      case other => Left(s"Unsupported property type: $other")

  def toString(value: PropertyType): String =
    value match
      case PropertyType.House => "house"
      case PropertyType.Apartment => "apartment"
      case PropertyType.VacantLand => "vacant_land"

  given Encoder[PropertyType] = Encoder.encodeString.contramap(toString)
  given Decoder[PropertyType] = Decoder.decodeString.emap(fromString)
