package messaging.tables.message_attachments
import identity.model.*
import listings.model.*
import messaging.model.*


import cats.effect.IO
import shared.*
import shared.ListingMediaStorage

import java.sql.{Connection, ResultSet, Timestamp}
import java.time.Instant

private[messaging] object MessageAttachmentsTable:

  private val createSql: String =
    """
      |create table if not exists message_attachments (
      |  id uuid primary key,
      |  message_id uuid references conversation_messages(id) on delete cascade,
      |  uploaded_by uuid not null references users(id) on delete cascade,
      |  bucket_name varchar(120) not null,
      |  object_key text not null unique,
      |  file_name varchar(220) not null,
      |  mime_type varchar(160) not null,
      |  size_bytes bigint not null,
      |  kind varchar(16) not null check (kind in ('image', 'file')),
      |  created_at timestamptz not null
      |);
      |create index if not exists message_attachments_message_idx on message_attachments(message_id, created_at);
      |create index if not exists message_attachments_uploaded_by_idx on message_attachments(uploaded_by, created_at);
      |""".stripMargin

  private val requiredColumns: List[String] =
    List(
      "id",
      "message_id",
      "uploaded_by",
      "bucket_name",
      "object_key",
      "file_name",
      "mime_type",
      "size_bytes",
      "kind",
      "created_at",
    )

  def initialize(connection: Connection): IO[Unit] =
    migrateLegacyTables(connection) *> SchemaSupport.executeStatements(connection, List(createSql))

  private val dropLegacyTablesSql: List[String] =
    List(
      "drop table if exists message_attachments cascade;",
      "drop table if exists message_messages cascade;",
      "drop table if exists message_threads cascade;"
    )

  private def migrateLegacyTables(connection: Connection): IO[Unit] =
    for
      messageAttachmentsTableExists <- SchemaSupport.hasTable(connection, "message_attachments")
      hasCompleteAttachmentSchema <-
        if messageAttachmentsTableExists then SchemaSupport.hasColumns(connection, "message_attachments", requiredColumns)
        else IO.pure(true)
      _ <-
        if messageAttachmentsTableExists && !hasCompleteAttachmentSchema then
          SchemaSupport.executeStatements(connection, dropLegacyTablesSql)
        else IO.unit
    yield ()

  private val insertUploadedAttachmentSql: String =
    """
      |insert into message_attachments (
      |  id, message_id, uploaded_by, bucket_name, object_key, file_name, mime_type, size_bytes, kind, created_at
      |)
      |values (?, null, ?, ?, ?, ?, ?, ?, ?, ?)
      |""".stripMargin

  def insertUploadedAttachment(
    connection: Connection,
    attachmentId: MessageAttachmentId,
    uploadedBy: UserId,
    bucketName: String,
    objectKey: String,
    fileName: String,
    mimeType: String,
    sizeBytes: Long,
    createdAt: Instant,
    storage: ListingMediaStorage
  ): IO[AppResult[MessageAttachment]] =
    val kind =
      if mimeType.startsWith("image/") then MessageAttachmentKind.Image
      else MessageAttachmentKind.File

    JdbcResources.update(connection, insertUploadedAttachmentSql) { statement =>
      statement.setObject(1, attachmentId.value)
      statement.setObject(2, uploadedBy.value)
      statement.setString(3, bucketName)
      statement.setString(4, objectKey)
      statement.setString(5, fileName)
      statement.setString(6, mimeType)
      statement.setLong(7, sizeBytes)
      statement.setString(8, MessageAttachmentKind.toString(kind))
      statement.setTimestamp(9, Timestamp.from(createdAt))
      statement.executeUpdate()
    }.as(
      Right(
        MessageAttachment(
          id = attachmentId,
          kind = kind,
          url = storage.publicUrl(objectKey),
          objectKey = objectKey,
          fileName = fileName,
          mimeType = mimeType,
          sizeBytes = sizeBytes,
          createdAt = createdAt
        )
      )
    )

  private val attachUploadedFileSql: String =
    """
      |update message_attachments
      |set message_id = ?
      |where id = ?
      |  and uploaded_by = ?
      |  and message_id is null
      |""".stripMargin

  def attachUploadedFiles(
    connection: Connection,
    messageId: ConversationMessageId,
    senderId: UserId,
    attachmentIds: List[MessageAttachmentId]
  ): IO[AppResult[Unit]] =
    attachmentIds.foldLeft(IO.pure(Right(()): AppResult[Unit])) { (acc, attachmentId) =>
      acc.flatMap {
        case Left(error) => IO.pure(Left(error))
        case Right(_) =>
          JdbcResources.update(connection, attachUploadedFileSql) { statement =>
            statement.setObject(1, messageId.value)
            statement.setObject(2, attachmentId.value)
            statement.setObject(3, senderId.value)
            if statement.executeUpdate() == 1 then Right(())
            else Left(AppError.NotFound("Uploaded attachment not found"))
          }
      }
    }

  private val listMessageAttachmentsSql: String =
    """
      |select id, object_key, file_name, mime_type, size_bytes, kind, created_at
      |from message_attachments
      |where message_id = ?
      |order by created_at asc
      |""".stripMargin

  def listMessageAttachments(
    connection: Connection,
    messageId: ConversationMessageId,
    storage: ListingMediaStorage
  ): IO[AppResult[List[MessageAttachment]]] =
    JdbcResources.select(connection, listMessageAttachmentsSql) { statement =>
      statement.setObject(1, messageId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => readAttachment(resultSet, storage))
        .foldRight(Right(Nil): AppResult[List[MessageAttachment]])((next, acc) =>
          for
            head <- next
            tail <- acc
          yield head :: tail
        )
    }

  private def readAttachment(resultSet: ResultSet, storage: ListingMediaStorage): AppResult[MessageAttachment] =
    MessageAttachmentKind.fromString(resultSet.getString("kind")).map(kind =>
      val objectKey = resultSet.getString("object_key")
      MessageAttachment(
        id = MessageAttachmentId(resultSet.getObject("id", classOf[java.util.UUID])),
        kind = kind,
        url = storage.publicUrl(objectKey),
        objectKey = objectKey,
        fileName = resultSet.getString("file_name"),
        mimeType = resultSet.getString("mime_type"),
        sizeBytes = resultSet.getLong("size_bytes"),
        createdAt = resultSet.getTimestamp("created_at").toInstant
      )
    ).left.map(AppError.Decoding.apply)
