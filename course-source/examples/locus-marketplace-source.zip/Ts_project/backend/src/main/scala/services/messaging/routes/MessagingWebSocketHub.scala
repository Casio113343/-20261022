package messaging.routes
import identity.model.*
import listings.model.*
import messaging.model.*


import cats.effect.IO
import cats.effect.kernel.Ref
import cats.effect.std.Queue
import fs2.Stream
import io.circe.syntax.*
import shared.*
import org.http4s.websocket.WebSocketFrame

final class MessagingWebSocketHub private (
  private val subscribers: Ref[IO, Map[ConversationId, Set[Queue[IO, WebSocketFrame]]]]
):

  def subscribe(conversationId: ConversationId, queue: Queue[IO, WebSocketFrame]): IO[Unit] =
    subscribers.update { current =>
      current.updated(conversationId, current.getOrElse(conversationId, Set.empty) + queue)
    }

  def remove(queue: Queue[IO, WebSocketFrame]): IO[Unit] =
    subscribers.update(
      _.view
        .mapValues(_.filterNot(_ == queue))
        .filter { case (_, queues) => queues.nonEmpty }
        .toMap
    )

  def publish(event: ServerMessagingEvent): IO[Unit] =
    subscribers.get.flatMap { current =>
      current
        .getOrElse(event.conversationId, Set.empty)
        .toList
        .foldLeft(IO.unit)((acc, queue) => acc *> queue.offer(WebSocketFrame.Text(event.asJson.noSpaces)))
    }

  def stream(queue: Queue[IO, WebSocketFrame]): Stream[IO, WebSocketFrame] =
    Stream.fromQueueUnterminated(queue)

object MessagingWebSocketHub:
  def create: IO[MessagingWebSocketHub] =
    Ref.of[IO, Map[ConversationId, Set[Queue[IO, WebSocketFrame]]]](Map.empty).map(MessagingWebSocketHub(_))
