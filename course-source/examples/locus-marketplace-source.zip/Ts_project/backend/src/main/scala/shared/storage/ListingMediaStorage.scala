package shared

import cats.effect.{IO, Resource}
import io.minio.BucketExistsArgs
import io.minio.GetObjectArgs
import io.minio.MakeBucketArgs
import io.minio.MinioClient
import io.minio.PutObjectArgs
import io.minio.RemoveObjectArgs
import io.minio.SetBucketPolicyArgs
import org.typelevel.log4cats.slf4j.Slf4jLogger

import java.io.ByteArrayInputStream

final class ListingMediaStorage private (
  val config: ObjectStorageConfig,
  private val client: MinioClient
):

  private val logger = Slf4jLogger.getLogger[IO]

  def initialize: IO[Unit] =
    ensureBucketExists *> ensurePublicReadPolicy

  def publicUrl(objectKey: String): String =
    MediaUrlResolver.listingImageUrl(config)(objectKey)

  def uploadBytes(
    objectKey: String,
    bytes: Array[Byte],
    contentType: String
  ): IO[Unit] =
    Resource
      .fromAutoCloseable(IO.blocking(ByteArrayInputStream(bytes)))
      .use(stream =>
        IO.blocking {
        client.putObject(
          PutObjectArgs
            .builder()
            .bucket(config.bucketName)
            .`object`(objectKey)
            .stream(stream, bytes.length.toLong, -1)
            .contentType(contentType)
            .build()
        )
        }.void
      )

  def deleteObject(objectKey: String): IO[Unit] =
    IO.blocking {
      client.removeObject(
        RemoveObjectArgs
          .builder()
          .bucket(config.bucketName)
          .`object`(objectKey)
          .build()
      )
    }.void.handleErrorWith { error =>
      logger.warn(error)(s"Unable to delete object $objectKey from ${config.bucketName}")
    }

  def readObjectBytes(objectKey: String): IO[Array[Byte]] =
    Resource
      .fromAutoCloseable(
        IO.blocking {
        client.getObject(
          GetObjectArgs
            .builder()
            .bucket(config.bucketName)
            .`object`(objectKey)
            .build()
        )
        }
      )
      .use(stream => IO.blocking(stream.readAllBytes()))

  private def ensureBucketExists: IO[Unit] =
    IO.blocking {
      val exists =
        client.bucketExists(
          BucketExistsArgs
            .builder()
            .bucket(config.bucketName)
            .build()
        )

      if !exists then
        client.makeBucket(
          MakeBucketArgs
            .builder()
            .bucket(config.bucketName)
            .build()
        )
    }.void

  private def ensurePublicReadPolicy: IO[Unit] =
    val policy =
      s"""{
         |  "Version": "2012-10-17",
         |  "Statement": [
         |    {
         |      "Effect": "Allow",
         |      "Principal": {"AWS": ["*"]},
         |      "Action": ["s3:GetObject"],
         |      "Resource": ["arn:aws:s3:::${config.bucketName}/*"]
         |    }
         |  ]
         |}
         |""".stripMargin

    IO.blocking {
      client.setBucketPolicy(
        SetBucketPolicyArgs
          .builder()
          .bucket(config.bucketName)
          .config(policy)
          .build()
      )
    }.void

object ListingMediaStorage:

  def initialize: Resource[IO, ListingMediaStorage] =
    for
      config <- Resource.eval(ObjectStorageConfig.load)
      client <- Resource.eval(IO.delay(
        MinioClient
          .builder()
          .endpoint(config.endpoint)
          .credentials(config.accessKey, config.secretKey)
          .build()
      ))
      storage = ListingMediaStorage(config, client)
      _ <- Resource.eval(storage.initialize)
    yield storage
