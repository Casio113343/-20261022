package renovations.api.responses

import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import renovations.model.ListingRenovation

final case class ListListingRenovationsResponse(
  renovations: List[ListingRenovation]
)

object ListListingRenovationsResponse:
  given Encoder[ListListingRenovationsResponse] = deriveEncoder[ListListingRenovationsResponse]
