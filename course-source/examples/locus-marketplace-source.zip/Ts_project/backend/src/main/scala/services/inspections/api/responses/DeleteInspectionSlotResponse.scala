package inspections.api.responses
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class DeleteInspectionSlotResponse()

object DeleteInspectionSlotResponse:
  given Encoder[DeleteInspectionSlotResponse] = deriveEncoder[DeleteInspectionSlotResponse]
