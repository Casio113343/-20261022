package inspections.application

import cats.effect.IO
import cats.syntax.all.*
import identity.api.IdentityPublicApi
import identity.model.UserId
import inspections.model.*
import inspections.tables.inspection_slots.InspectionSlotsTable
import listings.api.ListingsPublicApi
import shared.{AppError, AppResult, ListingMediaStorage}

import java.sql.Connection

private[inspections] object InspectionApplication:

  def findPublicSlot(
    connection: Connection,
    slotId: InspectionSlotId,
    buyerId: UserId
  ): IO[AppResult[PublicInspectionSlot]] =
    InspectionSlotsTable.listingIdForSlot(connection, slotId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(listingId) =>
        ListingsPublicApi.findActiveConversationListing(connection, listingId).flatMap {
          case Left(error) => IO.pure(Left(error))
          case Right(None) => IO.pure(Right(Nil))
          case Right(Some(_)) =>
            InspectionSlotsTable.listPublicSlots(connection, listingId, Some(buyerId))
        }.map(
          _.flatMap(_.find(_.id == slotId).toRight(AppError.NotFound("Inspection slot not found")))
        )
    }

  def listAgentSlots(
    connection: Connection,
    storage: ListingMediaStorage,
    agentId: UserId
  ): IO[AppResult[List[AgentInspectionSlot]]] =
    InspectionSlotsTable.listAgentSlots(connection, agentId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(records) => enrichAgentSlots(connection, storage, records)
    }

  private def enrichAgentSlots(
    connection: Connection,
    storage: ListingMediaStorage,
    records: List[InspectionSlotsTable.AgentInspectionSlotRecord]
  ): IO[AppResult[List[AgentInspectionSlot]]] =
    for
      listingMapResult <- ListingsPublicApi.loadAnyConversationListingMap(
        connection,
        records.map(_.listingId)
      )
      buyerMapResult <- IdentityPublicApi.loadUserMap(
        connection,
        storage,
        records.flatMap(_.buyerId)
      )
    yield
      for
        listingMap <- listingMapResult
        buyerMap <- buyerMapResult
        slots <- records.foldRight(Right(Nil): AppResult[List[AgentInspectionSlot]]) { (record, acc) =>
          for
            tail <- acc
            listing <- listingMap.get(record.listingId).toRight(AppError.NotFound("Listing not found"))
            buyer <- record.buyerId.traverse(id =>
              buyerMap
                .get(id)
                .toRight(AppError.NotFound("Inspection buyer not found"))
                .map(user => InspectionBuyerSummary(user.id, user.fullName, user.email, user.avatarUrl))
            )
          yield AgentInspectionSlot(
            id = record.id,
            listing = InspectionListingSummary(
              id = listing.summary.id,
              addressLine = listing.summary.addressLine,
              suburb = listing.summary.suburb,
              state = listing.summary.state,
              postcode = listing.summary.postcode
            ),
            startsAt = record.startsAt,
            endsAt = record.endsAt,
            bookingId = record.bookingId,
            bookedAt = record.bookedAt,
            buyer = buyer
          ) :: tail
        }
      yield slots
