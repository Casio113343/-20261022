package inspections.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import identity.model.UserId

final case class InspectionBuyerSummary(
  id: UserId,
  fullName: String,
  email: String,
  avatarUrl: Option[String]
)

object InspectionBuyerSummary:
  given Encoder[InspectionBuyerSummary] = deriveEncoder[InspectionBuyerSummary]
  given Decoder[InspectionBuyerSummary] = deriveDecoder[InspectionBuyerSummary]
