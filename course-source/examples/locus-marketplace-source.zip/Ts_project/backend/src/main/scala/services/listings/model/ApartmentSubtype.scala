package listings.model


import io.circe.{Decoder, Encoder}

enum ApartmentSubtype:
  case Standard
  case Unit
  case Penthouse
  case Studio
  case OffThePlan

object ApartmentSubtype:
  def fromString(value: String): Either[String, ApartmentSubtype] =
    value.trim.toLowerCase match
      case "standard" => Right(ApartmentSubtype.Standard)
      case "unit" => Right(ApartmentSubtype.Unit)
      case "penthouse" => Right(ApartmentSubtype.Penthouse)
      case "studio" => Right(ApartmentSubtype.Studio)
      case "off_the_plan" => Right(ApartmentSubtype.OffThePlan)
      case other => Left(s"Unsupported apartment subtype: $other")

  def toString(value: ApartmentSubtype): String =
    value match
      case ApartmentSubtype.Standard => "standard"
      case ApartmentSubtype.Unit => "unit"
      case ApartmentSubtype.Penthouse => "penthouse"
      case ApartmentSubtype.Studio => "studio"
      case ApartmentSubtype.OffThePlan => "off_the_plan"

  given Encoder[ApartmentSubtype] = Encoder.encodeString.contramap(toString)
  given Decoder[ApartmentSubtype] = Decoder.decodeString.emap(fromString)
