package listings.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class ListingFaq(
  question: String,
  response: String
)

object ListingFaq:
  given Encoder[ListingFaq] = deriveEncoder[ListingFaq]
  given Decoder[ListingFaq] = deriveDecoder[ListingFaq]
