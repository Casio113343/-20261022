package messaging.api.responses
import identity.model.*
import listings.model.*
import messaging.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import shared.*

final case class ListConversationsResponse(conversations: List[ConversationSummary])

object ListConversationsResponse:
  given Encoder[ListConversationsResponse] = deriveEncoder[ListConversationsResponse]
