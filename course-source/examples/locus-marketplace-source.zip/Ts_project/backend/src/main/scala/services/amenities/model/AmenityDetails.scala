package amenities.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class AmenityDetails(
  businessStatus: Option[String],
  googleMapsUri: Option[String],
  nationalPhoneNumber: Option[String],
  openingStatus: Option[String],
  photoUrls: List[String],
  reviews: List[AmenityReview],
  todayHours: Option[String],
  weekdayDescriptions: List[String],
  websiteUri: Option[String]
)

object AmenityDetails:
  given Encoder[AmenityDetails] = deriveEncoder[AmenityDetails]
  given Decoder[AmenityDetails] = deriveDecoder[AmenityDetails]
