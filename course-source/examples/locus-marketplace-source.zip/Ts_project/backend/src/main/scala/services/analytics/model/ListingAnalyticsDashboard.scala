package analytics.model

import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import shared.TimeCodecs

import java.time.Instant

import TimeCodecs.given

final case class ListingAnalyticsDashboard(
  summary: ListingAnalyticsSummary,
  range: ListingAnalyticsDateRange,
  timeline: List[ListingAnalyticsDay],
  funnel: List[ListingAnalyticsFunnelStep],
  search: ListingAnalyticsSearchPerformance,
  trafficSources: List[ListingAnalyticsBreakdownItem],
  deviceBreakdown: List[ListingAnalyticsBreakdownItem],
  searchFilters: List[ListingAnalyticsBreakdownItem],
  amenities: List[ListingAnalyticsBreakdownItem],
  photos: List[ListingAnalyticsBreakdownItem],
  photoEngagement: ListingAnalyticsPhotoEngagement,
  messages: ListingAnalyticsLeadPerformance,
  inspections: ListingAnalyticsInspectionPerformance,
  leadQuality: ListingAnalyticsLeadQuality,
  benchmark: List[ListingAnalyticsBenchmark],
  recommendations: List[ListingAnalyticsRecommendation],
  activity: List[ListingAnalyticsActivity]
)

final case class ListingAnalyticsSummary(
  views: Int,
  favourites: Int,
  messages: Int,
  inspectionRequests: Int,
  conversionRate: Double
)

final case class ListingAnalyticsDay(
  date: String,
  views: Int,
  favourites: Int,
  messages: Int,
  inspectionRequests: Int
)

final case class ListingAnalyticsFunnelStep(
  label: String,
  value: Int
)

final case class ListingAnalyticsSearchPerformance(
  impressions: Int,
  clicks: Int,
  clickThroughRate: Double
)

final case class ListingAnalyticsBreakdownItem(
  label: String,
  value: Int
)

final case class ListingAnalyticsPhotoEngagement(
  galleryEngagementRate: Double,
  averagePhotoIndex: Double,
  mostOpenedPhoto: Option[String],
  firstPhotoOpens: Int,
  floorPlanOpens: Int
)

final case class ListingAnalyticsLeadPerformance(
  conversations: Int,
  responseActions: Int
)

final case class ListingAnalyticsInspectionPerformance(
  requests: Int,
  requestRate: Double
)

final case class ListingAnalyticsLeadQuality(
  highIntentActions: Int,
  savedToLeadRate: Double,
  viewToLeadRate: Double,
  searchClickToLeadRate: Double
)

final case class ListingAnalyticsBenchmark(
  label: String,
  value: Int,
  peerAverage: Int,
  deltaPercent: Int
)

final case class ListingAnalyticsRecommendation(
  id: String,
  title: String,
  message: String
)

final case class ListingAnalyticsActivity(
  label: String,
  eventType: ListingAnalyticsEventType,
  occurredAt: Instant
)

object ListingAnalyticsDashboard:
  given Encoder[ListingAnalyticsSummary] = deriveEncoder[ListingAnalyticsSummary]
  given Encoder[ListingAnalyticsDay] = deriveEncoder[ListingAnalyticsDay]
  given Encoder[ListingAnalyticsFunnelStep] = deriveEncoder[ListingAnalyticsFunnelStep]
  given Encoder[ListingAnalyticsSearchPerformance] = deriveEncoder[ListingAnalyticsSearchPerformance]
  given Encoder[ListingAnalyticsBreakdownItem] = deriveEncoder[ListingAnalyticsBreakdownItem]
  given Encoder[ListingAnalyticsPhotoEngagement] = deriveEncoder[ListingAnalyticsPhotoEngagement]
  given Encoder[ListingAnalyticsLeadPerformance] = deriveEncoder[ListingAnalyticsLeadPerformance]
  given Encoder[ListingAnalyticsInspectionPerformance] = deriveEncoder[ListingAnalyticsInspectionPerformance]
  given Encoder[ListingAnalyticsLeadQuality] = deriveEncoder[ListingAnalyticsLeadQuality]
  given Encoder[ListingAnalyticsBenchmark] = deriveEncoder[ListingAnalyticsBenchmark]
  given Encoder[ListingAnalyticsRecommendation] = deriveEncoder[ListingAnalyticsRecommendation]
  given Encoder[ListingAnalyticsActivity] = deriveEncoder[ListingAnalyticsActivity]
  given Encoder[ListingAnalyticsDashboard] = deriveEncoder[ListingAnalyticsDashboard]
