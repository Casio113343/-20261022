package analytics.api.messages

import analytics.api.requests.GetManagedListingAnalyticsRequest
import analytics.api.responses.GetManagedListingAnalyticsResponse
import analytics.tables.listing_analytics_events.ListingAnalyticsEventsTable
import cats.effect.IO
import identity.api.IdentityPublicApi
import listings.api.ListingsPublicApi
import shared.{ApiTransaction, ApiWithTokenMessage, AppError, AppResult, AuthenticatedPrincipal}

import java.sql.Connection

object GetManagedListingAnalyticsApiMessage
    extends ApiWithTokenMessage[GetManagedListingAnalyticsRequest, GetManagedListingAnalyticsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(
    request: GetManagedListingAnalyticsRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[GetManagedListingAnalyticsResponse]] =
    ListingsPublicApi.listingOwnedByAgent(connection, request.listingId, principal.userId).flatMap {
      case false => IO.pure(Left(AppError.NotFound("Listing not found")))
      case true =>
        ListingAnalyticsEventsTable
          .loadDashboard(connection, request.listingId, request.range)
          .map(_.map(GetManagedListingAnalyticsResponse.apply))
    }
