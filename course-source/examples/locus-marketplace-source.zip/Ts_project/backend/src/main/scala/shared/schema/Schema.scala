package shared

import cats.effect.IO
import analytics.tables.AnalyticsSchema
import favourites.tables.FavouritesSchema
import fengshui.tables.FengshuiSchema
import identity.tables.IdentitySchema
import inspections.tables.InspectionsSchema
import listings.tables.ListingsSchema
import media.tables.MediaSchema
import messaging.tables.MessagingSchema
import renovations.tables.RenovationsSchema

import java.sql.Connection

object Schema:

  private val serviceSchemas: List[Connection => IO[Unit]] =
    List(
      IdentitySchema.initialize,
      ListingsSchema.initialize,
      MediaSchema.initialize,
      FavouritesSchema.initialize,
      MessagingSchema.initialize,
      InspectionsSchema.initialize,
      FengshuiSchema.initialize,
      RenovationsSchema.initialize,
      AnalyticsSchema.initialize
    )

  def initialize(connection: Connection): IO[Unit] =
    serviceSchemas.foldLeft(IO.unit)((program, initializeService) => program *> initializeService(connection))
