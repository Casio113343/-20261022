package fengshui.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class FengshuiHouseInsight(
  id: String,
  title: String,
  location: String,
  summary: String
)

object FengshuiHouseInsight:
  given Encoder[FengshuiHouseInsight] = deriveEncoder[FengshuiHouseInsight]
  given Decoder[FengshuiHouseInsight] = deriveDecoder[FengshuiHouseInsight]
