package listings.api

import cats.effect.IO
import identity.model.UserId
import listings.application.ListingApplication
import listings.model.{ListingDetail, ListingId, ListingStatus, ListingSummary}
import listings.tables.listing_records.ListingQueriesTable
import shared.{AppError, AppResult, ListingMediaStorage}

import java.sql.Connection

object ListingsPublicApi:

  def findPublicDetail(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    listingId: ListingId
  ): IO[AppResult[Option[ListingDetail]]] =
    ListingApplication.findPublicDetail(connection, listingMediaStorage, listingId)

  def findPublicSummaries(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    listingIds: List[ListingId]
  ): IO[AppResult[List[ListingSummary]]] =
    ListingApplication.findPublicSummaries(connection, listingMediaStorage, listingIds)

  def findConversationListing(
    connection: Connection,
    listingId: ListingId
  ): IO[AppResult[Option[ConversationListingTarget]]] =
    ListingQueriesTable.findConversationListing(
      connection,
      listingId,
      Some(List(ListingStatus.Active, ListingStatus.Sold, ListingStatus.Leased))
    ).map(
      _.map(_.map(record => ConversationListingTarget(record.summary, record.agentId)))
    )

  def findActiveConversationListing(
    connection: Connection,
    listingId: ListingId
  ): IO[AppResult[Option[ConversationListingTarget]]] =
    ListingQueriesTable.findConversationListing(connection, listingId, Some(List(ListingStatus.Active))).map(
      _.map(_.map(record => ConversationListingTarget(record.summary, record.agentId)))
    )

  def findAnyConversationListing(
    connection: Connection,
    listingId: ListingId
  ): IO[AppResult[Option[ConversationListingTarget]]] =
    ListingQueriesTable.findConversationListing(connection, listingId, None).map(
      _.map(_.map(record => ConversationListingTarget(record.summary, record.agentId)))
    )

  def listingOwnedByAgent(connection: Connection, listingId: ListingId, agentId: UserId): IO[Boolean] =
    ListingQueriesTable.listingOwnedByAgent(connection, listingId, agentId)

  def loadConversationListingMap(
    connection: Connection,
    listingIds: List[ListingId]
  ): IO[AppResult[Map[ListingId, ConversationListingTarget]]] =
    listingIds.distinct.foldLeft(IO.pure(Right(Map.empty): AppResult[Map[ListingId, ConversationListingTarget]])) { (acc, listingId) =>
      for
        loaded <- acc
        next <- loaded match
          case Left(error) => IO.pure(Left(error))
          case Right(targets) =>
            findConversationListing(connection, listingId).map(
              _.flatMap(_.toRight(AppError.NotFound("Listing not found")).map(target => targets + (listingId -> target)))
            )
      yield next
    }

  def loadAnyConversationListingMap(
    connection: Connection,
    listingIds: List[ListingId]
  ): IO[AppResult[Map[ListingId, ConversationListingTarget]]] =
    listingIds.distinct.foldLeft(IO.pure(Right(Map.empty): AppResult[Map[ListingId, ConversationListingTarget]])) { (acc, listingId) =>
      for
        loaded <- acc
        next <- loaded match
          case Left(error) => IO.pure(Left(error))
          case Right(targets) =>
            findAnyConversationListing(connection, listingId).map(
              _.flatMap(_.toRight(AppError.NotFound("Listing not found")).map(target => targets + (listingId -> target)))
            )
      yield next
    }
