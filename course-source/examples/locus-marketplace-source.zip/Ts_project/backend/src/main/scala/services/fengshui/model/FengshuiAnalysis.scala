package fengshui.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class FengshuiAnalysis(
  overallScore: Int,
  overallLabel: String,
  overallSummary: String,
  orientation: FengshuiOrientation,
  houseInsights: List[FengshuiHouseInsight],
  priorityActions: List[FengshuiPriorityAction],
  confidenceNote: String
)

object FengshuiAnalysis:
  given Encoder[FengshuiAnalysis] = deriveEncoder[FengshuiAnalysis]
  given Decoder[FengshuiAnalysis] = deriveDecoder[FengshuiAnalysis]
