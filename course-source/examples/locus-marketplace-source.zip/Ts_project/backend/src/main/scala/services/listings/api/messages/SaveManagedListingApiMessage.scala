package listings.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.AfterCommitApiWithTokenMessage
import cats.effect.IO
import database.TransactionSuccess
import identity.api.IdentityPublicApi
import listings.api.requests.SaveManagedListingRequest
import listings.api.responses.SaveManagedListingResponse
import listings.application.ListingApplication
import shared.{AppError, AppResult}
import shared.AuthenticatedPrincipal
import shared.ListingMediaStorage
import renovations.api.RenovationScheduler

import java.sql.Connection

final case class SaveManagedListingApiMessage(
  storage: ListingMediaStorage,
  renovationScheduler: RenovationScheduler
)
    extends AfterCommitApiWithTokenMessage[SaveManagedListingRequest, SaveManagedListingResponse]:


  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(
    request: SaveManagedListingRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[TransactionSuccess[SaveManagedListingResponse]]] =
    val saveProgram = request.listingId match
      case Some(listingId) =>
        ListingApplication.update(connection, storage, renovationScheduler, principal.userId, listingId, request.listing)
      case None =>
        ListingApplication.create(connection, storage, renovationScheduler, principal.userId, request.listing)

    saveProgram.map(_.map(transaction => transaction.copy(value = SaveManagedListingResponse(transaction.value))))
