package listings.api.responses
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import listings.model.ListingDetail

final case class SaveManagedListingResponse(
  listing: ListingDetail
)

object SaveManagedListingResponse:
  given Encoder[SaveManagedListingResponse] = deriveEncoder[SaveManagedListingResponse]
