package identity.model

final case class SignInCredentials(
  email: String,
  password: String
)
