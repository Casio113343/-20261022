package renovations.tables

import cats.effect.IO
import renovations.tables.renovation_images.RenovationImagesTable

import java.sql.Connection

object RenovationsSchema:
  def initialize(connection: Connection): IO[Unit] =
    RenovationImagesTable.initialize(connection)
