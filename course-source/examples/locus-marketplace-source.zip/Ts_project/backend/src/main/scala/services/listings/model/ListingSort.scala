package listings.model


import io.circe.{Decoder, Encoder}

enum ListingSort:
  case Newest
  case PriceAscending
  case PriceDescending

object ListingSort:
  def fromString(value: String): Either[String, ListingSort] =
    value.trim.toLowerCase match
      case "newest" => Right(ListingSort.Newest)
      case "price_asc" => Right(ListingSort.PriceAscending)
      case "price_desc" => Right(ListingSort.PriceDescending)
      case other => Left(s"Unsupported sort: $other")

  def toString(value: ListingSort): String =
    value match
      case ListingSort.Newest => "newest"
      case ListingSort.PriceAscending => "price_asc"
      case ListingSort.PriceDescending => "price_desc"

  given Encoder[ListingSort] = Encoder.encodeString.contramap(toString)
  given Decoder[ListingSort] = Decoder.decodeString.emap(fromString)
