package inspections.model


import io.circe.{Decoder, Encoder}

import java.util.UUID

final case class InspectionBookingId(value: UUID) extends AnyVal

object InspectionBookingId:
  given Encoder[InspectionBookingId] = Encoder.encodeUUID.contramap(_.value)
  given Decoder[InspectionBookingId] = Decoder.decodeUUID.map(InspectionBookingId(_))
