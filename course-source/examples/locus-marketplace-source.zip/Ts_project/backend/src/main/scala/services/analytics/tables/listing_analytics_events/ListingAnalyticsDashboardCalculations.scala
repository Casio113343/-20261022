package analytics.tables.listing_analytics_events

import analytics.model.*
import analytics.tables.listing_analytics_events.ListingAnalyticsDashboardReads.{EventCounts, PeerAverages, PhotoEngagementStats}

private[analytics] object ListingAnalyticsDashboardCalculations:

  // Dashboard assembly is pure: all database reads happen before this point, and this
  // object only turns counted events into the agent-facing analytics response.
  def build(
    range: ListingAnalyticsDateRange,
    counts: EventCounts,
    timeline: List[ListingAnalyticsDay],
    trafficSources: List[ListingAnalyticsBreakdownItem],
    deviceBreakdown: List[ListingAnalyticsBreakdownItem],
    searchFilters: List[ListingAnalyticsBreakdownItem],
    amenities: List[ListingAnalyticsBreakdownItem],
    photos: List[ListingAnalyticsBreakdownItem],
    photoEngagementStats: PhotoEngagementStats,
    peerAverages: PeerAverages,
    activity: List[ListingAnalyticsActivity]
  ): ListingAnalyticsDashboard =
    ListingAnalyticsDashboard(
      range = range,
      summary = ListingAnalyticsSummary(
        views = counts.views,
        favourites = counts.favourites,
        messages = counts.messages,
        inspectionRequests = counts.inspections,
        conversionRate = percent(counts.messages + counts.inspections, counts.views)
      ),
      timeline = timeline,
      funnel = funnel(counts),
      search = ListingAnalyticsSearchPerformance(
        impressions = counts.searchImpressions,
        clicks = counts.searchClicks,
        clickThroughRate = percent(counts.searchClicks, counts.searchImpressions)
      ),
      trafficSources = trafficSources,
      deviceBreakdown = deviceBreakdown,
      searchFilters = searchFilters,
      amenities = amenities,
      photos = photos,
      photoEngagement = ListingAnalyticsPhotoEngagement(
        galleryEngagementRate = percent(counts.photoOpens, counts.views),
        averagePhotoIndex =
          if photoEngagementStats.indexedPhotoOpens <= 0 then 0.0
          else BigDecimal(photoEngagementStats.photoIndexTotal.toDouble / photoEngagementStats.indexedPhotoOpens.toDouble)
            .setScale(1, BigDecimal.RoundingMode.HALF_UP)
            .toDouble,
        mostOpenedPhoto = photos.headOption.map(_.label),
        firstPhotoOpens = photoEngagementStats.firstPhotoOpens,
        floorPlanOpens = photoEngagementStats.floorPlanOpens
      ),
      messages = ListingAnalyticsLeadPerformance(
        conversations = counts.messages,
        responseActions = counts.messages + counts.inspections
      ),
      inspections = ListingAnalyticsInspectionPerformance(
        requests = counts.inspections,
        requestRate = percent(counts.inspections, counts.views)
      ),
      leadQuality = ListingAnalyticsLeadQuality(
        highIntentActions = counts.favourites + counts.messages + counts.inspections,
        savedToLeadRate = percent(counts.messages + counts.inspections, counts.favourites),
        viewToLeadRate = percent(counts.messages + counts.inspections, counts.views),
        searchClickToLeadRate = percent(counts.messages + counts.inspections, counts.searchClicks)
      ),
      benchmark = benchmark(counts, peerAverages),
      recommendations = recommendations(counts),
      activity = activity
    )

  // Funnel, benchmark, and recommendation helpers are presentation-level calculations:
  // they transform counted events into the agent-facing analytics sections.
  private def funnel(counts: EventCounts): List[ListingAnalyticsFunnelStep] =
    List(
      ListingAnalyticsFunnelStep("Views", counts.views),
      ListingAnalyticsFunnelStep("Photos", counts.photoOpens),
      ListingAnalyticsFunnelStep("Amenities", counts.amenityInterest),
      ListingAnalyticsFunnelStep("Saved", counts.favourites),
      ListingAnalyticsFunnelStep("Messages", counts.messages),
      ListingAnalyticsFunnelStep("Inspections", counts.inspections)
    )

  private def benchmark(counts: EventCounts, peerAverages: PeerAverages): List[ListingAnalyticsBenchmark] =
    List(
      ListingAnalyticsBenchmark("Views", counts.views, peerAverages.views, deltaPercent(counts.views, peerAverages.views)),
      ListingAnalyticsBenchmark("Saved", counts.favourites, peerAverages.favourites, deltaPercent(counts.favourites, peerAverages.favourites)),
      ListingAnalyticsBenchmark("Messages", counts.messages, peerAverages.messages, deltaPercent(counts.messages, peerAverages.messages)),
      ListingAnalyticsBenchmark("Inspections", counts.inspections, peerAverages.inspections, deltaPercent(counts.inspections, peerAverages.inspections))
    )

  private def recommendations(counts: EventCounts): List[ListingAnalyticsRecommendation] =
    // Thresholds are deliberately conservative so the dashboard avoids noisy advice
    // when a listing has only a handful of events.
    val lowSearchClick =
      Option.when(counts.searchImpressions >= 20 && percent(counts.searchClicks, counts.searchImpressions) < 8)(
        ListingAnalyticsRecommendation(
          "search-clicks",
          "Search appeal",
          "Improve the first photo, price position, or headline details."
        )
      )
    val lowLeads =
      Option.when(counts.views >= 20 && counts.messages + counts.inspections == 0)(
        ListingAnalyticsRecommendation(
          "lead-rate",
          "Lead conversion",
          "Add clearer inspection times and stronger contact prompts."
        )
      )
    val amenityInterest =
      Option.when(counts.amenityInterest >= 5)(
        ListingAnalyticsRecommendation(
          "amenities",
          "Amenity demand",
          "Mention the top nearby amenities in the listing copy."
        )
      )
    val photoInterest =
      Option.when(counts.views > 0 && counts.photoOpens < counts.views / 4)(
        ListingAnalyticsRecommendation(
          "photos",
          "Gallery engagement",
          "Review the gallery order for stronger first impressions."
        )
      )
    val savedButQuiet =
      Option.when(counts.favourites >= 5 && counts.messages + counts.inspections < counts.favourites / 3)(
        ListingAnalyticsRecommendation(
          "saved-but-quiet",
          "Saved audience",
          "Buyers are saving this listing. Add urgency around inspection availability."
        )
      )

    List(lowSearchClick, lowLeads, amenityInterest, photoInterest, savedButQuiet).flatten.take(4) match
      case Nil =>
        List(ListingAnalyticsRecommendation(
          "healthy",
          "Steady performance",
          "Performance is stable. Keep monitoring search and lead trends."
        ))
      case items => items

  private def percent(numerator: Int, denominator: Int): Double =
    if denominator <= 0 then 0.0
    else BigDecimal(numerator * 100.0 / denominator).setScale(1, BigDecimal.RoundingMode.HALF_UP).toDouble

  private def deltaPercent(value: Int, peerAverage: Int): Int =
    if peerAverage <= 0 then 0
    else Math.round(((value - peerAverage).toDouble / peerAverage.toDouble) * 100).toInt
