package amenities.model

import io.circe.{Decoder, Encoder}

enum TravelMode:
  case Walking, Driving, Transit

object TravelMode:
  def toString(value: TravelMode): String =
    value match
      case TravelMode.Walking => "walking"
      case TravelMode.Driving => "driving"
      case TravelMode.Transit => "transit"

  def fromString(value: String): Either[String, TravelMode] =
    value match
      case "walking" => Right(TravelMode.Walking)
      case "driving" => Right(TravelMode.Driving)
      case "transit" => Right(TravelMode.Transit)
      case other => Left(s"Unsupported travel mode: $other")

  given Encoder[TravelMode] = Encoder.encodeString.contramap(toString)
  given Decoder[TravelMode] = Decoder.decodeString.emap(fromString)
