package listings.tables
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import _root_.listings.tables.listing_records.ListingsTable

import java.sql.Connection

object ListingsSchema:

  def initialize(connection: Connection): IO[Unit] =
    ListingsTable.initialize(connection)
