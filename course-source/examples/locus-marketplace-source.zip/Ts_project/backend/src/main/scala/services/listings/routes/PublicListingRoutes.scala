package listings.routes
import identity.model.*
import listings.model.*
import media.model.*


import shared.ApiMessage
import listings.api.messages.{GetPublicListingDetailApiMessage, SearchPublicListingsApiMessage}
import shared.ListingMediaStorage

object PublicListingRoutes:

  def apiMessages(storage: ListingMediaStorage): List[ApiMessage] =
    List(
      SearchPublicListingsApiMessage(storage),
      GetPublicListingDetailApiMessage(storage)
    )
