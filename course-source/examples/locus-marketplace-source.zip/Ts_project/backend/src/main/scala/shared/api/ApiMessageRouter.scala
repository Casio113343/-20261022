package shared

import cats.data.EitherT
import cats.effect.IO
import cats.syntax.all.*
import database.{DatabaseSession, TransactionSuccess}
import io.circe.Json
import io.circe.parser.decode
import io.circe.syntax.*
import shared.{AppError, ErrorResponse}
import org.http4s.circe.CirceEntityEncoder.*
import org.http4s.dsl.io.*
import org.http4s.{Header, HttpRoutes, Request, Response}
import org.http4s.multipart.Multipart
import org.typelevel.ci.CIString
import org.typelevel.log4cats.slf4j.Slf4jLogger

import java.sql.Connection

object ApiMessageRouter:

  private val logger = Slf4jLogger.getLogger[IO]

  private enum RouteFailure:
    case Unauthorized(message: String)
    case Forbidden(message: String)
    case NotFound(message: String)
    case BadRequest(message: String)
    case Conflict(message: String)
    case RateLimited(message: String)

  private type RouteResult[A] = EitherT[IO, RouteFailure, A]

  private val sessionCookieName = "locus_session"
  private val csrfCookieName = "locus_csrf"
  private val csrfHeaderName = "X-CSRF-Token"
  private val sessionMaxAgeSeconds = 60 * 60 * 24 * 30
  private val secureCookie = sys.env.get("SESSION_COOKIE_SECURE").exists(_.trim.equalsIgnoreCase("true"))

  def routes(
    databaseSession: DatabaseSession,
    serviceMessages: List[ApiServiceMessages],
    tokenResolver: ApiTokenResolver,
    rateLimiter: ApiRateLimiter
  ): HttpRoutes[IO] =
    val messagesByName =
      serviceMessages
        .flatMap(service => service.messages.map(message => (service.serviceName, message.apiName) -> message))
        .toMap

    HttpRoutes.of[IO] {
      case req @ POST -> Root / "api" / "messages" / serviceName / "requests" / apiName =>
        messagesByName.get(serviceName -> apiName) match
          case Some(message) => handleMessage(databaseSession, tokenResolver, rateLimiter, serviceName, apiName, message, req)
          case None => NotFound(ErrorResponse(s"Unknown API message: $serviceName/$apiName").asJson)
    }

  private def handleMessage(
    databaseSession: DatabaseSession,
    tokenResolver: ApiTokenResolver,
    rateLimiter: ApiRateLimiter,
    serviceName: String,
    apiName: String,
    message: ApiMessage,
    req: Request[IO]
  ): IO[Response[IO]] =
    val result =
      message.transaction match
        case ApiTransaction.ReadOnly =>
          databaseSession
            .withConnection(connection => executeMessage(message, tokenResolver, req, connection))
            .map(_.map(_.value))
        case ApiTransaction.ReadWrite =>
          databaseSession
            .withTransactionEitherConnection(connection => executeMessage(message, tokenResolver, req, connection).map(_.map(_.value)))
        case ApiTransaction.AfterCommit =>
          databaseSession.withTransactionEitherConnectionAfterCommit(connection => executeMessage(message, tokenResolver, req, connection))

    val limitedResult =
      rateLimiter.allow(clientKey(req), serviceName, apiName).flatMap {
        case true => result
        case false => IO.pure(Left(RouteFailure.RateLimited("Too many requests. Please slow down.")))
      }

    handleRequest(limitedResult.flatMap(_.traverse(apiResponse => Ok(apiResponse.body).map(withSessionCookies(_, apiResponse.sessionDirective)))))

  private def executeMessage(
    message: ApiMessage,
    tokenResolver: ApiTokenResolver,
    req: Request[IO],
    connection: Connection
  ): IO[Either[RouteFailure, ApiMessage.Response]] =
    (
      for
        authorization <- resolveAuthorization(message.authorization, tokenResolver, connection, req)
        request <- decodeRequest(message, req)
        response <- liftApp(message.planAny(request, authorization, connection))
      yield response
    ).value

  private def decodeRequest(message: ApiMessage, req: Request[IO]): RouteResult[ApiMessage.Request] =
    message match
      case multipartMessage: MultipartMessage =>
        liftIO(req.as[Multipart[IO]])
          .flatMap(multipart => liftApp(multipartMessage.decodeMultipartAny(multipart)))
      case _ =>
        liftIO(req.as[String])
          .flatMap(rawBody =>
            val json = rawBody.trim match
              case "" => Right(Json.obj())
              case body => decode[Json](body).left.map(error => AppError.Decoding(error.getMessage))

            EitherT.fromEither[IO](json.flatMap(message.decodeJson).left.map(toRouteFailure))
          )

  private def resolveAuthorization(
    authorization: ApiAuthorization,
    tokenResolver: ApiTokenResolver,
    connection: Connection,
    req: Request[IO]
  ): RouteResult[ResolvedApiAuthorization] =
    authorization match
      case ApiAuthorization.Public =>
        EitherT.rightT(ResolvedApiAuthorization.Public)
      case ApiAuthorization.OptionalPrincipal =>
        optionalPrincipal(tokenResolver, connection, req).map(ResolvedApiAuthorization.OptionalPrincipal.apply)
      case ApiAuthorization.RequiredPrincipal =>
        requirePrincipal(tokenResolver, connection, req).map { case (principal, token) =>
          ResolvedApiAuthorization.RequiredPrincipal(principal, token)
        }

  private def requirePrincipal(
    tokenResolver: ApiTokenResolver,
    connection: Connection,
    req: Request[IO]
  ): RouteResult[(AuthenticatedPrincipal, String)] =
    for
      token <- sessionToken(req)
      principalOption <- resolvePrincipal(tokenResolver, connection, Some(token))
      principal <- EitherT.fromOption[IO](principalOption, RouteFailure.Unauthorized("You must be signed in"))
    yield principal -> token

  private def optionalPrincipal(
    tokenResolver: ApiTokenResolver,
    connection: Connection,
    req: Request[IO]
  ): RouteResult[Option[AuthenticatedPrincipal]] =
    optionalSessionToken(req).flatMap(token => resolvePrincipal(tokenResolver, connection, token))

  private def resolvePrincipal(
    tokenResolver: ApiTokenResolver,
    connection: Connection,
    token: Option[String]
  ): RouteResult[Option[AuthenticatedPrincipal]] =
    EitherT(tokenResolver.resolveOptionalPrincipal(connection, token).map(_.leftMap(toRouteFailure)))

  private def sessionToken(req: Request[IO]): RouteResult[String] =
    bearerToken(req) match
      case Some(token) => EitherT.rightT(token)
      case None =>
        for
          token <- EitherT.fromOption[IO](cookieValue(req, sessionCookieName), RouteFailure.Unauthorized("You must be signed in"))
          _ <- csrfToken(req)
        yield token

  private def optionalSessionToken(req: Request[IO]): RouteResult[Option[String]] =
    bearerToken(req) match
      case Some(token) => EitherT.rightT(Some(token))
      case None =>
        cookieValue(req, sessionCookieName) match
          case None => EitherT.rightT(None)
          case Some(token) => csrfToken(req).as(Some(token))

  private def csrfToken(req: Request[IO]): RouteResult[String] =
    val headerToken =
      req.headers.headers
        .find(_.name.toString.equalsIgnoreCase(csrfHeaderName))
        .map(_.value.trim)
        .filter(_.nonEmpty)

    val cookieToken = cookieValue(req, csrfCookieName)

    EitherT.cond[IO](
      headerToken.isDefined && headerToken == cookieToken,
      headerToken.getOrElse(""),
      RouteFailure.Unauthorized("Invalid session verification token")
    )

  private def bearerToken(req: Request[IO]): Option[String] =
    req.headers.headers
      .find(_.name.toString.equalsIgnoreCase("Authorization"))
      .map(_.value)
      .flatMap { rawValue =>
        rawValue.stripPrefix("Bearer ").trim match
          case "" => None
          case token => Some(token)
      }

  private def cookieValue(req: Request[IO], name: String): Option[String] =
    req.cookies.find(_.name == name).map(_.content.trim).filter(_.nonEmpty)

  private def clientKey(req: Request[IO]): String =
    req.headers.headers
      .find(_.name.toString.equalsIgnoreCase("X-Forwarded-For"))
      .flatMap(_.value.split(',').headOption)
      .map(_.trim)
      .filter(_.nonEmpty)
      .orElse(req.remoteAddr.map(_.toString))
      .getOrElse("unknown")

  private def liftIO[A](ioa: IO[A]): RouteResult[A] =
    EitherT.right(ioa)

  private def liftApp[A](ioa: IO[Either[AppError, A]]): RouteResult[A] =
    EitherT(ioa.map(_.leftMap(toRouteFailure)))

  private def handleRequest(
    program: IO[Either[RouteFailure, Response[IO]]]
  ): IO[Response[IO]] =
    program
      .flatMap {
        case Right(response) => IO.pure(response)
        case Left(RouteFailure.Unauthorized(message)) => unauthorizedResponse(message)
        case Left(RouteFailure.Forbidden(message)) => Forbidden(ErrorResponse(message).asJson)
        case Left(RouteFailure.NotFound(message)) => NotFound(ErrorResponse(message).asJson)
        case Left(RouteFailure.BadRequest(message)) => BadRequest(ErrorResponse(message).asJson)
        case Left(RouteFailure.Conflict(message)) => Conflict(ErrorResponse(message).asJson)
        case Left(RouteFailure.RateLimited(message)) =>
          Response[IO](status = org.http4s.Status.TooManyRequests)
            .withEntity(ErrorResponse(message).asJson)
            .pure[IO]
      }
      .handleErrorWith {
        case failure: org.http4s.MessageFailure =>
          logger.warn(failure)(failure.message) *> BadRequest(ErrorResponse("Invalid request message").asJson)
        case error =>
          logger.error(error)(errorMessage(error)) *> InternalServerError(ErrorResponse("Unexpected server error").asJson)
      }

  private def toRouteFailure(error: AppError): RouteFailure =
    error match
      case AppError.Validation(message) => RouteFailure.BadRequest(message)
      case AppError.Unauthorized(message) => RouteFailure.Unauthorized(message)
      case AppError.Forbidden(message) => RouteFailure.Forbidden(message)
      case AppError.NotFound(message) => RouteFailure.NotFound(message)
      case AppError.Conflict(message) => RouteFailure.Conflict(message)
      case AppError.Decoding(message) => RouteFailure.BadRequest(message)
      case AppError.Unexpected(message) => RouteFailure.BadRequest(message)

  private def errorMessage(error: Throwable): String =
    Option(error.getMessage).map(_.trim).filter(_.nonEmpty).getOrElse(error.getClass.getSimpleName)

  private def unauthorizedResponse(message: String): IO[Response[IO]] =
    Response[IO](status = org.http4s.Status.Unauthorized)
      .withEntity(ErrorResponse(message).asJson)
      .pure[IO]

  private def withSessionCookies(response: Response[IO], directive: ApiSessionDirective): Response[IO] =
    directive match
      case ApiSessionDirective.None => response
      case ApiSessionDirective.Create(sessionToken, csrfToken) =>
        response.putHeaders(
          Header.Raw(CIString("Set-Cookie"), cookie(sessionCookieName, sessionToken, httpOnly = true, maxAge = Some(sessionMaxAgeSeconds))),
          Header.Raw(CIString("Set-Cookie"), cookie(csrfCookieName, csrfToken, httpOnly = false, maxAge = Some(sessionMaxAgeSeconds)))
        )
      case ApiSessionDirective.Clear =>
        response.putHeaders(
          Header.Raw(CIString("Set-Cookie"), cookie(sessionCookieName, "", httpOnly = true, maxAge = Some(0))),
          Header.Raw(CIString("Set-Cookie"), cookie(csrfCookieName, "", httpOnly = false, maxAge = Some(0)))
        )

  private def cookie(
    name: String,
    value: String,
    httpOnly: Boolean,
    maxAge: Option[Int]
  ): String =
    List(
      Some(s"$name=$value"),
      Some("Path=/"),
      maxAge.map(seconds => s"Max-Age=$seconds"),
      Some("SameSite=Lax"),
      Option.when(httpOnly)("HttpOnly"),
      Option.when(secureCookie)("Secure")
    ).flatten.mkString("; ")
