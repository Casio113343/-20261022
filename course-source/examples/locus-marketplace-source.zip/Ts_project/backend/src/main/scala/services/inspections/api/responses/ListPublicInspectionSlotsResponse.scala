package inspections.api.responses
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import inspections.model.PublicInspectionSlot
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class ListPublicInspectionSlotsResponse(slots: List[PublicInspectionSlot])

object ListPublicInspectionSlotsResponse:
  given Encoder[ListPublicInspectionSlotsResponse] = deriveEncoder[ListPublicInspectionSlotsResponse]
