package analytics.tables.listing_analytics_events

import analytics.model.*
import cats.effect.IO
import listings.model.ListingId
import shared.*

import java.sql.{Connection, ResultSet}

private[analytics] object ListingAnalyticsDashboardReads:

  // Internal aggregation models keep table-specific SQL result shapes private to this file.
  // The public analytics model is assembled later from these narrower persistence reads.
  final case class EventCounts(
    views: Int,
    searchImpressions: Int,
    searchClicks: Int,
    favourites: Int,
    messages: Int,
    inspections: Int,
    photoOpens: Int,
    amenityInterest: Int
  )

  final case class PeerAverages(
    views: Int,
    favourites: Int,
    messages: Int,
    inspections: Int
  )

  final case class PhotoEngagementStats(
    firstPhotoOpens: Int,
    floorPlanOpens: Int,
    photoIndexTotal: Int,
    indexedPhotoOpens: Int
  )

  private def rangeClause(range: ListingAnalyticsDateRange, alias: String = ""): String =
    val prefix = if alias.trim.isEmpty then "" else s"$alias."

    ListingAnalyticsDateRange.days(range)
      .map(days => s" and ${prefix}occurred_at >= now() - interval '$days days'")
      .getOrElse("")

  // Summary and timeline queries provide the stable top-level dashboard numbers.
  // More specific drill-downs are loaded below as independent query/load pairs.
  private def countsSql(range: ListingAnalyticsDateRange): String =
    """
      |select
      |  count(*) filter (where event_type = 'listing_view') as views,
      |  count(*) filter (where event_type = 'search_impression') as search_impressions,
      |  count(*) filter (where event_type = 'search_click') as search_clicks,
      |  count(*) filter (where event_type = 'favourite') as favourites,
      |  count(*) filter (where event_type = 'message_start') as messages,
      |  count(*) filter (where event_type = 'inspection_request') as inspections,
      |  count(*) filter (where event_type = 'photo_open') as photo_opens,
      |  count(*) filter (where event_type = 'amenity_interest') as amenity_interest
      |from listing_analytics_events
      |where listing_id = ?
      |""".stripMargin + rangeClause(range)

  def loadCounts(connection: Connection, listingId: ListingId, range: ListingAnalyticsDateRange): IO[EventCounts] =
    JdbcResources.select(connection, countsSql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      if resultSet.next() then
        EventCounts(
          views = resultSet.getInt("views"),
          searchImpressions = resultSet.getInt("search_impressions"),
          searchClicks = resultSet.getInt("search_clicks"),
          favourites = resultSet.getInt("favourites"),
          messages = resultSet.getInt("messages"),
          inspections = resultSet.getInt("inspections"),
          photoOpens = resultSet.getInt("photo_opens"),
          amenityInterest = resultSet.getInt("amenity_interest")
        )
      else EventCounts(0, 0, 0, 0, 0, 0, 0, 0)
    }

  private def timelineSql(range: ListingAnalyticsDateRange): String =
    val days = ListingAnalyticsDateRange.days(range).getOrElse(90)

    s"""
       |select
       |  to_char(days.day, 'YYYY-MM-DD') as event_day,
       |  count(e.id) filter (where e.event_type = 'listing_view') as views,
       |  count(e.id) filter (where e.event_type = 'favourite') as favourites,
       |  count(e.id) filter (where e.event_type = 'message_start') as messages,
       |  count(e.id) filter (where e.event_type = 'inspection_request') as inspections
       |from generate_series(current_date - interval '${days - 1} days', current_date, interval '1 day') as days(day)
       |left join listing_analytics_events e
       |  on e.listing_id = ?
       | and e.occurred_at >= days.day
       | and e.occurred_at < days.day + interval '1 day'
       |group by days.day
       |order by days.day asc
       |""".stripMargin

  def loadTimeline(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[List[ListingAnalyticsDay]] =
    JdbcResources.select(connection, timelineSql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ =>
          ListingAnalyticsDay(
            date = resultSet.getString("event_day"),
            views = resultSet.getInt("views"),
            favourites = resultSet.getInt("favourites"),
            messages = resultSet.getInt("messages"),
            inspectionRequests = resultSet.getInt("inspections")
          )
        )
        .toList
    }

  // Breakdown query/load pairs stay close together so each dashboard panel can be
  // reviewed by reading the SQL and its row mapping in one place.
  private def amenitiesSql(range: ListingAnalyticsDateRange): String =
    """
      |select coalesce(category, 'Amenities') as category, count(*) as value
      |from listing_analytics_events
      |where listing_id = ?
      |  and event_type = 'amenity_interest'
      |""".stripMargin + rangeClause(range) +
      """
      |group by coalesce(category, 'Amenities')
      |order by value desc, category asc
      |limit 6
      |""".stripMargin

  def loadAmenities(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[List[ListingAnalyticsBreakdownItem]] =
    JdbcResources.select(connection, amenitiesSql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => ListingAnalyticsBreakdownItem(resultSet.getString("category"), resultSet.getInt("value")))
        .toList
    }

  private def trafficSourcesSql(range: ListingAnalyticsDateRange): String =
    """
      |select coalesce(metadata ->> 'trafficSource', category, 'direct_link') as source, count(*) as value
      |from listing_analytics_events
      |where listing_id = ?
      |  and event_type = 'listing_view'
      |""".stripMargin + rangeClause(range) +
      """
      |group by coalesce(metadata ->> 'trafficSource', category, 'direct_link')
      |order by value desc, source asc
      |limit 8
      |""".stripMargin

  // Traffic source and device queries prefer typed metadata, but fall back to the
  // older display columns so existing analytics rows still contribute after migration.
  def loadTrafficSources(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[List[ListingAnalyticsBreakdownItem]] =
    JdbcResources.select(connection, trafficSourcesSql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ =>
          ListingAnalyticsBreakdownItem(
            ListingAnalyticsEventDisplay.trafficSourceLabel(resultSet.getString("source")),
            resultSet.getInt("value")
          )
        )
        .toList
    }

  private def deviceBreakdownSql(range: ListingAnalyticsDateRange): String =
    """
      |select
      |  coalesce(metadata ->> 'deviceClass', label, 'unknown') as device,
      |  count(*) as value
      |from listing_analytics_events
      |where listing_id = ?
      |  and event_type = 'listing_view'
      |""".stripMargin + rangeClause(range) +
      """
      |group by coalesce(metadata ->> 'deviceClass', label, 'unknown')
      |order by value desc, device asc
      |limit 4
      |""".stripMargin

  def loadDeviceBreakdown(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[List[ListingAnalyticsBreakdownItem]] =
    JdbcResources.select(connection, deviceBreakdownSql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ =>
          ListingAnalyticsBreakdownItem(
            ListingAnalyticsEventDisplay.deviceLabel(resultSet.getString("device")),
            resultSet.getInt("value")
          )
        )
        .toList
    }

  private def photosSql(range: ListingAnalyticsDateRange): String =
    """
      |select coalesce(label, 'Gallery') as label, count(*) as value
      |from listing_analytics_events
      |where listing_id = ?
      |  and event_type = 'photo_open'
      |""".stripMargin + rangeClause(range) +
      """
      |group by coalesce(label, 'Gallery')
      |order by value desc, label asc
      |limit 8
      |""".stripMargin

  def loadPhotos(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[List[ListingAnalyticsBreakdownItem]] =
    JdbcResources.select(connection, photosSql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => ListingAnalyticsBreakdownItem(resultSet.getString("label"), resultSet.getInt("value")))
        .toList
    }

  // Photo engagement supports both the current JSON metadata shape and older photo_N
  // category values. This keeps average photo index and floor-plan interest stable after migration.
  private def photoEngagementSql(range: ListingAnalyticsDateRange): String =
    """
      |select
      |  count(*) filter (where category = 'photo_1' or metadata #>> '{photo,index}' = '1') as first_photo_opens,
      |  count(*) filter (where category = 'floor_plan' or metadata #>> '{photo,kind}' = 'floor_plan') as floor_plan_opens,
      |  coalesce(sum(
      |    case
      |      when metadata #>> '{photo,index}' is not null then (metadata #>> '{photo,index}')::int
      |      when category like 'photo_%' then nullif(regexp_replace(category, '[^0-9]', '', 'g'), '')::int
      |      else null
      |    end
      |  ), 0)::int as photo_index_total,
      |  count(*) filter (where metadata #>> '{photo,index}' is not null or category like 'photo_%') as indexed_photo_opens
      |from listing_analytics_events
      |where listing_id = ?
      |  and event_type = 'photo_open'
      |""".stripMargin + rangeClause(range)

  def loadPhotoEngagementStats(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[PhotoEngagementStats] =
    JdbcResources.select(connection, photoEngagementSql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      if resultSet.next() then
        PhotoEngagementStats(
          firstPhotoOpens = resultSet.getInt("first_photo_opens"),
          floorPlanOpens = resultSet.getInt("floor_plan_opens"),
          photoIndexTotal = resultSet.getInt("photo_index_total"),
          indexedPhotoOpens = resultSet.getInt("indexed_photo_opens")
        )
      else PhotoEngagementStats(0, 0, 0, 0)
    }

  private def searchFiltersSql(range: ListingAnalyticsDateRange): String =
    """
      |select coalesce(label, category, 'Search') as label, count(*) as value
      |from listing_analytics_events
      |where listing_id = ?
      |  and event_type = 'search_impression'
      |""".stripMargin + rangeClause(range) +
      """
      |group by coalesce(label, category, 'Search')
      |order by value desc, label asc
      |limit 8
      |""".stripMargin

  def loadSearchFilters(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[List[ListingAnalyticsBreakdownItem]] =
    JdbcResources.select(connection, searchFiltersSql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => ListingAnalyticsBreakdownItem(resultSet.getString("label"), resultSet.getInt("value")))
        .toList
    }

  private def peerAveragesSql(range: ListingAnalyticsDateRange): String =
    """
      |select
      |  coalesce(round(avg(views))::int, 0) as views,
      |  coalesce(round(avg(favourites))::int, 0) as favourites,
      |  coalesce(round(avg(messages))::int, 0) as messages,
      |  coalesce(round(avg(inspections))::int, 0) as inspections
      |from (
      |  select
      |    listing_id,
      |    count(*) filter (where event_type = 'listing_view') as views,
      |    count(*) filter (where event_type = 'favourite') as favourites,
      |    count(*) filter (where event_type = 'message_start') as messages,
      |    count(*) filter (where event_type = 'inspection_request') as inspections
      |  from listing_analytics_events
      |  where 1 = 1
      |""".stripMargin + rangeClause(range) +
      """
      |  group by listing_id
      |) listing_counts
      |""".stripMargin

  def loadPeerAverages(connection: Connection, range: ListingAnalyticsDateRange): IO[PeerAverages] =
    JdbcResources.select(connection, peerAveragesSql(range))(_ => ()) { resultSet =>
      if resultSet.next() then
        PeerAverages(
          views = resultSet.getInt("views"),
          favourites = resultSet.getInt("favourites"),
          messages = resultSet.getInt("messages"),
          inspections = resultSet.getInt("inspections")
        )
      else PeerAverages(0, 0, 0, 0)
    }

  private def activitySql(range: ListingAnalyticsDateRange): String =
    """
      |select event_type, category, label, metadata, occurred_at
      |from listing_analytics_events
      |where listing_id = ?
      |""".stripMargin + rangeClause(range) +
      """
      |order by occurred_at desc
      |limit 8
      |""".stripMargin

  // Activity is intentionally lightweight: it shows the latest events with the best
  // available human label instead of reconstructing every metadata-specific detail.
  def loadActivity(
    connection: Connection,
    listingId: ListingId,
    range: ListingAnalyticsDateRange
  ): IO[AppResult[List[ListingAnalyticsActivity]]] =
    JdbcResources.select(connection, activitySql(range)) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => readActivity(resultSet))
        .foldRight(Right(Nil): AppResult[List[ListingAnalyticsActivity]])((next, acc) =>
          for
            head <- next
            tail <- acc
          yield head :: tail
        )
    }

  // Activity rows show the best available label. Typed inserts usually provide a
  // derived label/category, while older or sparse events fall back to a generic event label.
  private def readActivity(resultSet: ResultSet): AppResult[ListingAnalyticsActivity] =
    for
      rawEventType <- DbCodec.requiredText(resultSet, "event_type")
      eventType <- DbCodec.decodeDatabaseValue(ListingAnalyticsEventType.fromString(rawEventType), "event_type")
      occurredAt <- DbCodec.requiredInstant(resultSet, "occurred_at")
    yield ListingAnalyticsActivity(
      label = Option(resultSet.getString("label"))
        .orElse(Option(resultSet.getString("category")))
        .getOrElse(ListingAnalyticsEventDisplay.activityLabel(eventType)),
      eventType = eventType,
      occurredAt = occurredAt
    )
