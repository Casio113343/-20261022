package database

object DatabaseDefaults:
  val DefaultDatabaseName: String = "locus"
