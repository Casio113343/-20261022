package analytics.api.responses

import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class RecordListingAnalyticsEventsResponse(
  recorded: Int
)

object RecordListingAnalyticsEventsResponse:
  given Encoder[RecordListingAnalyticsEventsResponse] = deriveEncoder[RecordListingAnalyticsEventsResponse]
