package shared

import cats.effect.IO
import identity.model.UserId

import java.sql.Connection

trait AuthenticatedPrincipal:
  def userId: UserId

trait ApiTokenResolver:
  def resolveOptionalPrincipal(
    connection: Connection,
    token: Option[String]
  ): IO[AppResult[Option[AuthenticatedPrincipal]]]
