package messaging.model


import io.circe.{Decoder, Encoder}

import java.util.UUID
import scala.util.Try

final case class ConversationMessageId(value: UUID)

object ConversationMessageId:
  given Encoder[ConversationMessageId] = Encoder.encodeString.contramap(_.value.toString)
  given Decoder[ConversationMessageId] = Decoder.decodeString.emap(parseUuid(_, "messageId").map(ConversationMessageId(_)))

  private def parseUuid(value: String, label: String): Either[String, UUID] =
    Try(UUID.fromString(value)).toEither.left.map(_ => s"Invalid $label")
