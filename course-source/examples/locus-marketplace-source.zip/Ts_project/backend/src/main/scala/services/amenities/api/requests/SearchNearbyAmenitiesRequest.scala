package amenities.api.requests

import amenities.model.ListingMapPosition
import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder

final case class SearchNearbyAmenitiesRequest(
  location: ListingMapPosition,
  includedTypes: List[String]
)

object SearchNearbyAmenitiesRequest:
  given Decoder[SearchNearbyAmenitiesRequest] = deriveDecoder[SearchNearbyAmenitiesRequest]
