package media.tables
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import _root_.media.tables.property_images.PropertyImagesTable

import java.sql.Connection

object MediaSchema:

  def initialize(connection: Connection): IO[Unit] =
    PropertyImagesTable.initialize(connection)
