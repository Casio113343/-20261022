package listings.api.requests
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.ListingId

final case class GetManagedListingDetailRequest(
  listingId: ListingId
)

object GetManagedListingDetailRequest:
  given Decoder[GetManagedListingDetailRequest] = deriveDecoder[GetManagedListingDetailRequest]
