package database

import cats.effect.IO
import java.nio.file.Paths

final case class DatabaseConfig(
  host: String,
  port: Int,
  databaseName: String,
  user: String,
  password: String,
  maxPoolSize: Int,
  connectionTimeoutMs: Long
)

object DatabaseConfig:

  private def defaultDatabaseName(environment: Map[String, String], userDirectory: String): String =
    environment
      .get("DB_NAME")
      .orElse {
        Option(Paths.get(userDirectory).getFileName)
          .map(_.toString.replace('-', '_'))
      }
      .getOrElse(DatabaseDefaults.DefaultDatabaseName)

  extension (config: DatabaseConfig)
    def url: String =
      s"jdbc:postgresql://${config.host}:${config.port}/${config.databaseName}"

  val load: IO[DatabaseConfig] =
    IO.delay {
      val environment = sys.env
      val userDirectory = sys.props.getOrElse("user.dir", ".")

      DatabaseConfig(
        host = environment.getOrElse("DB_HOST", "127.0.0.1"),
        port = environment.get("DB_PORT").flatMap(_.toIntOption).getOrElse(5432),
        databaseName = defaultDatabaseName(environment, userDirectory),
        user = environment.getOrElse("DB_USER", "db"),
        password = environment.getOrElse("DB_PASSWORD", "root"),
        maxPoolSize = environment.get("DB_MAX_POOL_SIZE").flatMap(_.toIntOption).getOrElse(10),
        connectionTimeoutMs = environment.get("DB_CONNECTION_TIMEOUT_MS").flatMap(_.toLongOption).getOrElse(3000L)
      )
    }
