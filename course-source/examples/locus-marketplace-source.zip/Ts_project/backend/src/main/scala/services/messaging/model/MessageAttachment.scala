package messaging.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import shared.TimeCodecs

import java.time.Instant

import TimeCodecs.given

final case class MessageAttachment(
  id: MessageAttachmentId,
  kind: MessageAttachmentKind,
  url: String,
  objectKey: String,
  fileName: String,
  mimeType: String,
  sizeBytes: Long,
  createdAt: Instant
)

object MessageAttachment:
  given Encoder[MessageAttachment] = deriveEncoder[MessageAttachment]
  given Decoder[MessageAttachment] = deriveDecoder[MessageAttachment]
