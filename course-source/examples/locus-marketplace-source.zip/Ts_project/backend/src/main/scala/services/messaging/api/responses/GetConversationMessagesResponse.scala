package messaging.api.responses
import identity.model.*
import listings.model.*
import messaging.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import shared.*

final case class GetConversationMessagesResponse(messages: List[ConversationMessage])

object GetConversationMessagesResponse:
  given Encoder[GetConversationMessagesResponse] = deriveEncoder[GetConversationMessagesResponse]
