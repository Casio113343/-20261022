package media.api.responses
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class DeleteManagedListingImageResponse(
  deleted: Boolean
)

object DeleteManagedListingImageResponse:
  given Encoder[DeleteManagedListingImageResponse] = deriveEncoder[DeleteManagedListingImageResponse]
