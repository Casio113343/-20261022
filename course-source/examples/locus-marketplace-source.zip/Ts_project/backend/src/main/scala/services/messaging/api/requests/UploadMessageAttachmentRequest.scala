package messaging.api.requests
import identity.model.*
import listings.model.*
import messaging.model.*


final case class UploadMessageAttachmentRequest(
  fileName: String,
  contentType: String,
  bytes: Array[Byte]
)
