package renovations.api

import cats.effect.{IO, Resource}
import database.DatabaseSession
import listings.model.ListingId
import media.model.PropertyImage
import renovations.application.RenovationWorker
import renovations.clients.GeminiRenovationClient
import renovations.tables.renovation_images.RenovationImagesTable
import shared.{AppResult, ListingMediaStorage, RuntimeValues}

import java.sql.Connection

object RenovationsPublicApi:

  val MaxImagesPerListing: Int = 15

  def createScheduler(
    databaseSession: DatabaseSession,
    storage: ListingMediaStorage,
    client: Option[GeminiRenovationClient]
  ): Resource[IO, RenovationScheduler] =
    RenovationWorker.create(databaseSession, storage, client)

  def reconcile(
    connection: Connection,
    listingId: ListingId,
    images: List[PropertyImage],
    enabled: Boolean,
    retryFailed: Boolean
  ): IO[AppResult[RenovationReconcileResult]] =
    val eligibleImages = images.filterNot(_.isFloorPlan).take(MaxImagesPerListing)

    if enabled then
      RuntimeValues.now.flatMap(timestamp =>
        RenovationImagesTable
          .reconcile(connection, listingId, eligibleImages.map(_.id), retryFailed, timestamp)
          .map(_.map(result => RenovationReconcileResult(result.removedObjectKeys)))
      )
    else
      IO.pure(Right(RenovationReconcileResult(Nil)))

  def removeIneligibleForRequest(
    connection: Connection,
    listingId: ListingId,
    eligibleImageIds: List[media.model.PropertyImageId]
  ): IO[AppResult[RenovationReconcileResult]] =
    RenovationImagesTable
      .prune(connection, listingId, eligibleImageIds)
      .map(_.map(result => RenovationReconcileResult(result.removedObjectKeys)))
