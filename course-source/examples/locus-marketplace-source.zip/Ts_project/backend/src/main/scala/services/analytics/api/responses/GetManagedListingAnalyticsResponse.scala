package analytics.api.responses

import analytics.model.*
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class GetManagedListingAnalyticsResponse(
  analytics: ListingAnalyticsDashboard
)

object GetManagedListingAnalyticsResponse:
  import ListingAnalyticsDashboard.given

  given Encoder[GetManagedListingAnalyticsResponse] = deriveEncoder[GetManagedListingAnalyticsResponse]
