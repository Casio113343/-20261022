package fengshui.api.responses

import fengshui.model.FengshuiAnalysis
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class SavedFengshuiAnalysis(
  analysis: FengshuiAnalysis
)

object SavedFengshuiAnalysis:
  given Encoder[SavedFengshuiAnalysis] = deriveEncoder[SavedFengshuiAnalysis]
