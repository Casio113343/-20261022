package inspections.model


import io.circe.{Decoder, Encoder}

import java.util.UUID

final case class InspectionSlotId(value: UUID) extends AnyVal

object InspectionSlotId:
  given Encoder[InspectionSlotId] = Encoder.encodeUUID.contramap(_.value)
  given Decoder[InspectionSlotId] = Decoder.decodeUUID.map(InspectionSlotId(_))
