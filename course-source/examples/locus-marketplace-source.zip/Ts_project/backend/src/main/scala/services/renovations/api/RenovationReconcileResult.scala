package renovations.api

final case class RenovationReconcileResult(
  removedObjectKeys: List[String]
)
