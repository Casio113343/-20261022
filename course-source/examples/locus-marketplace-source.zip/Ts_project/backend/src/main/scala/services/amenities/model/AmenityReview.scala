package amenities.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class AmenityReview(
  authorName: String,
  rating: Option[Int],
  text: String
)

object AmenityReview:
  given Encoder[AmenityReview] = deriveEncoder[AmenityReview]
  given Decoder[AmenityReview] = deriveDecoder[AmenityReview]
