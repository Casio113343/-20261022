package inspections.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import listings.model.ListingId

final case class InspectionListingSummary(
  id: ListingId,
  addressLine: String,
  suburb: String,
  state: String,
  postcode: String
)

object InspectionListingSummary:
  given Encoder[InspectionListingSummary] = deriveEncoder[InspectionListingSummary]
  given Decoder[InspectionListingSummary] = deriveDecoder[InspectionListingSummary]
