package analytics.tables.listing_analytics_events

import analytics.model.*

private[analytics] object ListingAnalyticsEventDisplay:

  // These helpers are the only place where typed metadata is flattened into display columns.
  // That keeps frontend callers from coordinating fragile category/label strings manually.
  def eventCategory(
    eventType: ListingAnalyticsEventType,
    metadata: ListingAnalyticsEventMetadata
  ): Option[String] =
    eventType match
      case ListingAnalyticsEventType.ListingView =>
        metadata.trafficSource.map(ListingAnalyticsTrafficSource.displayLabel)
      case ListingAnalyticsEventType.SearchImpression | ListingAnalyticsEventType.SearchClick =>
        metadata.search.map(search => ListingAnalyticsSearchMarket.toString(search.marketMode))
      case ListingAnalyticsEventType.PhotoOpen =>
        metadata.photo.map(photo => ListingAnalyticsPhotoKind.toString(photo.kind))
      case ListingAnalyticsEventType.AmenityInterest =>
        metadata.amenity.map(_.category)
      case _ => None

  def eventLabel(
    eventType: ListingAnalyticsEventType,
    metadata: ListingAnalyticsEventMetadata
  ): Option[String] =
    metadata.action.map(ListingAnalyticsAction.displayLabel).orElse {
      eventType match
        case ListingAnalyticsEventType.ListingView =>
          metadata.deviceClass.map(ListingAnalyticsDeviceClass.displayLabel)
        case ListingAnalyticsEventType.SearchImpression =>
          metadata.search.flatMap(_.filterLabel)
        case ListingAnalyticsEventType.PhotoOpen =>
          metadata.photo.map(photoLabel)
        case ListingAnalyticsEventType.AmenityInterest =>
          metadata.amenity.map(_.label)
        case _ => None
      }

  def activityLabel(eventType: ListingAnalyticsEventType): String =
    eventType match
      case ListingAnalyticsEventType.ListingView => "Listing viewed"
      case ListingAnalyticsEventType.SearchImpression => "Shown in search"
      case ListingAnalyticsEventType.SearchClick => "Opened from search"
      case ListingAnalyticsEventType.Favourite => "Saved by a buyer"
      case ListingAnalyticsEventType.MessageStart => "Conversation started"
      case ListingAnalyticsEventType.InspectionRequest => "Inspection requested"
      case ListingAnalyticsEventType.PhotoOpen => "Gallery opened"
      case ListingAnalyticsEventType.AmenityInterest => "Amenity viewed"

  // Database values may be typed metadata keys or historical display strings.
  // Decoding first gives consistent labels for new rows while preserving old labels if needed.
  def trafficSourceLabel(value: String): String =
    ListingAnalyticsTrafficSource
      .fromString(value)
      .map(ListingAnalyticsTrafficSource.displayLabel)
      .getOrElse(value)

  def deviceLabel(value: String): String =
    ListingAnalyticsDeviceClass
      .fromString(value)
      .map(ListingAnalyticsDeviceClass.displayLabel)
      .getOrElse(ListingAnalyticsDeviceClass.displayLabel(ListingAnalyticsDeviceClass.Unknown))

  private def photoLabel(photo: ListingAnalyticsPhotoContext): String =
    photo.kind match
      case ListingAnalyticsPhotoKind.FloorPlan => "Floor plan"
      case ListingAnalyticsPhotoKind.Photo => s"Photo ${photo.index}"
