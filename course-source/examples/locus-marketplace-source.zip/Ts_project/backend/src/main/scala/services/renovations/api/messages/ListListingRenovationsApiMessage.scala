package renovations.api.messages

import cats.data.EitherT
import cats.effect.IO
import listings.api.ListingsPublicApi
import renovations.api.requests.ListListingRenovationsRequest
import renovations.api.responses.ListListingRenovationsResponse
import renovations.tables.renovation_images.RenovationImagesTable
import shared.{ApiTransaction, AppError, AppResult, JsonApiMessage, ListingMediaStorage}

import java.sql.Connection

final case class ListListingRenovationsApiMessage(storage: ListingMediaStorage)
    extends JsonApiMessage[ListListingRenovationsRequest, ListListingRenovationsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(
    request: ListListingRenovationsRequest,
    connection: Connection
  ): IO[AppResult[ListListingRenovationsResponse]] =
    (
      for
        listing <- EitherT(ListingsPublicApi.findPublicDetail(connection, storage, request.listingId))
        _ <- EitherT.fromOption[IO](listing, AppError.NotFound("Listing not found"))
        renovations <- EitherT(
          RenovationImagesTable.list(connection, request.listingId, storage.publicUrl)
        )
      yield ListListingRenovationsResponse(renovations)
    ).value
