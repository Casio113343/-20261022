package messaging.model


import identity.model.UserId
import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import shared.TimeCodecs

import java.time.Instant

import TimeCodecs.given

final case class ConversationMessage(
  id: ConversationMessageId,
  conversationId: ConversationId,
  senderId: UserId,
  body: String,
  attachments: List[MessageAttachment],
  createdAt: Instant,
  seenAt: Option[Instant]
)

object ConversationMessage:
  given Encoder[ConversationMessage] = deriveEncoder[ConversationMessage]
  given Decoder[ConversationMessage] = deriveDecoder[ConversationMessage]
