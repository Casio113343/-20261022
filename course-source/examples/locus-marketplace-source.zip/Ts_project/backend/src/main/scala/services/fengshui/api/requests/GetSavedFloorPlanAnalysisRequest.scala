package fengshui.api.requests
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.ListingId

final case class GetSavedFloorPlanAnalysisRequest(
  listingId: ListingId
)

object GetSavedFloorPlanAnalysisRequest:
  given Decoder[GetSavedFloorPlanAnalysisRequest] = deriveDecoder[GetSavedFloorPlanAnalysisRequest]
