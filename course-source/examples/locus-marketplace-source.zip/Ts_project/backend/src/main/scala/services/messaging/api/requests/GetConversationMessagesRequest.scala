package messaging.api.requests
import identity.model.*
import listings.model.*
import messaging.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import shared.*

final case class GetConversationMessagesRequest(conversationId: ConversationId)

object GetConversationMessagesRequest:
  given Decoder[GetConversationMessagesRequest] = deriveDecoder[GetConversationMessagesRequest]
