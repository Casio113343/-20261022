package listings.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class ListingImage(
  id: ListingImageId,
  listingId: ListingId,
  url: String,
  objectKey: String,
  contentType: String,
  sizeBytes: Long,
  sortOrder: Int,
  altText: Option[String],
  isFloorPlan: Boolean
)

object ListingImage:
  given Encoder[ListingImage] = deriveEncoder[ListingImage]
  given Decoder[ListingImage] = deriveDecoder[ListingImage]
