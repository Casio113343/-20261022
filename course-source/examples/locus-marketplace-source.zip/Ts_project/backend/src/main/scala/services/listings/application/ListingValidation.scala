package listings.application
import identity.model.*
import listings.model.*
import media.model.*


import shared.{AppError, AppResult}
import listings.model.{ListingWrite, PropertyType}
import renovations.api.RenovationsPublicApi

private[listings] object ListingValidation:

  private def invalid(message: String): AppResult[Unit] =
    Left(AppError.Validation(message))

  def validateListingRequest(request: ListingWrite): AppResult[Unit] =
    if request.addressLine.trim.length < 1 then invalid("Address line is required.")
    else if request.suburb.trim.length < 1 then invalid("Suburb is required.")
    else if request.state.trim.length < 1 then invalid("State is required.")
    else if request.postcode.trim.length < 1 then invalid("Postcode is required.")
    else if request.price <= 0 then invalid("Price must be greater than zero.")
    else if request.bedrooms <= 0 then invalid("Bedrooms must be greater than zero.")
    else if request.bathrooms <= 0 then invalid("Bathrooms must be greater than zero.")
    else if request.carSpaces <= 0 then invalid("Car spaces must be greater than zero.")
    else if request.propertyType != PropertyType.VacantLand && request.buildingSize.forall(_ <= 0) then
      invalid("Floor size is required.")
    else if request.propertyType != PropertyType.Apartment && request.landSize.forall(_ <= 0) then
      invalid("Land size is required.")
    else if request.description.trim.length < 1 then invalid("Description is required.")
    else if request.propertyType == PropertyType.House && request.houseSubtypeOption.isEmpty then
      invalid("House listings must include a subtype.")
    else if request.propertyType == PropertyType.Apartment && request.apartmentSubtypeOption.isEmpty then
      invalid("Apartment listings must include a subtype.")
    else if request.propertyType == PropertyType.VacantLand && (request.houseSubtypeOption.nonEmpty || request.apartmentSubtypeOption.nonEmpty) then
      invalid("Vacant land listings cannot include a property subtype")
    else if request.propertyType != PropertyType.House && request.houseSubtypeOption.nonEmpty then
      invalid("House subtype is only valid for house listings")
    else if request.propertyType != PropertyType.Apartment && request.apartmentSubtypeOption.nonEmpty then
      invalid("Apartment subtype is only valid for apartment listings")
    else if request.propertyType == PropertyType.House && request.apartmentSubtypeOption.nonEmpty then
      invalid("House listings cannot include an apartment subtype")
    else if request.propertyType == PropertyType.Apartment && request.houseSubtypeOption.nonEmpty then
      invalid("Apartment listings cannot include a house subtype")
    else if request.images.isEmpty then invalid("Add at least one image.")
    else if request.renovateWithAi && request.images.count(image => !image.isFloorPlan) > RenovationsPublicApi.MaxImagesPerListing then
      invalid(s"Renovate with AI supports up to ${RenovationsPublicApi.MaxImagesPerListing} gallery images per listing.")
    else if request.faqs.length > 6 then invalid("Listings can include up to six FAQs.")
    else if request.faqs.exists(faq => faq.question.trim.isEmpty || faq.response.trim.isEmpty) then
      invalid("FAQ questions and responses cannot be blank.")
    else Right(())
