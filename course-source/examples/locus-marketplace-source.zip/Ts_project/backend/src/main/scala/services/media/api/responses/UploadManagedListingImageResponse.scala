package media.api.responses
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class UploadManagedListingImageResponse(
  image: UploadedPropertyImage
)

object UploadManagedListingImageResponse:
  given Encoder[UploadManagedListingImageResponse] = deriveEncoder[UploadManagedListingImageResponse]
