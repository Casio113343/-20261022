package listings.routes
import identity.model.*
import listings.model.*
import media.model.*


import shared.ApiMessage
import listings.api.messages.*
import shared.ListingMediaStorage
import renovations.api.RenovationScheduler

object AgentListingRoutes:

  def apiMessages(storage: ListingMediaStorage, renovationScheduler: RenovationScheduler): List[ApiMessage] =
    List(
      ListManagedListingsApiMessage(storage),
      GetManagedListingDetailApiMessage(storage),
      SaveManagedListingApiMessage(storage, renovationScheduler),
      ArchiveManagedListingApiMessage
    )
