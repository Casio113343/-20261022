package identity.api.messages
import identity.model.*


import shared.{AfterCommitMultipartWithTokenMessage, AuthenticatedPrincipal, MultipartDecoders}
import cats.effect.IO
import database.TransactionSuccess
import identity.api.requests.UploadProfilePictureRequest
import identity.api.responses.UploadProfilePictureResponse
import identity.application.IdentityApplication
import shared.AppResult
import org.http4s.multipart.Multipart
import shared.ListingMediaStorage

import java.sql.Connection

final case class UploadProfilePictureApiMessage(storage: ListingMediaStorage)
    extends AfterCommitMultipartWithTokenMessage[UploadProfilePictureRequest, UploadProfilePictureResponse]:


  override def decodeMultipart(multipart: Multipart[IO]): IO[AppResult[UploadProfilePictureRequest]] =
    MultipartDecoders
      .result(
        MultipartDecoders.fileUpload(
          multipart,
          "Profile picture upload must include a file field",
          "Profile picture upload must include a filename"
        )
      )
      .map(_.map { case (fileName, contentType, bytes) => UploadProfilePictureRequest(fileName, contentType, bytes) })

  override def plan(
    request: UploadProfilePictureRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[TransactionSuccess[UploadProfilePictureResponse]]] =
    IdentityApplication
      .uploadProfilePicture(connection, principal.userId, request.fileName, request.contentType, request.bytes, storage)
      .map(_.map(transaction => transaction.copy(value = UploadProfilePictureResponse(transaction.value))))
