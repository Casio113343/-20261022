package identity.application
import identity.model.*


import cats.data.EitherT
import cats.effect.IO
import database.TransactionSuccess
import identity.security.Security
import identity.tables.agent_profiles.AgentProfilesTable
import identity.tables.user_sessions.UserSessionsTable
import identity.tables.users.UsersTable
import shared.*
import shared.ListingMediaStorage

import java.sql.Connection
import java.util.UUID

private[identity] object IdentityApplication:

  private type AppEitherT[A] = EitherT[IO, AppError, A]

  private def liftApp[A](ioResult: IO[AppResult[A]]): AppEitherT[A] =
    EitherT(ioResult)

  private def liftValidation[A](result: AppResult[A]): AppEitherT[A] =
    EitherT.fromEither[IO](result)

  private def requireValue[A](value: Option[A], message: => String): AppEitherT[A] =
    EitherT.fromOption[IO](value, AppError.Unexpected(message))

  final case class AuthenticatedSession(
    sessionToken: String,
    csrfToken: String,
    user: User
  )

  def signUp(connection: Connection, request: RegistrationDetails): IO[AppResult[AuthenticatedSession]] =
    val normalizedEmail = request.email.trim.toLowerCase

    (
      for
        _ <- liftValidation(AuthValidation.validateAuthRequest(request.fullName, normalizedEmail, request.password))
        existingUser <- liftApp(UsersTable.findUserRecordByEmail(connection, normalizedEmail))
        _ <- EitherT.cond[IO](existingUser.isEmpty, (), AppError.Conflict("An account already exists for this email"))
        digest <- EitherT.right(Security.hashPassword(request.password))
        userId <- EitherT.right(RuntimeValues.uuid.map(UserId(_)))
        createdAt <- EitherT.right(RuntimeValues.now)
        _ <- EitherT.right[AppError](createUserWithProfile(connection, userId, request, normalizedEmail, digest, createdAt))
        sessionTokens <- EitherT.right[AppError](UserSessionsTable.createSession(connection, userId))
        maybeUser <- liftApp(UsersTable.loadUser(connection, userId))
        user <- requireValue(maybeUser, "Created user could not be loaded")
      yield AuthenticatedSession(sessionTokens.sessionToken, sessionTokens.csrfToken, user)
    ).value

  def signUpWithProfilePicture(
    connection: Connection,
    request: RegistrationDetails,
    fileName: String,
    reportedContentType: String,
    bytes: Array[Byte],
    storage: ListingMediaStorage
  ): IO[AppResult[TransactionSuccess[AuthenticatedSession]]] =
    val normalizedEmail = request.email.trim.toLowerCase

    validateProfilePicture(fileName, reportedContentType, bytes) match
      case Left(error) => IO.pure(Left(error))
      case Right(contentType) =>
        (
          for
            _ <- liftValidation(AuthValidation.validateAuthRequest(request.fullName, normalizedEmail, request.password))
            existingUser <- liftApp(UsersTable.findUserRecordByEmail(connection, normalizedEmail))
            _ <- EitherT.cond[IO](existingUser.isEmpty, (), AppError.Conflict("An account already exists for this email"))
            digest <- EitherT.right(Security.hashPassword(request.password))
            userId <- EitherT.right(RuntimeValues.uuid.map(UserId(_)))
            imageId <- EitherT.right[AppError](IO.delay(UUID.randomUUID()))
            createdAt <- EitherT.right(RuntimeValues.now)
            objectKey = profileAvatarObjectKey(userId, imageId, fileName)
            _ <- EitherT.right[AppError](storage.uploadBytes(objectKey, bytes, contentType))
            createResult <- EitherT.right[AppError](
              createUserWithProfile(connection, userId, request, normalizedEmail, digest, createdAt).attempt
            )
            _ <- liftUploadSideEffect(createResult, objectKey, storage)
            updateResult <- EitherT.right[AppError](updateAvatarObjectKey(connection, userId, objectKey).attempt)
            oldObjectKey <- liftUploadAppResult(updateResult, objectKey, storage)
            sessionTokensResult <- EitherT.right[AppError](UserSessionsTable.createSession(connection, userId).attempt)
            sessionTokens <- liftUploadSideEffect(sessionTokensResult, objectKey, storage)
            loadUserResult <- EitherT.right[AppError](UsersTable.loadUser(connection, userId).attempt)
            maybeUser <- liftUploadAppResult(loadUserResult, objectKey, storage)
            user <- requireUploadValue(maybeUser, "Created user could not be loaded", objectKey, storage)
            resolvedUser = resolveAvatarUrl(storage)(user)
          yield TransactionSuccess(
            value = AuthenticatedSession(sessionTokens.sessionToken, sessionTokens.csrfToken, resolvedUser),
            afterCommit = oldObjectKey.fold(IO.unit)(storage.deleteObject),
            afterRollback = storage.deleteObject(objectKey)
          )
        ).value

  def uploadProfilePicture(
    connection: Connection,
    userId: UserId,
    fileName: String,
    reportedContentType: String,
    bytes: Array[Byte],
    storage: ListingMediaStorage
  ): IO[AppResult[TransactionSuccess[User]]] =
    validateProfilePicture(fileName, reportedContentType, bytes) match
      case Left(error) => IO.pure(Left(error))
      case Right(contentType) =>
        (
          for
            imageId <- EitherT.right[AppError](IO.delay(UUID.randomUUID()))
            objectKey = profileAvatarObjectKey(userId, imageId, fileName)
            _ <- EitherT.right[AppError](storage.uploadBytes(objectKey, bytes, contentType))
            updateResult <- EitherT.right[AppError](updateAvatarObjectKey(connection, userId, objectKey).attempt)
            oldObjectKey <- liftUploadAppResult(updateResult, objectKey, storage)
            loadUserResult <- EitherT.right[AppError](UsersTable.loadUser(connection, userId).attempt)
            maybeUser <- liftUploadAppResult(loadUserResult, objectKey, storage)
            updatedUser <- requireUploadValue(maybeUser, "Updated user could not be loaded", objectKey, storage)
            resolvedUser = resolveAvatarUrl(storage)(updatedUser)
          yield TransactionSuccess(
            value = resolvedUser,
            afterCommit = oldObjectKey.fold(IO.unit)(storage.deleteObject),
            afterRollback = storage.deleteObject(objectKey)
          )
        ).value

  def signIn(connection: Connection, request: SignInCredentials): IO[AppResult[AuthenticatedSession]] =
    val normalizedEmail = request.email.trim.toLowerCase

    (
      for
        maybeUserRecord <- liftApp(UsersTable.findUserRecordByEmail(connection, normalizedEmail))
        userRecord <- EitherT.fromOption[IO](
          maybeUserRecord,
          AppError.Unauthorized("Invalid email or password")
        )
        isValid <- EitherT.right(
          Security.verifyPassword(
            request.password,
            Security.PasswordDigest(userRecord.passwordSalt, userRecord.passwordHash)
          )
        )
        _ <- EitherT.cond[IO](isValid, (), AppError.Unauthorized("Invalid email or password"))
        sessionTokens <- EitherT.right[AppError](UserSessionsTable.createSession(connection, userRecord.id))
        maybeUser <- liftApp(UsersTable.loadUser(connection, userRecord.id))
        user <- requireValue(maybeUser, "Signed-in user could not be loaded")
      yield AuthenticatedSession(sessionTokens.sessionToken, sessionTokens.csrfToken, user)
    ).value

  val MaxProfilePictureBytes: Long = 5L * 1024L * 1024L

  def resolveAvatarUrl(storage: ListingMediaStorage)(user: User): User =
    user.copy(
      avatarUrl = user.avatarUrl.map(storage.publicUrl)
    )

  private def updateAvatarObjectKey(
    connection: Connection,
    userId: UserId,
    objectKey: String
  ): IO[AppResult[Option[String]]] =
    UsersTable.updateUserAvatarObjectKey(connection, userId, objectKey)

  private def createUserWithProfile(
    connection: Connection,
    userId: UserId,
    request: RegistrationDetails,
    normalizedEmail: String,
    digest: Security.PasswordDigest,
    createdAt: java.time.Instant
  ): IO[Unit] =
    for
      _ <- UsersTable.insertUser(connection, userId, request, normalizedEmail, digest, createdAt)
      _ <- AgentProfilesTable.insertAgentProfileIfNeeded(connection, userId, request)
    yield ()

  private val AllowedProfileImageTypes = Set("image/jpeg", "image/png", "image/webp", "image/avif")

  private def validateProfilePicture(
    fileName: String,
    reportedContentType: String,
    bytes: Array[Byte]
  ): AppResult[String] =
    val sizeBytes = bytes.length.toLong

    for
      _ <-
        if fileName.trim.isEmpty then Left(AppError.Validation("Profile picture upload must include a filename."))
        else if sizeBytes <= 0 then Left(AppError.Validation("Profile picture upload is empty."))
        else if sizeBytes > MaxProfilePictureBytes then Left(AppError.Validation("Profile picture must be smaller than 5 MB."))
        else Right(())
      detectedContentType <- inferContentTypeFromBytes(bytes)
        .filter(AllowedProfileImageTypes.contains)
        .toRight(AppError.Validation("Profile picture must be a real JPEG, PNG, WebP, or AVIF image."))
      reportedType = normalizedContentType(reportedContentType)
      _ <- reportedType match
        case Some(value) if value != detectedContentType =>
          Left(AppError.Validation("Profile picture content does not match the reported image type."))
        case _ => Right(())
    yield detectedContentType

  private def normalizedContentType(reportedContentType: String): Option[String] =
    reportedContentType.trim.toLowerCase match
      case "image/jpg" => Some("image/jpeg")
      case value @ ("image/jpeg" | "image/png" | "image/webp" | "image/avif") => Some(value)
      case _ => None

  private def inferContentTypeFromBytes(bytes: Array[Byte]): Option[String] =
    def startsWith(prefix: Int*): Boolean =
      bytes.length >= prefix.length && prefix.zipWithIndex.forall { case (value, index) =>
        (bytes(index) & 0xff) == value
      }

    def containsAsciiAt(offset: Int, value: String): Boolean =
      bytes.length >= offset + value.length &&
        value.zipWithIndex.forall { case (character, index) =>
          bytes(offset + index) == character.toByte
        }

    def containsAsciiBetween(start: Int, end: Int, value: String): Boolean =
      val upperBound = bytes.length.min(end)
      start.to(upperBound - value.length).exists(offset => containsAsciiAt(offset, value))

    if startsWith(0xff, 0xd8, 0xff) then Some("image/jpeg")
    else if startsWith(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a) then Some("image/png")
    else if containsAsciiAt(0, "RIFF") && containsAsciiAt(8, "WEBP") then Some("image/webp")
    else if containsAsciiAt(4, "ftyp") && (containsAsciiBetween(8, 32, "avif") || containsAsciiBetween(8, 32, "avis")) then Some("image/avif")
    else None

  private def profileAvatarObjectKey(userId: UserId, imageId: UUID, fileName: String): String =
    s"profile-avatars/${userId.value}/$imageId/${sanitizeFileName(fileName)}"

  private def liftUploadSideEffect[A](result: Either[Throwable, A], objectKey: String, storage: ListingMediaStorage): AppEitherT[A] =
    result match
      case Right(value) => EitherT.rightT[IO, AppError](value)
      case Left(error) =>
        EitherT(storage.deleteObject(objectKey).as(Left(AppError.Unexpected(errorMessage(error))): AppResult[A]))

  private def liftUploadAppResult[A](
    result: Either[Throwable, AppResult[A]],
    objectKey: String,
    storage: ListingMediaStorage
  ): AppEitherT[A] =
    result match
      case Right(Right(value)) => EitherT.rightT[IO, AppError](value)
      case Right(Left(error)) => EitherT(storage.deleteObject(objectKey).as(Left(error): AppResult[A]))
      case Left(error) => EitherT(storage.deleteObject(objectKey).as(Left(AppError.Unexpected(errorMessage(error))): AppResult[A]))

  private def requireUploadValue[A](
    value: Option[A],
    message: => String,
    objectKey: String,
    storage: ListingMediaStorage
  ): AppEitherT[A] =
    value match
      case Some(actualValue) => EitherT.rightT[IO, AppError](actualValue)
      case None => EitherT(storage.deleteObject(objectKey).as(Left(AppError.Unexpected(message)): AppResult[A]))

  private def errorMessage(error: Throwable): String =
    Option(error.getMessage).map(_.trim).filter(_.nonEmpty).getOrElse(error.getClass.getSimpleName)

  private def sanitizeFileName(fileName: String): String =
    fileName.trim match
      case "" => "profile-picture"
      case trimmed =>
        trimmed
          .map {
            case character if character.isLetterOrDigit => character
            case character @ ('.' | '-' | '_') => character
            case _ => '-'
          }
          .mkString
