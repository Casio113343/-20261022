package messaging.api.responses
import identity.model.*
import listings.model.*
import messaging.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import shared.*

final case class StartConversationResponse(conversation: ConversationSummary)

object StartConversationResponse:
  given Encoder[StartConversationResponse] = deriveEncoder[StartConversationResponse]
