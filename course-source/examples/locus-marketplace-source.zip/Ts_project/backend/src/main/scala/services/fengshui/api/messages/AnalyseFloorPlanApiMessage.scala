package fengshui.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import fengshui.api.requests.AnalyseFloorPlanRequest
import fengshui.api.responses.AnalyseFloorPlanResponse
import fengshui.clients.GeminiFengshuiClient
import fengshui.tables.fengshui_analyses.FengshuiAnalysesTable
import shared.AuthenticatedPrincipal
import listings.api.ListingsPublicApi
import shared.{AppError, AppResult, RuntimeValues}
import shared.ListingMediaStorage

import java.sql.Connection

final case class AnalyseFloorPlanApiMessage(
  storage: ListingMediaStorage,
  fengshuiClient: Option[GeminiFengshuiClient]
) extends ApiWithTokenMessage[AnalyseFloorPlanRequest, AnalyseFloorPlanResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: AnalyseFloorPlanRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[AnalyseFloorPlanResponse]] =
    fengshuiClient match
      case None => IO.pure(Left(AppError.Validation("Fengshui analysis is not configured.")))
      case Some(configuredClient) =>
        (
          for
            now <- EitherT.right[AppError](RuntimeValues.now)
            listingOption <- EitherT(ListingsPublicApi.findPublicDetail(connection, storage, request.listingId))
            listing <- EitherT.fromOption[IO](listingOption, AppError.NotFound("Listing not found"))
            floorPlan <- EitherT.fromOption[IO](
              listing.images.find(_.isFloorPlan),
              AppError.Validation("No floor plan has been nominated for this listing.")
            )
            imageBytes <- EitherT.right[AppError](storage.readObjectBytes(floorPlan.objectKey))
            analysis <- EitherT(configuredClient.analyse(listing, floorPlan.contentType, imageBytes))
            _ <- EitherT.right[AppError](
              FengshuiAnalysesTable.upsertSavedAnalysis(
                connection = connection,
                userId = principal.userId,
                listingId = listing.id,
                floorPlanImageId = PropertyImageId(floorPlan.id.value),
                analysis = analysis,
                timestamp = now
              )
            )
          yield AnalyseFloorPlanResponse(analysis)
        ).value
