package inspections.api.messages
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import inspections.api.requests.ChangeInspectionBookingRequest
import inspections.api.responses.ChangeInspectionBookingResponse
import inspections.application.InspectionApplication
import inspections.model.InspectionSlotId
import inspections.tables.inspection_bookings.InspectionBookingsTable
import shared.{AppError, AppResult, RuntimeValues}
import shared.AuthenticatedPrincipal

import java.sql.Connection

object ChangeInspectionBookingApiMessage
    extends ApiWithTokenMessage[ChangeInspectionBookingRequest, ChangeInspectionBookingResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: ChangeInspectionBookingRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[ChangeInspectionBookingResponse]] =
    (
      for
        now <- EitherT.right[AppError](RuntimeValues.now)
        rows <- EitherT.right[AppError](
          InspectionBookingsTable.changeBooking(connection, principal.userId, request.currentSlotId, request.nextSlotId, now)
        )
        _ <- EitherT.cond[IO](rows > 0, (), AppError.Conflict("This inspection time is no longer available"))
        previousSlot <- EitherT(
          InspectionApplication.findPublicSlot(connection, request.currentSlotId, principal.userId)
        )
        nextSlot <- EitherT(
          InspectionApplication.findPublicSlot(connection, request.nextSlotId, principal.userId)
        )
      yield ChangeInspectionBookingResponse(previousSlot, nextSlot)
    ).value
