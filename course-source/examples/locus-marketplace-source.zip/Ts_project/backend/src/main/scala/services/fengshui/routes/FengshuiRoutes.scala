package fengshui.routes
import identity.model.*
import listings.model.*
import media.model.*


import shared.ApiServiceMessages
import fengshui.api.messages.{AnalyseFloorPlanApiMessage, GetSavedFloorPlanAnalysisApiMessage}
import fengshui.clients.GeminiFengshuiClient
import shared.ListingMediaStorage

object FengshuiRoutes:

  def apiMessages(
    storage: ListingMediaStorage,
    fengshuiClient: Option[GeminiFengshuiClient]
  ): ApiServiceMessages =
    ApiServiceMessages("fengshui", List(
      AnalyseFloorPlanApiMessage(storage, fengshuiClient),
      GetSavedFloorPlanAnalysisApiMessage
    ))
