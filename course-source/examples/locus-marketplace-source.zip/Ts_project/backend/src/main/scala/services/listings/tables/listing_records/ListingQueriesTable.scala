package listings.tables.listing_records
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import shared.*

import java.sql.Connection

private[listings] object ListingQueriesTable:

  final case class ConversationListingRecord(
    summary: ConversationListingSummary,
    agentId: UserId
  )

  private def searchListingsSql(whereClause: String, orderClause: String): String =
    s"""
       |select l.id, l.title, l.description, l.transaction_type, l.property_type, l.house_subtype, l.apartment_subtype, l.price, l.address_line, l.suburb,
       |       l.state, l.postcode, l.bedrooms, l.bathrooms, l.car_spaces, l.land_size, l.building_size,
       |       l.listing_status, l.agent_id, l.created_at, l.updated_at
       |from listings l
       |$whereClause
       |$orderClause
       |limit ?
       |""".stripMargin

  private def countListingsSql(whereClause: String): String =
    s"""
       |select count(*)
       |from listings l
       |$whereClause
       |""".stripMargin

  def searchListings(
    connection: Connection,
    query: SearchListingsQuery,
  ): IO[AppResult[(List[ListingTableSupport.ListingSummaryRecord], Int)]] =
    val searchSql = ListingTableSupport.listingSearchSql(query, publicOnly = true, agentId = None)
    val orderClause = ListingTableSupport.orderByClause(query.sort)

    for
      listingsResult <- JdbcResources.select(connection, searchListingsSql(searchSql.whereClause, orderClause)) { statement =>
          ListingTableSupport.bindParams(statement, searchSql.params :+ ListingTableSupport.SqlParam.IntValue(query.limit))
      }(ListingTableSupport.readListingSummaries)
      total <- JdbcResources.select(connection, countListingsSql(searchSql.whereClause)) { statement =>
          ListingTableSupport.bindParams(statement, searchSql.params)
      } { resultSet =>
            if resultSet.next() then resultSet.getInt(1)
            else 0
      }
    yield listingsResult.map(listings => listings -> total)

  def findListingDetail(
    connection: Connection,
    listingId: ListingId,
    publicOnly: Boolean
  ): IO[AppResult[Option[ListingTableSupport.ListingDetailRecord]]] =
    val allowedStatuses =
      if publicOnly then Some(List(ListingStatus.Active))
      else None

    findListingDetailForStatuses(connection, listingId, allowedStatuses)

  def findPublicListingDetail(
    connection: Connection,
    listingId: ListingId
  ): IO[AppResult[Option[ListingTableSupport.ListingDetailRecord]]] =
    findListingDetailForStatuses(
      connection,
      listingId,
      Some(List(ListingStatus.Active, ListingStatus.Sold, ListingStatus.Leased)),
    )

  private def findConversationListingSql(statusCount: Int): String =
    val statusClause =
      if statusCount == 0 then ""
      else s" and listing_status in (${List.fill(statusCount)("?").mkString(", ")})"

    s"""
       |select id, title, address_line, suburb, state, postcode, price, transaction_type, agent_id
       |from listings
       |where id = ?
       |$statusClause
       |""".stripMargin

  def findConversationListing(
    connection: Connection,
    listingId: ListingId,
    allowedStatuses: Option[List[ListingStatus]]
  ): IO[AppResult[Option[ConversationListingRecord]]] =
    val statuses = allowedStatuses.getOrElse(Nil)

    JdbcResources.select(connection, findConversationListingSql(statuses.size)) { statement =>
      statement.setObject(1, listingId.value)
      statuses.zipWithIndex.foreach { case (status, index) =>
        statement.setString(index + 2, ListingStatus.toString(status))
      }
    } { resultSet =>
      if resultSet.next() then
        for
          title <- DbCodec.requiredText(resultSet, "title")
          addressLine <- DbCodec.requiredText(resultSet, "address_line")
          suburb <- DbCodec.requiredText(resultSet, "suburb")
          state <- DbCodec.requiredText(resultSet, "state")
          postcode <- DbCodec.requiredText(resultSet, "postcode")
          transactionTypeText <- DbCodec.requiredText(resultSet, "transaction_type")
          rowListingId <- DbCodec.requiredUuid(resultSet, "id")
          agentId <- DbCodec.requiredUuid(resultSet, "agent_id")
          transactionType <- DbCodec.decodeDatabaseValue(TransactionType.fromString(transactionTypeText), "transaction_type")
        yield Some(ConversationListingRecord(
          summary = ConversationListingSummary(
            id = ListingId(rowListingId),
            title = title,
            addressLine = addressLine,
            suburb = suburb,
            state = state,
            postcode = postcode,
            price = resultSet.getInt("price"),
            transactionType = transactionType
          ),
          agentId = UserId(agentId)
        ))
      else Right(None)
    }

  private val listingOwnedByAgentSql: String =
    """
      |select 1
      |from listings
      |where id = ?
      |  and agent_id = ?
      |limit 1
      |""".stripMargin

  def listingOwnedByAgent(connection: Connection, listingId: ListingId, agentId: UserId): IO[Boolean] =
    JdbcResources.select(connection, listingOwnedByAgentSql) { statement =>
      statement.setObject(1, listingId.value)
      statement.setObject(2, agentId.value)
    }(_.next())

  private def findListingDetailSql(statusCount: Int): String =
    val statusClause =
      if statusCount == 0 then ""
      else s" and l.listing_status in (${List.fill(statusCount)("?").mkString(", ")})"

    s"""
       |select l.id, l.title, l.description, l.transaction_type, l.property_type, l.house_subtype, l.apartment_subtype, l.price, l.address_line, l.suburb,
       |       l.state, l.postcode, l.bedrooms, l.bathrooms, l.car_spaces, l.land_size, l.building_size,
       |       l.listing_status, l.renovate_with_ai, l.agent_id, coalesce(l.faqs::text, '[]') as faqs_json, l.created_at, l.updated_at
       |from listings l
       |where l.id = ?
       |$statusClause
       |""".stripMargin

  private def findListingDetailForStatuses(
    connection: Connection,
    listingId: ListingId,
    allowedStatuses: Option[List[ListingStatus]]
  ): IO[AppResult[Option[ListingTableSupport.ListingDetailRecord]]] =
    val statuses = allowedStatuses.getOrElse(Nil)

    JdbcResources.select(connection, findListingDetailSql(statuses.size)) { statement =>
        statement.setObject(1, listingId.value)
        statuses.zipWithIndex.foreach { case (status, index) =>
          statement.setString(index + 2, ListingStatus.toString(status))
        }
    } { resultSet =>
          if resultSet.next() then ListingTableSupport.readListingDetailBase(resultSet).map(Some(_))
          else Right(None)
    }
