package database

import cats.effect.{IO, Resource}
import com.zaxxer.hikari.{HikariConfig, HikariDataSource}
import org.typelevel.log4cats.slf4j.Slf4jLogger

import java.sql.Connection

final case class TransactionSuccess[+A](
  value: A,
  afterCommit: IO[Unit] = IO.unit,
  afterRollback: IO[Unit] = IO.unit
)

final class DatabaseSession private (dataSource: HikariDataSource):

  private def pooledConnectionResource: Resource[IO, Connection] =
    Resource.make(IO.blocking(dataSource.getConnection)) { connection =>
      IO.blocking(connection.close()).handleErrorWith(_ => IO.unit)
    }

  def withConnection[A](operation: Connection => IO[A]): IO[A] =
    pooledConnectionResource.use(operation)

  def withTransactionConnection[A](operation: Connection => IO[A]): IO[A] =
    pooledConnectionResource.use { connection =>
      for
        _ <- IO.blocking(connection.setAutoCommit(false))
        result <- operation(connection).attempt
        _ <- result match
          case Right(_) => IO.blocking(connection.commit())
          case Left(_) => IO.blocking(connection.rollback()).handleErrorWith(_ => IO.unit)
        value <- IO.fromEither(result)
      yield value
    }

  def withTransactionEitherConnection[E, A](
    operation: Connection => IO[Either[E, A]]
  ): IO[Either[E, A]] =
    pooledConnectionResource.use { connection =>
      for
        _ <- IO.blocking(connection.setAutoCommit(false))
        result <- operation(connection).attempt
        _ <- result match
          case Right(Right(_)) => IO.blocking(connection.commit())
          case Right(Left(_)) => IO.blocking(connection.rollback()).handleErrorWith(_ => IO.unit)
          case Left(_) => IO.blocking(connection.rollback()).handleErrorWith(_ => IO.unit)
        value <- result match
          case Right(outcome) => IO.pure(outcome)
          case Left(error) => IO.raiseError(error)
      yield value
    }

  def withTransactionEitherConnectionAfterCommit[E, A](
    operation: Connection => IO[Either[E, TransactionSuccess[A]]]
  ): IO[Either[E, A]] =
    pooledConnectionResource.use { connection =>
      for
        _ <- IO.blocking(connection.setAutoCommit(false))
        result <- operation(connection).attempt
        value <- result match
          case Right(Right(transaction)) =>
            IO.blocking(connection.commit()).attempt.flatMap {
              case Right(_) => transaction.afterCommit.as(Right(transaction.value))
              case Left(error) =>
                IO.blocking(connection.rollback()).handleErrorWith(_ => IO.unit) *>
                  transaction.afterRollback *>
                  IO.raiseError(error)
            }
          case Right(Left(error)) =>
            IO.blocking(connection.rollback()).handleErrorWith(_ => IO.unit).as(Left(error))
          case Left(error) =>
            IO.blocking(connection.rollback()).handleErrorWith(_ => IO.unit) *> IO.raiseError(error)
      yield value
    }

object DatabaseSession:

  private val logger = Slf4jLogger.getLogger[IO]

  def initialize: Resource[IO, DatabaseSession] =
    for
      config <- Resource.eval(DatabaseConfig.load)
      dataSource <- Resource.make(createDataSource(config))(closeDataSource)
      _ <- Resource.eval(
        logger.info(
          s"Initialized PostgreSQL connection pool, host=${config.host}, port=${config.port}, database=${config.databaseName}, maxPoolSize=${config.maxPoolSize}"
        )
      )
    yield DatabaseSession(dataSource)

  private def createDataSource(config: DatabaseConfig): IO[HikariDataSource] =
    IO.blocking {
      Class.forName("org.postgresql.Driver")
      val hikariConfig = HikariConfig()
      hikariConfig.setJdbcUrl(config.url)
      hikariConfig.setUsername(config.user)
      hikariConfig.setPassword(config.password)
      hikariConfig.setMaximumPoolSize(config.maxPoolSize)
      hikariConfig.setConnectionTimeout(config.connectionTimeoutMs)
      hikariConfig.setPoolName("locus-backend-pool")
      new HikariDataSource(hikariConfig)
    }

  private def closeDataSource(dataSource: HikariDataSource): IO[Unit] =
    IO.blocking(dataSource.close()).handleErrorWith(_ => IO.unit)
