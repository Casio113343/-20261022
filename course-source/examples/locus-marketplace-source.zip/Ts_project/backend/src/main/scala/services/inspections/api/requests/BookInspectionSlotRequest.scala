package inspections.api.requests
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import inspections.model.InspectionSlotId
import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder

final case class BookInspectionSlotRequest(slotId: InspectionSlotId)

object BookInspectionSlotRequest:
  given Decoder[BookInspectionSlotRequest] = deriveDecoder[BookInspectionSlotRequest]
