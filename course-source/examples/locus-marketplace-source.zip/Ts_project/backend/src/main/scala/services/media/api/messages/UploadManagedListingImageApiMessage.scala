package media.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.{ApiTransaction, MultipartWithTokenMessage, MultipartDecoders}
import cats.effect.IO
import identity.api.IdentityPublicApi
import shared.{AppError, AppResult, RuntimeValues}
import shared.AuthenticatedPrincipal
import media.api.requests.UploadManagedListingImageRequest
import media.api.responses.UploadManagedListingImageResponse
import media.tables.property_images.PropertyImagesTable
import org.http4s.multipart.Multipart
import shared.ListingMediaStorage

import java.sql.Connection

final case class UploadManagedListingImageApiMessage(storage: ListingMediaStorage)
    extends MultipartWithTokenMessage[UploadManagedListingImageRequest, UploadManagedListingImageResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def decodeMultipart(multipart: Multipart[IO]): IO[AppResult[UploadManagedListingImageRequest]] =
    MultipartDecoders
      .result(
        MultipartDecoders.fileUpload(
          multipart,
          "Image upload must include a file field",
          "Image upload must include a filename"
        )
      )
      .map(_.map { case (fileName, contentType, bytes) => UploadManagedListingImageRequest(fileName, contentType, bytes) })

  override def plan(
    request: UploadManagedListingImageRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[UploadManagedListingImageResponse]] =
    resolveContentType(request.fileName, request.bytes) match
      case Left(error) => IO.pure(Left(error))
      case Right(resolvedContentType) =>
        for
          imageId <- RuntimeValues.uuid.map(PropertyImageId(_))
          createdAt <- RuntimeValues.now
          objectKey = s"listings/${principal.userId.value}/${imageId.value}/${sanitizeFileName(request.fileName)}"
          _ <- storage.uploadBytes(objectKey, request.bytes, resolvedContentType)
          insertResult <- PropertyImagesTable
            .insertUploadedImage(
              connection = connection,
              imageId = imageId,
              uploadedBy = principal.userId,
              bucketName = storage.config.bucketName,
              objectKey = objectKey,
              contentType = resolvedContentType,
              sizeBytes = request.bytes.length.toLong,
              createdAt = createdAt
            )
            .attempt
          result <- insertResult match
            case Right(_) =>
              IO.pure(
                Right(
                  UploadManagedListingImageResponse(
                    UploadedPropertyImage(
                      id = imageId,
                      url = storage.publicUrl(objectKey),
                      objectKey = objectKey,
                      contentType = resolvedContentType,
                      sizeBytes = request.bytes.length.toLong,
                      altText = None
                    )
                  )
                )
              )
            case Left(error) =>
              storage.deleteObject(objectKey) *> IO.raiseError(error)
        yield result

  private val MaxImageSizeInBytes = 12L * 1024L * 1024L

  private def resolveContentType(fileName: String, bytes: Array[Byte]): AppResult[String] =
    val sizeBytes = bytes.length.toLong

    if fileName.trim.isEmpty then Left(AppError.Validation("Image uploads must include a filename"))
    else if sizeBytes <= 0 then Left(AppError.Validation("Uploaded image is empty"))
    else if sizeBytes > MaxImageSizeInBytes then Left(AppError.Validation("Uploaded image exceeds the 12 MB limit"))
    else
      inferContentTypeFromBytes(bytes)
        .filter(AllowedListingImageTypes.contains)
        .toRight(AppError.Validation("Only JPEG, PNG, WebP, GIF, or AVIF image uploads are supported"))

  private val AllowedListingImageTypes =
    Set("image/jpeg", "image/png", "image/webp", "image/gif", "image/avif")

  private def inferContentTypeFromBytes(bytes: Array[Byte]): Option[String] =
    def startsWith(prefix: Int*): Boolean =
      bytes.length >= prefix.length && prefix.zipWithIndex.forall { case (value, index) =>
        (bytes(index) & 0xff) == value
      }

    def containsAsciiAt(offset: Int, value: String): Boolean =
      bytes.length >= offset + value.length &&
        value.zipWithIndex.forall { case (character, index) =>
          bytes(offset + index) == character.toByte
        }

    if startsWith(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a) then Some("image/png")
    else if startsWith(0xff, 0xd8, 0xff) then Some("image/jpeg")
    else if startsWith(0x47, 0x49, 0x46, 0x38) then Some("image/gif")
    else if containsAsciiAt(0, "RIFF") && containsAsciiAt(8, "WEBP") then Some("image/webp")
    else if containsAsciiAt(4, "ftypavif") then Some("image/avif")
    else None

  private def sanitizeFileName(fileName: String): String =
    fileName.trim match
      case "" => "image.bin"
      case trimmed =>
        trimmed
          .map {
            case character if character.isLetterOrDigit => character
            case character @ ('.' | '-' | '_') => character
            case _ => '-'
          }
          .mkString
