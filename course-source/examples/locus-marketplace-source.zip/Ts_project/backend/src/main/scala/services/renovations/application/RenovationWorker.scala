package renovations.application

import cats.data.EitherT
import cats.effect.{IO, Resource}
import cats.effect.std.Supervisor
import database.DatabaseSession
import listings.model.ListingId
import media.model.PropertyImageId
import org.typelevel.log4cats.slf4j.Slf4jLogger
import renovations.api.RenovationScheduler
import renovations.clients.GeminiRenovationClient
import renovations.tables.renovation_images.RenovationImagesTable
import shared.{AppError, ListingMediaStorage, RuntimeValues}

private[renovations] final class RenovationWorker private (
  databaseSession: DatabaseSession,
  storage: ListingMediaStorage,
  client: Option[GeminiRenovationClient],
  supervisor: Supervisor[IO]
) extends RenovationScheduler:

  private val logger = Slf4jLogger.getLogger[IO]

  def schedule(listingId: ListingId): IO[Unit] =
    supervisor.supervise(processListing(listingId)).void

  def resumePending: IO[Unit] =
    databaseSession
      .withConnection(RenovationImagesTable.pendingListingIds)
      .flatMap(_.foldLeft(IO.unit)((program, listingId) => program *> schedule(listingId)))

  private def processListing(listingId: ListingId): IO[Unit] =
    client match
      case None =>
        failPendingAsUnconfigured(listingId)
      case Some(configuredClient) =>
        databaseSession
          .withConnection(connection => RenovationImagesTable.pendingImageIds(connection, listingId))
          .flatMap(_.foldLeft(IO.unit) { (program, imageId) =>
            program *> processImage(configuredClient, imageId)
          })

  private def processImage(
    configuredClient: GeminiRenovationClient,
    imageId: PropertyImageId
  ): IO[Unit] =
    val program =
      for
        claimedAt <- RuntimeValues.now
        claimed <- databaseSession.withTransactionEitherConnection(connection =>
          RenovationImagesTable.claim(connection, imageId, claimedAt)
        )
        _ <- claimed match
          case Left(error) => IO.raiseError(new RuntimeException(error.getMessage))
          case Right(None) => IO.unit
          case Right(Some(job)) =>
            generateAndStore(configuredClient, job)
      yield ()

    program.handleErrorWith(error =>
      logger.error(error)(s"Renovation generation failed for image ${imageId.value}")
    )

  private def generateAndStore(
    configuredClient: GeminiRenovationClient,
    job: RenovationImagesTable.ClaimedJob
  ): IO[Unit] =
    val upload =
      for
        originalBytes <- EitherT.right[AppError](storage.readObjectBytes(job.originalObjectKey))
        generated <- EitherT(configuredClient.generate(job.originalContentType, originalBytes))
        generatedId <- EitherT.right[AppError](RuntimeValues.uuid)
        extension = contentTypeExtension(generated.contentType)
        objectKey =
          s"renovations/${job.listingId.value}/${job.originalImageId.value}/$generatedId.$extension"
        _ <- EitherT.right[AppError](storage.uploadBytes(objectKey, generated.bytes, generated.contentType))
      yield (objectKey, generated.contentType)

    upload.value.attempt.flatMap {
      case Right(Right((objectKey, contentType))) =>
        persistCompleted(job.originalImageId, objectKey, contentType)
      case Right(Left(error)) =>
        markFailed(job.originalImageId, error.getMessage) *>
          logger.warn(s"Renovation generation failed for image ${job.originalImageId.value}: ${error.getMessage}")
      case Left(error) =>
        markFailed(job.originalImageId, "Unable to prepare or store the renovation concept.") *>
          logger.error(error)(s"Unexpected renovation failure for image ${job.originalImageId.value}")
    }

  private def persistCompleted(
    imageId: PropertyImageId,
    objectKey: String,
    contentType: String
  ): IO[Unit] =
    (
      for
        completedAt <- EitherT.right[AppError](RuntimeValues.now)
        completedRows <- EitherT.right[AppError](
          databaseSession.withTransactionConnection(connection =>
            RenovationImagesTable.complete(
              connection,
              imageId,
              objectKey,
              contentType,
              completedAt
            )
          )
        )
        _ <- EitherT.cond[IO](
          completedRows > 0,
          (),
          AppError.Conflict("The source image changed before generation completed.")
        )
      yield ()
    ).value.attempt.flatMap {
      case Right(Right(_)) => IO.unit
      case Right(Left(error)) =>
        storage.deleteObject(objectKey) *>
          markFailed(imageId, error.getMessage) *>
          logger.warn(s"Unable to retain renovation result for image ${imageId.value}: ${error.getMessage}")
      case Left(error) =>
        storage.deleteObject(objectKey) *>
          markFailed(imageId, "Unable to store the renovation concept.") *>
          logger.error(error)(s"Unable to persist renovation result for image ${imageId.value}")
    }

  private def markFailed(imageId: PropertyImageId, message: String): IO[Unit] =
    RuntimeValues.now.flatMap(failedAt =>
      databaseSession.withTransactionConnection(connection =>
        RenovationImagesTable.fail(connection, imageId, message, failedAt)
      )
    )

  private def failPendingAsUnconfigured(listingId: ListingId): IO[Unit] =
    for
      pendingIds <- databaseSession.withConnection(connection =>
        RenovationImagesTable.pendingImageIds(connection, listingId)
      )
      _ <- pendingIds.foldLeft(IO.unit) { (program, imageId) =>
        program *> (
          for
            claimedAt <- RuntimeValues.now
            claimed <- databaseSession.withTransactionEitherConnection(connection =>
              RenovationImagesTable.claim(connection, imageId, claimedAt)
            )
            _ <- claimed match
              case Right(Some(_)) =>
                RuntimeValues.now.flatMap(failedAt =>
                  databaseSession.withTransactionConnection(connection =>
                    RenovationImagesTable.fail(
                      connection,
                      imageId,
                      "Gemini image generation is not configured.",
                      failedAt
                    )
                  )
                )
              case _ => IO.unit
          yield ()
        )
      }
    yield ()

  private def contentTypeExtension(contentType: String): String =
    contentType.trim.toLowerCase match
      case "image/jpeg" => "jpg"
      case "image/webp" => "webp"
      case _ => "png"

private[renovations] object RenovationWorker:
  def create(
    databaseSession: DatabaseSession,
    storage: ListingMediaStorage,
    client: Option[GeminiRenovationClient]
  ): Resource[IO, RenovationWorker] =
    Supervisor[IO].map(supervisor => RenovationWorker(databaseSession, storage, client, supervisor))
