package messaging.tables
import identity.model.*
import listings.model.*
import messaging.model.*


import cats.effect.IO
import _root_.messaging.tables.conversation_messages.ConversationMessagesTable
import _root_.messaging.tables.conversations.ConversationsTable
import _root_.messaging.tables.message_attachments.MessageAttachmentsTable

import java.sql.Connection

object MessagingSchema:

  def initialize(connection: Connection): IO[Unit] =
    List[Connection => IO[Unit]](
      ConversationsTable.initialize,
      ConversationMessagesTable.initialize,
      MessageAttachmentsTable.initialize
    ).foldLeft(IO.unit)((program, initializeTable) => program *> initializeTable(connection))
