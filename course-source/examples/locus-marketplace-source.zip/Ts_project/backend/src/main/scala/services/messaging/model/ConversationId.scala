package messaging.model


import io.circe.{Decoder, Encoder}

import java.util.UUID
import scala.util.Try

final case class ConversationId(value: UUID)

object ConversationId:
  given Encoder[ConversationId] = Encoder.encodeString.contramap(_.value.toString)
  given Decoder[ConversationId] = Decoder.decodeString.emap(parseUuid(_, "conversationId").map(ConversationId(_)))

  private def parseUuid(value: String, label: String): Either[String, UUID] =
    Try(UUID.fromString(value)).toEither.left.map(_ => s"Invalid $label")
