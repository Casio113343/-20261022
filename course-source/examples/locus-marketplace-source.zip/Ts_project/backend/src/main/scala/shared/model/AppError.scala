package shared

sealed abstract class AppError(message: String) extends RuntimeException(message)

type AppResult[+A] = Either[AppError, A]

object AppError:
  final case class Validation(message: String) extends AppError(message)
  final case class Unauthorized(message: String) extends AppError(message)
  final case class Forbidden(message: String) extends AppError(message)
  final case class NotFound(message: String) extends AppError(message)
  final case class Conflict(message: String) extends AppError(message)
  final case class Decoding(message: String) extends AppError(message)
  final case class Unexpected(message: String) extends AppError(message)
