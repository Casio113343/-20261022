package messaging.api.messages
import identity.model.*
import listings.model.*
import messaging.model.*


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.effect.IO
import identity.api.IdentityPublicApi
import shared.AppResult
import shared.AuthenticatedPrincipal
import messaging.api.requests.StartConversationRequest
import messaging.api.responses.StartConversationResponse
import messaging.application.MessagingApplication
import shared.ListingMediaStorage

import java.sql.Connection

final case class StartConversationApiMessage(storage: ListingMediaStorage)
    extends ApiWithTokenMessage[StartConversationRequest, StartConversationResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: StartConversationRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[StartConversationResponse]] =
    IdentityPublicApi.requireBuyer(principal) match
      case Left(error) => IO.pure(Left(error))
      case Right(buyer) =>
        MessagingApplication
          .findOrCreateConversation(connection, storage, request.listingId, buyer.userId)
          .map(_.map(StartConversationResponse.apply))
