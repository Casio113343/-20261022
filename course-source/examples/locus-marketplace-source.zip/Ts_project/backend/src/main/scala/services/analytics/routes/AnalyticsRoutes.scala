package analytics.routes

import analytics.api.messages.{GetManagedListingAnalyticsApiMessage, RecordListingAnalyticsEventsApiMessage}
import shared.ApiServiceMessages

object AnalyticsRoutes:

  def apiMessages: ApiServiceMessages =
    ApiServiceMessages(
      "analytics",
      List(
        RecordListingAnalyticsEventsApiMessage,
        GetManagedListingAnalyticsApiMessage
      )
    )
