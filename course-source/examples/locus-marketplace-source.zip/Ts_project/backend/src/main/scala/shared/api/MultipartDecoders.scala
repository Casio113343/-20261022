package shared

import cats.data.EitherT
import cats.effect.IO
import shared.{AppError, AppResult}
import org.http4s.multipart.Multipart
import org.http4s.headers.`Content-Type`

import java.nio.charset.StandardCharsets

object MultipartDecoders:

  private type AppEitherT[A] = EitherT[IO, AppError, A]

  def requiredTextPart(multipart: Multipart[IO], name: String): AppEitherT[String] =
    EitherT.fromOption[IO](
      multipart.parts.find(_.name.contains(name)),
      AppError.Validation(s"Request must include $name")
    ).flatMap(part =>
      EitherT.right[AppError](
        part.body.compile.to(Array).map(bytes => new String(bytes, StandardCharsets.UTF_8).trim)
      ).flatMap(value =>
        EitherT.fromOption[IO](
          Option(value).filter(_.nonEmpty),
          AppError.Validation(s"Request must include $name")
        )
      )
    )

  def optionalTextPart(multipart: Multipart[IO], name: String): AppEitherT[Option[String]] =
    multipart.parts.find(_.name.contains(name)) match
      case Some(part) =>
        EitherT.right[AppError](
          part.body.compile.to(Array).map(bytes =>
            Option(new String(bytes, StandardCharsets.UTF_8).trim).filter(_.nonEmpty)
          )
        )
      case None => EitherT.rightT[IO, AppError](None)

  def fileUpload(multipart: Multipart[IO], missingFileMessage: String, missingNameMessage: String): AppEitherT[(String, String, Array[Byte])] =
    for
      filePart <- EitherT.fromOption[IO](
        multipart.parts.find(_.name.contains("file")),
        AppError.Validation(missingFileMessage)
      )
      fileName <- EitherT.fromOption[IO](
        filePart.filename.map(_.trim).filter(_.nonEmpty),
        AppError.Validation(missingNameMessage)
      )
      bytes <- EitherT.right[AppError](filePart.body.compile.to(Array))
      contentType = filePart.headers
        .get[`Content-Type`]
        .map(header => s"${header.mediaType.mainType}/${header.mediaType.subType}")
        .getOrElse("application/octet-stream")
    yield (fileName, contentType, bytes)

  def result[A](value: AppEitherT[A]): IO[AppResult[A]] =
    value.value
