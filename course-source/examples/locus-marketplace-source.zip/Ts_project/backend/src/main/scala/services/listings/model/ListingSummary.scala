package listings.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import shared.TimeCodecs

import java.time.Instant

import TimeCodecs.given

final case class ListingSummary(
  id: ListingId,
  title: String,
  transactionType: TransactionType,
  propertyType: PropertyType,
  houseSubtype: Option[HouseSubtype],
  apartmentSubtype: Option[ApartmentSubtype],
  price: Int,
  addressLine: String,
  suburb: String,
  state: String,
  postcode: String,
  bedrooms: Int,
  bathrooms: Int,
  carSpaces: Int,
  landSize: Option[Int],
  buildingSize: Option[Int],
  listingStatus: ListingStatus,
  headline: Option[String],
  primaryImageUrl: Option[String],
  previewImageUrls: List[String],
  agent: ListingAgentSummary,
  createdAt: Instant
)

object ListingSummary:
  given Encoder[ListingSummary] = deriveEncoder[ListingSummary]
  given Decoder[ListingSummary] = deriveDecoder[ListingSummary]
