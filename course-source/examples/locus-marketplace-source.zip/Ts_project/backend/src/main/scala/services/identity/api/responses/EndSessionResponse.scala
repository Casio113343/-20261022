package identity.api.responses
import identity.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import shared.SessionClearedResponse

final case class EndSessionResponse(
  ended: Boolean
) extends SessionClearedResponse

object EndSessionResponse:
  given Encoder[EndSessionResponse] = deriveEncoder[EndSessionResponse]
