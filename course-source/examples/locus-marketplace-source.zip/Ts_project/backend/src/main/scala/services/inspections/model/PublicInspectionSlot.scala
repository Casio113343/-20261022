package inspections.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import listings.model.ListingId
import shared.TimeCodecs.given

import java.time.Instant

final case class PublicInspectionSlot(
  id: InspectionSlotId,
  listingId: ListingId,
  startsAt: Instant,
  endsAt: Instant,
  isBooked: Boolean,
  isBookedByCurrentUser: Boolean
)

object PublicInspectionSlot:
  given Encoder[PublicInspectionSlot] = deriveEncoder[PublicInspectionSlot]
  given Decoder[PublicInspectionSlot] = deriveDecoder[PublicInspectionSlot]
