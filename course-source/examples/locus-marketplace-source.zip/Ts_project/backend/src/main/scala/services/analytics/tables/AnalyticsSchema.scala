package analytics.tables

import analytics.tables.listing_analytics_events.ListingAnalyticsEventsTable
import cats.effect.IO

import java.sql.Connection

object AnalyticsSchema:

  def initialize(connection: Connection): IO[Unit] =
    ListingAnalyticsEventsTable.initialize(connection)
