package listings.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import shared.TimeCodecs

import java.time.Instant

import TimeCodecs.given

final case class ListingDetail(
  id: ListingId,
  title: String,
  description: String,
  transactionType: TransactionType,
  propertyType: PropertyType,
  houseSubtype: Option[HouseSubtype],
  apartmentSubtype: Option[ApartmentSubtype],
  price: Int,
  addressLine: String,
  suburb: String,
  state: String,
  postcode: String,
  bedrooms: Int,
  bathrooms: Int,
  carSpaces: Int,
  landSize: Option[Int],
  buildingSize: Option[Int],
  listingStatus: ListingStatus,
  renovateWithAi: Boolean,
  agent: ListingAgentSummary,
  images: List[ListingImage],
  faqs: List[ListingFaq],
  createdAt: Instant,
  updatedAt: Instant
)

object ListingDetail:
  given Encoder[ListingDetail] = deriveEncoder[ListingDetail]
  given Decoder[ListingDetail] = deriveDecoder[ListingDetail]
