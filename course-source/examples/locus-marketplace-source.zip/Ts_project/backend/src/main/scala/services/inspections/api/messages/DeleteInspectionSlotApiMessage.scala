package inspections.api.messages
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import identity.api.IdentityPublicApi
import inspections.api.requests.DeleteInspectionSlotRequest
import inspections.api.responses.DeleteInspectionSlotResponse
import inspections.tables.inspection_slots.InspectionSlotsTable
import listings.api.ListingsPublicApi
import shared.{AppError, AppResult, RuntimeValues}
import shared.AuthenticatedPrincipal
import messaging.api.MessagingPublicApi

import java.sql.Connection

object DeleteInspectionSlotApiMessage
    extends ApiWithTokenMessage[DeleteInspectionSlotRequest, DeleteInspectionSlotResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(
    request: DeleteInspectionSlotRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[DeleteInspectionSlotResponse]] =
    (
      for
        maybeNotice <- EitherT(InspectionSlotsTable.cancellationNoticeForSlot(connection, principal.userId, request.slotId))
        now <- EitherT.right[AppError](RuntimeValues.now)
        rows <- EitherT.right[AppError](InspectionSlotsTable.deleteSlot(connection, principal.userId, request.slotId))
        _ <- EitherT.cond[IO](rows > 0, (), AppError.Conflict("This inspection slot has already passed or is no longer available."))
        _ <- EitherT(maybeNotice.fold(IO.pure(Right(()): AppResult[Unit]))(notice =>
          ListingsPublicApi.findAnyConversationListing(connection, notice.listingId).flatMap {
            case Left(error) => IO.pure(Left(error))
            case Right(None) => IO.pure(Left(AppError.NotFound("Listing not found")))
            case Right(Some(listing)) =>
              MessagingPublicApi.addListingBuyerSystemMessage(
                connection = connection,
                listingId = notice.listingId,
                buyerId = notice.buyerId,
                agentId = notice.agentId,
                body = s"Inspection cancelled: ${notice.startsAt.toString} for ${listing.summary.addressLine}.",
                occurredAt = now
              )
          }
        ))
      yield DeleteInspectionSlotResponse()
    ).value
