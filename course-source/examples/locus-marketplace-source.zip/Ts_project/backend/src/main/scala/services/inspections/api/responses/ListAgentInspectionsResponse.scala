package inspections.api.responses
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import inspections.model.AgentInspectionSlot
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class ListAgentInspectionsResponse(slots: List[AgentInspectionSlot])

object ListAgentInspectionsResponse:
  given Encoder[ListAgentInspectionsResponse] = deriveEncoder[ListAgentInspectionsResponse]
