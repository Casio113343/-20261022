package analytics.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import listings.model.ListingId

final case class ListingAnalyticsEventInput(
  listingId: ListingId,
  eventType: ListingAnalyticsEventType,
  metadata: Option[ListingAnalyticsEventMetadata]
)

object ListingAnalyticsEventInput:
  given Encoder[ListingAnalyticsEventInput] = deriveEncoder[ListingAnalyticsEventInput]
  given Decoder[ListingAnalyticsEventInput] = deriveDecoder[ListingAnalyticsEventInput]
