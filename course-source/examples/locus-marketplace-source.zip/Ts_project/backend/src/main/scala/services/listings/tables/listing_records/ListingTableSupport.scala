package listings.tables.listing_records
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import shared.*

import java.sql.{Connection, PreparedStatement, ResultSet, Timestamp, Types}
import java.time.Instant
import java.util.UUID

private[listings] object ListingTableSupport:

  type ResolveMediaUrl = String => String

  enum SqlParam:
    case Text(value: String)
    case IntValue(value: Int)
    case UuidValue(value: UUID)

  final case class ListingSearchSql(whereClause: String, params: List[SqlParam])

  final case class ListingSummaryRecord(
    id: ListingId,
    title: String,
    description: Option[String],
    transactionType: TransactionType,
    propertyType: PropertyType,
    houseSubtype: Option[HouseSubtype],
    apartmentSubtype: Option[ApartmentSubtype],
    price: Int,
    addressLine: String,
    suburb: String,
    state: String,
    postcode: String,
    bedrooms: Int,
    bathrooms: Int,
    carSpaces: Int,
    landSize: Option[Int],
    buildingSize: Option[Int],
    listingStatus: ListingStatus,
    agentId: UserId,
    createdAt: Instant
  )

  final case class ListingDetailRecord(
    id: ListingId,
    title: String,
    description: String,
    transactionType: TransactionType,
    propertyType: PropertyType,
    houseSubtype: Option[HouseSubtype],
    apartmentSubtype: Option[ApartmentSubtype],
    price: Int,
    addressLine: String,
    suburb: String,
    state: String,
    postcode: String,
    bedrooms: Int,
    bathrooms: Int,
    carSpaces: Int,
    landSize: Option[Int],
    buildingSize: Option[Int],
    listingStatus: ListingStatus,
    renovateWithAi: Boolean,
    agentId: UserId,
    faqs: List[ListingFaq],
    createdAt: Instant,
    updatedAt: Instant
  )

  def readListingSummaries(resultSet: ResultSet): AppResult[List[ListingSummaryRecord]] =
    Iterator
      .continually(resultSet.next())
      .takeWhile(Predef.identity)
      .map(_ => readListingSummary(resultSet))
      .foldRight(Right(Nil): AppResult[List[ListingSummaryRecord]])((next, acc) =>
        for
          head <- next
          tail <- acc
        yield head :: tail
      )

  def readListingSummary(resultSet: ResultSet): AppResult[ListingSummaryRecord] =
    for
      title <- DbCodec.requiredText(resultSet, "title")
      transactionTypeText <- DbCodec.requiredText(resultSet, "transaction_type")
      propertyTypeText <- DbCodec.requiredText(resultSet, "property_type")
      addressLine <- DbCodec.requiredText(resultSet, "address_line")
      suburb <- DbCodec.requiredText(resultSet, "suburb")
      state <- DbCodec.requiredText(resultSet, "state")
      postcode <- DbCodec.requiredText(resultSet, "postcode")
      listingStatusText <- DbCodec.requiredText(resultSet, "listing_status")
      createdAt <- DbCodec.requiredInstant(resultSet, "created_at")
      listingId <- DbCodec.requiredUuid(resultSet, "id")
      agentId <- DbCodec.requiredUuid(resultSet, "agent_id")
      description = DbCodec.optionalText(resultSet, "description")
      houseSubtype = DbCodec.optionalText(resultSet, "house_subtype")
      apartmentSubtype = DbCodec.optionalText(resultSet, "apartment_subtype")
      landSize = DbCodec.optionalInt(resultSet, "land_size")
      buildingSize = DbCodec.optionalInt(resultSet, "building_size")
      transactionType <- DbCodec.decodeDatabaseValue(TransactionType.fromString(transactionTypeText), "transaction_type")
      propertyType <- DbCodec.decodeDatabaseValue(PropertyType.fromString(propertyTypeText), "property_type")
      decodedHouseSubtype <- DbCodec.decodeOptionalValue(houseSubtype, "house_subtype", HouseSubtype.fromString)
      decodedApartmentSubtype <- DbCodec.decodeOptionalValue(apartmentSubtype, "apartment_subtype", ApartmentSubtype.fromString)
      listingStatus <- DbCodec.decodeDatabaseValue(ListingStatus.fromString(listingStatusText), "listing_status")
    yield ListingSummaryRecord(
      id = ListingId(listingId),
      title = title,
      description = description,
      transactionType = transactionType,
      propertyType = propertyType,
      houseSubtype = decodedHouseSubtype,
      apartmentSubtype = decodedApartmentSubtype,
      price = resultSet.getInt("price"),
      addressLine = addressLine,
      suburb = suburb,
      state = state,
      postcode = postcode,
      bedrooms = resultSet.getInt("bedrooms"),
      bathrooms = resultSet.getInt("bathrooms"),
      carSpaces = resultSet.getInt("car_spaces"),
      landSize = landSize,
      buildingSize = buildingSize,
      listingStatus = listingStatus,
      agentId = UserId(agentId),
      createdAt = createdAt
    )

  def readListingDetailBase(resultSet: ResultSet): AppResult[ListingDetailRecord] =
    for
      title <- DbCodec.requiredText(resultSet, "title")
      description <- DbCodec.requiredText(resultSet, "description")
      transactionTypeText <- DbCodec.requiredText(resultSet, "transaction_type")
      propertyTypeText <- DbCodec.requiredText(resultSet, "property_type")
      addressLine <- DbCodec.requiredText(resultSet, "address_line")
      suburb <- DbCodec.requiredText(resultSet, "suburb")
      state <- DbCodec.requiredText(resultSet, "state")
      postcode <- DbCodec.requiredText(resultSet, "postcode")
      listingStatusText <- DbCodec.requiredText(resultSet, "listing_status")
      createdAt <- DbCodec.requiredInstant(resultSet, "created_at")
      updatedAt <- DbCodec.requiredInstant(resultSet, "updated_at")
      listingId <- DbCodec.requiredUuid(resultSet, "id")
      agentId <- DbCodec.requiredUuid(resultSet, "agent_id")
      houseSubtype = DbCodec.optionalText(resultSet, "house_subtype")
      apartmentSubtype = DbCodec.optionalText(resultSet, "apartment_subtype")
      landSize = DbCodec.optionalInt(resultSet, "land_size")
      buildingSize = DbCodec.optionalInt(resultSet, "building_size")
      faqs <- DbCodec.decodeField[List[ListingFaq]](resultSet, "faqs_json")
      transactionType <- DbCodec.decodeDatabaseValue(TransactionType.fromString(transactionTypeText), "transaction_type")
      propertyType <- DbCodec.decodeDatabaseValue(PropertyType.fromString(propertyTypeText), "property_type")
      decodedHouseSubtype <- DbCodec.decodeOptionalValue(houseSubtype, "house_subtype", HouseSubtype.fromString)
      decodedApartmentSubtype <- DbCodec.decodeOptionalValue(apartmentSubtype, "apartment_subtype", ApartmentSubtype.fromString)
      listingStatus <- DbCodec.decodeDatabaseValue(ListingStatus.fromString(listingStatusText), "listing_status")
    yield ListingDetailRecord(
      id = ListingId(listingId),
      title = title,
      description = description,
      transactionType = transactionType,
      propertyType = propertyType,
      houseSubtype = decodedHouseSubtype,
      apartmentSubtype = decodedApartmentSubtype,
      price = resultSet.getInt("price"),
      addressLine = addressLine,
      suburb = suburb,
      state = state,
      postcode = postcode,
      bedrooms = resultSet.getInt("bedrooms"),
      bathrooms = resultSet.getInt("bathrooms"),
      carSpaces = resultSet.getInt("car_spaces"),
      landSize = landSize,
      buildingSize = buildingSize,
      listingStatus = listingStatus,
      renovateWithAi = resultSet.getBoolean("renovate_with_ai"),
      agentId = UserId(agentId),
      faqs = faqs,
      createdAt = createdAt,
      updatedAt = updatedAt
    )

  def listingSearchSql(
    query: SearchListingsQuery,
    publicOnly: Boolean,
    agentId: Option[UserId]
  ): ListingSearchSql =
    val normalizedQuery = query.query.map(_.trim.toLowerCase).filter(_.nonEmpty)
    val statusFilter =
      if query.listingStatuses.nonEmpty then query.listingStatuses
      else if publicOnly then List(ListingStatus.Active)
      else Nil
    val baseConditions =
      List(
        agentId.map(_ => "l.agent_id = ?"),
        query.transactionType.map(_ => "l.transaction_type = ?"),
        Option.when(statusFilter.nonEmpty)(
          s"l.listing_status in (${statusFilter.map(_ => "?").mkString(", ")})"
        ),
        Option.when(query.propertyTypes.nonEmpty)(
          s"l.property_type in (${query.propertyTypes.map(_ => "?").mkString(", ")})"
        ),
        Option.when(query.houseSubtypes.nonEmpty)(
          s"l.house_subtype in (${query.houseSubtypes.map(_ => "?").mkString(", ")})"
        ),
        Option.when(query.apartmentSubtypes.nonEmpty)(
          s"l.apartment_subtype in (${query.apartmentSubtypes.map(_ => "?").mkString(", ")})"
        ),
        query.minPrice.map(_ => "l.price >= ?"),
        query.maxPrice.map(_ => "l.price <= ?"),
        query.minFloorSize.map(_ => "coalesce(l.building_size, 0) >= ?"),
        query.maxFloorSize.map(_ => "coalesce(l.building_size, 0) <= ?"),
        query.minLandSize.map(_ => "coalesce(l.land_size, 0) >= ?"),
        query.maxLandSize.map(_ => "coalesce(l.land_size, 0) <= ?"),
        query.bedrooms.map(_ => "l.bedrooms >= ?"),
        query.bathrooms.map(_ => "l.bathrooms >= ?"),
        query.carSpaces.map(_ => "l.car_spaces >= ?"),
        normalizedQuery.map(_ => "(lower(l.title) like ? or lower(l.address_line) like ? or lower(l.suburb) like ? or lower(l.state) like ? or l.postcode like ?)")
      ).flatten

    val params =
      agentId.map(userId => List(SqlParam.UuidValue(userId.value))).getOrElse(Nil) :::
        query.transactionType.map(value => List(SqlParam.Text(TransactionType.toString(value)))).getOrElse(Nil) :::
        statusFilter.map(value => SqlParam.Text(ListingStatus.toString(value))) :::
        query.propertyTypes.map(value => SqlParam.Text(PropertyType.toString(value))) :::
        query.houseSubtypes.map(value => SqlParam.Text(HouseSubtype.toString(value))) :::
        query.apartmentSubtypes.map(value => SqlParam.Text(ApartmentSubtype.toString(value))) :::
        query.minPrice.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        query.maxPrice.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        query.minFloorSize.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        query.maxFloorSize.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        query.minLandSize.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        query.maxLandSize.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        query.bedrooms.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        query.bathrooms.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        query.carSpaces.map(value => List(SqlParam.IntValue(value))).getOrElse(Nil) :::
        normalizedQuery
          .map(value => List.fill(5)(SqlParam.Text(s"%$value%")))
          .getOrElse(Nil)

    val whereClause =
      if baseConditions.isEmpty then ""
      else s"where ${baseConditions.mkString(" and ")}"

    ListingSearchSql(whereClause, params)

  def bindParams(statement: PreparedStatement, params: List[SqlParam]): Unit =
    params.zipWithIndex.foreach { case (param, index) =>
      param match
        case SqlParam.Text(value) => statement.setString(index + 1, value)
        case SqlParam.IntValue(value) => statement.setInt(index + 1, value)
        case SqlParam.UuidValue(value) => statement.setObject(index + 1, value)
    }

  def orderByClause(sort: ListingSort): String =
    sort match
      case ListingSort.Newest => "order by l.created_at desc"
      case ListingSort.PriceAscending => "order by l.price asc, l.created_at desc"
      case ListingSort.PriceDescending => "order by l.price desc, l.created_at desc"

  def setOptionalInt(statement: PreparedStatement, index: Int, value: Option[Int]): Unit =
    value match
      case Some(number) => statement.setInt(index, number)
      case None => statement.setNull(index, Types.INTEGER)

  def setOptionalText(statement: PreparedStatement, index: Int, value: Option[String]): Unit =
    value match
      case Some(text) => statement.setString(index, text)
      case None => statement.setNull(index, Types.VARCHAR)

  private val insertListingSql: String =
    """
      |insert into listings (
      |  id, title, description, transaction_type, property_type, house_subtype, apartment_subtype, price, address_line, suburb, state, postcode,
      |  bedrooms, bathrooms, car_spaces, land_size, building_size, listing_status, renovate_with_ai, faqs, agent_id, created_at, updated_at
      |)
      |values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?::jsonb, ?, ?, ?)
      |""".stripMargin

  def insertListing(
    connection: Connection,
    listingId: ListingId,
    agentId: UserId,
    request: ListingWrite,
    timestamp: Instant
  ): IO[Unit] =
    JdbcResources.update(connection, insertListingSql) { statement =>
        statement.setObject(1, listingId.value)
        statement.setString(2, request.addressLine.trim)
        statement.setString(3, request.description.trim)
        statement.setString(4, TransactionType.toString(request.transactionType))
        statement.setString(5, PropertyType.toString(request.propertyType))
        setOptionalText(statement, 6, request.houseSubtypeOption.map(HouseSubtype.toString))
        setOptionalText(statement, 7, request.apartmentSubtypeOption.map(ApartmentSubtype.toString))
        statement.setInt(8, request.price)
        statement.setString(9, request.addressLine.trim)
        statement.setString(10, request.suburb.trim)
        statement.setString(11, request.state.trim.toUpperCase)
        statement.setString(12, request.postcode.trim)
        statement.setInt(13, request.bedrooms)
        statement.setInt(14, request.bathrooms)
        statement.setInt(15, request.carSpaces)
        setOptionalInt(statement, 16, request.landSize)
        setOptionalInt(statement, 17, request.buildingSize)
        statement.setString(18, ListingStatus.toString(request.listingStatus))
        statement.setBoolean(19, request.renovateWithAi)
        DbCodec.setJson(statement, 20, request.faqs)
        statement.setObject(21, agentId.value)
        statement.setTimestamp(22, Timestamp.from(timestamp))
        statement.setTimestamp(23, Timestamp.from(timestamp))
        statement.executeUpdate()
    }.void
