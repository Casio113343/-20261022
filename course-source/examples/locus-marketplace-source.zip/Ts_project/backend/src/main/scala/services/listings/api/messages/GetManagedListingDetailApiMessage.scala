package listings.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import identity.api.IdentityPublicApi
import listings.api.requests.GetManagedListingDetailRequest
import listings.api.responses.GetManagedListingDetailResponse
import listings.application.ListingApplication
import shared.{AppError, AppResult}
import shared.AuthenticatedPrincipal
import listings.model.ListingDetail
import shared.ListingMediaStorage

import java.sql.Connection

final case class GetManagedListingDetailApiMessage(storage: ListingMediaStorage)
    extends ApiWithTokenMessage[GetManagedListingDetailRequest, GetManagedListingDetailResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(
    request: GetManagedListingDetailRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[GetManagedListingDetailResponse]] =
    (
      for
        listingOption <- EitherT(
          ListingApplication.findManagedDetail(connection, storage, request.listingId, publicOnly = false)
        )
        listing <- EitherT.fromOption[IO](listingOption, AppError.NotFound("Listing not found"))
        managedListing <- ensureManagedByAgent(principal, listing)
      yield GetManagedListingDetailResponse(managedListing)
    ).value

  private def ensureManagedByAgent(principal: AuthenticatedPrincipal, listing: ListingDetail): EitherT[IO, AppError, ListingDetail] =
    EitherT.cond[IO](
      listing.agent.id == principal.userId.value.toString,
      listing,
      AppError.Forbidden("You can only manage your own listings")
    )
