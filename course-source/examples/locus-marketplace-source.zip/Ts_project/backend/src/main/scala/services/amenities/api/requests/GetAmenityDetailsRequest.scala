package amenities.api.requests

import amenities.model.{ListingMapPosition, NearbyAmenity}
import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder

final case class GetAmenityDetailsRequest(
  origin: ListingMapPosition,
  place: NearbyAmenity
)

object GetAmenityDetailsRequest:
  given Decoder[GetAmenityDetailsRequest] = deriveDecoder[GetAmenityDetailsRequest]
