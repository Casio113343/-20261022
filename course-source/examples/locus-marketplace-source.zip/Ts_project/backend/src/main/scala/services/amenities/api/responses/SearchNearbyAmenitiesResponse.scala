package amenities.api.responses

import amenities.model.NearbyAmenity
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class SearchNearbyAmenitiesResponse(
  places: List[NearbyAmenity]
)

object SearchNearbyAmenitiesResponse:
  given Encoder[SearchNearbyAmenitiesResponse] = deriveEncoder[SearchNearbyAmenitiesResponse]
