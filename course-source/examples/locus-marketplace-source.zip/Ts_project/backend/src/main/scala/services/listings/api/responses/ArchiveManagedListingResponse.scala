package listings.api.responses
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import listings.model.{ListingId, ListingStatus}

final case class ArchiveManagedListingResponse(
  listingId: ListingId,
  listingStatus: ListingStatus
)

object ArchiveManagedListingResponse:
  given Encoder[ArchiveManagedListingResponse] = deriveEncoder[ArchiveManagedListingResponse]
