package inspections.api.responses
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import inspections.model.PublicInspectionSlot
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class CancelInspectionBookingResponse(slot: PublicInspectionSlot)

object CancelInspectionBookingResponse:
  given Encoder[CancelInspectionBookingResponse] = deriveEncoder[CancelInspectionBookingResponse]
