package messaging.application

import cats.effect.IO
import identity.api.IdentityPublicApi
import identity.model.*
import listings.api.ListingsPublicApi
import listings.model.*
import messaging.model.*
import messaging.tables.conversation_messages.ConversationMessagesTable
import messaging.tables.conversations.ConversationsTable
import messaging.tables.conversations.ConversationsTable.ConversationRecord
import shared.*

import java.sql.Connection
import java.time.Instant

private[messaging] object MessagingApplication:

  private def findConversationForUser(
    connection: Connection,
    storage: ListingMediaStorage,
    conversationId: ConversationId,
    userId: UserId
  ): IO[AppResult[Option[ConversationSummary]]] =
    ConversationsTable.findForUser(connection, conversationId, userId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(None) => IO.pure(Right(None))
      case Right(Some(record)) =>
        enrichConversationRecords(connection, storage, List(record))
          .flatMap(addLastMessages(connection, _))
          .map(_.map(_.headOption))
    }

  def listConversationsForUser(
    connection: Connection,
    storage: ListingMediaStorage,
    userId: UserId
  ): IO[AppResult[List[ConversationSummary]]] =
    ConversationsTable.listForUser(connection, userId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(records) =>
        enrichConversationRecords(connection, storage, records)
          .flatMap(addLastMessages(connection, _))
    }

  def findOrCreateConversation(
    connection: Connection,
    storage: ListingMediaStorage,
    listingId: ListingId,
    buyerId: UserId
  ): IO[AppResult[ConversationSummary]] =
    ConversationsTable.findByListingAndBuyer(connection, listingId, buyerId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(Some(record)) =>
        enrichConversationRecords(connection, storage, List(record))
          .flatMap(addLastMessages(connection, _))
          .map(_.flatMap(_.headOption.toRight(AppError.Unexpected("Conversation could not be loaded"))))
      case Right(None) => createConversation(connection, storage, listingId, buyerId)
    }

  def addListingBuyerSystemMessage(
    connection: Connection,
    listingId: ListingId,
    buyerId: UserId,
    agentId: UserId,
    body: String,
    occurredAt: Instant
  ): IO[AppResult[Unit]] =
    for
      conversationId <- RuntimeValues.uuid.map(ConversationId(_))
      messageId <- RuntimeValues.uuid.map(ConversationMessageId(_))
      resolvedConversationId <- ConversationsTable.upsert(
        connection,
        conversationId,
        listingId,
        buyerId,
        agentId,
        occurredAt
      )
      result <- resolvedConversationId match
        case Left(error) => IO.pure(Left(error))
        case Right(value) =>
          ConversationMessagesTable
            .insertSystemMessage(connection, messageId, value, agentId, body, occurredAt)
            .as(Right(()))
    yield result

  def listMessagesEnsuringIntroduction(
    connection: Connection,
    conversationId: ConversationId,
    userId: UserId,
    storage: ListingMediaStorage
  ): IO[AppResult[List[ConversationMessage]]] =
    authorizeConversation(connection, conversationId, userId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(_) =>
        ensureIntroMessage(connection, conversationId).flatMap {
          case Left(error) => IO.pure(Left(error))
          case Right(_) =>
            ConversationMessagesTable.listConversationMessages(connection, conversationId, storage)
        }
    }

  def createMessage(
    connection: Connection,
    conversationId: ConversationId,
    senderId: UserId,
    body: String,
    attachmentIds: List[MessageAttachmentId],
    storage: ListingMediaStorage
  ): IO[AppResult[ConversationMessage]] =
    val normalizedBody = body.trim

    if normalizedBody.isEmpty && attachmentIds.isEmpty then
      IO.pure(Left(AppError.Validation("Message must include text or an attachment")))
    else
      authorizeConversation(connection, conversationId, senderId).flatMap {
        case Left(error) => IO.pure(Left(error))
        case Right(_) =>
          ConversationMessagesTable.createConversationMessage(
            connection,
            conversationId,
            senderId,
            normalizedBody,
            attachmentIds,
            storage
          )
      }

  def markSeen(
    connection: Connection,
    conversationId: ConversationId,
    readerId: UserId
  ): IO[AppResult[Instant]] =
    authorizeConversation(connection, conversationId, readerId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(_) =>
        ConversationMessagesTable.markConversationMessagesSeen(connection, conversationId, readerId)
    }

  private def authorizeConversation(
    connection: Connection,
    conversationId: ConversationId,
    userId: UserId
  ): IO[AppResult[Unit]] =
    ConversationsTable.findForUser(connection, conversationId, userId).map(
      _.flatMap(_.toRight(AppError.NotFound("Conversation not found"))).map(_ => ())
    )

  private def createConversation(
    connection: Connection,
    storage: ListingMediaStorage,
    listingId: ListingId,
    buyerId: UserId
  ): IO[AppResult[ConversationSummary]] =
    ListingsPublicApi.findConversationListing(connection, listingId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(None) => IO.pure(Left(AppError.NotFound("Listing not found")))
      case Right(Some(listing)) if listing.agentId == buyerId =>
        IO.pure(Left(AppError.Forbidden("You cannot message your own listing")))
      case Right(Some(listing)) =>
        for
          conversationId <- RuntimeValues.uuid.map(ConversationId(_))
          now <- RuntimeValues.now
          _ <- ConversationsTable.insert(
            connection,
            conversationId,
            listingId,
            buyerId,
            listing.agentId,
            now
          )
          introResult <- ensureIntroMessage(connection, conversationId)
          conversation <- introResult match
            case Left(error) => IO.pure(Left(error))
            case Right(_) =>
              findConversationForUser(connection, storage, conversationId, buyerId)
                .map(_.flatMap(_.toRight(AppError.Unexpected("Created conversation could not be loaded"))))
        yield conversation
    }

  private def ensureIntroMessage(
    connection: Connection,
    conversationId: ConversationId
  ): IO[AppResult[Unit]] =
    ConversationsTable.findIntroMetadata(connection, conversationId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(None) => IO.pure(Left(AppError.NotFound("Conversation not found")))
      case Right(Some(metadata)) =>
        ListingsPublicApi.findConversationListing(connection, metadata.listingId).flatMap {
          case Left(error) => IO.pure(Left(error))
          case Right(None) => IO.pure(Left(AppError.NotFound("Listing not found")))
          case Right(Some(listing)) =>
            val body = s"Hi there, happy to help with any questions about ${listing.summary.addressLine}."

            for
              messageId <- RuntimeValues.uuid.map(ConversationMessageId(_))
              _ <- ConversationMessagesTable.insertIntroMessageIfAbsent(
                connection,
                messageId,
                conversationId,
                metadata.agentId,
                body,
                metadata.createdAt.minusMillis(1)
              )
            yield Right(())
        }
    }

  private def enrichConversationRecords(
    connection: Connection,
    storage: ListingMediaStorage,
    records: List[ConversationRecord]
  ): IO[AppResult[List[ConversationSummary]]] =
    for
      listingMapResult <- ListingsPublicApi.loadAnyConversationListingMap(connection, records.map(_.listingId))
      userMapResult <- IdentityPublicApi.loadAgentSummaryMap(
        connection,
        storage,
        records.flatMap(record => List(record.buyerId, record.agentId))
      )
    yield
      for
        listingMap <- listingMapResult
        userMap <- userMapResult
        summaries <- records.foldRight(Right(Nil): AppResult[List[ConversationSummary]]) { (record, acc) =>
          for
            tail <- acc
            listing <- listingMap.get(record.listingId).toRight(AppError.NotFound("Listing not found"))
            buyer <- userMap.get(record.buyerId).toRight(AppError.NotFound("Conversation buyer not found"))
            agent <- userMap.get(record.agentId).toRight(AppError.NotFound("Conversation agent not found"))
          yield ConversationSummary(
            id = record.id,
            listing = listing.summary,
            buyer = buyer,
            agent = agent,
            lastMessage = None,
            unreadCount = record.unreadCount,
            updatedAt = record.updatedAt
          ) :: tail
        }
      yield summaries

  private def addLastMessages(
    connection: Connection,
    conversationsResult: AppResult[List[ConversationSummary]]
  ): IO[AppResult[List[ConversationSummary]]] =
    conversationsResult match
      case Left(error) => IO.pure(Left(error))
      case Right(conversations) =>
        conversations.foldRight(IO.pure(Right(Nil): AppResult[List[ConversationSummary]])) { (conversation, acc) =>
          for
            lastMessageResult <- ConversationMessagesTable.loadLastMessage(connection, conversation.id)
            tailResult <- acc
          yield
            for
              lastMessage <- lastMessageResult
              tail <- tailResult
            yield conversation.copy(lastMessage = lastMessage) :: tail
        }
