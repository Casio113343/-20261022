package inspections.api.messages
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.{ApiTransaction, OptionalTokenApiMessage}
import cats.effect.IO
import inspections.api.requests.ListPublicInspectionSlotsRequest
import inspections.api.responses.ListPublicInspectionSlotsResponse
import inspections.tables.inspection_slots.InspectionSlotsTable
import listings.api.ListingsPublicApi
import shared.AppResult
import shared.AuthenticatedPrincipal

import java.sql.Connection

object ListPublicInspectionSlotsApiMessage
    extends OptionalTokenApiMessage[ListPublicInspectionSlotsRequest, ListPublicInspectionSlotsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(
    request: ListPublicInspectionSlotsRequest,
    principal: Option[AuthenticatedPrincipal],
    connection: Connection
  ): IO[AppResult[ListPublicInspectionSlotsResponse]] =
    ListingsPublicApi.findActiveConversationListing(connection, request.listingId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(None) => IO.pure(Right(Nil))
      case Right(Some(_)) =>
        InspectionSlotsTable.listPublicSlots(connection, request.listingId, principal.map(_.userId))
    }
      .map(_.map(ListPublicInspectionSlotsResponse.apply))
