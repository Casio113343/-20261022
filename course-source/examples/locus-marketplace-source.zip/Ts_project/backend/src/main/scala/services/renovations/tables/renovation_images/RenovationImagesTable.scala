package renovations.tables.renovation_images

import cats.effect.IO
import listings.model.ListingId
import media.model.PropertyImageId
import renovations.model.{ListingRenovation, RenovationStatus}
import shared.{AppError, AppResult, DbCodec, JdbcResources, SchemaSupport}

import java.sql.{Connection, Timestamp}
import java.time.Instant
import java.util.UUID

private[renovations] object RenovationImagesTable:

  final case class ClaimedJob(
    listingId: ListingId,
    originalImageId: PropertyImageId,
    originalObjectKey: String,
    originalContentType: String
  )

  final case class ReconcileResult(
    removedObjectKeys: List[String]
  )

  private val createSql: String =
    """
      |create table if not exists renovation_images (
      |  original_image_id uuid primary key references property_images(id) on delete cascade,
      |  listing_id uuid not null references listings(id) on delete cascade,
      |  status varchar(16) not null check (status in ('pending', 'processing', 'completed', 'failed')),
      |  renovated_object_key text unique,
      |  renovated_content_type varchar(160),
      |  error_message varchar(500),
      |  attempts int not null default 0,
      |  created_at timestamptz not null,
      |  updated_at timestamptz not null
      |);
      |create index if not exists renovation_images_listing_idx
      |on renovation_images(listing_id, status, updated_at);
      |""".stripMargin

  private val resetInterruptedSql: String =
    """
      |update renovation_images
      |set status = 'pending',
      |    error_message = null,
      |    updated_at = now()
      |where status = 'processing';
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql, resetInterruptedSql))

  def reconcile(
    connection: Connection,
    listingId: ListingId,
    eligibleImageIds: List[PropertyImageId],
    retryFailed: Boolean,
    timestamp: Instant
  ): IO[AppResult[ReconcileResult]] =
    for
      removedKeys <- removeIneligible(connection, listingId, eligibleImageIds)
      _ <- eligibleImageIds.foldLeft(IO.unit) { (program, imageId) =>
        program *> upsertPending(connection, listingId, imageId, retryFailed, timestamp)
      }
    yield Right(ReconcileResult(removedKeys))

  def removeAll(connection: Connection, listingId: ListingId): IO[AppResult[ReconcileResult]] =
    removeIneligible(connection, listingId, Nil).map(keys => Right(ReconcileResult(keys)))

  def prune(
    connection: Connection,
    listingId: ListingId,
    eligibleImageIds: List[PropertyImageId]
  ): IO[AppResult[ReconcileResult]] =
    removeIneligible(connection, listingId, eligibleImageIds).map(keys => Right(ReconcileResult(keys)))

  private def removeIneligibleSql(imageCount: Int): String =
    val condition =
      if imageCount == 0 then ""
      else s" and original_image_id not in (${List.fill(imageCount)("?").mkString(", ")})"

    s"""
       |delete from renovation_images
       |where listing_id = ?
       |$condition
       |returning renovated_object_key
       |""".stripMargin

  private def removeIneligible(
    connection: Connection,
    listingId: ListingId,
    eligibleImageIds: List[PropertyImageId]
  ): IO[List[String]] =
    JdbcResources.select(connection, removeIneligibleSql(eligibleImageIds.size)) { statement =>
      statement.setObject(1, listingId.value)
      eligibleImageIds.zipWithIndex.foreach { case (imageId, index) =>
        statement.setObject(index + 2, imageId.value)
      }
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .flatMap(_ => Option(resultSet.getString("renovated_object_key")))
        .toList
    }

  private val upsertPendingSql: String =
    """
      |insert into renovation_images (
      |  original_image_id, listing_id, status, created_at, updated_at
      |)
      |values (?, ?, 'pending', ?, ?)
      |on conflict (original_image_id) do nothing
      |""".stripMargin

  private val retryFailedSql: String =
    """
      |insert into renovation_images (
      |  original_image_id, listing_id, status, created_at, updated_at
      |)
      |values (?, ?, 'pending', ?, ?)
      |on conflict (original_image_id) do update
      |set status = case when renovation_images.status = 'failed' then 'pending' else renovation_images.status end,
      |    error_message = case when renovation_images.status = 'failed' then null else renovation_images.error_message end,
      |    updated_at = case when renovation_images.status = 'failed' then excluded.updated_at else renovation_images.updated_at end
      |""".stripMargin

  private def upsertPending(
    connection: Connection,
    listingId: ListingId,
    imageId: PropertyImageId,
    retryFailed: Boolean,
    timestamp: Instant
  ): IO[Unit] =
    val sql = if retryFailed then retryFailedSql else upsertPendingSql

    JdbcResources.update(connection, sql) { statement =>
      statement.setObject(1, imageId.value)
      statement.setObject(2, listingId.value)
      statement.setTimestamp(3, Timestamp.from(timestamp))
      statement.setTimestamp(4, Timestamp.from(timestamp))
      statement.executeUpdate()
    }.void

  private val pendingImageIdsSql: String =
    """
      |select original_image_id
      |from renovation_images
      |where listing_id = ? and status = 'pending'
      |order by created_at, original_image_id
      |""".stripMargin

  def pendingImageIds(connection: Connection, listingId: ListingId): IO[List[PropertyImageId]] =
    JdbcResources.select(connection, pendingImageIdsSql) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => PropertyImageId(resultSet.getObject("original_image_id", classOf[UUID])))
        .toList
    }

  private val pendingListingIdsSql: String =
    """
      |select distinct listing_id
      |from renovation_images
      |where status = 'pending'
      |order by listing_id
      |""".stripMargin

  def pendingListingIds(connection: Connection): IO[List[ListingId]] =
    JdbcResources.select(connection, pendingListingIdsSql)(_ => ()) { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => ListingId(resultSet.getObject("listing_id", classOf[UUID])))
        .toList
    }

  private val claimSql: String =
    """
      |update renovation_images r
      |set status = 'processing',
      |    attempts = attempts + 1,
      |    error_message = null,
      |    updated_at = ?
      |from property_images p
      |where r.original_image_id = ?
      |  and r.original_image_id = p.id
      |  and r.status = 'pending'
      |  and p.is_floor_plan = false
      |returning r.listing_id, r.original_image_id, p.object_key, p.content_type
      |""".stripMargin

  def claim(
    connection: Connection,
    imageId: PropertyImageId,
    timestamp: Instant
  ): IO[AppResult[Option[ClaimedJob]]] =
    JdbcResources.select(connection, claimSql) { statement =>
      statement.setTimestamp(1, Timestamp.from(timestamp))
      statement.setObject(2, imageId.value)
    } { resultSet =>
      if resultSet.next() then
        for
          objectKey <- DbCodec.requiredText(resultSet, "object_key")
          contentType <- DbCodec.requiredText(resultSet, "content_type")
          listingUuid <- DbCodec.requiredUuid(resultSet, "listing_id")
          imageUuid <- DbCodec.requiredUuid(resultSet, "original_image_id")
        yield Some(ClaimedJob(
          ListingId(listingUuid),
          PropertyImageId(imageUuid),
          objectKey,
          contentType
        ))
      else Right(None)
    }

  private val completeSql: String =
    """
      |update renovation_images
      |set status = 'completed',
      |    renovated_object_key = ?,
      |    renovated_content_type = ?,
      |    error_message = null,
      |    updated_at = ?
      |where original_image_id = ? and status = 'processing'
      |""".stripMargin

  def complete(
    connection: Connection,
    imageId: PropertyImageId,
    objectKey: String,
    contentType: String,
    timestamp: Instant
  ): IO[Int] =
    JdbcResources.update(connection, completeSql) { statement =>
      statement.setString(1, objectKey)
      statement.setString(2, contentType)
      statement.setTimestamp(3, Timestamp.from(timestamp))
      statement.setObject(4, imageId.value)
      statement.executeUpdate()
    }

  private val failSql: String =
    """
      |update renovation_images
      |set status = 'failed',
      |    error_message = ?,
      |    updated_at = ?
      |where original_image_id = ? and status = 'processing'
      |""".stripMargin

  def fail(
    connection: Connection,
    imageId: PropertyImageId,
    message: String,
    timestamp: Instant
  ): IO[Unit] =
    JdbcResources.update(connection, failSql) { statement =>
      statement.setString(1, message.take(500))
      statement.setTimestamp(2, Timestamp.from(timestamp))
      statement.setObject(3, imageId.value)
      statement.executeUpdate()
    }.void

  private val listSql: String =
    """
      |select original_image_id, status, renovated_object_key, error_message
      |from renovation_images
      |where listing_id = ?
      |order by created_at, original_image_id
      |""".stripMargin

  def list(
    connection: Connection,
    listingId: ListingId,
    resolveUrl: String => String
  ): IO[AppResult[List[ListingRenovation]]] =
    JdbcResources.select(connection, listSql) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ =>
          for
            statusText <- DbCodec.requiredText(resultSet, "status")
            status <- DbCodec.decodeDatabaseValue(RenovationStatus.fromString(statusText), "renovation status")
          yield ListingRenovation(
            originalImageId = PropertyImageId(resultSet.getObject("original_image_id", classOf[UUID])),
            status = status,
            renovatedImageUrl = Option(resultSet.getString("renovated_object_key")).map(resolveUrl),
            errorMessage = Option(resultSet.getString("error_message"))
          )
        )
        .foldRight(Right(Nil): AppResult[List[ListingRenovation]])((next, acc) =>
          for
            head <- next
            tail <- acc
          yield head :: tail
        )
    }
