package identity.model

final case class RegistrationDetails(
  fullName: String,
  email: String,
  password: String,
  role: UserRole,
  agencyName: Option[String],
  phone: Option[String]
)
