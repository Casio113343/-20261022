package messaging.api.messages
import identity.model.*
import listings.model.*
import messaging.model.*


import shared.{ApiTransaction, MultipartDecoders, MultipartWithTokenMessage}
import cats.effect.IO
import shared.{AppError, AppResult, RuntimeValues}
import shared.AuthenticatedPrincipal
import messaging.api.requests.UploadMessageAttachmentRequest
import messaging.api.responses.UploadMessageAttachmentResponse
import messaging.tables.message_attachments.MessageAttachmentsTable
import org.http4s.multipart.Multipart
import shared.ListingMediaStorage

import java.sql.Connection

final case class UploadMessageAttachmentApiMessage(storage: ListingMediaStorage)
    extends MultipartWithTokenMessage[UploadMessageAttachmentRequest, UploadMessageAttachmentResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def decodeMultipart(multipart: Multipart[IO]): IO[AppResult[UploadMessageAttachmentRequest]] =
    MultipartDecoders
      .result(
        MultipartDecoders.fileUpload(
          multipart,
          "Attachment upload must include a file field",
          "Attachment upload must include a filename"
        )
      )
      .map(_.map { case (fileName, contentType, bytes) => UploadMessageAttachmentRequest(fileName, contentType, bytes) })

  override def plan(
    request: UploadMessageAttachmentRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[UploadMessageAttachmentResponse]] =
    validateUpload(request.fileName, request.contentType, request.bytes) match
      case Left(error) => IO.pure(Left(error))
      case Right((safeFileName, safeContentType)) =>
        for
          attachmentId <- RuntimeValues.uuid.map(MessageAttachmentId(_))
          now <- RuntimeValues.now
          objectKey = s"message-attachments/${principal.userId.value}/${attachmentId.value}/$safeFileName"
          _ <- storage.uploadBytes(objectKey, request.bytes, safeContentType)
          inserted <- MessageAttachmentsTable.insertUploadedAttachment(
            connection = connection,
            attachmentId = attachmentId,
            uploadedBy = principal.userId,
            bucketName = storage.config.bucketName,
            objectKey = objectKey,
            fileName = safeFileName,
            mimeType = safeContentType,
            sizeBytes = request.bytes.length.toLong,
            createdAt = now,
            storage = storage
          )
        yield inserted.map(UploadMessageAttachmentResponse.apply)

  private val MaxAttachmentSizeBytes = 16L * 1024L * 1024L

  private def validateUpload(
    fileName: String,
    contentType: String,
    bytes: Array[Byte]
  ): AppResult[(String, String)] =
    val safeFileName = sanitizeFileName(fileName)
    val sizeBytes = bytes.length.toLong
    val safeContentType = inferSafeContentType(bytes, contentType)

    if safeFileName.isEmpty then Left(AppError.Validation("Attachment upload must include a filename"))
    else if sizeBytes <= 0 then Left(AppError.Validation("Attachment upload is empty"))
    else if sizeBytes > MaxAttachmentSizeBytes then Left(AppError.Validation("Attachment exceeds the 16 MB limit"))
    else Right((safeFileName, safeContentType))

  private def sanitizeFileName(fileName: String): String =
    fileName.trim
      .replaceAll("[^A-Za-z0-9._-]", "_")
      .replaceAll("_+", "_")
      .take(120)

  private def inferSafeContentType(bytes: Array[Byte], reportedContentType: String): String =
    inferImageContentType(bytes)
      .orElse(inferDocumentContentType(bytes, reportedContentType))
      .getOrElse("application/octet-stream")

  private def inferDocumentContentType(bytes: Array[Byte], reportedContentType: String): Option[String] =
    val normalized = reportedContentType.trim.toLowerCase

    if startsWith(bytes, 0x25, 0x50, 0x44, 0x46) then Some("application/pdf")
    else if normalized == "text/plain" && bytes.forall(byte => byte == 9 || byte == 10 || byte == 13 || (byte >= 32 && byte != 127)) then Some("text/plain")
    else None

  private def inferImageContentType(bytes: Array[Byte]): Option[String] =
    if startsWith(bytes, 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a) then Some("image/png")
    else if startsWith(bytes, 0xff, 0xd8, 0xff) then Some("image/jpeg")
    else if startsWith(bytes, 0x47, 0x49, 0x46, 0x38) then Some("image/gif")
    else if containsAsciiAt(bytes, 0, "RIFF") && containsAsciiAt(bytes, 8, "WEBP") then Some("image/webp")
    else if containsAsciiAt(bytes, 4, "ftypavif") then Some("image/avif")
    else None

  private def startsWith(bytes: Array[Byte], prefix: Int*): Boolean =
    bytes.length >= prefix.length && prefix.zipWithIndex.forall { case (value, index) =>
      (bytes(index) & 0xff) == value
    }

  private def containsAsciiAt(bytes: Array[Byte], offset: Int, value: String): Boolean =
    bytes.length >= offset + value.length &&
      value.zipWithIndex.forall { case (character, index) =>
        bytes(offset + index) == character.toByte
      }
