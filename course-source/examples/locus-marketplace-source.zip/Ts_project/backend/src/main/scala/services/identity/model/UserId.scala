package identity.model


import io.circe.{Decoder, Encoder}

import java.util.UUID
import scala.util.Try

final case class UserId(value: UUID)

object UserId:
  given Encoder[UserId] = Encoder.encodeString.contramap(_.value.toString)
  given Decoder[UserId] = Decoder.decodeString.emap(parseUuid(_, "userId").map(UserId(_)))

  private def parseUuid(value: String, label: String): Either[String, UUID] =
    Try(UUID.fromString(value)).toEither.left.map(_ => s"Invalid $label")
