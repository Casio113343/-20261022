package shared

import cats.effect.IO

import java.time.Instant
import java.util.UUID

object RuntimeValues:

  val now: IO[Instant] =
    IO.realTimeInstant

  val uuid: IO[UUID] =
    IO.randomUUID
