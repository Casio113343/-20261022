package media.routes
import identity.model.*
import listings.model.*
import media.model.*


import shared.ApiServiceMessages
import media.api.messages.{DeleteManagedListingImageApiMessage, UploadManagedListingImageApiMessage}
import shared.ListingMediaStorage

object MediaRoutes:

  def apiMessages(storage: ListingMediaStorage): ApiServiceMessages =
    ApiServiceMessages(
      "media",
      List(
        UploadManagedListingImageApiMessage(storage),
        DeleteManagedListingImageApiMessage(storage)
      )
    )
