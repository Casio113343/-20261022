package analytics.api.requests

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import analytics.model.ListingAnalyticsDateRange
import listings.model.ListingId

final case class GetManagedListingAnalyticsRequest(
  listingId: ListingId,
  range: ListingAnalyticsDateRange = ListingAnalyticsDateRange.Last30Days
)

object GetManagedListingAnalyticsRequest:
  given Encoder[GetManagedListingAnalyticsRequest] = deriveEncoder[GetManagedListingAnalyticsRequest]
  given Decoder[GetManagedListingAnalyticsRequest] = deriveDecoder[GetManagedListingAnalyticsRequest]
