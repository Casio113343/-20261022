package shared

import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class ErrorResponse(
  error: String
)

object ErrorResponse:
  given Encoder[ErrorResponse] = deriveEncoder[ErrorResponse]
