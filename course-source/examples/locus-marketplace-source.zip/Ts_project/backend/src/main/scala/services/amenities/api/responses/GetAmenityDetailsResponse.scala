package amenities.api.responses

import amenities.model.{AmenityDetails, TravelSummary}
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class GetAmenityDetailsResponse(
  details: AmenityDetails,
  routes: List[TravelSummary]
)

object GetAmenityDetailsResponse:
  given Encoder[GetAmenityDetailsResponse] = deriveEncoder[GetAmenityDetailsResponse]
