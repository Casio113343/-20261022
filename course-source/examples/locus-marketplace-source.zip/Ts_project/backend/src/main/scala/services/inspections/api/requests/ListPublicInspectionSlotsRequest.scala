package inspections.api.requests
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.ListingId
import shared.TimeCodecs.given

final case class ListPublicInspectionSlotsRequest(listingId: ListingId)

object ListPublicInspectionSlotsRequest:
  given Decoder[ListPublicInspectionSlotsRequest] = deriveDecoder[ListPublicInspectionSlotsRequest]
