package listings.tables.listing_records
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import shared.*

import java.sql.Connection
import java.sql.Timestamp

private[listings] object AgentListingsTable:

  private def listAgentListingsSql(whereClause: String): String =
    s"""
       |select l.id, l.title, l.description, l.transaction_type, l.property_type, l.house_subtype, l.apartment_subtype, l.price, l.address_line, l.suburb,
       |       l.state, l.postcode, l.bedrooms, l.bathrooms, l.car_spaces, l.land_size, l.building_size,
       |       l.listing_status, l.agent_id, l.created_at, l.updated_at
       |from listings l
       |$whereClause
       |${ListingTableSupport.orderByClause(ListingSort.Newest)}
       |""".stripMargin

  def listAgentListings(
    connection: Connection,
    agentId: UserId
  ): IO[AppResult[List[ListingTableSupport.ListingSummaryRecord]]] =
    val searchSql = ListingTableSupport.listingSearchSql(
      SearchListingsQuery(
        query = None,
        transactionType = None,
        listingStatuses = Nil,
        propertyTypes = Nil,
        houseSubtypes = Nil,
        apartmentSubtypes = Nil,
        minPrice = None,
        maxPrice = None,
        minFloorSize = None,
        maxFloorSize = None,
        minLandSize = None,
        maxLandSize = None,
        bedrooms = None,
        bathrooms = None,
        carSpaces = None,
        sort = ListingSort.Newest,
        limit = 100,
      ),
      publicOnly = false,
      agentId = Some(agentId)
    )

    JdbcResources.select(connection, listAgentListingsSql(searchSql.whereClause)) { statement =>
        ListingTableSupport.bindParams(statement, searchSql.params)
    }(ListingTableSupport.readListingSummaries)

  def insertListing(
    connection: Connection,
    listingId: ListingId,
    agentId: UserId,
    request: ListingWrite,
    timestamp: java.time.Instant
  ): IO[Unit] =
    ListingTableSupport.insertListing(connection, listingId, agentId, request, timestamp)

  private val updateListingSql: String =
    """
      |update listings
      |set title = ?, description = ?, transaction_type = ?, property_type = ?, house_subtype = ?, apartment_subtype = ?, price = ?, address_line = ?, suburb = ?, state = ?,
      |    postcode = ?, bedrooms = ?, bathrooms = ?, car_spaces = ?, land_size = ?, building_size = ?, listing_status = ?, renovate_with_ai = ?, faqs = ?::jsonb, updated_at = ?
      |where id = ? and agent_id = ?
      |""".stripMargin

  def updateListing(
    connection: Connection,
    agentId: UserId,
    listingId: ListingId,
    request: ListingWrite,
    updatedAt: java.time.Instant
  ): IO[Int] =
    JdbcResources.update(connection, updateListingSql) { statement =>
        statement.setString(1, request.addressLine.trim)
        statement.setString(2, request.description.trim)
        statement.setString(3, TransactionType.toString(request.transactionType))
        statement.setString(4, PropertyType.toString(request.propertyType))
        ListingTableSupport.setOptionalText(statement, 5, request.houseSubtypeOption.map(HouseSubtype.toString))
        ListingTableSupport.setOptionalText(statement, 6, request.apartmentSubtypeOption.map(ApartmentSubtype.toString))
        statement.setInt(7, request.price)
        statement.setString(8, request.addressLine.trim)
        statement.setString(9, request.suburb.trim)
        statement.setString(10, request.state.trim.toUpperCase)
        statement.setString(11, request.postcode.trim)
        statement.setInt(12, request.bedrooms)
        statement.setInt(13, request.bathrooms)
        statement.setInt(14, request.carSpaces)
        ListingTableSupport.setOptionalInt(statement, 15, request.landSize)
        ListingTableSupport.setOptionalInt(statement, 16, request.buildingSize)
        statement.setString(17, ListingStatus.toString(request.listingStatus))
        statement.setBoolean(18, request.renovateWithAi)
        DbCodec.setJson(statement, 19, request.faqs)
        statement.setTimestamp(20, Timestamp.from(updatedAt))
        statement.setObject(21, listingId.value)
        statement.setObject(22, agentId.value)
        statement.executeUpdate()
    }

  private val archiveListingSql: String =
    """
      |update listings
      |set listing_status = 'archived', updated_at = ?
      |where id = ? and agent_id = ?
      |""".stripMargin

  def archiveListing(
    connection: Connection,
    agentId: UserId,
    listingId: ListingId,
    updatedAt: java.time.Instant
  ): IO[Int] =
    JdbcResources.update(connection, archiveListingSql) { statement =>
        statement.setTimestamp(1, Timestamp.from(updatedAt))
        statement.setObject(2, listingId.value)
        statement.setObject(3, agentId.value)
        statement.executeUpdate()
    }
