package shared

import cats.effect.{IO, Resource}

import java.sql.{Connection, PreparedStatement, ResultSet, Statement}

object JdbcResources:

  def preparedStatement(connection: Connection, sql: String): Resource[IO, PreparedStatement] =
    Resource.fromAutoCloseable(IO.blocking(connection.prepareStatement(sql)))

  def statement(connection: Connection): Resource[IO, Statement] =
    Resource.fromAutoCloseable(IO.blocking(connection.createStatement()))

  def query(statement: PreparedStatement): Resource[IO, ResultSet] =
    Resource.fromAutoCloseable(IO.blocking(statement.executeQuery()))

  def update[A](connection: Connection, sql: String)(execute: PreparedStatement => A): IO[A] =
    preparedStatement(connection, sql).use(statement => IO.blocking(execute(statement)))

  def select[A](
    connection: Connection,
    sql: String
  )(bind: PreparedStatement => Unit)(read: ResultSet => A): IO[A] =
    preparedStatement(connection, sql).use { statement =>
      IO.blocking(bind(statement)) *> query(statement).use(resultSet => IO.blocking(read(resultSet)))
    }
