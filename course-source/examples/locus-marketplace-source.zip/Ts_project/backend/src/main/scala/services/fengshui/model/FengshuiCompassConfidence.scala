package fengshui.model


import io.circe.{Decoder, Encoder}

enum FengshuiCompassConfidence:
  case High, Moderate, Low

object FengshuiCompassConfidence:
  def toString(value: FengshuiCompassConfidence): String =
    value match
      case FengshuiCompassConfidence.High => "High"
      case FengshuiCompassConfidence.Moderate => "Moderate"
      case FengshuiCompassConfidence.Low => "Low"

  def fromString(value: String): Either[String, FengshuiCompassConfidence] =
    value match
      case "High" => Right(FengshuiCompassConfidence.High)
      case "Moderate" => Right(FengshuiCompassConfidence.Moderate)
      case "Low" => Right(FengshuiCompassConfidence.Low)
      case _ => Left("Unsupported compass confidence")

  given Encoder[FengshuiCompassConfidence] = Encoder.encodeString.contramap(toString)
  given Decoder[FengshuiCompassConfidence] = Decoder.decodeString.emap(fromString)
