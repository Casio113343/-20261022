package identity.api.responses
import identity.model.*


import io.circe.Encoder
import identity.model.User

final case class RegisterIdentityResponse(
  user: User
)

object RegisterIdentityResponse:
  given Encoder[RegisterIdentityResponse] =
    Encoder.forProduct1("user")(_.user)
