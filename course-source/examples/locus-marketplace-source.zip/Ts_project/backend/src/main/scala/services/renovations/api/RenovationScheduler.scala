package renovations.api

import cats.effect.IO
import listings.model.ListingId

trait RenovationScheduler:
  def schedule(listingId: ListingId): IO[Unit]

  def resumePending: IO[Unit]
