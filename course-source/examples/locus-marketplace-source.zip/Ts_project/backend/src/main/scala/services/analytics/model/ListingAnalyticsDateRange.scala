package analytics.model

import io.circe.{Decoder, Encoder}

enum ListingAnalyticsDateRange:
  case Last7Days
  case Last30Days
  case Last90Days
  case AllTime

object ListingAnalyticsDateRange:

  def toString(value: ListingAnalyticsDateRange): String =
    value match
      case ListingAnalyticsDateRange.Last7Days => "7d"
      case ListingAnalyticsDateRange.Last30Days => "30d"
      case ListingAnalyticsDateRange.Last90Days => "90d"
      case ListingAnalyticsDateRange.AllTime => "all"

  def fromString(value: String): Either[String, ListingAnalyticsDateRange] =
    value.trim.toLowerCase match
      case "7d" => Right(ListingAnalyticsDateRange.Last7Days)
      case "30d" => Right(ListingAnalyticsDateRange.Last30Days)
      case "90d" => Right(ListingAnalyticsDateRange.Last90Days)
      case "all" => Right(ListingAnalyticsDateRange.AllTime)
      case other => Left(s"Unknown analytics date range: $other")

  def days(value: ListingAnalyticsDateRange): Option[Int] =
    value match
      case ListingAnalyticsDateRange.Last7Days => Some(7)
      case ListingAnalyticsDateRange.Last30Days => Some(30)
      case ListingAnalyticsDateRange.Last90Days => Some(90)
      case ListingAnalyticsDateRange.AllTime => None

  given Encoder[ListingAnalyticsDateRange] =
    Encoder.encodeString.contramap(toString)

  given Decoder[ListingAnalyticsDateRange] =
    Decoder.decodeString.emap(fromString)
