package identity.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import shared.TimeCodecs

import java.time.Instant

import TimeCodecs.given

final case class User(
  id: UserId,
  fullName: String,
  email: String,
  role: UserRole,
  createdAt: Instant,
  avatarUrl: Option[String],
  agentProfile: Option[AgentProfile]
)

object User:
  given Encoder[User] = deriveEncoder[User]
  given Decoder[User] = deriveDecoder[User]
