package inspections.api.requests
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.ListingId
import shared.TimeCodecs.given

import java.time.Instant

final case class CreateInspectionSlotRequest(listingId: ListingId, startsAt: Instant, endsAt: Instant)

object CreateInspectionSlotRequest:
  given Decoder[CreateInspectionSlotRequest] = deriveDecoder[CreateInspectionSlotRequest]
