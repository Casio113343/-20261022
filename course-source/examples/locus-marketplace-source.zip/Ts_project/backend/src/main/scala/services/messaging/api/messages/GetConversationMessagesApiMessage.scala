package messaging.api.messages
import identity.model.*
import listings.model.*
import messaging.model.*


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.effect.IO
import shared.AppResult
import shared.AuthenticatedPrincipal
import messaging.api.requests.GetConversationMessagesRequest
import messaging.api.responses.GetConversationMessagesResponse
import messaging.application.MessagingApplication
import shared.ListingMediaStorage

import java.sql.Connection

final case class GetConversationMessagesApiMessage(storage: ListingMediaStorage)
    extends ApiWithTokenMessage[GetConversationMessagesRequest, GetConversationMessagesResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: GetConversationMessagesRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[GetConversationMessagesResponse]] =
    MessagingApplication
      .listMessagesEnsuringIntroduction(connection, request.conversationId, principal.userId, storage)
      .map(_.map(GetConversationMessagesResponse.apply))
