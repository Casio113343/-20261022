package identity.api.responses
import identity.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import identity.model.User

final case class UploadProfilePictureResponse(
  user: User
)

object UploadProfilePictureResponse:
  given Encoder[UploadProfilePictureResponse] = deriveEncoder[UploadProfilePictureResponse]
