package listings.application
import identity.model.*
import listings.model.*
import media.model.*


import cats.data.EitherT
import cats.effect.IO
import database.TransactionSuccess
import identity.api.IdentityPublicApi
import listings.tables.listing_records.{AgentListingsTable, ListingQueriesTable}
import listings.tables.listing_records.ListingTableSupport.{ListingDetailRecord, ListingSummaryRecord}
import shared.*
import media.api.MediaPublicApi
import renovations.api.{RenovationScheduler, RenovationsPublicApi}
import shared.ListingMediaStorage

import java.sql.Connection

private[listings] object ListingApplication:

  private type AppEitherT[A] = EitherT[IO, AppError, A]

  private def liftApp[A](ioResult: IO[AppResult[A]]): AppEitherT[A] =
    EitherT(ioResult)

  private def liftValidation[A](result: AppResult[A]): AppEitherT[A] =
    EitherT.fromEither[IO](result)

  private def requireValue[A](value: Option[A], message: => String): AppEitherT[A] =
    EitherT.fromOption[IO](value, AppError.Unexpected(message))

  def search(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    query: SearchListingsQuery
  ): IO[AppResult[ListingSearchResult]] =
    ListingQueriesTable.searchListings(connection, query).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right((records, total)) =>
        enrichSummaries(connection, listingMediaStorage, records).map(
          _.map(listings => ListingSearchResult(listings = listings, total = total))
        )
    }

  def findPublicDetail(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    listingId: ListingId
  ): IO[AppResult[Option[ListingDetail]]] =
    ListingQueriesTable.findPublicListingDetail(connection, listingId).flatMap(enrichDetailOption(connection, listingMediaStorage))

  def findPublicSummaries(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    listingIds: List[ListingId]
  ): IO[AppResult[List[ListingSummary]]] =
    listingIds
      .foldLeft(IO.pure(Right(Nil): AppResult[List[ListingSummary]])) { (acc, listingId) =>
        for
          loaded <- acc
          next <- loaded match
            case Left(error) => IO.pure(Left(error))
            case Right(summaries) =>
              findPublicDetail(connection, listingMediaStorage, listingId).map(
                _.map(_.map(summaryFrom).fold(summaries)(summary => summaries :+ summary))
              )
        yield next
      }

  def findManagedDetail(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    listingId: ListingId,
    publicOnly: Boolean,
  ): IO[AppResult[Option[ListingDetail]]] =
    ListingQueriesTable.findListingDetail(connection, listingId, publicOnly).flatMap(enrichDetailOption(connection, listingMediaStorage))

  def listAgentListings(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    agentId: UserId
  ): IO[AppResult[List[ListingSummary]]] =
    AgentListingsTable.listAgentListings(connection, agentId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(records) => enrichSummaries(connection, listingMediaStorage, records)
    }

  def create(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    renovationScheduler: RenovationScheduler,
    agentId: UserId,
    request: ListingWrite,
  ): IO[AppResult[TransactionSuccess[ListingDetail]]] =
    (
      for
        _ <- liftValidation(ListingValidation.validateListingRequest(request))
        listingId <- EitherT.right(RuntimeValues.uuid.map(ListingId(_)))
        timestamp <- EitherT.right(RuntimeValues.now)
        _ <- EitherT.right[AppError](AgentListingsTable.insertListing(connection, listingId, agentId, request, timestamp))
        _ <- liftApp(MediaPublicApi.syncListingImages(connection, listingId, agentId, request.images.map(mediaImageInputFrom)))
        maybeListing <- liftApp(
          findManagedDetail(connection, listingMediaStorage, listingId, publicOnly = false)
        )
        listing <- requireValue(maybeListing, "Created listing could not be loaded")
        renovationImages <- liftApp(MediaPublicApi.listListingImages(connection, listingMediaStorage, listingId))
        renovationResult <- liftApp(
          RenovationsPublicApi.reconcile(
            connection,
            listingId,
            renovationImages,
            enabled = request.renovateWithAi,
            retryFailed = false
          )
        )
      yield TransactionSuccess(
        value = listing,
        afterCommit =
          deleteObjects(listingMediaStorage, renovationResult.removedObjectKeys) *>
            Option.when(request.renovateWithAi)(renovationScheduler.schedule(listingId)).getOrElse(IO.unit)
      )
    ).value

  def update(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    renovationScheduler: RenovationScheduler,
    agentId: UserId,
    listingId: ListingId,
    request: ListingWrite,
  ): IO[AppResult[TransactionSuccess[ListingDetail]]] =
    (
      for
        _ <- liftValidation(ListingValidation.validateListingRequest(request))
        existingListingOption <- liftApp(
          findManagedDetail(connection, listingMediaStorage, listingId, publicOnly = false)
        )
        existingListing <- EitherT.fromOption[IO](existingListingOption, AppError.NotFound("Listing not found"))
        eligibleRequestImageIds = request.images.filterNot(_.isFloorPlan).map(image => PropertyImageId(image.id.value))
        prunedRenovations <- liftApp(
          RenovationsPublicApi.removeIneligibleForRequest(connection, listingId, eligibleRequestImageIds)
        )
        updatedAt <- EitherT.right(RuntimeValues.now)
        rowsUpdated <- EitherT.right[AppError](AgentListingsTable.updateListing(connection, agentId, listingId, request, updatedAt))
        _ <- EitherT.cond[IO](rowsUpdated > 0, (), AppError.NotFound("Listing not found"))
        removedImages <- liftApp(MediaPublicApi.syncListingImages(connection, listingId, agentId, request.images.map(mediaImageInputFrom)))
        maybeListing <- liftApp(
          findManagedDetail(connection, listingMediaStorage, listingId, publicOnly = false)
        )
        listing <- requireValue(maybeListing, "Updated listing could not be loaded")
        renovationImages <- liftApp(MediaPublicApi.listListingImages(connection, listingMediaStorage, listingId))
        renovationResult <- liftApp(
          RenovationsPublicApi.reconcile(
            connection,
            listingId,
            renovationImages,
            enabled = request.renovateWithAi,
            retryFailed = !existingListing.renovateWithAi && request.renovateWithAi
          )
        )
        removedObjectKeys =
          prunedRenovations.removedObjectKeys ::: renovationResult.removedObjectKeys ::: removedImages.map(_.objectKey)
      yield TransactionSuccess(
        value = listing,
        afterCommit =
          deleteObjects(listingMediaStorage, removedObjectKeys) *>
            Option.when(request.renovateWithAi)(renovationScheduler.schedule(listingId)).getOrElse(IO.unit)
      )
    ).value

  private def deleteObjects(storage: ListingMediaStorage, objectKeys: List[String]): IO[Unit] =
    objectKeys.distinct.foldLeft(IO.unit)((program, objectKey) => program *> storage.deleteObject(objectKey))

  private def enrichDetailOption(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage
  )(detailRecordResult: AppResult[Option[ListingDetailRecord]]): IO[AppResult[Option[ListingDetail]]] =
    detailRecordResult match
      case Left(error) => IO.pure(Left(error))
      case Right(None) => IO.pure(Right(None))
      case Right(Some(record)) => enrichDetail(connection, listingMediaStorage, record).map(_.map(Some(_)))

  private def enrichDetail(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    record: ListingDetailRecord
  ): IO[AppResult[ListingDetail]] =
    for
      agentResult <- IdentityPublicApi.loadAgentSummaryMap(connection, listingMediaStorage, List(record.agentId))
      imagesResult <- MediaPublicApi.listListingImages(connection, listingMediaStorage, record.id)
    yield
      for
        agents <- agentResult
        agent <- agents.get(record.agentId).toRight(AppError.NotFound("Listing agent not found"))
        images <- imagesResult
      yield detailFrom(record, agent, images)

  private def enrichSummaries(
    connection: Connection,
    listingMediaStorage: ListingMediaStorage,
    records: List[ListingSummaryRecord]
  ): IO[AppResult[List[ListingSummary]]] =
    IdentityPublicApi.loadAgentSummaryMap(connection, listingMediaStorage, records.map(_.agentId)).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(agentMap) =>
        records.foldLeft(IO.pure(Right(Nil): AppResult[List[ListingSummary]])) { (acc, record) =>
          for
            loaded <- acc
            next <- loaded match
              case Left(error) => IO.pure(Left(error))
              case Right(items) =>
                MediaPublicApi.listListingImages(connection, listingMediaStorage, record.id).map(
                  _.flatMap(images =>
                    agentMap
                      .get(record.agentId)
                      .toRight(AppError.NotFound("Listing agent not found"))
                      .map(agent => items :+ summaryFrom(record, agent, images))
                  )
                )
          yield next
        }
    }

  private def mediaImageInputFrom(image: ListingImageInput): PropertyImageInput =
    PropertyImageInput(
      id = PropertyImageId(image.id.value),
      altText = image.altText,
      isFloorPlan = image.isFloorPlan
    )

  private def listingAgentFrom(agent: AgentSummary): ListingAgentSummary =
    ListingAgentSummary(
      id = agent.id.value.toString,
      fullName = agent.fullName,
      agencyName = agent.agencyName,
      phone = agent.phone,
      avatarUrl = agent.avatarUrl
    )

  private def listingImageFrom(image: PropertyImage): ListingImage =
    ListingImage(
      id = ListingImageId(image.id.value),
      listingId = image.listingId,
      url = image.url,
      objectKey = image.objectKey,
      contentType = image.contentType,
      sizeBytes = image.sizeBytes,
      sortOrder = image.sortOrder,
      altText = image.altText,
      isFloorPlan = image.isFloorPlan
    )

  private def summaryFrom(record: ListingSummaryRecord, agent: AgentSummary, images: List[PropertyImage]): ListingSummary =
    val listingImages = images.map(listingImageFrom)

    ListingSummary(
      id = record.id,
      title = record.title,
      transactionType = record.transactionType,
      propertyType = record.propertyType,
      houseSubtype = record.houseSubtype,
      apartmentSubtype = record.apartmentSubtype,
      price = record.price,
      addressLine = record.addressLine,
      suburb = record.suburb,
      state = record.state,
      postcode = record.postcode,
      bedrooms = record.bedrooms,
      bathrooms = record.bathrooms,
      carSpaces = record.carSpaces,
      landSize = record.landSize,
      buildingSize = record.buildingSize,
      listingStatus = record.listingStatus,
      headline = record.description.map(_.take(120)),
      primaryImageUrl = listingImages.headOption.map(_.url),
      previewImageUrls = listingImages.map(_.url),
      agent = listingAgentFrom(agent),
      createdAt = record.createdAt
    )

  private def detailFrom(record: ListingDetailRecord, agent: AgentSummary, images: List[PropertyImage]): ListingDetail =
    val listingImages = images.map(listingImageFrom)

    ListingDetail(
      id = record.id,
      title = record.title,
      description = record.description,
      transactionType = record.transactionType,
      propertyType = record.propertyType,
      houseSubtype = record.houseSubtype,
      apartmentSubtype = record.apartmentSubtype,
      price = record.price,
      addressLine = record.addressLine,
      suburb = record.suburb,
      state = record.state,
      postcode = record.postcode,
      bedrooms = record.bedrooms,
      bathrooms = record.bathrooms,
      carSpaces = record.carSpaces,
      landSize = record.landSize,
      buildingSize = record.buildingSize,
      listingStatus = record.listingStatus,
      renovateWithAi = record.renovateWithAi,
      agent = listingAgentFrom(agent),
      images = listingImages,
      faqs = record.faqs,
      createdAt = record.createdAt,
      updatedAt = record.updatedAt
    )

  private def summaryFrom(detail: ListingDetail): ListingSummary =
    ListingSummary(
      id = detail.id,
      title = detail.title,
      transactionType = detail.transactionType,
      propertyType = detail.propertyType,
      houseSubtype = detail.houseSubtype,
      apartmentSubtype = detail.apartmentSubtype,
      price = detail.price,
      addressLine = detail.addressLine,
      suburb = detail.suburb,
      state = detail.state,
      postcode = detail.postcode,
      bedrooms = detail.bedrooms,
      bathrooms = detail.bathrooms,
      carSpaces = detail.carSpaces,
      landSize = detail.landSize,
      buildingSize = detail.buildingSize,
      listingStatus = detail.listingStatus,
      headline = Some(detail.description.take(120)),
      primaryImageUrl = detail.images.headOption.map(_.url),
      previewImageUrls = detail.images.map(_.url),
      agent = detail.agent,
      createdAt = detail.createdAt
    )
