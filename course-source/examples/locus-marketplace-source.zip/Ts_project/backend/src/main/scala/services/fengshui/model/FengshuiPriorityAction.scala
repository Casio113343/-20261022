package fengshui.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class FengshuiPriorityAction(
  id: String,
  priority: FengshuiActionPriority,
  location: String,
  title: String,
  recommendation: String,
  reason: String
)

object FengshuiPriorityAction:
  given Encoder[FengshuiPriorityAction] = deriveEncoder[FengshuiPriorityAction]
  given Decoder[FengshuiPriorityAction] = deriveDecoder[FengshuiPriorityAction]
