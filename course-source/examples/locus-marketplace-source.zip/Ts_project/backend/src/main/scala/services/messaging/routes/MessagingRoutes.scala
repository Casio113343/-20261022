package messaging.routes
import identity.model.*
import listings.model.*
import messaging.model.*

import shared.ApiServiceMessages
import messaging.api.messages.*
import shared.ListingMediaStorage

object MessagingRoutes:

  def apiMessages(storage: ListingMediaStorage): ApiServiceMessages =
    ApiServiceMessages("messaging", List(
      StartConversationApiMessage(storage),
      ListConversationsApiMessage(storage),
      GetConversationMessagesApiMessage(storage),
      UploadMessageAttachmentApiMessage(storage)
    ))
