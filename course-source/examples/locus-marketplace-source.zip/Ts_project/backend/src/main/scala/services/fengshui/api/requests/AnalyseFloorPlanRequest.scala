package fengshui.api.requests
import identity.model.*
import listings.model.*
import media.model.*

import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.ListingId
import shared.TimeCodecs.given

final case class AnalyseFloorPlanRequest(listingId: ListingId)

object AnalyseFloorPlanRequest:
  given Decoder[AnalyseFloorPlanRequest] = deriveDecoder[AnalyseFloorPlanRequest]
