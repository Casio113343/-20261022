package favourites.api.responses
import identity.model.*
import listings.model.*

import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import listings.model.ListingSummary

final case class ListFavouriteListingsResponse(
  listings: List[ListingSummary]
)

object ListFavouriteListingsResponse:
  given Encoder[ListFavouriteListingsResponse] = deriveEncoder[ListFavouriteListingsResponse]
