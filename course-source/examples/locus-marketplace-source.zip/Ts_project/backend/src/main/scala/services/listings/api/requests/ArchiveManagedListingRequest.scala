package listings.api.requests
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.ListingId

final case class ArchiveManagedListingRequest(
  listingId: ListingId
)

object ArchiveManagedListingRequest:
  given Decoder[ArchiveManagedListingRequest] = deriveDecoder[ArchiveManagedListingRequest]
