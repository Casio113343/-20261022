package identity.api.messages
import identity.model.*


import shared.{AfterCommitMultipartApiMessage, MultipartDecoders, SessionCreatedResponse}
import cats.data.EitherT
import cats.effect.IO
import database.TransactionSuccess
import identity.api.requests.RegisterWithProfilePictureRequest
import identity.api.responses.RegisterIdentityResponse
import identity.application.IdentityApplication
import shared.{AppError, AppResult}
import identity.model.{RegistrationDetails, UserRole}
import org.http4s.multipart.Multipart
import shared.ListingMediaStorage

import java.sql.Connection

final case class RegisterWithProfilePictureApiMessage(storage: ListingMediaStorage)
    extends AfterCommitMultipartApiMessage[RegisterWithProfilePictureRequest, SessionCreatedResponse[RegisterIdentityResponse]]:

  override def decodeMultipart(multipart: Multipart[IO]): IO[AppResult[RegisterWithProfilePictureRequest]] =
    MultipartDecoders.result {
      for
        fullName <- MultipartDecoders.requiredTextPart(multipart, "fullName")
        email <- MultipartDecoders.requiredTextPart(multipart, "email")
        password <- MultipartDecoders.requiredTextPart(multipart, "password")
        roleText <- MultipartDecoders.requiredTextPart(multipart, "role")
        role <- EitherT.fromEither[IO](UserRole.fromString(roleText).left.map(AppError.Validation.apply))
        agencyName <- MultipartDecoders.optionalTextPart(multipart, "agencyName")
        phone <- MultipartDecoders.optionalTextPart(multipart, "phone")
        uploadParts <- MultipartDecoders.fileUpload(
          multipart,
          "Profile picture upload must include a file field",
          "Profile picture upload must include a filename"
        )
        (fileName, contentType, bytes) = uploadParts
      yield RegisterWithProfilePictureRequest(
        fullName = fullName,
        email = email,
        password = password,
        role = role,
        agencyName = agencyName,
        phone = phone,
        fileName = fileName,
        contentType = contentType,
        bytes = bytes
      )
    }

  override def plan(
    request: RegisterWithProfilePictureRequest,
    connection: Connection
  ): IO[AppResult[TransactionSuccess[SessionCreatedResponse[RegisterIdentityResponse]]]] =
    IdentityApplication
      .signUpWithProfilePicture(
        connection,
        RegistrationDetails(
          fullName = request.fullName,
          email = request.email,
          password = request.password,
          role = request.role,
          agencyName = request.agencyName,
          phone = request.phone
        ),
        request.fileName,
        request.contentType,
        request.bytes,
        storage
      )
      .map(_.map(transaction =>
        transaction.copy(value = SessionCreatedResponse(
          body = RegisterIdentityResponse(
            user = transaction.value.user
          ),
          sessionToken = transaction.value.sessionToken,
          csrfToken = transaction.value.csrfToken
        ))
      ))
