package listings.api.responses
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import listings.model.ListingSummary

final case class ListManagedListingsResponse(
  listings: List[ListingSummary]
)

object ListManagedListingsResponse:
  given Encoder[ListManagedListingsResponse] = deriveEncoder[ListManagedListingsResponse]
