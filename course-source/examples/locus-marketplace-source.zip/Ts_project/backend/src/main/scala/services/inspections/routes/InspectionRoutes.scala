package inspections.routes
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.ApiServiceMessages
import inspections.api.messages.*
import shared.ListingMediaStorage

object InspectionRoutes:

  def apiMessages(storage: ListingMediaStorage): ApiServiceMessages =
    ApiServiceMessages("inspections", List(
      ListPublicInspectionSlotsApiMessage,
      BookInspectionSlotApiMessage,
      ChangeInspectionBookingApiMessage,
      CancelInspectionBookingApiMessage,
      ListAgentInspectionsApiMessage(storage),
      CreateInspectionSlotApiMessage(storage),
      DeleteInspectionSlotApiMessage,
      OpenBookedInspectionConversationApiMessage(storage)
    ))
