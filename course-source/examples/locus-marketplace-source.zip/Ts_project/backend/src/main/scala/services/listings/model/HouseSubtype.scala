package listings.model


import io.circe.{Decoder, Encoder}

enum HouseSubtype:
  case FreeStanding
  case Duplex
  case Terrace
  case Villa
  case OffThePlan

object HouseSubtype:
  def fromString(value: String): Either[String, HouseSubtype] =
    value.trim.toLowerCase match
      case "free_standing" => Right(HouseSubtype.FreeStanding)
      case "duplex" => Right(HouseSubtype.Duplex)
      case "terrace" => Right(HouseSubtype.Terrace)
      case "villa" => Right(HouseSubtype.Villa)
      case "off_the_plan" => Right(HouseSubtype.OffThePlan)
      case other => Left(s"Unsupported house subtype: $other")

  def toString(value: HouseSubtype): String =
    value match
      case HouseSubtype.FreeStanding => "free_standing"
      case HouseSubtype.Duplex => "duplex"
      case HouseSubtype.Terrace => "terrace"
      case HouseSubtype.Villa => "villa"
      case HouseSubtype.OffThePlan => "off_the_plan"

  given Encoder[HouseSubtype] = Encoder.encodeString.contramap(toString)
  given Decoder[HouseSubtype] = Decoder.decodeString.emap(fromString)
