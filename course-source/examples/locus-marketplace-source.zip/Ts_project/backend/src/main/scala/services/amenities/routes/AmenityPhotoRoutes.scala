package amenities.routes

import amenities.clients.GoogleAmenitiesClient
import cats.effect.IO
import io.circe.syntax.*
import org.http4s.circe.CirceEntityEncoder.*
import org.http4s.dsl.io.*
import org.http4s.{Header, HttpRoutes, Response, Status, Uri}
import org.typelevel.ci.CIString
import shared.ErrorResponse

object AmenityPhotoRoutes:

  private object PlacePhotoNameQueryParamMatcher extends QueryParamDecoderMatcher[String]("name")

  def routes(googleAmenitiesClient: Option[GoogleAmenitiesClient]): HttpRoutes[IO] =
    HttpRoutes.of[IO] {
      case GET -> Root / "api" / "amenities" / "place-photo" :? PlacePhotoNameQueryParamMatcher(photoName) =>
        googleAmenitiesClient match
          case None => BadRequest(ErrorResponse("Amenity photos are not configured.").asJson)
          case Some(client) =>
            client.resolvePlacePhoto(photoName).flatMap {
              case Left(error) =>
                BadRequest(ErrorResponse(Option(error.getMessage).getOrElse("Unable to load place photo.")).asJson)
              case Right(photo) =>
                Uri
                  .fromString(photo.uri.toString)
                  .fold(
                    _ => BadRequest(ErrorResponse("Invalid place photo URI.").asJson),
                    photoUri =>
                      IO.pure(
                        Response[IO](status = Status.Found)
                          .putHeaders(
                            Header.Raw(CIString("Location"), photoUri.renderString),
                            Header.Raw(CIString("Cache-Control"), "no-store")
                          )
                      )
                  )
            }
    }
