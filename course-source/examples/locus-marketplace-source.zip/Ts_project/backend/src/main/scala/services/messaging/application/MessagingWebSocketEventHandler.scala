package messaging.application
import identity.model.*
import listings.model.*
import messaging.model.*


import cats.data.EitherT
import cats.effect.IO
import shared.*
import shared.ListingMediaStorage

import java.sql.Connection

private[messaging] object MessagingWebSocketEventHandler:

  private type AppEitherT[A] = EitherT[IO, AppError, A]

  private def liftApp[A](ioResult: IO[AppResult[A]]): AppEitherT[A] =
    EitherT(ioResult)

  def handleWebSocketEvent(
    connection: Connection,
    storage: ListingMediaStorage,
    userId: UserId,
    event: ClientMessagingEvent
  ): IO[AppResult[Option[ServerMessagingEvent]]] =
    event match
      case ClientMessagingEvent.SendMessage(conversationId, body, attachmentIds) =>
        MessagingApplication
          .createMessage(connection, conversationId, userId, body, attachmentIds, storage)
          .map(_.map(message => Some(ServerMessagingEvent.MessageCreated(conversationId, message, message.createdAt))))
      case ClientMessagingEvent.MarkSeen(conversationId) =>
        MessagingApplication
          .markSeen(connection, conversationId, userId)
          .map(_.map(seenAt => Some(ServerMessagingEvent.MessagesSeen(conversationId, userId, seenAt, seenAt))))
      case ClientMessagingEvent.TypingStarted(conversationId) =>
        RuntimeValues.now.map(now => Right(Some(ServerMessagingEvent.TypingChanged(conversationId, userId, typing = true, now))))
      case ClientMessagingEvent.TypingStopped(conversationId) =>
        RuntimeValues.now.map(now => Right(Some(ServerMessagingEvent.TypingChanged(conversationId, userId, typing = false, now))))
      case ClientMessagingEvent.SubscribeConversation(conversationId) =>
        (
          for
            _ <- liftApp(
              MessagingApplication.listMessagesEnsuringIntroduction(
                connection,
                conversationId,
                userId,
                storage
              )
            )
          yield None
        ).value
