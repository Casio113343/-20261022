package analytics.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

enum ListingAnalyticsSearchMarket:
  case Sale
  case Rent
  case Sold
  case Leased

object ListingAnalyticsSearchMarket:
  def toString(value: ListingAnalyticsSearchMarket): String =
    value match
      case ListingAnalyticsSearchMarket.Sale => "sale"
      case ListingAnalyticsSearchMarket.Rent => "rent"
      case ListingAnalyticsSearchMarket.Sold => "sold"
      case ListingAnalyticsSearchMarket.Leased => "leased"

  def fromString(value: String): Either[String, ListingAnalyticsSearchMarket] =
    value.trim.toLowerCase match
      case "sale" => Right(ListingAnalyticsSearchMarket.Sale)
      case "rent" => Right(ListingAnalyticsSearchMarket.Rent)
      case "sold" => Right(ListingAnalyticsSearchMarket.Sold)
      case "leased" => Right(ListingAnalyticsSearchMarket.Leased)
      case other => Left(s"Unknown listing analytics search market: $other")

  given Encoder[ListingAnalyticsSearchMarket] =
    Encoder.encodeString.contramap(toString)

  given Decoder[ListingAnalyticsSearchMarket] =
    Decoder.decodeString.emap(fromString)

enum ListingAnalyticsTrafficSource:
  case SearchResults
  case SavedListings
  case DirectLink
  case AgentDashboardPreview
  case Recommendations

object ListingAnalyticsTrafficSource:
  def toString(value: ListingAnalyticsTrafficSource): String =
    value match
      case ListingAnalyticsTrafficSource.SearchResults => "search_results"
      case ListingAnalyticsTrafficSource.SavedListings => "saved_listings"
      case ListingAnalyticsTrafficSource.DirectLink => "direct_link"
      case ListingAnalyticsTrafficSource.AgentDashboardPreview => "agent_dashboard_preview"
      case ListingAnalyticsTrafficSource.Recommendations => "recommendations"

  def fromString(value: String): Either[String, ListingAnalyticsTrafficSource] =
    value.trim.toLowerCase.replace(" ", "_") match
      case "search_results" => Right(ListingAnalyticsTrafficSource.SearchResults)
      case "saved_listings" => Right(ListingAnalyticsTrafficSource.SavedListings)
      case "direct_link" => Right(ListingAnalyticsTrafficSource.DirectLink)
      case "agent_dashboard_preview" => Right(ListingAnalyticsTrafficSource.AgentDashboardPreview)
      case "recommendations" => Right(ListingAnalyticsTrafficSource.Recommendations)
      case other => Left(s"Unknown listing analytics traffic source: $other")

  def displayLabel(value: ListingAnalyticsTrafficSource): String =
    value match
      case ListingAnalyticsTrafficSource.SearchResults => "Search results"
      case ListingAnalyticsTrafficSource.SavedListings => "Saved listings"
      case ListingAnalyticsTrafficSource.DirectLink => "Direct link"
      case ListingAnalyticsTrafficSource.AgentDashboardPreview => "Agent dashboard preview"
      case ListingAnalyticsTrafficSource.Recommendations => "Recommendations"

  given Encoder[ListingAnalyticsTrafficSource] =
    Encoder.encodeString.contramap(toString)

  given Decoder[ListingAnalyticsTrafficSource] =
    Decoder.decodeString.emap(fromString)

enum ListingAnalyticsDeviceClass:
  case Mobile
  case Tablet
  case Desktop
  case Unknown

object ListingAnalyticsDeviceClass:
  def toString(value: ListingAnalyticsDeviceClass): String =
    value match
      case ListingAnalyticsDeviceClass.Mobile => "mobile"
      case ListingAnalyticsDeviceClass.Tablet => "tablet"
      case ListingAnalyticsDeviceClass.Desktop => "desktop"
      case ListingAnalyticsDeviceClass.Unknown => "unknown"

  def fromString(value: String): Either[String, ListingAnalyticsDeviceClass] =
    value.trim.toLowerCase.replace(" ", "_") match
      case "mobile" => Right(ListingAnalyticsDeviceClass.Mobile)
      case "tablet" => Right(ListingAnalyticsDeviceClass.Tablet)
      case "desktop" => Right(ListingAnalyticsDeviceClass.Desktop)
      case "unknown" | "unknown_device" => Right(ListingAnalyticsDeviceClass.Unknown)
      case other => Left(s"Unknown listing analytics device class: $other")

  def displayLabel(value: ListingAnalyticsDeviceClass): String =
    value match
      case ListingAnalyticsDeviceClass.Mobile => "Mobile"
      case ListingAnalyticsDeviceClass.Tablet => "Tablet"
      case ListingAnalyticsDeviceClass.Desktop => "Desktop"
      case ListingAnalyticsDeviceClass.Unknown => "Unknown device"

  given Encoder[ListingAnalyticsDeviceClass] =
    Encoder.encodeString.contramap(toString)

  given Decoder[ListingAnalyticsDeviceClass] =
    Decoder.decodeString.emap(fromString)

enum ListingAnalyticsPhotoKind:
  case Photo
  case FloorPlan

object ListingAnalyticsPhotoKind:
  def toString(value: ListingAnalyticsPhotoKind): String =
    value match
      case ListingAnalyticsPhotoKind.Photo => "photo"
      case ListingAnalyticsPhotoKind.FloorPlan => "floor_plan"

  def fromString(value: String): Either[String, ListingAnalyticsPhotoKind] =
    value.trim.toLowerCase match
      case "photo" => Right(ListingAnalyticsPhotoKind.Photo)
      case "floor_plan" => Right(ListingAnalyticsPhotoKind.FloorPlan)
      case other => Left(s"Unknown listing analytics photo kind: $other")

  given Encoder[ListingAnalyticsPhotoKind] =
    Encoder.encodeString.contramap(toString)

  given Decoder[ListingAnalyticsPhotoKind] =
    Decoder.decodeString.emap(fromString)

enum ListingAnalyticsAction:
  case OpenedFromSearch
  case ConversationStarted
  case InspectionRequested
  case SavedByBuyer

object ListingAnalyticsAction:
  def toString(value: ListingAnalyticsAction): String =
    value match
      case ListingAnalyticsAction.OpenedFromSearch => "opened_from_search"
      case ListingAnalyticsAction.ConversationStarted => "conversation_started"
      case ListingAnalyticsAction.InspectionRequested => "inspection_requested"
      case ListingAnalyticsAction.SavedByBuyer => "saved_by_buyer"

  def fromString(value: String): Either[String, ListingAnalyticsAction] =
    value.trim.toLowerCase match
      case "opened_from_search" => Right(ListingAnalyticsAction.OpenedFromSearch)
      case "conversation_started" => Right(ListingAnalyticsAction.ConversationStarted)
      case "inspection_requested" => Right(ListingAnalyticsAction.InspectionRequested)
      case "saved_by_buyer" => Right(ListingAnalyticsAction.SavedByBuyer)
      case other => Left(s"Unknown listing analytics action: $other")

  def displayLabel(value: ListingAnalyticsAction): String =
    value match
      case ListingAnalyticsAction.OpenedFromSearch => "Opened from search"
      case ListingAnalyticsAction.ConversationStarted => "Conversation started"
      case ListingAnalyticsAction.InspectionRequested => "Inspection requested"
      case ListingAnalyticsAction.SavedByBuyer => "Saved by a buyer"

  given Encoder[ListingAnalyticsAction] =
    Encoder.encodeString.contramap(toString)

  given Decoder[ListingAnalyticsAction] =
    Decoder.decodeString.emap(fromString)

final case class ListingAnalyticsSearchContext(
  marketMode: ListingAnalyticsSearchMarket,
  filterLabel: Option[String]
)

object ListingAnalyticsSearchContext:
  given Encoder[ListingAnalyticsSearchContext] = deriveEncoder[ListingAnalyticsSearchContext]
  given Decoder[ListingAnalyticsSearchContext] = deriveDecoder[ListingAnalyticsSearchContext]

final case class ListingAnalyticsPhotoContext(
  kind: ListingAnalyticsPhotoKind,
  index: Int
)

object ListingAnalyticsPhotoContext:
  given Encoder[ListingAnalyticsPhotoContext] = deriveEncoder[ListingAnalyticsPhotoContext]
  given Decoder[ListingAnalyticsPhotoContext] = deriveDecoder[ListingAnalyticsPhotoContext]

final case class ListingAnalyticsAmenityContext(
  category: String,
  label: String
)

object ListingAnalyticsAmenityContext:
  given Encoder[ListingAnalyticsAmenityContext] = deriveEncoder[ListingAnalyticsAmenityContext]
  given Decoder[ListingAnalyticsAmenityContext] = deriveDecoder[ListingAnalyticsAmenityContext]

final case class ListingAnalyticsEventMetadata(
  trafficSource: Option[ListingAnalyticsTrafficSource],
  deviceClass: Option[ListingAnalyticsDeviceClass],
  search: Option[ListingAnalyticsSearchContext],
  photo: Option[ListingAnalyticsPhotoContext],
  amenity: Option[ListingAnalyticsAmenityContext],
  action: Option[ListingAnalyticsAction]
)

object ListingAnalyticsEventMetadata:
  val empty: ListingAnalyticsEventMetadata =
    ListingAnalyticsEventMetadata(
      trafficSource = None,
      deviceClass = None,
      search = None,
      photo = None,
      amenity = None,
      action = None
    )

  given Encoder[ListingAnalyticsEventMetadata] = deriveEncoder[ListingAnalyticsEventMetadata]
  given Decoder[ListingAnalyticsEventMetadata] = deriveDecoder[ListingAnalyticsEventMetadata]
