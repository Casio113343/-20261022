package identity.api.messages
import identity.model.*


import shared.{ApiTransaction, JsonApiMessage, SessionCreatedResponse}
import cats.effect.IO
import identity.api.requests.RegisterIdentityRequest
import identity.api.responses.RegisterIdentityResponse
import identity.application.IdentityApplication
import shared.AppResult
import identity.model.RegistrationDetails
import shared.ListingMediaStorage

import java.sql.Connection

final case class RegisterIdentityApiMessage(storage: ListingMediaStorage)
    extends JsonApiMessage[RegisterIdentityRequest, SessionCreatedResponse[RegisterIdentityResponse]]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: RegisterIdentityRequest,
    connection: Connection
  ): IO[AppResult[SessionCreatedResponse[RegisterIdentityResponse]]] =
    IdentityApplication
      .signUp(
        connection,
        RegistrationDetails(
          fullName = request.fullName,
          email = request.email,
          password = request.password,
          role = request.role,
          agencyName = request.agencyName,
          phone = request.phone
        )
      )
      .map(_.map(session =>
        SessionCreatedResponse(
          body = RegisterIdentityResponse(
            user = IdentityApplication.resolveAvatarUrl(storage)(session.user)
          ),
          sessionToken = session.sessionToken,
          csrfToken = session.csrfToken
        )
      ))
