package fengshui.model


import io.circe.{Decoder, Encoder}

enum FengshuiActionPriority:
  case High, Medium, Low

object FengshuiActionPriority:
  def toString(value: FengshuiActionPriority): String =
    value match
      case FengshuiActionPriority.High => "high"
      case FengshuiActionPriority.Medium => "medium"
      case FengshuiActionPriority.Low => "low"

  def fromString(value: String): Either[String, FengshuiActionPriority] =
    value match
      case "high" => Right(FengshuiActionPriority.High)
      case "medium" => Right(FengshuiActionPriority.Medium)
      case "low" => Right(FengshuiActionPriority.Low)
      case _ => Left("Unsupported fengshui action priority")

  given Encoder[FengshuiActionPriority] = Encoder.encodeString.contramap(toString)
  given Decoder[FengshuiActionPriority] = Decoder.decodeString.emap(fromString)
