package identity.api.messages
import identity.model.*


import shared.{ApiTransaction, NoRequestWithSessionTokenMessage}
import cats.effect.IO
import identity.api.responses.EndSessionResponse
import identity.tables.user_sessions.UserSessionsTable
import shared.AppResult

import java.sql.Connection

object EndSessionApiMessage extends NoRequestWithSessionTokenMessage[EndSessionResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    sessionToken: String,
    connection: Connection
  ): IO[AppResult[EndSessionResponse]] =
    UserSessionsTable
      .signOut(connection, sessionToken)
      .map(_.map(_ => EndSessionResponse(ended = true)))
