package media.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import listings.model.ListingId

final case class PropertyImage(
  id: PropertyImageId,
  listingId: ListingId,
  url: String,
  objectKey: String,
  contentType: String,
  sizeBytes: Long,
  sortOrder: Int,
  altText: Option[String],
  isFloorPlan: Boolean
)

object PropertyImage:
  given Encoder[PropertyImage] = deriveEncoder[PropertyImage]
  given Decoder[PropertyImage] = deriveDecoder[PropertyImage]
