package amenities.api.messages

import amenities.api.requests.GetAmenityDetailsRequest
import amenities.api.responses.GetAmenityDetailsResponse
import amenities.clients.GoogleAmenitiesClient
import cats.effect.IO
import shared.{ApiTransaction, AppError, AppResult, JsonApiMessage}

import java.sql.Connection

final case class GetAmenityDetailsApiMessage(
  googleAmenitiesClient: Option[GoogleAmenitiesClient]
) extends JsonApiMessage[GetAmenityDetailsRequest, GetAmenityDetailsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(
    request: GetAmenityDetailsRequest,
    connection: Connection
  ): IO[AppResult[GetAmenityDetailsResponse]] =
    googleAmenitiesClient match
      case None => IO.pure(Left(AppError.Validation("Amenity details are not configured.")))
      case Some(client) =>
        client
          .fetchAmenityDetails(request.origin, request.place)
          .map(_.map { case (details, routes) => GetAmenityDetailsResponse(details, routes) })
