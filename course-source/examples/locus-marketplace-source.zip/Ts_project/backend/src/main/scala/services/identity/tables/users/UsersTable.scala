package identity.tables.users
import identity.model.*


import cats.effect.IO
import identity.security.Security
import shared.*

import java.sql.{Connection, ResultSet, Timestamp, Types}
import java.time.Instant

private[identity] object UsersTable:

  final case class UserRecord(
    id: UserId,
    fullName: String,
    email: String,
    role: UserRole,
    createdAt: Instant,
    passwordSalt: String,
    passwordHash: String
  )

  private val createSql: String =
    """
      |create table if not exists users (
      |  id uuid primary key,
      |  full_name varchar(160) not null,
      |  email varchar(200) not null unique,
      |  password_salt text not null,
      |  password_hash text not null,
      |  role varchar(32) not null check (role in ('buyer_renter', 'agent_admin')),
      |  created_at timestamptz not null,
      |  avatar_object_key text
      |);
      |""".stripMargin

  private val ensureAvatarObjectKeySql: String =
    """
      |alter table users
      |add column if not exists avatar_object_key text;
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql, ensureAvatarObjectKeySql))

  private val findUserRecordByEmailSql: String =
    """
      |select id, full_name, email, role, created_at, password_salt, password_hash
      |from users
      |where email = ?
      |""".stripMargin

  def findUserRecordByEmail(
    connection: Connection,
    email: String
  ): IO[AppResult[Option[UserRecord]]] =
    JdbcResources.select(connection, findUserRecordByEmailSql) { statement =>
      statement.setString(1, email)
    } { resultSet =>
      if resultSet.next() then readUserRecord(resultSet).map(Some(_))
      else Right(None)
    }

  private val insertUserSql: String =
    """
      |insert into users (id, full_name, email, password_salt, password_hash, role, created_at, avatar_object_key)
      |values (?, ?, ?, ?, ?, ?, ?, ?)
      |""".stripMargin

  def insertUser(
    connection: Connection,
    userId: UserId,
    request: RegistrationDetails,
    normalizedEmail: String,
    digest: Security.PasswordDigest,
    createdAt: Instant
  ): IO[Unit] =
    JdbcResources.update(connection, insertUserSql) { statement =>
      statement.setObject(1, userId.value)
      statement.setString(2, request.fullName.trim)
      statement.setString(3, normalizedEmail)
      statement.setString(4, digest.salt)
      statement.setString(5, digest.hash)
      statement.setString(6, UserRole.toString(request.role))
      statement.setTimestamp(7, Timestamp.from(createdAt))
      statement.setNull(8, Types.VARCHAR)
      statement.executeUpdate()
    }.void

  private val loadUserSql: String =
    """
      |select u.id, u.full_name, u.email, u.role, u.created_at,
      |       u.avatar_object_key as user_avatar_object_key,
      |       ap.agency_name, ap.phone, ap.license_number, ap.bio
      |from users u
      |left join agent_profiles ap on ap.user_id = u.id
      |where u.id = ?
      |""".stripMargin

  def loadUser(connection: Connection, userId: UserId): IO[AppResult[Option[User]]] =
    JdbcResources.select(connection, loadUserSql) { statement =>
      statement.setObject(1, userId.value)
    } { resultSet =>
      if resultSet.next() then readUser(resultSet).map(Some(_))
      else Right(None)
    }

  private val updateUserAvatarObjectKeySql: String =
    """
      |with previous as (
      |  select avatar_object_key
      |  from users
      |  where id = ?
      |),
      |updated as (
      |  update users
      |  set avatar_object_key = ?
      |  where id = ?
      |  returning 1
      |)
      |select previous.avatar_object_key
      |from previous
      |join updated on true
      |""".stripMargin

  def updateUserAvatarObjectKey(connection: Connection, userId: UserId, avatarObjectKey: String): IO[AppResult[Option[String]]] =
    JdbcResources.select(connection, updateUserAvatarObjectKeySql) { statement =>
      statement.setObject(1, userId.value)
      statement.setString(2, avatarObjectKey)
      statement.setObject(3, userId.value)
    } { resultSet =>
      if resultSet.next() then Right(DbCodec.optionalText(resultSet, "avatar_object_key"))
      else Left(AppError.NotFound("User not found"))
    }

  private def readUserRecord(resultSet: ResultSet): AppResult[UserRecord] =
    for
      fullName <- DbCodec.requiredText(resultSet, "full_name")
      email <- DbCodec.requiredText(resultSet, "email")
      roleText <- DbCodec.requiredText(resultSet, "role")
      createdAt <- DbCodec.requiredInstant(resultSet, "created_at")
      passwordSalt <- DbCodec.requiredText(resultSet, "password_salt")
      passwordHash <- DbCodec.requiredText(resultSet, "password_hash")
      id <- DbCodec.requiredUuid(resultSet, "id")
      role <- DbCodec.decodeDatabaseValue(UserRole.fromString(roleText), "role")
    yield UserRecord(
      id = UserId(id),
      fullName = fullName,
      email = email,
      role = role,
      createdAt = createdAt,
      passwordSalt = passwordSalt,
      passwordHash = passwordHash
    )

  private def readUser(resultSet: ResultSet): AppResult[User] =
    for
      fullName <- DbCodec.requiredText(resultSet, "full_name")
      email <- DbCodec.requiredText(resultSet, "email")
      roleText <- DbCodec.requiredText(resultSet, "role")
      createdAt <- DbCodec.requiredInstant(resultSet, "created_at")
      id <- DbCodec.requiredUuid(resultSet, "id")
      accountAvatarObjectKey = DbCodec.optionalText(resultSet, "user_avatar_object_key")
      agencyName = DbCodec.optionalText(resultSet, "agency_name")
      phone = DbCodec.optionalText(resultSet, "phone")
      licenseNumber = DbCodec.optionalText(resultSet, "license_number")
      bio = DbCodec.optionalText(resultSet, "bio")
      role <- DbCodec.decodeDatabaseValue(UserRole.fromString(roleText), "role")
      userId = UserId(id)
    yield User(
      id = userId,
      fullName = fullName,
      email = email,
      role = role,
      createdAt = createdAt,
      avatarUrl = accountAvatarObjectKey,
      agentProfile = agencyName.map(name =>
        AgentProfile(
          userId = userId,
          agencyName = name,
          phone = phone.getOrElse(""),
          licenseNumber = licenseNumber,
          bio = bio
        )
      )
    )
