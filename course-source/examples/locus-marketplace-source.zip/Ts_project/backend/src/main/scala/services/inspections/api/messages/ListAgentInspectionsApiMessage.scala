package inspections.api.messages
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.{ApiTransaction, NoRequestWithTokenMessage}
import cats.effect.IO
import identity.api.IdentityPublicApi
import inspections.application.InspectionApplication
import inspections.api.responses.ListAgentInspectionsResponse
import shared.AppResult
import shared.AuthenticatedPrincipal
import shared.ListingMediaStorage

import java.sql.Connection

final case class ListAgentInspectionsApiMessage(storage: ListingMediaStorage)
    extends NoRequestWithTokenMessage[ListAgentInspectionsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(principal: AuthenticatedPrincipal, connection: Connection): IO[AppResult[ListAgentInspectionsResponse]] =
    InspectionApplication
      .listAgentSlots(connection, storage, principal.userId)
      .map(_.map(ListAgentInspectionsResponse.apply))
