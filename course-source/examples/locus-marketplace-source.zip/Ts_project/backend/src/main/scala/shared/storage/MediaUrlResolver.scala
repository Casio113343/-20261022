package shared

object MediaUrlResolver:

  def listingImageUrl(config: ObjectStorageConfig)(objectKey: String): String =
    listingImageUrl(
      publicBaseUrl = config.publicBaseUrl,
      bucketName = config.bucketName,
      objectKey = objectKey,
    )

  def listingImageUrl(publicBaseUrl: String, bucketName: String, objectKey: String): String =
    val normalizedBaseUrl = publicBaseUrl.stripSuffix("/")
    s"$normalizedBaseUrl/$bucketName/$objectKey"
