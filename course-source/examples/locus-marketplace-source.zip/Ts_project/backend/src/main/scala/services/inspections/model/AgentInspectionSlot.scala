package inspections.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import shared.TimeCodecs.given

import java.time.Instant

final case class AgentInspectionSlot(
  id: InspectionSlotId,
  listing: InspectionListingSummary,
  startsAt: Instant,
  endsAt: Instant,
  bookingId: Option[InspectionBookingId],
  bookedAt: Option[Instant],
  buyer: Option[InspectionBuyerSummary]
)

object AgentInspectionSlot:
  given Encoder[AgentInspectionSlot] = deriveEncoder[AgentInspectionSlot]
  given Decoder[AgentInspectionSlot] = deriveDecoder[AgentInspectionSlot]
