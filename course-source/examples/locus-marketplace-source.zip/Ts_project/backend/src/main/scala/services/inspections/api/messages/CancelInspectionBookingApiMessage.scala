package inspections.api.messages
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import inspections.api.requests.CancelInspectionBookingRequest
import inspections.api.responses.CancelInspectionBookingResponse
import inspections.application.InspectionApplication
import inspections.model.InspectionSlotId
import inspections.tables.inspection_bookings.InspectionBookingsTable
import shared.{AppError, AppResult}
import shared.AuthenticatedPrincipal

import java.sql.Connection

object CancelInspectionBookingApiMessage
    extends ApiWithTokenMessage[CancelInspectionBookingRequest, CancelInspectionBookingResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: CancelInspectionBookingRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[CancelInspectionBookingResponse]] =
    (
      for
        rows <- EitherT.right[AppError](InspectionBookingsTable.cancelBooking(connection, principal.userId, request.slotId))
        _ <- EitherT.cond[IO](rows > 0, (), AppError.Conflict("This inspection can no longer be cancelled."))
        slot <- EitherT(InspectionApplication.findPublicSlot(connection, request.slotId, principal.userId))
      yield CancelInspectionBookingResponse(slot)
    ).value
