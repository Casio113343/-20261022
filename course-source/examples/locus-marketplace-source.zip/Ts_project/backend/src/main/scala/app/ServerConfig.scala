package app

import cats.effect.IO
import com.comcast.ip4s.{Host, Port, host, port}

final case class ServerConfig(
  host: Host,
  port: Port
):
  def address: String =
    s"${host.toString}:${port.value}"

object ServerConfig:

  private val defaultHost: Host = host"0.0.0.0"
  private val defaultPort: Port = port"8080"

  val load: IO[ServerConfig] =
    IO.delay {
      val environment = sys.env

      ServerConfig(
        host = environment.get("BACKEND_HOST").flatMap(Host.fromString).getOrElse(defaultHost),
        port = environment.get("BACKEND_PORT").flatMap(_.toIntOption).flatMap(Port.fromInt).getOrElse(defaultPort)
      )
    }
