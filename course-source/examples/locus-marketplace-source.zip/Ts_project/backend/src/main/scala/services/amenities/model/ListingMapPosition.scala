package amenities.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class ListingMapPosition(
  lat: Double,
  lng: Double
)

object ListingMapPosition:
  given Encoder[ListingMapPosition] = deriveEncoder[ListingMapPosition]
  given Decoder[ListingMapPosition] = deriveDecoder[ListingMapPosition]
