package listings.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class ConversationListingSummary(
  id: ListingId,
  title: String,
  addressLine: String,
  suburb: String,
  state: String,
  postcode: String,
  price: Int,
  transactionType: TransactionType
)

object ConversationListingSummary:
  given Encoder[ConversationListingSummary] = deriveEncoder[ConversationListingSummary]
  given Decoder[ConversationListingSummary] = deriveDecoder[ConversationListingSummary]
