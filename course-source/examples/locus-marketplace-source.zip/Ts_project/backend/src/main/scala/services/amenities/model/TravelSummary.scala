package amenities.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class TravelSummary(
  distanceMeters: Int,
  durationLabel: String,
  mode: TravelMode,
  polyline: Option[List[ListingMapPosition]]
)

object TravelSummary:
  given Encoder[TravelSummary] = deriveEncoder[TravelSummary]
  given Decoder[TravelSummary] = deriveDecoder[TravelSummary]
