package identity.tables.agent_profiles
import identity.model.*


import cats.effect.IO
import shared.*

import java.sql.Connection

private[identity] object AgentProfilesTable:

  private val createSql: String =
    """
      |create table if not exists agent_profiles (
      |  user_id uuid primary key references users(id) on delete cascade,
      |  agency_name varchar(160) not null,
      |  phone varchar(64) not null,
      |  license_number varchar(80),
      |  bio text
      |);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql)) *> migrateAvatarObjectKey(connection)

  private val copyLegacyAvatarUrlSql: String =
    """
      |update agent_profiles
      |set avatar_object_key = substring(avatar_url from '/listing-media/(.*)$')
      |where avatar_object_key is null
      |  and avatar_url like '%/listing-media/%';
      |""".stripMargin

  private val copyProfileAvatarToUserSql: String =
    """
      |update users u
      |set avatar_object_key = ap.avatar_object_key
      |from agent_profiles ap
      |where ap.user_id = u.id
      |  and u.avatar_object_key is null
      |  and ap.avatar_object_key is not null;
      |""".stripMargin

  private val dropLegacyAvatarUrlSql: String =
    "alter table agent_profiles drop column avatar_url;"

  private val dropMigratedAvatarObjectKeySql: String =
    "alter table agent_profiles drop column if exists avatar_object_key;"

  private def migrateAvatarObjectKey(connection: Connection): IO[Unit] =
    for
      hasLegacyAvatarUrl <- SchemaSupport.hasColumn(connection, "agent_profiles", "avatar_url")
      hasAgentAvatarObjectKey <- SchemaSupport.hasColumn(connection, "agent_profiles", "avatar_object_key")
      _ <-
        if hasLegacyAvatarUrl then SchemaSupport.executeStatements(connection, List(copyLegacyAvatarUrlSql))
        else IO.unit
      _ <-
        if hasLegacyAvatarUrl || hasAgentAvatarObjectKey then SchemaSupport.executeStatements(connection, List(copyProfileAvatarToUserSql))
        else IO.unit
      _ <-
        if hasLegacyAvatarUrl then SchemaSupport.executeStatements(connection, List(dropLegacyAvatarUrlSql))
        else IO.unit
      _ <-
        if hasLegacyAvatarUrl || hasAgentAvatarObjectKey then SchemaSupport.executeStatements(connection, List(dropMigratedAvatarObjectKeySql))
        else IO.unit
    yield ()

  private val insertAgentProfileSql: String =
    """
      |insert into agent_profiles (user_id, agency_name, phone, license_number, bio)
      |values (?, ?, ?, ?, ?)
      |""".stripMargin

  def insertAgentProfileIfNeeded(
    connection: Connection,
    userId: UserId,
    request: RegistrationDetails
  ): IO[Unit] =
    request.role match
      case UserRole.AgentAdmin =>
        val agencyName = request.agencyName.map(_.trim).filter(_.nonEmpty).getOrElse("Independent Agency")
        val phone = request.phone.map(_.trim).filter(_.nonEmpty).getOrElse("0400 000 000")

        JdbcResources.update(connection, insertAgentProfileSql) { statement =>
          statement.setObject(1, userId.value)
          statement.setString(2, agencyName)
          statement.setString(3, phone)
          statement.setNull(4, java.sql.Types.VARCHAR)
          statement.setNull(5, java.sql.Types.VARCHAR)
          statement.executeUpdate()
        }.void
      case UserRole.BuyerRenter => IO.unit
