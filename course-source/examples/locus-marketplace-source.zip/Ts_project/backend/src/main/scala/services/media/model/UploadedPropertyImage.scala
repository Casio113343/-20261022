package media.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class UploadedPropertyImage(
  id: PropertyImageId,
  url: String,
  objectKey: String,
  contentType: String,
  sizeBytes: Long,
  altText: Option[String]
)

object UploadedPropertyImage:
  given Encoder[UploadedPropertyImage] = deriveEncoder[UploadedPropertyImage]
  given Decoder[UploadedPropertyImage] = deriveDecoder[UploadedPropertyImage]
