package messaging.model


import io.circe.{Decoder, DecodingFailure}

enum ClientMessagingEvent:
  case SendMessage(conversationId: ConversationId, body: String, attachmentIds: List[MessageAttachmentId])
  case TypingStarted(conversationId: ConversationId)
  case TypingStopped(conversationId: ConversationId)
  case MarkSeen(conversationId: ConversationId)
  case SubscribeConversation(conversationId: ConversationId)

object ClientMessagingEvent:
  given Decoder[ClientMessagingEvent] = Decoder.instance { cursor =>
    cursor.get[String]("type").flatMap {
      case "send_message" =>
        for
          conversationId <- cursor.get[ConversationId]("conversationId")
          body <- cursor.get[String]("body")
          attachmentIds <- cursor.getOrElse[List[MessageAttachmentId]]("attachmentIds")(Nil)
        yield SendMessage(conversationId, body, attachmentIds)
      case "typing_started" => cursor.get[ConversationId]("conversationId").map(TypingStarted.apply)
      case "typing_stopped" => cursor.get[ConversationId]("conversationId").map(TypingStopped.apply)
      case "mark_seen" => cursor.get[ConversationId]("conversationId").map(MarkSeen.apply)
      case "subscribe_conversation" => cursor.get[ConversationId]("conversationId").map(SubscribeConversation.apply)
      case other => Left(DecodingFailure(s"Unknown messaging event: $other", cursor.history))
    }
  }
