package listings.api.requests
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import shared.*

final case class SearchPublicListingsRequest(
  query: Option[String],
  transactionType: Option[TransactionType],
  listingStatuses: List[ListingStatus],
  propertyTypes: List[PropertyType],
  houseSubtypes: List[HouseSubtype],
  apartmentSubtypes: List[ApartmentSubtype],
  minPrice: Option[Int],
  maxPrice: Option[Int],
  minFloorSize: Option[Int],
  maxFloorSize: Option[Int],
  minLandSize: Option[Int],
  maxLandSize: Option[Int],
  bedrooms: Option[Int],
  bathrooms: Option[Int],
  carSpaces: Option[Int],
  sort: Option[ListingSort],
  limit: Option[Int]
)

object SearchPublicListingsRequest:
  given Decoder[SearchPublicListingsRequest] = deriveDecoder[SearchPublicListingsRequest]
