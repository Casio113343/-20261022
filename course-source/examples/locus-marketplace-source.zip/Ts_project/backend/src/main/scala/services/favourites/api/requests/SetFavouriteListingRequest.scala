package favourites.api.requests
import identity.model.*
import listings.model.*

import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.ListingId

final case class SetFavouriteListingRequest(
  listingId: ListingId,
  saved: Boolean
)

object SetFavouriteListingRequest:
  given Decoder[SetFavouriteListingRequest] = deriveDecoder[SetFavouriteListingRequest]
