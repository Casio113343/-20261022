package favourites.tables
import identity.model.*
import listings.model.*

import cats.effect.IO
import _root_.favourites.tables.favourite_records.FavouritesTable

import java.sql.Connection

object FavouritesSchema:

  def initialize(connection: Connection): IO[Unit] =
    FavouritesTable.initialize(connection)
