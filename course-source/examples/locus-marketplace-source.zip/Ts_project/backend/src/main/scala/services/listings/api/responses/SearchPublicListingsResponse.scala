package listings.api.responses
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import listings.model.ListingSummary

final case class SearchPublicListingsResponse(
  listings: List[ListingSummary],
  total: Int
)

object SearchPublicListingsResponse:
  given Encoder[SearchPublicListingsResponse] = deriveEncoder[SearchPublicListingsResponse]
