package inspections.tables.inspection_slots
import identity.model.*
import listings.model.*
import cats.effect.IO
import inspections.model.*
import shared.*

import java.sql.{Connection, ResultSet, Timestamp}
import java.time.Instant
import java.util.UUID

private[inspections] object InspectionSlotsTable:

  final case class CancelledInspectionNotice(
    listingId: ListingId,
    agentId: UserId,
    buyerId: UserId,
    startsAt: Instant
  )

  final case class AgentInspectionSlotRecord(
    id: InspectionSlotId,
    listingId: ListingId,
    startsAt: Instant,
    endsAt: Instant,
    bookingId: Option[InspectionBookingId],
    bookedAt: Option[Instant],
    buyerId: Option[UserId]
  )

  final case class BookedInspectionConversationTarget(
    listingId: ListingId,
    buyerId: UserId
  )

  private val createSql: String =
    """
      |create table if not exists inspection_slots (
      |  id uuid primary key,
      |  listing_id uuid not null references listings(id) on delete cascade,
      |  agent_id uuid not null references users(id) on delete cascade,
      |  starts_at timestamptz not null,
      |  ends_at timestamptz not null,
      |  created_at timestamptz not null,
      |  check (ends_at > starts_at),
      |  unique (listing_id, starts_at)
      |);
      |create index if not exists inspection_slots_listing_idx on inspection_slots(listing_id, starts_at);
      |create index if not exists inspection_slots_agent_idx on inspection_slots(agent_id, starts_at);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql))

  private val listPublicSlotsSql: String =
    """
      |select s.id, s.listing_id, s.starts_at, s.ends_at, b.id as booking_id, b.buyer_id
      |from inspection_slots s
      |left join inspection_bookings b on b.slot_id = s.id
      |where s.listing_id = ?
      |  and s.starts_at > now()
      |order by s.starts_at asc
      |""".stripMargin

  def listPublicSlots(
    connection: Connection,
    listingId: ListingId,
    currentBuyerId: Option[UserId] = None
  ): IO[AppResult[List[PublicInspectionSlot]]] =
    JdbcResources.select(connection, listPublicSlotsSql) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ =>
          for
            slotId <- DbCodec.requiredUuid(resultSet, "id")
            rowListingId <- DbCodec.requiredUuid(resultSet, "listing_id")
            startsAt <- DbCodec.requiredInstant(resultSet, "starts_at")
            endsAt <- DbCodec.requiredInstant(resultSet, "ends_at")
            bookingBuyerId = Option(resultSet.getObject("buyer_id", classOf[UUID])).map(UserId(_))
          yield PublicInspectionSlot(
            id = InspectionSlotId(slotId),
            listingId = ListingId(rowListingId),
            startsAt = startsAt,
            endsAt = endsAt,
            isBooked = Option(resultSet.getObject("booking_id", classOf[UUID])).nonEmpty,
            isBookedByCurrentUser = bookingBuyerId.exists(currentBuyerId.contains)
          )
        )
        .foldRight(Right(Nil): AppResult[List[PublicInspectionSlot]])((next, acc) =>
          for
            head <- next
            tail <- acc
          yield head :: tail
        )
    }

  private val listAgentSlotsSql: String =
    """
      |select s.id, s.listing_id, s.starts_at, s.ends_at,
      |       b.id as booking_id, b.created_at as booked_at, b.buyer_id
      |from inspection_slots s
      |left join inspection_bookings b on b.slot_id = s.id
      |where s.agent_id = ?
      |  and s.starts_at > now()
      |order by s.starts_at asc
      |""".stripMargin

  def listAgentSlots(connection: Connection, agentId: UserId): IO[AppResult[List[AgentInspectionSlotRecord]]] =
    JdbcResources.select(connection, listAgentSlotsSql) { statement =>
      statement.setObject(1, agentId.value)
    }(readAgentSlots)

  private val createSlotSql: String =
    """
      |insert into inspection_slots (id, listing_id, agent_id, starts_at, ends_at, created_at)
      |values (?, ?, ?, ?, ?, ?)
      |""".stripMargin

  def createSlot(
    connection: Connection,
    slotId: InspectionSlotId,
    agentId: UserId,
    listingId: ListingId,
    startsAt: Instant,
    endsAt: Instant,
    createdAt: Instant
  ): IO[Int] =
    JdbcResources.update(connection, createSlotSql) { statement =>
      statement.setObject(1, slotId.value)
      statement.setObject(2, listingId.value)
      statement.setObject(3, agentId.value)
      statement.setTimestamp(4, Timestamp.from(startsAt))
      statement.setTimestamp(5, Timestamp.from(endsAt))
      statement.setTimestamp(6, Timestamp.from(createdAt))
      statement.executeUpdate()
    }

  private val slotExistsAtSql: String =
    """
      |select 1
      |from inspection_slots
      |where listing_id = ? and starts_at = ?
      |limit 1
      |""".stripMargin

  def slotExistsAt(connection: Connection, listingId: ListingId, startsAt: Instant): IO[Boolean] =
    JdbcResources.select(connection, slotExistsAtSql) { statement =>
      statement.setObject(1, listingId.value)
      statement.setTimestamp(2, Timestamp.from(startsAt))
    }(_.next())

  private val listingIdForSlotSql: String =
    """
      |select listing_id
      |from inspection_slots
      |where id = ?
      |""".stripMargin

  def listingIdForSlot(connection: Connection, slotId: InspectionSlotId): IO[AppResult[ListingId]] =
    JdbcResources.select(connection, listingIdForSlotSql) { statement =>
      statement.setObject(1, slotId.value)
    } { resultSet =>
      if resultSet.next() then Right(ListingId(resultSet.getObject("listing_id", classOf[UUID])))
      else Left(AppError.NotFound("Inspection slot not found"))
    }

  private val deleteSlotSql: String =
    """
      |delete from inspection_slots
      |where id = ?
      |  and agent_id = ?
      |  and starts_at > now()
      |""".stripMargin

  def deleteSlot(connection: Connection, agentId: UserId, slotId: InspectionSlotId): IO[Int] =
    JdbcResources.update(connection, deleteSlotSql) { statement =>
      statement.setObject(1, slotId.value)
      statement.setObject(2, agentId.value)
      statement.executeUpdate()
    }

  private val cancellationNoticeForSlotSql: String =
    """
      |select s.listing_id, s.agent_id, s.starts_at, b.buyer_id
      |from inspection_slots s
      |join inspection_bookings b on b.slot_id = s.id
      |where s.id = ? and s.agent_id = ?
      |""".stripMargin

  def cancellationNoticeForSlot(
    connection: Connection,
    agentId: UserId,
    slotId: InspectionSlotId
  ): IO[AppResult[Option[CancelledInspectionNotice]]] =
    JdbcResources.select(connection, cancellationNoticeForSlotSql) { statement =>
      statement.setObject(1, slotId.value)
      statement.setObject(2, agentId.value)
    } { resultSet =>
      if resultSet.next() then
        for
          listingId <- DbCodec.requiredUuid(resultSet, "listing_id")
          rowAgentId <- DbCodec.requiredUuid(resultSet, "agent_id")
          buyerId <- DbCodec.requiredUuid(resultSet, "buyer_id")
          startsAt <- DbCodec.requiredInstant(resultSet, "starts_at")
        yield Some(CancelledInspectionNotice(
          listingId = ListingId(listingId),
          agentId = UserId(rowAgentId),
          buyerId = UserId(buyerId),
          startsAt = startsAt
        ))
      else Right(None)
    }

  private val bookedConversationTargetSql: String =
    """
      |select s.listing_id, b.buyer_id
      |from inspection_slots s
      |join inspection_bookings b on b.slot_id = s.id
      |where s.id = ? and s.agent_id = ?
      |""".stripMargin

  def bookedConversationTarget(
    connection: Connection,
    agentId: UserId,
    slotId: InspectionSlotId
  ): IO[AppResult[Option[BookedInspectionConversationTarget]]] =
    JdbcResources.select(connection, bookedConversationTargetSql) { statement =>
      statement.setObject(1, slotId.value)
      statement.setObject(2, agentId.value)
    } { resultSet =>
      if resultSet.next() then
        for
          listingId <- DbCodec.requiredUuid(resultSet, "listing_id")
          buyerId <- DbCodec.requiredUuid(resultSet, "buyer_id")
        yield Some(BookedInspectionConversationTarget(ListingId(listingId), UserId(buyerId)))
      else Right(None)
    }

  private def readAgentSlots(resultSet: ResultSet): AppResult[List[AgentInspectionSlotRecord]] =
    Iterator
      .continually(resultSet.next())
      .takeWhile(Predef.identity)
      .map(_ =>
        for
          slotId <- DbCodec.requiredUuid(resultSet, "id")
          listingId <- DbCodec.requiredUuid(resultSet, "listing_id")
          startsAt <- DbCodec.requiredInstant(resultSet, "starts_at")
          endsAt <- DbCodec.requiredInstant(resultSet, "ends_at")
          bookingId = Option(resultSet.getObject("booking_id", classOf[UUID])).map(InspectionBookingId(_))
          bookedAt = Option(resultSet.getTimestamp("booked_at")).map(_.toInstant)
          buyerId = Option(resultSet.getObject("buyer_id", classOf[UUID])).map(UserId(_))
        yield AgentInspectionSlotRecord(
          id = InspectionSlotId(slotId),
          listingId = ListingId(listingId),
          startsAt = startsAt,
          endsAt = endsAt,
          bookingId = bookingId,
          bookedAt = bookedAt,
          buyerId = buyerId
        )
      )
      .foldRight(Right(Nil): AppResult[List[AgentInspectionSlotRecord]])((next, acc) =>
        for
          head <- next
          tail <- acc
        yield head :: tail
      )
