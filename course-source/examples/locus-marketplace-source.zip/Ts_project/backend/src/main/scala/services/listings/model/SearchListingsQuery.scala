package listings.model


final case class SearchListingsQuery(
  query: Option[String],
  transactionType: Option[TransactionType],
  listingStatuses: List[ListingStatus],
  propertyTypes: List[PropertyType],
  houseSubtypes: List[HouseSubtype],
  apartmentSubtypes: List[ApartmentSubtype],
  minPrice: Option[Int],
  maxPrice: Option[Int],
  minFloorSize: Option[Int],
  maxFloorSize: Option[Int],
  minLandSize: Option[Int],
  maxLandSize: Option[Int],
  bedrooms: Option[Int],
  bathrooms: Option[Int],
  carSpaces: Option[Int],
  sort: ListingSort,
  limit: Int
)
