package listings.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.effect.IO
import cats.data.EitherT
import identity.api.IdentityPublicApi
import listings.api.requests.ArchiveManagedListingRequest
import listings.api.responses.ArchiveManagedListingResponse
import listings.tables.listing_records.AgentListingsTable
import shared.{AppError, AppResult, RuntimeValues}
import shared.AuthenticatedPrincipal
import listings.model.ListingStatus

import java.sql.Connection

object ArchiveManagedListingApiMessage
    extends ApiWithTokenMessage[ArchiveManagedListingRequest, ArchiveManagedListingResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(
    request: ArchiveManagedListingRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[ArchiveManagedListingResponse]] =
    (
      for
        updatedAt <- EitherT.right[AppError](RuntimeValues.now)
        rowsUpdated <- EitherT.right[AppError](
          AgentListingsTable.archiveListing(connection, principal.userId, request.listingId, updatedAt)
        )
        _ <- EitherT.cond[IO](rowsUpdated > 0, (), AppError.NotFound("Listing not found"))
      yield ArchiveManagedListingResponse(request.listingId, ListingStatus.Archived)
    ).value
