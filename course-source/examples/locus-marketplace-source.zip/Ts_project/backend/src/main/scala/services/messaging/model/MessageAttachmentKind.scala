package messaging.model


import io.circe.{Decoder, Encoder}

enum MessageAttachmentKind:
  case Image, File

object MessageAttachmentKind:
  def toString(kind: MessageAttachmentKind): String =
    kind match
      case Image => "image"
      case File => "file"

  def fromString(value: String): Either[String, MessageAttachmentKind] =
    value match
      case "image" => Right(Image)
      case "file" => Right(File)
      case other => Left(s"Invalid attachment kind: $other")

  given Encoder[MessageAttachmentKind] = Encoder.encodeString.contramap(toString)
  given Decoder[MessageAttachmentKind] = Decoder.decodeString.emap(fromString)
