package identity.api.responses
import identity.model.*


import io.circe.Encoder
import identity.model.User

final case class AuthenticateIdentityResponse(
  user: User
)

object AuthenticateIdentityResponse:
  given Encoder[AuthenticateIdentityResponse] =
    Encoder.forProduct1("user")(_.user)
