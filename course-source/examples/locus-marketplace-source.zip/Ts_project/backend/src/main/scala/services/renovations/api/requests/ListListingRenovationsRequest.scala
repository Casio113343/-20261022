package renovations.api.requests

import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.ListingId

final case class ListListingRenovationsRequest(listingId: ListingId)

object ListListingRenovationsRequest:
  given Decoder[ListListingRenovationsRequest] = deriveDecoder[ListListingRenovationsRequest]
