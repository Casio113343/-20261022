package shared

import cats.effect.IO
import cats.effect.kernel.Ref

import scala.concurrent.duration.*

final class ApiRateLimiter private (
  state: Ref[IO, Map[ApiRateLimiter.Key, ApiRateLimiter.Window]]
):

  import ApiRateLimiter.*

  def allow(clientKey: String, serviceName: String, apiName: String): IO[Boolean] =
    val limit = limitFor(serviceName, apiName)

    nowMillis.flatMap(currentTime =>
      state.modify { windows =>
        val key = Key(clientKey, serviceName, apiName)
        val current = windows.get(key)
        val nextWindow =
          current match
            case Some(window) if currentTime - window.startedAtMillis < limit.window.toMillis =>
              Window(window.startedAtMillis, window.count + 1)
            case _ =>
              Window(currentTime, 1)

        val retainedWindows =
          windows.filter { case (_, window) => currentTime - window.startedAtMillis < MaxRetainedWindow.toMillis }

        (retainedWindows + (key -> nextWindow), nextWindow.count <= limit.maxRequests)
      }
    )

object ApiRateLimiter:

  final case class Key(clientKey: String, serviceName: String, apiName: String)
  final case class Window(startedAtMillis: Long, count: Int)
  final case class Limit(maxRequests: Int, window: FiniteDuration)

  private val MaxRetainedWindow = 10.minutes

  def create: IO[ApiRateLimiter] =
    Ref.of[IO, Map[Key, Window]](Map.empty).map(ApiRateLimiter(_))

  private def nowMillis: IO[Long] =
    IO.realTime.map(_.toMillis)

  private def limitFor(serviceName: String, apiName: String): Limit =
    (serviceName, apiName) match
      case ("identity", "authenticate-identity") => Limit(10, 1.minute)
      case ("identity", "register-identity") => Limit(5, 10.minutes)
      case ("identity", "register-with-profile-picture") => Limit(5, 10.minutes)
      case ("fengshui", "analyse-floor-plan") => Limit(5, 10.minutes)
      case ("amenities", _) => Limit(120, 1.minute)
      case (_, api) if api.contains("upload") => Limit(30, 10.minutes)
      case ("messaging", "start-conversation") => Limit(60, 1.minute)
      case _ => Limit(300, 1.minute)
