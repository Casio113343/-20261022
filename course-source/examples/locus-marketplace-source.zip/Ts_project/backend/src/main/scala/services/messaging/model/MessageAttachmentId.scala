package messaging.model


import io.circe.{Decoder, Encoder}

import java.util.UUID
import scala.util.Try

final case class MessageAttachmentId(value: UUID)

object MessageAttachmentId:
  given Encoder[MessageAttachmentId] = Encoder.encodeString.contramap(_.value.toString)
  given Decoder[MessageAttachmentId] = Decoder.decodeString.emap(parseUuid(_, "attachmentId").map(MessageAttachmentId(_)))

  private def parseUuid(value: String, label: String): Either[String, UUID] =
    Try(UUID.fromString(value)).toEither.left.map(_ => s"Invalid $label")
