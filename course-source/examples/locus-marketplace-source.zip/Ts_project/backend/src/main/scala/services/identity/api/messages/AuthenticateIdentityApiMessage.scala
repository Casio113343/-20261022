package identity.api.messages
import identity.model.*


import shared.{ApiTransaction, JsonApiMessage, SessionCreatedResponse}
import cats.effect.IO
import identity.api.requests.AuthenticateIdentityRequest
import identity.api.responses.AuthenticateIdentityResponse
import identity.application.IdentityApplication
import shared.AppResult
import identity.model.SignInCredentials
import shared.ListingMediaStorage

import java.sql.Connection

final case class AuthenticateIdentityApiMessage(storage: ListingMediaStorage)
    extends JsonApiMessage[AuthenticateIdentityRequest, SessionCreatedResponse[AuthenticateIdentityResponse]]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: AuthenticateIdentityRequest,
    connection: Connection
  ): IO[AppResult[SessionCreatedResponse[AuthenticateIdentityResponse]]] =
    IdentityApplication
      .signIn(connection, SignInCredentials(request.email, request.password))
      .map(_.map(session =>
        SessionCreatedResponse(
          body = AuthenticateIdentityResponse(
            user = IdentityApplication.resolveAvatarUrl(storage)(session.user)
          ),
          sessionToken = session.sessionToken,
          csrfToken = session.csrfToken
        )
      ))
