package inspections.tables
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import cats.effect.IO
import _root_.inspections.tables.inspection_bookings.InspectionBookingsTable
import _root_.inspections.tables.inspection_slots.InspectionSlotsTable

import java.sql.Connection

object InspectionsSchema:

  def initialize(connection: Connection): IO[Unit] =
    List[Connection => IO[Unit]](
      InspectionSlotsTable.initialize,
      InspectionBookingsTable.initialize
    ).foldLeft(IO.unit)((program, initializeTable) => program *> initializeTable(connection))
