package inspections.api.responses
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import inspections.model.PublicInspectionSlot
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class BookInspectionSlotResponse(slot: PublicInspectionSlot)

object BookInspectionSlotResponse:
  given Encoder[BookInspectionSlotResponse] = deriveEncoder[BookInspectionSlotResponse]
