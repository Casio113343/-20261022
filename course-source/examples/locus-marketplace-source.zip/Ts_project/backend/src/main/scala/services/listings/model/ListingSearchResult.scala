package listings.model

final case class ListingSearchResult(
  listings: List[ListingSummary],
  total: Int
)
