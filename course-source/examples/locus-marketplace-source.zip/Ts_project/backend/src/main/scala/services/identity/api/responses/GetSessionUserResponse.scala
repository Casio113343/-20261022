package identity.api.responses
import identity.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder
import identity.model.User

final case class GetSessionUserResponse(
  user: User
)

object GetSessionUserResponse:
  given Encoder[GetSessionUserResponse] = deriveEncoder[GetSessionUserResponse]
