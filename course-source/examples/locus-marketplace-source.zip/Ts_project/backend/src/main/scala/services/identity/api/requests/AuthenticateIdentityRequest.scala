package identity.api.requests
import identity.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder

final case class AuthenticateIdentityRequest(
  email: String,
  password: String
)

object AuthenticateIdentityRequest:
  given Decoder[AuthenticateIdentityRequest] = deriveDecoder[AuthenticateIdentityRequest]
