package identity.model


import io.circe.{Decoder, Encoder}

enum UserRole:
  case BuyerRenter
  case AgentAdmin

object UserRole:
  def fromString(value: String): Either[String, UserRole] =
    value.trim.toLowerCase match
      case "buyer_renter" => Right(UserRole.BuyerRenter)
      case "agent_admin" => Right(UserRole.AgentAdmin)
      case other => Left(s"Unsupported user role: $other")

  def toString(role: UserRole): String =
    role match
      case UserRole.BuyerRenter => "buyer_renter"
      case UserRole.AgentAdmin => "agent_admin"

  given Encoder[UserRole] = Encoder.encodeString.contramap(toString)
  given Decoder[UserRole] = Decoder.decodeString.emap(fromString)
