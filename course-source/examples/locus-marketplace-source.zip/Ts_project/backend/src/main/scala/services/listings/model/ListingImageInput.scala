package listings.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class ListingImageInput(
  id: ListingImageId,
  altText: Option[String],
  isFloorPlan: Boolean
)

object ListingImageInput:
  given Encoder[ListingImageInput] = deriveEncoder[ListingImageInput]
  given Decoder[ListingImageInput] = deriveDecoder[ListingImageInput]
