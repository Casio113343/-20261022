package listings.model

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class ListingAgentSummary(
  id: String,
  fullName: String,
  agencyName: String,
  phone: String,
  avatarUrl: Option[String]
)

object ListingAgentSummary:
  given Encoder[ListingAgentSummary] = deriveEncoder[ListingAgentSummary]
  given Decoder[ListingAgentSummary] = deriveDecoder[ListingAgentSummary]
