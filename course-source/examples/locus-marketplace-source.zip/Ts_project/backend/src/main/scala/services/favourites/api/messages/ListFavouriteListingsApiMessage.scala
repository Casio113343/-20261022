package favourites.api.messages
import identity.model.*
import listings.model.*

import shared.{ApiTransaction, NoRequestWithTokenMessage}
import cats.effect.IO
import favourites.api.responses.ListFavouriteListingsResponse
import favourites.tables.favourite_records.FavouritesTable
import listings.api.ListingsPublicApi
import shared.AppResult
import shared.AuthenticatedPrincipal
import shared.ListingMediaStorage

import java.sql.Connection

final case class ListFavouriteListingsApiMessage(storage: ListingMediaStorage)
    extends NoRequestWithTokenMessage[ListFavouriteListingsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(principal: AuthenticatedPrincipal, connection: Connection): IO[AppResult[ListFavouriteListingsResponse]] =
    FavouritesTable.listFavouriteListingIds(connection, principal.userId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(listingIds) =>
        ListingsPublicApi
          .findPublicSummaries(connection, storage, listingIds)
          .map(_.map(ListFavouriteListingsResponse.apply))
    }
