package fengshui.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class FengshuiOrientation(
  direction: String,
  confidence: FengshuiCompassConfidence,
  evidence: String
)

object FengshuiOrientation:
  given Encoder[FengshuiOrientation] = deriveEncoder[FengshuiOrientation]
  given Decoder[FengshuiOrientation] = deriveDecoder[FengshuiOrientation]
