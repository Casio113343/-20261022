package renovations.model

import io.circe.{Decoder, Encoder}

enum RenovationStatus:
  case Pending
  case Processing
  case Completed
  case Failed

object RenovationStatus:
  def fromString(value: String): Either[String, RenovationStatus] =
    value.trim.toLowerCase match
      case "pending" => Right(RenovationStatus.Pending)
      case "processing" => Right(RenovationStatus.Processing)
      case "completed" => Right(RenovationStatus.Completed)
      case "failed" => Right(RenovationStatus.Failed)
      case other => Left(s"Unsupported renovation status: $other")

  def toString(status: RenovationStatus): String =
    status match
      case RenovationStatus.Pending => "pending"
      case RenovationStatus.Processing => "processing"
      case RenovationStatus.Completed => "completed"
      case RenovationStatus.Failed => "failed"

  given Encoder[RenovationStatus] = Encoder.encodeString.contramap(toString)
  given Decoder[RenovationStatus] = Decoder.decodeString.emap(fromString)
