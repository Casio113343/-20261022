package renovations.clients

final case class GeneratedRenovation(
  bytes: Array[Byte],
  contentType: String
)
