package media.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.AfterCommitApiWithTokenMessage
import cats.effect.IO
import database.TransactionSuccess
import identity.api.IdentityPublicApi
import shared.{AppError, AppResult}
import shared.AuthenticatedPrincipal
import media.api.requests.DeleteManagedListingImageRequest
import media.api.responses.DeleteManagedListingImageResponse
import media.tables.property_images.PropertyImagesTable
import shared.ListingMediaStorage

import java.sql.Connection

final case class DeleteManagedListingImageApiMessage(storage: ListingMediaStorage)
    extends AfterCommitApiWithTokenMessage[DeleteManagedListingImageRequest, DeleteManagedListingImageResponse]:


  override protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    IdentityPublicApi.requireAgent(principal)

  override def plan(
    request: DeleteManagedListingImageRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[TransactionSuccess[DeleteManagedListingImageResponse]]] =
    PropertyImagesTable.deleteUnattachedImage(connection, request.imageId, principal.userId).map {
      case Left(error) => Left(error)
      case Right(None) => Left(AppError.NotFound("Uploaded image not found"))
      case Right(Some(record)) =>
        Right(
          TransactionSuccess(
            value = DeleteManagedListingImageResponse(deleted = true),
            afterCommit = storage.deleteObject(record.objectKey)
          )
        )
    }
