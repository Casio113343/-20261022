package messaging.model


import identity.model.AgentSummary
import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import listings.model.ConversationListingSummary
import shared.TimeCodecs

import java.time.Instant

import TimeCodecs.given

final case class ConversationSummary(
  id: ConversationId,
  listing: ConversationListingSummary,
  buyer: AgentSummary,
  agent: AgentSummary,
  lastMessage: Option[ConversationMessage],
  unreadCount: Int,
  updatedAt: Instant
)

object ConversationSummary:
  given Encoder[ConversationSummary] = deriveEncoder[ConversationSummary]
  given Decoder[ConversationSummary] = deriveDecoder[ConversationSummary]
