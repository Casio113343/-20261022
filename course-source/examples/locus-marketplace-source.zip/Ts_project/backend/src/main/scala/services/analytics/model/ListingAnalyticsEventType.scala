package analytics.model

import io.circe.{Decoder, Encoder}

enum ListingAnalyticsEventType:
  case ListingView
  case SearchImpression
  case SearchClick
  case Favourite
  case MessageStart
  case InspectionRequest
  case PhotoOpen
  case AmenityInterest

object ListingAnalyticsEventType:

  def toString(value: ListingAnalyticsEventType): String =
    value match
      case ListingAnalyticsEventType.ListingView => "listing_view"
      case ListingAnalyticsEventType.SearchImpression => "search_impression"
      case ListingAnalyticsEventType.SearchClick => "search_click"
      case ListingAnalyticsEventType.Favourite => "favourite"
      case ListingAnalyticsEventType.MessageStart => "message_start"
      case ListingAnalyticsEventType.InspectionRequest => "inspection_request"
      case ListingAnalyticsEventType.PhotoOpen => "photo_open"
      case ListingAnalyticsEventType.AmenityInterest => "amenity_interest"

  def fromString(value: String): Either[String, ListingAnalyticsEventType] =
    value.trim.toLowerCase match
      case "listing_view" => Right(ListingAnalyticsEventType.ListingView)
      case "search_impression" => Right(ListingAnalyticsEventType.SearchImpression)
      case "search_click" => Right(ListingAnalyticsEventType.SearchClick)
      case "favourite" => Right(ListingAnalyticsEventType.Favourite)
      case "message_start" => Right(ListingAnalyticsEventType.MessageStart)
      case "inspection_request" => Right(ListingAnalyticsEventType.InspectionRequest)
      case "photo_open" => Right(ListingAnalyticsEventType.PhotoOpen)
      case "amenity_interest" => Right(ListingAnalyticsEventType.AmenityInterest)
      case other => Left(s"Unknown listing analytics event type: $other")

  given Encoder[ListingAnalyticsEventType] =
    Encoder.encodeString.contramap(toString)

  given Decoder[ListingAnalyticsEventType] =
    Decoder.decodeString.emap(fromString)
