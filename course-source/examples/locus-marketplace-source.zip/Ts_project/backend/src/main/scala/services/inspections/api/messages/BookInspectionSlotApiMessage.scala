package inspections.api.messages
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import inspections.api.requests.BookInspectionSlotRequest
import inspections.api.responses.BookInspectionSlotResponse
import inspections.application.InspectionApplication
import inspections.model.{InspectionBookingId, InspectionSlotId}
import inspections.tables.inspection_bookings.InspectionBookingsTable
import shared.{AppError, AppResult, RuntimeValues}
import shared.AuthenticatedPrincipal

import java.sql.Connection

object BookInspectionSlotApiMessage
    extends ApiWithTokenMessage[BookInspectionSlotRequest, BookInspectionSlotResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: BookInspectionSlotRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[BookInspectionSlotResponse]] =
    (
      for
        bookingId <- EitherT.right[AppError](RuntimeValues.uuid.map(InspectionBookingId(_)))
        now <- EitherT.right[AppError](RuntimeValues.now)
        rows <- EitherT.right[AppError](InspectionBookingsTable.bookSlot(connection, bookingId, principal.userId, request.slotId, now))
        _ <- EitherT.cond[IO](rows > 0, (), AppError.Conflict("This inspection slot is no longer available"))
        slot <- EitherT(InspectionApplication.findPublicSlot(connection, request.slotId, principal.userId))
      yield BookInspectionSlotResponse(slot)
    ).value
