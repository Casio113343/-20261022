package identity.api.requests
import identity.model.*


final case class UploadProfilePictureRequest(
  fileName: String,
  contentType: String,
  bytes: Array[Byte]
)
