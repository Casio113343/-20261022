package listings.api.requests
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import listings.model.{ListingId, ListingWrite}

final case class SaveManagedListingRequest(
  listingId: Option[ListingId],
  listing: ListingWrite
)

object SaveManagedListingRequest:
  given Decoder[SaveManagedListingRequest] = deriveDecoder[SaveManagedListingRequest]
