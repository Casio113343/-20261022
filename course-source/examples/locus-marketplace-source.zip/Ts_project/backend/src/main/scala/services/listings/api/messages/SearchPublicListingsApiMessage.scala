package listings.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.{ApiTransaction, JsonApiMessage}
import cats.effect.IO
import listings.api.requests.SearchPublicListingsRequest
import listings.api.responses.SearchPublicListingsResponse
import listings.application.ListingApplication
import shared.AppResult
import listings.model.{ListingSort, SearchListingsQuery}
import shared.ListingMediaStorage

import java.sql.Connection

final case class SearchPublicListingsApiMessage(storage: ListingMediaStorage)
    extends JsonApiMessage[SearchPublicListingsRequest, SearchPublicListingsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(
    request: SearchPublicListingsRequest,
    connection: Connection
  ): IO[AppResult[SearchPublicListingsResponse]] =
    ListingApplication
      .search(connection, storage, searchQueryFrom(request))
      .map(_.map(response => SearchPublicListingsResponse(response.listings, response.total)))

  private def searchQueryFrom(request: SearchPublicListingsRequest): SearchListingsQuery =
    SearchListingsQuery(
      query = request.query.map(_.trim).filter(_.nonEmpty),
      transactionType = request.transactionType,
      listingStatuses = request.listingStatuses,
      propertyTypes = request.propertyTypes,
      houseSubtypes = request.houseSubtypes,
      apartmentSubtypes = request.apartmentSubtypes,
      minPrice = request.minPrice,
      maxPrice = request.maxPrice,
      minFloorSize = request.minFloorSize,
      maxFloorSize = request.maxFloorSize,
      minLandSize = request.minLandSize,
      maxLandSize = request.maxLandSize,
      bedrooms = request.bedrooms,
      bathrooms = request.bathrooms,
      carSpaces = request.carSpaces,
      sort = request.sort.getOrElse(ListingSort.Newest),
      limit = request.limit.map(_.min(60).max(1)).getOrElse(24)
    )
