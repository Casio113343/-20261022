package favourites.api.messages
import identity.model.*
import listings.model.*

import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.data.EitherT
import cats.effect.IO
import favourites.api.requests.SetFavouriteListingRequest
import favourites.api.responses.SetFavouriteListingResponse
import favourites.tables.favourite_records.FavouritesTable
import listings.api.ListingsPublicApi
import shared.{AppError, AppResult}
import shared.AuthenticatedPrincipal
import shared.ListingMediaStorage

import java.sql.Connection

final case class SetFavouriteListingApiMessage(storage: ListingMediaStorage)
    extends ApiWithTokenMessage[SetFavouriteListingRequest, SetFavouriteListingResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: SetFavouriteListingRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[SetFavouriteListingResponse]] =
    val updateProgram =
      if request.saved then
        (
          for
            listing <- EitherT(ListingsPublicApi.findPublicDetail(connection, storage, request.listingId))
            _ <- EitherT.fromOption[IO](listing, AppError.NotFound("Listing not found"))
            _ <- EitherT(FavouritesTable.saveFavourite(connection, principal.userId, request.listingId))
          yield ()
        ).value
      else FavouritesTable.removeFavourite(connection, principal.userId, request.listingId)

    updateProgram.map(_.map(_ => SetFavouriteListingResponse(request.listingId, request.saved)))
