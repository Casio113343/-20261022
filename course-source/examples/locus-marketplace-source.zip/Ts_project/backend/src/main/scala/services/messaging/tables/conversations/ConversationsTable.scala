package messaging.tables.conversations
import identity.model.*
import listings.model.*
import messaging.model.*

import cats.effect.IO
import shared.*

import java.sql.{Connection, ResultSet, Timestamp}
import java.time.Instant
import java.util.UUID

private[messaging] object ConversationsTable:

  final case class ConversationRecord(
    id: ConversationId,
    listingId: ListingId,
    buyerId: UserId,
    agentId: UserId,
    unreadCount: Int,
    updatedAt: Instant
  )

  final case class ConversationIntroMetadata(
    agentId: UserId,
    listingId: ListingId,
    createdAt: Instant
  )

  private val createSql: String =
    """
      |create table if not exists conversations (
      |  id uuid primary key,
      |  listing_id uuid not null references listings(id) on delete cascade,
      |  buyer_id uuid not null references users(id) on delete cascade,
      |  agent_id uuid not null references users(id) on delete cascade,
      |  created_at timestamptz not null,
      |  updated_at timestamptz not null,
      |  last_message_at timestamptz not null,
      |  unique (listing_id, buyer_id)
      |);
      |create index if not exists conversations_buyer_idx on conversations(buyer_id, updated_at);
      |create index if not exists conversations_agent_idx on conversations(agent_id, updated_at);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql))

  private val conversationSelectSql: String =
    """
      |select c.id, c.listing_id, c.buyer_id, c.agent_id, c.updated_at,
      |       (
      |         select count(*)
      |         from conversation_messages unread
      |         where unread.conversation_id = c.id and unread.sender_id <> ? and unread.seen_at is null
      |       ) as unread_count
      |from conversations c
      |""".stripMargin

  private val findForUserSql: String =
    s"""
       |${conversationSelectSql}
       |where c.id = ?
       |  and (c.buyer_id = ? or c.agent_id = ?)
       |""".stripMargin

  def findForUser(
    connection: Connection,
    conversationId: ConversationId,
    userId: UserId
  ): IO[AppResult[Option[ConversationRecord]]] =
    query(connection, findForUserSql, statement => {
      statement.setObject(1, userId.value)
      statement.setObject(2, conversationId.value)
      statement.setObject(3, userId.value)
      statement.setObject(4, userId.value)
    }).map(_.map(_.headOption))

  private val listForUserSql: String =
    s"""
       |${conversationSelectSql}
       |where c.buyer_id = ? or c.agent_id = ?
       |order by c.updated_at desc
       |""".stripMargin

  def listForUser(connection: Connection, userId: UserId): IO[AppResult[List[ConversationRecord]]] =
    query(connection, listForUserSql, statement => {
      statement.setObject(1, userId.value)
      statement.setObject(2, userId.value)
      statement.setObject(3, userId.value)
    })

  private val findByListingAndBuyerSql: String =
    s"""
       |${conversationSelectSql}
       |where c.listing_id = ?
       |  and c.buyer_id = ?
       |""".stripMargin

  def findByListingAndBuyer(
    connection: Connection,
    listingId: ListingId,
    buyerId: UserId
  ): IO[AppResult[Option[ConversationRecord]]] =
    query(connection, findByListingAndBuyerSql, statement => {
      statement.setObject(1, buyerId.value)
      statement.setObject(2, listingId.value)
      statement.setObject(3, buyerId.value)
    }).map(_.map(_.headOption))

  private val insertConversationSql: String =
    """
      |insert into conversations (id, listing_id, buyer_id, agent_id, created_at, updated_at, last_message_at)
      |values (?, ?, ?, ?, ?, ?, ?)
      |""".stripMargin

  def insert(
    connection: Connection,
    conversationId: ConversationId,
    listingId: ListingId,
    buyerId: UserId,
    agentId: UserId,
    createdAt: Instant
  ): IO[Unit] =
    JdbcResources.update(connection, insertConversationSql) { statement =>
      statement.setObject(1, conversationId.value)
      statement.setObject(2, listingId.value)
      statement.setObject(3, buyerId.value)
      statement.setObject(4, agentId.value)
      statement.setTimestamp(5, Timestamp.from(createdAt))
      statement.setTimestamp(6, Timestamp.from(createdAt))
      statement.setTimestamp(7, Timestamp.from(createdAt))
      statement.executeUpdate()
    }.void

  private val upsertConversationSql: String =
    """
      |insert into conversations (id, listing_id, buyer_id, agent_id, created_at, updated_at, last_message_at)
      |values (?, ?, ?, ?, ?, ?, ?)
      |on conflict (listing_id, buyer_id) do update
      |set updated_at = excluded.updated_at,
      |    last_message_at = excluded.last_message_at
      |returning id
      |""".stripMargin

  def upsert(
    connection: Connection,
    conversationId: ConversationId,
    listingId: ListingId,
    buyerId: UserId,
    agentId: UserId,
    occurredAt: Instant
  ): IO[AppResult[ConversationId]] =
    JdbcResources.select(connection, upsertConversationSql) { statement =>
      statement.setObject(1, conversationId.value)
      statement.setObject(2, listingId.value)
      statement.setObject(3, buyerId.value)
      statement.setObject(4, agentId.value)
      statement.setTimestamp(5, Timestamp.from(occurredAt))
      statement.setTimestamp(6, Timestamp.from(occurredAt))
      statement.setTimestamp(7, Timestamp.from(occurredAt))
    } { resultSet =>
      if resultSet.next() then Right(ConversationId(resultSet.getObject("id", classOf[UUID])))
      else Left(AppError.Unexpected("Conversation could not be created"))
    }

  private val touchSql: String =
    "update conversations set updated_at = ?, last_message_at = ? where id = ?"

  def touch(connection: Connection, conversationId: ConversationId, occurredAt: Instant): IO[Unit] =
    JdbcResources.update(connection, touchSql) { statement =>
      statement.setTimestamp(1, Timestamp.from(occurredAt))
      statement.setTimestamp(2, Timestamp.from(occurredAt))
      statement.setObject(3, conversationId.value)
      statement.executeUpdate()
    }.void

  private val findIntroMetadataSql: String =
    """
      |select agent_id, listing_id, created_at
      |from conversations
      |where id = ?
      |""".stripMargin

  def findIntroMetadata(
    connection: Connection,
    conversationId: ConversationId
  ): IO[AppResult[Option[ConversationIntroMetadata]]] =
    JdbcResources.select(connection, findIntroMetadataSql) { statement =>
      statement.setObject(1, conversationId.value)
    } { resultSet =>
      if resultSet.next() then
        for
          agentId <- DbCodec.requiredUuid(resultSet, "agent_id")
          listingId <- DbCodec.requiredUuid(resultSet, "listing_id")
          createdAt <- DbCodec.requiredInstant(resultSet, "created_at")
        yield Some(ConversationIntroMetadata(UserId(agentId), ListingId(listingId), createdAt))
      else Right(None)
    }

  private def query(
    connection: Connection,
    sql: String,
    bind: java.sql.PreparedStatement => Unit
  ): IO[AppResult[List[ConversationRecord]]] =
    JdbcResources.select(connection, sql)(bind) { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => readConversationRecord(resultSet))
        .foldRight(Right(Nil): AppResult[List[ConversationRecord]])((next, acc) =>
          for
            head <- next
            tail <- acc
          yield head :: tail
        )
    }

  private def readConversationRecord(resultSet: ResultSet): AppResult[ConversationRecord] =
    Right(ConversationRecord(
      id = ConversationId(resultSet.getObject("id", classOf[UUID])),
      listingId = ListingId(resultSet.getObject("listing_id", classOf[UUID])),
      buyerId = UserId(resultSet.getObject("buyer_id", classOf[UUID])),
      agentId = UserId(resultSet.getObject("agent_id", classOf[UUID])),
      unreadCount = resultSet.getInt("unread_count"),
      updatedAt = resultSet.getTimestamp("updated_at").toInstant
    ))
