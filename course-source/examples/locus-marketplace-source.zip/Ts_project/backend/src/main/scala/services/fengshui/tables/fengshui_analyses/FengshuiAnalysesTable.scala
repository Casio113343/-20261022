package fengshui.tables.fengshui_analyses
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import cats.syntax.functor.*
import fengshui.model.FengshuiAnalysis
import shared.*

import java.sql.Connection
import java.sql.Timestamp
import java.time.Instant

private[fengshui] object FengshuiAnalysesTable:

  final case class SavedAnalysis(
    analysis: FengshuiAnalysis
  )

  private val createSql: String =
    """
      |create table if not exists fengshui_analyses (
      |  user_id uuid not null references users(id) on delete cascade,
      |  listing_id uuid not null references listings(id) on delete cascade,
      |  floor_plan_image_id uuid not null references property_images(id) on delete cascade,
      |  occupants jsonb not null,
      |  analysis jsonb not null,
      |  created_at timestamptz not null,
      |  updated_at timestamptz not null,
      |  primary key (user_id, listing_id)
      |);
      |create index if not exists fengshui_analyses_listing_idx on fengshui_analyses(listing_id, updated_at);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql))

  private val findSavedAnalysisSql: String =
    """
      |select analysis::text
      |from fengshui_analyses
      |where user_id = ? and listing_id = ?
      |""".stripMargin

  def findSavedAnalysis(
    connection: Connection,
    userId: UserId,
    listingId: ListingId
  ): IO[AppResult[Option[SavedAnalysis]]] =
    JdbcResources.select(connection, findSavedAnalysisSql) { statement =>
      statement.setObject(1, userId.value)
      statement.setObject(2, listingId.value)
    } { resultSet =>
      if resultSet.next() then
        for
          analysis <- DbCodec.decodeValue[FengshuiAnalysis](resultSet.getString("analysis"), "fengshui analysis")
        yield Some(SavedAnalysis(analysis))
      else Right(None)
    }

  private val upsertSavedAnalysisSql: String =
    """
      |insert into fengshui_analyses (user_id, listing_id, floor_plan_image_id, occupants, analysis, created_at, updated_at)
      |values (?, ?, ?, '[]'::jsonb, ?::jsonb, ?, ?)
      |on conflict (user_id, listing_id) do update
      |set floor_plan_image_id = excluded.floor_plan_image_id,
      |    occupants = '[]'::jsonb,
      |    analysis = excluded.analysis,
      |    updated_at = excluded.updated_at
      |""".stripMargin

  def upsertSavedAnalysis(
    connection: Connection,
    userId: UserId,
    listingId: ListingId,
    floorPlanImageId: PropertyImageId,
    analysis: FengshuiAnalysis,
    timestamp: Instant
  ): IO[Unit] =
    JdbcResources.update(connection, upsertSavedAnalysisSql) { statement =>
      statement.setObject(1, userId.value)
      statement.setObject(2, listingId.value)
      statement.setObject(3, floorPlanImageId.value)
      DbCodec.setJson(statement, 4, analysis)
      statement.setTimestamp(5, Timestamp.from(timestamp))
      statement.setTimestamp(6, Timestamp.from(timestamp))
      statement.executeUpdate()
    }.void
