package amenities.clients

import amenities.model.*
import cats.effect.IO
import cats.syntax.all.*
import io.circe.{Decoder, Json, parser}
import io.circe.generic.semiauto.deriveDecoder
import io.circe.syntax.*
import org.typelevel.log4cats.slf4j.Slf4jLogger
import shared.{AppError, AppResult}

import java.net.URI
import java.net.http.{HttpClient, HttpRequest, HttpResponse}
import java.time.LocalDate

final case class ResolvedAmenityPhoto(uri: URI)

final class GoogleAmenitiesClient private (
  apiKey: String,
  httpClient: HttpClient
):

  import GoogleAmenitiesClient.*

  def searchNearby(
    location: ListingMapPosition,
    includedTypes: List[String]
  ): IO[AppResult[List[NearbyAmenity]]] =
    val request =
      postJson(
        endpoint = nearbySearchEndpoint,
        fieldMask = nearbySearchFieldMask,
        body = Json.obj(
          "includedTypes" -> includedTypes.asJson,
          "maxResultCount" -> Json.fromInt(20),
          "locationRestriction" -> Json.obj(
            "circle" -> Json.obj(
              "center" -> Json.obj(
                "latitude" -> Json.fromDoubleOrNull(location.lat),
                "longitude" -> Json.fromDoubleOrNull(location.lng)
              ),
              "radius" -> Json.fromInt(3000)
            )
          ),
          "rankPreference" -> Json.fromString("DISTANCE")
        )
      )

    sendString(request, "Unable to load nearby places.")
      .map(_.flatMap(decodeNearbySearch(location, includedTypes)))

  def fetchAmenityDetails(
    origin: ListingMapPosition,
    place: NearbyAmenity
  ): IO[AppResult[(AmenityDetails, List[TravelSummary])]] =
    place.placeResourceName match
      case None => IO.pure(Left(AppError.NotFound("Place details are unavailable for this result.")))
      case Some(resourceName) =>
        validatedPlaceResourceName(resourceName) match
          case Left(error) => IO.pure(Left(error))
          case Right(validResourceName) =>
            (
              fetchPlaceDetails(validResourceName),
              List(TravelMode.Walking, TravelMode.Driving, TravelMode.Transit).parTraverse(fetchTravelSummary(origin, place.location, _))
            ).mapN { (detailsResult, routeResults) =>
              for details <- detailsResult
              yield details -> routeResults.collect { case Right(summary) => summary }
            }

  def resolvePlacePhoto(photoName: String): IO[AppResult[ResolvedAmenityPhoto]] =
    validatedPhotoName(photoName) match
      case Left(error) => IO.pure(Left(error))
      case Right(validName) =>
        val metadataRequest =
          HttpRequest
            .newBuilder(photoMediaMetadataUri(validName))
            .GET()
            .build()

        sendString(metadataRequest, "Unable to load place photo.")
          .flatMap {
            case Left(error) => IO.pure(Left(error))
            case Right(body) =>
              decodeJson[PhotoMediaResponse](body, "Unable to read place photo response.")
                .flatMap(_.photoUri.toRight(AppError.NotFound("Place photo not found.")))
                .flatMap(validatedPhotoUri) match
                case Left(error) => IO.pure(Left(error))
                case Right(photoUri) => IO.pure(Right(ResolvedAmenityPhoto(photoUri)))
          }

  private def photoMediaMetadataUri(photoName: String): URI =
    URI.create(
      s"https://places.googleapis.com/v1/$photoName/media?key=${urlEncode(apiKey)}&maxWidthPx=1200&maxHeightPx=675&skipHttpRedirect=true"
    )

  private def fetchPlaceDetails(resourceName: String): IO[AppResult[AmenityDetails]] =
    val request =
      HttpRequest
        .newBuilder(URI.create(s"https://places.googleapis.com/v1/$resourceName"))
        .header("X-Goog-Api-Key", apiKey)
        .header("X-Goog-FieldMask", placeDetailsFieldMask)
        .GET()
        .build()

    sendString(request, "Unable to load place details.")
      .map(_.flatMap(body => decodeJson[PlaceDetailsResponse](body, "Unable to read place details.").map(toAmenityDetails)))

  private def fetchTravelSummary(
    origin: ListingMapPosition,
    destination: ListingMapPosition,
    mode: TravelMode
  ): IO[AppResult[TravelSummary]] =
    val request =
      postJson(
        endpoint = routesEndpoint,
        fieldMask = routeFieldMask,
        body = Json.obj(
          "origin" -> Json.obj("location" -> Json.obj("latLng" -> latLngJson(origin))),
          "destination" -> Json.obj("location" -> Json.obj("latLng" -> latLngJson(destination))),
          "travelMode" -> Json.fromString(routeMode(mode))
        ).deepMerge(
          mode match
            case TravelMode.Driving => Json.obj("routingPreference" -> Json.fromString("TRAFFIC_AWARE"))
            case _ => Json.obj()
        )
      )

    sendString(request, s"Unable to load ${TravelMode.toString(mode)} time.")
      .map(_.flatMap(body => decodeRoute(body, mode)))

  private def postJson(endpoint: URI, fieldMask: String, body: Json): HttpRequest =
    HttpRequest
      .newBuilder(endpoint)
      .header("Content-Type", "application/json")
      .header("X-Goog-Api-Key", apiKey)
      .header("X-Goog-FieldMask", fieldMask)
      .POST(HttpRequest.BodyPublishers.ofString(body.noSpaces))
      .build()

  private def sendString(request: HttpRequest, failureMessage: String): IO[AppResult[String]] =
    IO.blocking(httpClient.send(request, HttpResponse.BodyHandlers.ofString())).attempt.flatMap {
      case Left(error) =>
        logger.warn(error)(failureMessage).as(Left(AppError.Unexpected(failureMessage)))
      case Right(response) if response.statusCode() / 100 != 2 =>
        logger.warn(s"Google amenities request failed with ${response.statusCode()}: ${response.body()}")
          .as(Left(AppError.Unexpected(failureMessage)))
      case Right(response) =>
        IO.pure(Right(response.body()))
    }

object GoogleAmenitiesClient:

  private val logger = Slf4jLogger.getLogger[IO]

  private val nearbySearchEndpoint =
    URI.create("https://places.googleapis.com/v1/places:searchNearby")

  private val routesEndpoint =
    URI.create("https://routes.googleapis.com/directions/v2:computeRoutes")

  private val nearbySearchFieldMask =
    "places.id,places.name,places.displayName,places.formattedAddress,places.types,places.location,places.photos,places.rating,places.userRatingCount"

  private val placeDetailsFieldMask =
    "businessStatus,currentOpeningHours,googleMapsUri,nationalPhoneNumber,photos,regularOpeningHours,reviews,websiteUri"

  private val routeFieldMask =
    "routes.distanceMeters,routes.duration,routes.polyline.encodedPolyline"

  val configured: IO[Option[GoogleAmenitiesClient]] =
    IO.delay(
      sys.env
        .get("GOOGLE_MAPS_API_KEY")
        .orElse(sys.env.get("GOOGLE_PLACES_API_KEY"))
        .map(_.trim)
        .filter(_.nonEmpty)
    ).flatMap {
      case None => IO.pure(None)
      case Some(configuredApiKey) =>
        IO.delay(
          HttpClient
            .newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build()
        ).map(client => Some(GoogleAmenitiesClient(configuredApiKey, client)))
    }

  private final case class NearbySearchPlaceText(text: Option[String])
  private final case class NearbySearchPlaceLocation(latitude: Option[Double], longitude: Option[Double])
  private final case class GooglePlacePhoto(name: Option[String])

  private final case class NearbySearchPlace(
    id: Option[String],
    name: Option[String],
    displayName: Option[NearbySearchPlaceText],
    formattedAddress: Option[String],
    types: Option[List[String]],
    location: Option[NearbySearchPlaceLocation],
    photos: Option[List[GooglePlacePhoto]],
    rating: Option[Double],
    userRatingCount: Option[Int]
  )

  private final case class NearbySearchResponse(places: Option[List[NearbySearchPlace]])

  private final case class OpeningHours(openNow: Option[Boolean], weekdayDescriptions: Option[List[String]])
  private final case class AuthorAttribution(displayName: Option[String])
  private final case class ReviewText(text: Option[String])
  private final case class PlaceReview(
    authorAttribution: Option[AuthorAttribution],
    originalText: Option[ReviewText],
    rating: Option[Int],
    text: Option[ReviewText]
  )
  private final case class PlaceDetailsResponse(
    businessStatus: Option[String],
    currentOpeningHours: Option[OpeningHours],
    googleMapsUri: Option[String],
    nationalPhoneNumber: Option[String],
    photos: Option[List[GooglePlacePhoto]],
    regularOpeningHours: Option[OpeningHours],
    reviews: Option[List[PlaceReview]],
    websiteUri: Option[String]
  )
  private final case class PhotoMediaResponse(photoUri: Option[String])

  private final case class RoutePolyline(encodedPolyline: Option[String])
  private final case class Route(distanceMeters: Option[Int], duration: Option[String], polyline: Option[RoutePolyline])
  private final case class RouteResponse(routes: Option[List[Route]])

  private given Decoder[NearbySearchPlaceText] = deriveDecoder[NearbySearchPlaceText]
  private given Decoder[NearbySearchPlaceLocation] = deriveDecoder[NearbySearchPlaceLocation]
  private given Decoder[GooglePlacePhoto] = deriveDecoder[GooglePlacePhoto]
  private given Decoder[NearbySearchPlace] = deriveDecoder[NearbySearchPlace]
  private given Decoder[NearbySearchResponse] = deriveDecoder[NearbySearchResponse]
  private given Decoder[OpeningHours] = deriveDecoder[OpeningHours]
  private given Decoder[AuthorAttribution] = deriveDecoder[AuthorAttribution]
  private given Decoder[ReviewText] = deriveDecoder[ReviewText]
  private given Decoder[PlaceReview] = deriveDecoder[PlaceReview]
  private given Decoder[PlaceDetailsResponse] = deriveDecoder[PlaceDetailsResponse]
  private given Decoder[PhotoMediaResponse] = deriveDecoder[PhotoMediaResponse]
  private given Decoder[RoutePolyline] = deriveDecoder[RoutePolyline]
  private given Decoder[Route] = deriveDecoder[Route]
  private given Decoder[RouteResponse] = deriveDecoder[RouteResponse]

  private[clients] def urlEncode(value: String): String =
    java.net.URLEncoder.encode(value, java.nio.charset.StandardCharsets.UTF_8)

  private def decodeNearbySearch(
    listingPosition: ListingMapPosition,
    includedTypes: List[String],
  )(body: String): AppResult[List[NearbyAmenity]] =
    decodeJson[NearbySearchResponse](body, "Unable to read nearby places response.")
      .map(response =>
        mergePlaces(
          response.places
            .getOrElse(Nil)
            .zipWithIndex
            .flatMap { case (place, index) => toAmenity(listingPosition, place, index) }
            .filter(place => place.types.exists(includedTypes.contains))
        )
      )

  private def toAmenity(
    listingPosition: ListingMapPosition,
    place: NearbySearchPlace,
    index: Int
  ): Option[NearbyAmenity] =
    for
      placeLocation <- place.location
      latitude <- placeLocation.latitude
      longitude <- placeLocation.longitude
    yield
      val location = ListingMapPosition(latitude, longitude)
      val fallbackId = s"${place.displayName.flatMap(_.text).getOrElse("place")}-$latitude-$longitude-$index".replaceAll("\\s+", "_")

      NearbyAmenity(
        id = place.id.orElse(place.name).getOrElse(fallbackId),
        placeResourceName = place.name,
        name = place.displayName.flatMap(_.text).getOrElse("Nearby place"),
        address = place.formattedAddress.getOrElse("Address unavailable"),
        photoUrl = place.photos.getOrElse(Nil).flatMap(_.name).headOption.map(AmenityPhotoUrl.fromPlacePhotoName),
        rating = place.rating,
        userRatingCount = place.userRatingCount,
        types = place.types.getOrElse(Nil),
        location = location,
        distanceInMeters = haversineDistanceInMeters(listingPosition, location)
      )

  private def mergePlaces(places: List[NearbyAmenity]): List[NearbyAmenity] =
    places
      .groupBy(_.id)
      .values
      .flatMap(_.sortBy(_.distanceInMeters).headOption)
      .toList
      .sortBy(_.distanceInMeters)
      .take(20)

  private def toAmenityDetails(details: PlaceDetailsResponse): AmenityDetails =
    AmenityDetails(
      businessStatus = details.businessStatus,
      googleMapsUri = details.googleMapsUri,
      nationalPhoneNumber = details.nationalPhoneNumber,
      openingStatus = openingStatus(details),
      photoUrls = details.photos.getOrElse(Nil).flatMap(_.name).map(AmenityPhotoUrl.fromPlacePhotoName),
      reviews = details.reviews.getOrElse(Nil).flatMap(toAmenityReview).take(3),
      todayHours = todayDescription(details.currentOpeningHours.flatMap(_.weekdayDescriptions).orElse(details.regularOpeningHours.flatMap(_.weekdayDescriptions))),
      weekdayDescriptions = details.currentOpeningHours.flatMap(_.weekdayDescriptions).orElse(details.regularOpeningHours.flatMap(_.weekdayDescriptions)).getOrElse(Nil),
      websiteUri = details.websiteUri
    )

  private def toAmenityReview(review: PlaceReview): Option[AmenityReview] =
    review.originalText.flatMap(_.text).orElse(review.text.flatMap(_.text)).map(text =>
      AmenityReview(
        authorName = review.authorAttribution.flatMap(_.displayName).getOrElse("Google reviewer"),
        rating = review.rating,
        text = text
      )
    )

  private def openingStatus(details: PlaceDetailsResponse): Option[String] =
    details.currentOpeningHours.flatMap(_.openNow) match
      case Some(true) => Some("Open now")
      case Some(false) => Some("Closed now")
      case None =>
        details.businessStatus match
          case Some("CLOSED_PERMANENTLY") => Some("Permanently closed")
          case Some("CLOSED_TEMPORARILY") => Some("Temporarily closed")
          case _ => None

  private def todayDescription(descriptions: Option[List[String]]): Option[String] =
    descriptions.flatMap(_.lift(LocalDate.now().getDayOfWeek.getValue % 7))

  private def decodeRoute(body: String, mode: TravelMode): AppResult[TravelSummary] =
    for
      response <- decodeJson[RouteResponse](body, s"Unable to read ${TravelMode.toString(mode)} route.")
      route <- response.routes.flatMap(_.headOption).toRight(AppError.NotFound(s"No ${TravelMode.toString(mode)} route found."))
    yield TravelSummary(
      distanceMeters = route.distanceMeters.getOrElse(0),
      durationLabel = formatDuration(route.duration),
      mode = mode,
      polyline = route.polyline.flatMap(_.encodedPolyline).map(decodePolyline)
    )

  private def latLngJson(position: ListingMapPosition): Json =
    Json.obj(
      "latitude" -> Json.fromDoubleOrNull(position.lat),
      "longitude" -> Json.fromDoubleOrNull(position.lng)
    )

  private def routeMode(mode: TravelMode): String =
    mode match
      case TravelMode.Walking => "WALK"
      case TravelMode.Driving => "DRIVE"
      case TravelMode.Transit => "TRANSIT"

  private def formatDuration(duration: Option[String]): String =
    val seconds = duration.flatMap(_.stripSuffix("s").toIntOption).getOrElse(0)
    val minutes = Math.max(1, Math.round(seconds.toDouble / 60).toInt)

    if minutes >= 60 then s"${minutes / 60} hr ${if minutes % 60 == 0 then "" else s"${minutes % 60} min"}".trim
    else s"$minutes min"

  private def decodePolyline(encoded: String): List[ListingMapPosition] =
    @annotation.tailrec
    def readValue(index: Int, shift: Int, result: Int): (Int, Int) =
      val byte = encoded.charAt(index).toInt - 63
      val nextResult = result | ((byte & 0x1f) << shift)

      if byte < 0x20 then
        val decoded = if (nextResult & 1) == 1 then ~(nextResult >> 1) else nextResult >> 1
        decoded -> (index + 1)
      else readValue(index + 1, shift + 5, nextResult)

    @annotation.tailrec
    def loop(index: Int, lat: Int, lng: Int, points: List[ListingMapPosition]): List[ListingMapPosition] =
      if index >= encoded.length then points.reverse
      else
        val (latDelta, afterLat) = readValue(index, 0, 0)
        val (lngDelta, afterLng) = readValue(afterLat, 0, 0)
        val nextLat = lat + latDelta
        val nextLng = lng + lngDelta
        loop(afterLng, nextLat, nextLng, ListingMapPosition(nextLat.toDouble / 1e5, nextLng.toDouble / 1e5) :: points)

    loop(0, 0, 0, Nil)

  private def haversineDistanceInMeters(
    start: ListingMapPosition,
    destination: ListingMapPosition
  ): Double =
    val earthRadiusInMeters = 6371000
    val latitudeDelta = Math.toRadians(destination.lat - start.lat)
    val longitudeDelta = Math.toRadians(destination.lng - start.lng)
    val startLatitude = Math.toRadians(start.lat)
    val destinationLatitude = Math.toRadians(destination.lat)
    val distanceFactor =
      Math.sin(latitudeDelta / 2) * Math.sin(latitudeDelta / 2) +
        Math.cos(startLatitude) * Math.cos(destinationLatitude) * Math.sin(longitudeDelta / 2) * Math.sin(longitudeDelta / 2)

    2 * earthRadiusInMeters * Math.atan2(Math.sqrt(distanceFactor), Math.sqrt(1 - distanceFactor))

  private def decodeJson[A: Decoder](body: String, failureMessage: String): AppResult[A] =
    parser.decode[A](body).left.map(_ => AppError.Decoding(failureMessage))

  private def validatedPhotoName(photoName: String): AppResult[String] =
    Option(photoName.trim)
      .filter(_.startsWith("places/"))
      .filter(!_.contains(".."))
      .toRight(AppError.Validation("Invalid place photo name."))

  private def validatedPhotoUri(rawUri: String): AppResult[URI] =
    Either
      .catchNonFatal(URI.create(rawUri.trim))
      .leftMap(_ => AppError.Validation("Invalid place photo URI."))
      .flatMap(uri =>
        Option(uri.getScheme).map(_.toLowerCase) match
          case Some("https") => Right(uri)
          case _ => Left(AppError.Validation("Invalid place photo URI."))
      )

  private def validatedPlaceResourceName(resourceName: String): AppResult[String] =
    Option(resourceName.trim)
      .filter(_.startsWith("places/"))
      .filter(!_.contains(".."))
      .toRight(AppError.Validation("Invalid place resource name."))

object AmenityPhotoUrl:
  def fromPlacePhotoName(photoName: String): String =
    s"/api/amenities/place-photo?name=${GoogleAmenitiesClient.urlEncode(photoName)}"
