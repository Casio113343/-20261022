package fengshui.clients
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import cats.effect.std.Semaphore
import fengshui.model.*
import io.circe.{Json, parser}
import io.circe.syntax.*
import shared.{AppError, AppResult}
import listings.model.ListingDetail
import org.typelevel.log4cats.slf4j.Slf4jLogger

import java.net.URI
import java.net.http.{HttpClient, HttpRequest, HttpResponse}
import java.util.Base64
import scala.concurrent.duration.*

final class GeminiFengshuiClient private (
  apiKey: String,
  httpClient: HttpClient,
  providerSemaphore: Semaphore[IO]
):

  def analyse(
    listing: ListingDetail,
    imageContentType: String,
    imageBytes: Array[Byte]
  ): IO[AppResult[FengshuiAnalysis]] =
    val requestBody = GeminiFengshuiClient.buildRequestBody(listing, imageContentType, imageBytes)
    val request =
      HttpRequest
        .newBuilder(GeminiFengshuiClient.endpoint)
        .header("Content-Type", "application/json")
        .header("x-goog-api-key", apiKey)
        .POST(HttpRequest.BodyPublishers.ofString(requestBody.noSpaces))
        .build()

    val providerCall =
      IO.blocking {
        httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      }.attempt.flatMap {
        case Left(_) => IO.pure(Left(AppError.Unexpected("Unable to reach the analysis service right now.")))
        case Right(response) if response.statusCode() / 100 != 2 =>
          GeminiFengshuiClient.logger
            .warn(s"Gemini fengshui request failed with ${response.statusCode()}: ${response.body()}")
            .as(Left(AppError.Unexpected("Unable to generate fengshui guidance right now.")))
        case Right(response) => IO.pure(GeminiFengshuiClient.decodeAnalysisResponse(response.body()))
      }

    providerSemaphore.permit.use(_ =>
      providerCall.timeoutTo(
        GeminiFengshuiClient.ProviderTimeout,
        IO.pure(Left(AppError.Unexpected("The analysis service took too long to respond. Please try again.")))
      )
    )

object GeminiFengshuiClient:

  private val logger = Slf4jLogger.getLogger[IO]

  private val endpoint =
    URI.create("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent")

  private val MaxConcurrentRequests = 3
  private val ProviderTimeout = 45.seconds

  val configured: IO[Option[GeminiFengshuiClient]] =
    IO.delay(sys.env.get("GEMINI_API_KEY").map(_.trim).filter(_.nonEmpty)).flatMap {
      case None => IO.pure(None)
      case Some(apiKey) =>
        for
          client <- IO.delay(HttpClient.newHttpClient())
          semaphore <- Semaphore[IO](MaxConcurrentRequests)
        yield Some(GeminiFengshuiClient(apiKey, client, semaphore))
    }

  private def buildRequestBody(
    listing: ListingDetail,
    imageContentType: String,
    imageBytes: Array[Byte]
  ): Json =
    Json.obj(
      "contents" -> Json.arr(
        Json.obj(
          "parts" -> Json.arr(
            Json.obj("text" -> Json.fromString(prompt(listing))),
            Json.obj(
              "inline_data" -> Json.obj(
                "mime_type" -> Json.fromString(imageContentType),
                "data" -> Json.fromString(Base64.getEncoder.encodeToString(imageBytes))
              )
            )
          )
        )
      ),
      "generationConfig" -> Json.obj(
        "responseMimeType" -> Json.fromString("application/json"),
        "responseJsonSchema" -> outputSchema
      )
    )

  private def prompt(listing: ListingDetail): String =
    s"""Analyse the attached floor plan for the property at ${listing.addressLine}, ${listing.suburb}.
       |This is a fengshui-oriented buyer guidance feature, but the output must feel like a floor-plan decision layer, not a horoscope report.
       |Read visible room labels, circulation, entry paths, stairs, bathrooms, storage, outdoor areas, and the compass marker if present.
       |If any room label or orientation is unclear, say so in evidence and lower the confidence rather than guessing.
       |
       |Core product goal:
       |Explain the floor plan's strongest fengshui/layout qualities and the few practical changes that matter most.
       |
       |Rules:
       |- Every insight must be anchored to a visible room, entry, circulation path, storage area, or outdoor zone.
       |- Use exact floor-plan labels when visible, such as Master Bedroom, Bedroom 2, Living, Dining, Kitchen, Entry, Deck, Storage, Cellar, Pool.
       |- Avoid vague claims like "good potential", "wealth energy", or "keep the kitchen clean" unless tied to a visible feature.
       |- Do not promise wealth, health, safety, fertility, luck, or outcomes.
       |- Scores are product explainers from 0 to 100; they are not scientific measurements.
       |- Do not create marker-style labels, map links, or technical dashboard copy.
       |- Prefer physical layout observations over abstract energy claims.
       |- Use fengshui language sparingly and concretely: zone, balance, flow, retreat, calm, and circulation are useful when tied to a visible room relationship.
       |- Avoid mystical or generic phrases such as "positive energy", "overall harmony", "home's heart", "enhance chi", "vibrant plant", "sets a positive tone", or "crucial for stability".
       |- Action titles must sound like practical property advice, not mystical labels.
       |- Every action reason must point to a visible layout relationship, such as Kitchen between Dining and Living, Foyer leading into Living, Master Bedroom separated from activity zones, or Family/Media Room on the lower ground level.
       |
       |Return structured JSON only. Keep copy concise for a narrow panel:
       |- overallSummary maximum 18 words.
       |- Exactly 5 houseInsights, each describing a fengshui strength or benefit of the home.
       |- Strength titles should be short and specific, such as Master Bedroom Privacy, Indoor-Outdoor Flow, Distinct Living Zones, Lower-Ground Retreat, Entry Buffer.
       |- Strength summaries should explain the benefit in one calm sentence grounded in the visible floor plan.
       |- Exactly 3 priorityActions, each with a practical recommendation and a specific reason.
       |- Reasons/actions should be one sentence each, specific, and grounded in visible floor-plan evidence.
       |""".stripMargin

  private val outputSchema: Json =
    Json.obj(
      "type" -> Json.fromString("object"),
      "properties" -> Json.obj(
        "overallScore" -> integerSchema("Overall suitability score from 0 to 100."),
        "overallLabel" -> stringSchema("Short assessment label, such as Strong match, Good potential, or Needs adjustment."),
        "overallSummary" -> stringSchema("One grounded summary sentence, no more than 18 words."),
        "orientation" -> Json.obj(
          "type" -> Json.fromString("object"),
          "properties" -> Json.obj(
            "direction" -> stringSchema("Detected orientation label, or Unclear if not visible."),
            "confidence" -> confidenceSchema,
            "evidence" -> stringSchema("One concise sentence explaining the visual basis or uncertainty.")
          ),
          "required" -> Json.arr(List("direction", "confidence", "evidence").map(Json.fromString)*)
        ),
        "houseInsights" -> Json.obj(
          "type" -> Json.fromString("array"),
          "minItems" -> Json.fromInt(5),
          "maxItems" -> Json.fromInt(5),
          "items" -> Json.obj(
            "type" -> Json.fromString("object"),
            "properties" -> Json.obj(
              "id" -> stringSchema("Stable insight id such as S1, A1, or W1."),
              "title" -> stringSchema("Short title."),
              "location" -> stringSchema("Exact visible room or feature name."),
              "summary" -> stringSchema("One concise fengshui benefit tied to visible layout, zones, balance, or flow; avoid abstract energy claims.")
            ),
            "required" -> Json.arr(List("id", "title", "location", "summary").map(Json.fromString)*)
          )
        ),
        "priorityActions" -> Json.obj(
          "type" -> Json.fromString("array"),
          "minItems" -> Json.fromInt(3),
          "maxItems" -> Json.fromInt(3),
          "items" -> priorityActionSchema
        ),
        "confidenceNote" -> stringSchema("One concise note about key visual uncertainty.")
      ),
      "required" -> Json.arr(
        List(
          "overallScore",
          "overallLabel",
          "overallSummary",
          "orientation",
          "houseInsights",
          "priorityActions",
          "confidenceNote"
        ).map(Json.fromString)*
      )
    )

  private def priorityActionSchema: Json =
    Json.obj(
      "type" -> Json.fromString("object"),
      "properties" -> Json.obj(
        "id" -> stringSchema("Action id such as A1."),
        "priority" -> Json.obj("type" -> Json.fromString("string"), "enum" -> Json.arr(List("high", "medium", "low").map(Json.fromString)*)),
        "location" -> stringSchema("Exact visible room or feature label."),
        "title" -> stringSchema("Short practical property-advice title, not a mystical label."),
        "recommendation" -> stringSchema("One practical physical change or setup recommendation."),
        "reason" -> stringSchema("One concise reason pointing to a visible layout relationship.")
      ),
      "required" -> Json.arr(List("id", "priority", "location", "title", "recommendation", "reason").map(Json.fromString)*)
    )

  private def confidenceSchema: Json =
    Json.obj(
      "type" -> Json.fromString("string"),
      "enum" -> Json.arr(List("High", "Moderate", "Low").map(Json.fromString)*)
    )

  private def arraySchema(items: Json): Json =
    Json.obj(
      "type" -> Json.fromString("array"),
      "items" -> items
    )

  private def integerSchema(description: String): Json =
    Json.obj(
      "type" -> Json.fromString("integer"),
      "description" -> Json.fromString(description)
    )

  private def stringSchema(description: String): Json =
    Json.obj(
      "type" -> Json.fromString("string"),
      "description" -> Json.fromString(description)
    )

  private def decodeAnalysisResponse(body: String): AppResult[FengshuiAnalysis] =
    for
      responseJson <- parser.parse(body).left.map(_ => AppError.Decoding("Unable to read the analysis response."))
      analysisText <- responseJson.hcursor
        .downField("candidates")
        .downArray
        .downField("content")
        .downField("parts")
        .downArray
        .get[String]("text")
        .left
        .map(_ => AppError.Decoding("The analysis response was empty."))
      analysis <- parser.decode[FengshuiAnalysis](analysisText).left.map(_ => AppError.Decoding("Unable to read the structured analysis."))
    yield analysis
