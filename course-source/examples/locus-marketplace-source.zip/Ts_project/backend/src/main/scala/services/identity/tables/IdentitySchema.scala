package identity.tables
import identity.model.*


import cats.effect.IO
import _root_.identity.tables.agent_profiles.AgentProfilesTable
import _root_.identity.tables.user_sessions.UserSessionsTable
import _root_.identity.tables.users.UsersTable

import java.sql.Connection

object IdentitySchema:

  def initialize(connection: Connection): IO[Unit] =
    List[Connection => IO[Unit]](
      UsersTable.initialize,
      AgentProfilesTable.initialize,
      UserSessionsTable.initialize
    ).foldLeft(IO.unit)((program, initializeTable) => program *> initializeTable(connection))
