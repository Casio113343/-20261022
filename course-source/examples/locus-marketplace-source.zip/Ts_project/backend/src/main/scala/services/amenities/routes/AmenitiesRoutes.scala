package amenities.routes

import amenities.api.messages.{GetAmenityDetailsApiMessage, SearchNearbyAmenitiesApiMessage}
import amenities.clients.GoogleAmenitiesClient
import shared.ApiServiceMessages

object AmenitiesRoutes:

  def apiMessages(googleAmenitiesClient: Option[GoogleAmenitiesClient]): ApiServiceMessages =
    ApiServiceMessages(
      "amenities",
      List(
        SearchNearbyAmenitiesApiMessage(googleAmenitiesClient),
        GetAmenityDetailsApiMessage(googleAmenitiesClient)
      )
    )
