package favourites.tables.favourite_records
import identity.model.*
import listings.model.*

import cats.effect.IO
import identity.model.UserId
import listings.model.ListingId
import shared.*

import java.sql.Connection
import java.sql.Timestamp

private[favourites] object FavouritesTable:

  private val createSql: String =
    """
      |create table if not exists favourites (
      |  user_id uuid not null references users(id) on delete cascade,
      |  listing_id uuid not null references listings(id) on delete cascade,
      |  created_at timestamptz not null,
      |  primary key (user_id, listing_id)
      |);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql))

  private val saveFavouriteSql: String =
    """
      |insert into favourites (user_id, listing_id, created_at)
      |values (?, ?, ?)
      |on conflict (user_id, listing_id) do nothing
      |""".stripMargin

  def saveFavourite(connection: Connection, userId: UserId, listingId: ListingId): IO[AppResult[Unit]] =
    RuntimeValues.now.flatMap(createdAt =>
      JdbcResources.update(connection, saveFavouriteSql) { statement =>
        statement.setObject(1, userId.value)
        statement.setObject(2, listingId.value)
        statement.setTimestamp(3, Timestamp.from(createdAt))
        statement.executeUpdate()
      }.as(Right(()))
    )

  private val removeFavouriteSql: String =
    "delete from favourites where user_id = ? and listing_id = ?"

  def removeFavourite(connection: Connection, userId: UserId, listingId: ListingId): IO[AppResult[Unit]] =
    JdbcResources.update(connection, removeFavouriteSql) { statement =>
      statement.setObject(1, userId.value)
      statement.setObject(2, listingId.value)
      statement.executeUpdate()
    }.as(Right(()))

  private val listFavouriteListingIdsSql: String =
    """
      |select listing_id
      |from favourites
      |where user_id = ?
      |order by created_at desc
      |""".stripMargin

  def listFavouriteListingIds(connection: Connection, userId: UserId): IO[AppResult[List[ListingId]]] =
    JdbcResources.select(connection, listFavouriteListingIdsSql) { statement =>
      statement.setObject(1, userId.value)
    } { resultSet =>
      Right(
        Iterator
          .continually(resultSet.next())
          .takeWhile(Predef.identity)
          .map(_ => ListingId(resultSet.getObject("listing_id", classOf[java.util.UUID])))
          .toList
      )
    }
