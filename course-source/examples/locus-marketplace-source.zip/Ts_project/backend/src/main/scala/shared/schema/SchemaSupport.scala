package shared

import cats.effect.IO

import java.sql.Connection

object SchemaSupport:

  def executeStatements(connection: Connection, statements: List[String]): IO[Unit] =
    statements.foldLeft(IO.unit) { (acc, statementSql) =>
      acc *> JdbcResources.statement(connection).use(statement => IO.blocking(statement.execute(statementSql))).void
    }

  def hasColumn(connection: Connection, tableName: String, columnName: String): IO[Boolean] =
    val sql =
      """
        |select 1
        |from information_schema.columns
        |where table_name = ?
        |  and column_name = ?
        |limit 1
        |""".stripMargin

    JdbcResources.select(connection, sql) { statement =>
      statement.setString(1, tableName)
      statement.setString(2, columnName)
    }(_.next())

  def hasColumns(connection: Connection, tableName: String, columnNames: List[String]): IO[Boolean] =
    columnNames
      .foldLeft(IO.pure(true))((acc, columnName) =>
        acc.flatMap(hasAllColumnsSoFar =>
          if hasAllColumnsSoFar then hasColumn(connection, tableName, columnName)
          else IO.pure(false)
        )
      )

  def hasTable(connection: Connection, tableName: String): IO[Boolean] =
    val sql =
      """
        |select 1
        |from information_schema.tables
        |where table_name = ?
        |limit 1
        |""".stripMargin

    JdbcResources.select(connection, sql) { statement =>
      statement.setString(1, tableName)
    }(_.next())

  def setOptionalText(statement: java.sql.PreparedStatement, index: Int, value: Option[String]): Unit =
    value match
      case Some(text) => statement.setString(index, text)
      case None => statement.setNull(index, java.sql.Types.VARCHAR)
