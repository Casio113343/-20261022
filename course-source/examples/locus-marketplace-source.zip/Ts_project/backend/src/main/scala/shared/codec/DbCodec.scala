package shared

import io.circe.{Decoder, Encoder, Json}
import io.circe.parser.decode
import io.circe.syntax.*

import java.sql.{PreparedStatement, ResultSet, Timestamp, Types}
import java.time.Instant
import java.util.UUID

object DbCodec:

  def encodeValue[A: Encoder](value: A): String =
    value.asJson.noSpaces

  def decodeValue[A: Decoder](value: String, label: String): Either[AppError.Decoding, A] =
    decode[A](value).left.map(error => AppError.Decoding(s"Unable to decode $label: ${error.getMessage}"))

  def decodeField[A: Decoder](resultSet: ResultSet, columnName: String): Either[AppError.Decoding, A] =
    Option(resultSet.getString(columnName))
      .toRight(AppError.Decoding(s"Missing database field: $columnName"))
      .flatMap(value => decodeValue[A](value, columnName))

  def decodeOptionalField[A: Decoder](resultSet: ResultSet, columnName: String): Either[AppError.Decoding, Option[A]] =
    Option(resultSet.getString(columnName))
      .map(value => decodeValue[A](value, columnName).map(Some(_)))
      .getOrElse(Right(None))

  def decodeType[A: Decoder](json: Json, label: String): Either[AppError.Decoding, A] =
    json.as[A].left.map(error => AppError.Decoding(s"Unable to decode $label: ${error.getMessage}"))

  def setJson[A: Encoder](statement: PreparedStatement, index: Int, value: A): Unit =
    statement.setString(index, encodeValue(value))

  def setOptionalJson[A: Encoder](statement: PreparedStatement, index: Int, value: Option[A]): Unit =
    value match
      case Some(content) => statement.setString(index, encodeValue(content))
      case None => statement.setNull(index, Types.VARCHAR)

  def requiredText(resultSet: ResultSet, columnName: String): AppResult[String] =
    Option(resultSet.getString(columnName))
      .toRight(AppError.Decoding(s"Missing database field: $columnName"))

  def optionalText(resultSet: ResultSet, columnName: String): Option[String] =
    Option(resultSet.getString(columnName))

  def requiredInstant(resultSet: ResultSet, columnName: String): AppResult[Instant] =
    Option(resultSet.getTimestamp(columnName))
      .map(_.toInstant)
      .toRight(AppError.Decoding(s"Missing database field: $columnName"))

  def requiredUuid(resultSet: ResultSet, columnName: String): AppResult[UUID] =
    Option(resultSet.getObject(columnName, classOf[UUID]))
      .toRight(AppError.Decoding(s"Missing database field: $columnName"))

  def optionalInt(resultSet: ResultSet, columnName: String): Option[Int] =
    Option(resultSet.getObject(columnName, classOf[java.lang.Integer])).map(_.intValue())

  def decodeDatabaseValue[A](result: Either[String, A], fieldName: String): AppResult[A] =
    result.left.map(message => AppError.Decoding(s"Invalid value for $fieldName: $message"))

  def decodeOptionalValue[A](
    rawValue: Option[String],
    fieldName: String,
    decode: String => Either[String, A]
  ): AppResult[Option[A]] =
    rawValue match
      case Some(value) => decodeDatabaseValue(decode(value), fieldName).map(Some(_))
      case None => Right(None)
