package listings.model


import io.circe.{Decoder, Encoder}

enum TransactionType:
  case Sale
  case Rent

object TransactionType:
  def fromString(value: String): Either[String, TransactionType] =
    value.trim.toLowerCase match
      case "sale" => Right(TransactionType.Sale)
      case "rent" => Right(TransactionType.Rent)
      case other => Left(s"Unsupported transaction type: $other")

  def toString(value: TransactionType): String =
    value match
      case TransactionType.Sale => "sale"
      case TransactionType.Rent => "rent"

  given Encoder[TransactionType] = Encoder.encodeString.contramap(toString)
  given Decoder[TransactionType] = Decoder.decodeString.emap(fromString)
