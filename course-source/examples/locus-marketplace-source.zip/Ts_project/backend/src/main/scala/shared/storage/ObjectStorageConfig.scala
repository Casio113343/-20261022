package shared

import cats.effect.IO

final case class ObjectStorageConfig(
  endpoint: String,
  publicBaseUrl: String,
  accessKey: String,
  secretKey: String,
  bucketName: String
)

object ObjectStorageConfig:

  val load: IO[ObjectStorageConfig] =
    IO.delay {
      val environment = sys.env

      ObjectStorageConfig(
        endpoint = environment.getOrElse("MINIO_ENDPOINT", "http://127.0.0.1:9000"),
        publicBaseUrl = environment.getOrElse("MINIO_PUBLIC_BASE_URL", "http://127.0.0.1:9000"),
        accessKey = environment.getOrElse("MINIO_ACCESS_KEY", "minioadmin"),
        secretKey = environment.getOrElse("MINIO_SECRET_KEY", "minioadmin"),
        bucketName = environment.getOrElse("MINIO_BUCKET", "listing-media")
      )
    }
