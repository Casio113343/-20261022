package identity.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class AgentProfile(
  userId: UserId,
  agencyName: String,
  phone: String,
  licenseNumber: Option[String],
  bio: Option[String]
)

object AgentProfile:
  given Encoder[AgentProfile] = deriveEncoder[AgentProfile]
  given Decoder[AgentProfile] = deriveDecoder[AgentProfile]
