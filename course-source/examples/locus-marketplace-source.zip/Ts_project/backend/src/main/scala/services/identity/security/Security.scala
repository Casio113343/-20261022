package identity.security
import identity.model.*

import cats.effect.IO
import java.nio.charset.StandardCharsets
import java.security.{MessageDigest, SecureRandom}
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

private[identity] object Security:

  private val base64 = Base64.getUrlEncoder.withoutPadding()
  private val decoder = Base64.getUrlDecoder
  private val iterations = 65_536
  private val keyLength = 256

  final case class PasswordDigest(salt: String, hash: String)
  final case class SessionTokens(
    sessionToken: String,
    sessionTokenHash: String,
    csrfToken: String
  )

  def hashPassword(password: String): IO[PasswordDigest] =
    nextBytes(16).map { saltBytes =>
      PasswordDigest(
        salt = base64.encodeToString(saltBytes),
        hash = pbkdf2(password, saltBytes)
      )
    }

  def verifyPassword(password: String, digest: PasswordDigest): IO[Boolean] =
    IO.delay(pbkdf2(password, decoder.decode(digest.salt)) == digest.hash)

  def issueSessionTokens(): IO[SessionTokens] =
    for
      sessionBytes <- nextBytes(32)
      csrfBytes <- nextBytes(32)
      sessionToken = base64.encodeToString(sessionBytes)
      csrfToken = base64.encodeToString(csrfBytes)
    yield SessionTokens(
      sessionToken = sessionToken,
      sessionTokenHash = sha256(sessionToken),
      csrfToken = csrfToken
    )

  def hashToken(token: String): IO[String] =
    IO.delay(sha256(token))

  private def pbkdf2(password: String, salt: Array[Byte]): String =
    val secretFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
    val spec = PBEKeySpec(password.toCharArray, salt, iterations, keyLength)
    val encoded = secretFactory.generateSecret(spec).getEncoded
    base64.encodeToString(encoded)

  private def sha256(value: String): String =
    val digest = MessageDigest.getInstance("SHA-256")
    val bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8))
    base64.encodeToString(bytes)

  private def nextBytes(size: Int): IO[Array[Byte]] =
    IO.delay {
      val bytes = Array.ofDim[Byte](size)
      SecureRandom().nextBytes(bytes)
      bytes
    }
