package messaging.api.messages
import identity.model.*
import listings.model.*
import messaging.model.*


import shared.{ApiTransaction, NoRequestWithTokenMessage}
import cats.effect.IO
import shared.AppResult
import shared.AuthenticatedPrincipal
import messaging.api.responses.ListConversationsResponse
import messaging.application.MessagingApplication
import shared.ListingMediaStorage

import java.sql.Connection

final case class ListConversationsApiMessage(storage: ListingMediaStorage)
    extends NoRequestWithTokenMessage[ListConversationsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(principal: AuthenticatedPrincipal, connection: Connection): IO[AppResult[ListConversationsResponse]] =
    MessagingApplication
      .listConversationsForUser(connection, storage, principal.userId)
      .map(_.map(ListConversationsResponse.apply))
