package media.tables.property_images
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import shared.*

import java.sql.Connection
import java.sql.Timestamp
import java.util.UUID

private[media] object PropertyImagesTable:

  final case class StoredImageRecord(
    id: PropertyImageId,
    listingId: Option[ListingId],
    uploadedBy: UserId,
    bucketName: String,
    objectKey: String,
    contentType: String,
    sizeBytes: Long,
    sortOrder: Int,
    altText: Option[String],
    isFloorPlan: Boolean
  )

  private val createSql: String =
    """
      |create table if not exists property_images (
      |  id uuid primary key,
      |  listing_id uuid references listings(id) on delete cascade,
      |  uploaded_by uuid not null references users(id) on delete cascade,
      |  bucket_name varchar(120) not null,
      |  object_key text not null unique,
      |  content_type varchar(160) not null,
      |  size_bytes bigint not null,
      |  sort_order int not null,
      |  alt_text varchar(220),
      |  is_floor_plan boolean not null default false,
      |  created_at timestamptz not null
      |);
      |create index if not exists property_images_listing_idx on property_images(listing_id, sort_order);
      |create index if not exists property_images_uploaded_by_idx on property_images(uploaded_by, created_at);
      |""".stripMargin

  private val requiredColumns: List[String] =
    List(
      "id",
      "listing_id",
      "uploaded_by",
      "bucket_name",
      "object_key",
      "content_type",
      "size_bytes",
      "sort_order",
      "alt_text",
      "created_at",
    )

  def initialize(connection: Connection): IO[Unit] =
    migrate(connection)

  private val dropSql: String =
    "drop table if exists property_images;"

  private val ensureFloorPlanColumnSql: String =
    """
      |alter table property_images
      |add column if not exists is_floor_plan boolean not null default false;
      |""".stripMargin

  private def migrate(connection: Connection): IO[Unit] =
    for
      propertyImagesTableExists <- SchemaSupport.hasTable(connection, "property_images")
      containsLegacyUrlColumn <- SchemaSupport.hasColumn(connection, "property_images", "image_url")
      hasCompleteMinioSchema <-
        if propertyImagesTableExists then SchemaSupport.hasColumns(connection, "property_images", requiredColumns)
        else IO.pure(false)
      shouldRebuildPropertyImagesTable =
        propertyImagesTableExists && (containsLegacyUrlColumn || !hasCompleteMinioSchema)
      _ <-
        if shouldRebuildPropertyImagesTable then SchemaSupport.executeStatements(connection, List(dropSql, createSql))
        else SchemaSupport.executeStatements(connection, List(createSql))
      _ <- SchemaSupport.executeStatements(connection, List(ensureFloorPlanColumnSql))
    yield ()

  private val insertUploadedImageSql: String =
    """
      |insert into property_images (
      |  id, listing_id, uploaded_by, bucket_name, object_key, content_type, size_bytes, sort_order, alt_text, created_at
      |)
      |values (?, null, ?, ?, ?, ?, ?, 0, null, ?)
      |""".stripMargin

  def insertUploadedImage(
    connection: Connection,
    imageId: PropertyImageId,
    uploadedBy: UserId,
    bucketName: String,
    objectKey: String,
    contentType: String,
    sizeBytes: Long,
    createdAt: java.time.Instant
  ): IO[Unit] =
    JdbcResources.update(connection, insertUploadedImageSql) { statement =>
      statement.setObject(1, imageId.value)
      statement.setObject(2, uploadedBy.value)
      statement.setString(3, bucketName)
      statement.setString(4, objectKey)
      statement.setString(5, contentType)
      statement.setLong(6, sizeBytes)
      statement.setTimestamp(7, Timestamp.from(createdAt))
      statement.executeUpdate()
    }.void

  private val findImageSql: String =
    """
      |select id, listing_id, uploaded_by, bucket_name, object_key, content_type, size_bytes, sort_order, alt_text, is_floor_plan
      |from property_images
      |where id = ?
      |""".stripMargin

  def findImage(connection: Connection, imageId: PropertyImageId): IO[AppResult[Option[StoredImageRecord]]] =
    JdbcResources.select(connection, findImageSql) { statement =>
      statement.setObject(1, imageId.value)
    } { resultSet =>
      if resultSet.next() then readStoredImageRecord(resultSet).map(Some(_))
      else Right(None)
    }

  private val deleteUnattachedImageSql: String =
    "delete from property_images where id = ? and uploaded_by = ? and listing_id is null"

  def deleteUnattachedImage(
    connection: Connection,
    imageId: PropertyImageId,
    uploadedBy: UserId
  ): IO[AppResult[Option[StoredImageRecord]]] =
    findImage(connection, imageId).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(Some(record)) if record.uploadedBy != uploadedBy =>
        IO.pure(Left(AppError.Forbidden("You can only delete your own uploaded images")))
      case Right(Some(record)) if record.listingId.nonEmpty =>
        IO.pure(Left(AppError.Conflict("Attached images must be removed through listing updates")))
      case Right(Some(record)) =>
        JdbcResources.update(connection, deleteUnattachedImageSql) { statement =>
          statement.setObject(1, imageId.value)
          statement.setObject(2, uploadedBy.value)
          statement.executeUpdate()
          Right(Some(record))
        }
      case Right(None) => IO.pure(Right(None))
    }

  def syncListingImages(
    connection: Connection,
    listingId: ListingId,
    uploadedBy: UserId,
    images: List[PropertyImageInput]
  ): IO[AppResult[List[StoredImageRecord]]] =
    val imageIds = images.map(_.id)

    for
      requestedImagesResult <- loadImagesByIds(connection, imageIds)
      existingImagesResult <- loadListingImages(connection, listingId)
      syncResult <- (requestedImagesResult, existingImagesResult) match
        case (Left(error), _) => IO.pure(Left(error))
        case (_, Left(error)) => IO.pure(Left(error))
        case (Right(requestedImages), Right(existingImages)) =>
          validateSyncRequest(listingId, uploadedBy, images, requestedImages) match
            case Left(error) => IO.pure(Left(error))
            case Right(validRequestedImages) =>
              val requestedImageIds = validRequestedImages.map(_.id).toSet
              val removedImages = existingImages.filterNot(image => requestedImageIds.contains(image.id))

              for
                _ <- deleteListingImages(connection, removedImages.map(_.id))
                _ <- images.zipWithIndex.foldLeft(IO.unit) { case (acc, (image, index)) =>
                  acc *> attachImageToListing(
                    connection = connection,
                    listingId = listingId,
                    uploadedBy = uploadedBy,
                    imageId = image.id,
                    sortOrder = index,
                    altText = image.altText,
                    isFloorPlan = image.isFloorPlan
                  )
                }
              yield Right(removedImages)
    yield syncResult

  def listListingImages(
    connection: Connection,
    listingId: ListingId,
    resolveMediaUrl: String => String
  ): IO[AppResult[List[PropertyImage]]] =
    loadListingImages(connection, listingId).map(
      _.map(_.map(record =>
        PropertyImage(
          id = record.id,
          listingId = listingId,
          url = resolveMediaUrl(record.objectKey),
          objectKey = record.objectKey,
          contentType = record.contentType,
          sizeBytes = record.sizeBytes,
          sortOrder = record.sortOrder,
          altText = record.altText,
          isFloorPlan = record.isFloorPlan
        )
      ))
    )

  private def validateSyncRequest(
    listingId: ListingId,
    uploadedBy: UserId,
    requestedImagesInput: List[PropertyImageInput],
    requestedImages: List[StoredImageRecord]
  ): AppResult[List[StoredImageRecord]] =
    val requestedImageIds = requestedImagesInput.map(_.id)

    if requestedImageIds.distinct.length != requestedImageIds.length then
      Left(AppError.Validation("Listing images must not contain duplicates"))
    else if requestedImagesInput.count(_.isFloorPlan) > 1 then
      Left(AppError.Validation("A listing can have only one nominated floor plan"))
    else if requestedImages.length != requestedImageIds.length then
      Left(AppError.Validation("Every listing image must be uploaded before saving the listing"))
    else
      requestedImages.foldLeft(Right(requestedImages): AppResult[List[StoredImageRecord]]) { (acc, image) =>
        acc.flatMap { records =>
          if image.uploadedBy != uploadedBy then
            Left(AppError.Forbidden("You can only use images you uploaded"))
          else if image.listingId.exists(_ != listingId) then
            Left(AppError.Conflict("Uploaded image is already attached to another listing"))
          else Right(records)
        }
      }

  private val attachImageToListingSql: String =
    """
      |update property_images
      |set listing_id = ?, sort_order = ?, alt_text = ?, is_floor_plan = ?
      |where id = ?
      |  and uploaded_by = ?
      |  and (listing_id is null or listing_id = ?)
      |""".stripMargin

  private def attachImageToListing(
    connection: Connection,
    listingId: ListingId,
    uploadedBy: UserId,
    imageId: PropertyImageId,
    sortOrder: Int,
    altText: Option[String],
    isFloorPlan: Boolean
  ): IO[Unit] =
    JdbcResources.update(connection, attachImageToListingSql) { statement =>
      statement.setObject(1, listingId.value)
      statement.setInt(2, sortOrder)
      SchemaSupport.setOptionalText(statement, 3, altText.map(_.trim).filter(_.nonEmpty))
      statement.setBoolean(4, isFloorPlan)
      statement.setObject(5, imageId.value)
      statement.setObject(6, uploadedBy.value)
      statement.setObject(7, listingId.value)
      statement.executeUpdate()
    }.void

  private def loadImagesByIds(
    connection: Connection,
    imageIds: List[PropertyImageId]
  ): IO[AppResult[List[StoredImageRecord]]] =
    imageIds.foldLeft(IO.pure(Right(Nil): AppResult[List[StoredImageRecord]])) { (acc, imageId) =>
      for
        loaded <- acc
        next <- loaded match
          case Left(error) => IO.pure(Left(error))
          case Right(records) =>
            findImage(connection, imageId).map(_.flatMap {
              case Some(record) => Right(records :+ record)
              case None => Left(AppError.NotFound("Uploaded image not found"))
            })
      yield next
    }

  private val loadListingImagesSql: String =
    """
      |select id, listing_id, uploaded_by, bucket_name, object_key, content_type, size_bytes, sort_order, alt_text, is_floor_plan
      |from property_images
      |where listing_id = ?
      |order by sort_order asc
      |""".stripMargin

  private def loadListingImages(connection: Connection, listingId: ListingId): IO[AppResult[List[StoredImageRecord]]] =
    JdbcResources.select(connection, loadListingImagesSql) { statement =>
      statement.setObject(1, listingId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => readStoredImageRecord(resultSet))
        .foldRight(Right(Nil): AppResult[List[StoredImageRecord]])((next, acc) =>
          for
            head <- next
            tail <- acc
          yield head :: tail
        )
    }

  private val deleteListingImagesSql: String =
    "delete from property_images where id = ?"

  private def deleteListingImages(connection: Connection, imageIds: List[PropertyImageId]): IO[Unit] =
    imageIds.foldLeft(IO.unit) { (acc, imageId) =>
      acc *> JdbcResources.update(connection, deleteListingImagesSql) { statement =>
        statement.setObject(1, imageId.value)
        statement.executeUpdate()
      }.void
    }

  private def readStoredImageRecord(resultSet: java.sql.ResultSet): AppResult[StoredImageRecord] =
    for
      bucketName <- requiredField(resultSet, "bucket_name")
      objectKey <- requiredField(resultSet, "object_key")
      contentType <- requiredField(resultSet, "content_type")
    yield StoredImageRecord(
      id = PropertyImageId(resultSet.getObject("id", classOf[UUID])),
      listingId = Option(resultSet.getObject("listing_id", classOf[UUID])).map(ListingId(_)),
      uploadedBy = UserId(resultSet.getObject("uploaded_by", classOf[UUID])),
      bucketName = bucketName,
      objectKey = objectKey,
      contentType = contentType,
      sizeBytes = resultSet.getLong("size_bytes"),
      sortOrder = resultSet.getInt("sort_order"),
      altText = Option(resultSet.getString("alt_text")),
      isFloorPlan = resultSet.getBoolean("is_floor_plan")
    )

  private def requiredField(resultSet: java.sql.ResultSet, columnName: String): AppResult[String] =
    Option(resultSet.getString(columnName))
      .toRight(AppError.Decoding(s"Missing database field: $columnName"))
