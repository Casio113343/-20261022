package app.api

import amenities.clients.GoogleAmenitiesClient
import cats.effect.IO
import cats.syntax.semigroupk.*
import database.DatabaseSession
import fengshui.clients.GeminiFengshuiClient
import messaging.routes.MessagingWebSocketHub
import org.http4s.HttpApp
import org.http4s.HttpRoutes
import org.http4s.implicits.*
import org.http4s.server.websocket.WebSocketBuilder2
import shared.{ApiRateLimiter, ListingMediaStorage}
import renovations.api.RenovationScheduler

object ApiRouter:

  private def allRoutes(
    databaseSession: DatabaseSession,
    listingMediaStorage: ListingMediaStorage,
    rateLimiter: ApiRateLimiter,
    googleAmenitiesClient: Option[GoogleAmenitiesClient],
    fengshuiClient: Option[GeminiFengshuiClient],
    renovationScheduler: RenovationScheduler,
    messagingHub: MessagingWebSocketHub,
    webSocketBuilder: WebSocketBuilder2[IO]
  ): HttpRoutes[IO] =
    HealthRouter.routes <+> MarketplaceRouter.routes(
      databaseSession,
      listingMediaStorage,
      rateLimiter,
      googleAmenitiesClient,
      fengshuiClient,
      renovationScheduler,
      messagingHub,
      webSocketBuilder
    )

  def httpApp(
    databaseSession: DatabaseSession,
    listingMediaStorage: ListingMediaStorage,
    rateLimiter: ApiRateLimiter,
    googleAmenitiesClient: Option[GoogleAmenitiesClient],
    fengshuiClient: Option[GeminiFengshuiClient],
    renovationScheduler: RenovationScheduler,
    messagingHub: MessagingWebSocketHub,
    webSocketBuilder: WebSocketBuilder2[IO]
  ): HttpApp[IO] =
    allRoutes(
      databaseSession,
      listingMediaStorage,
      rateLimiter,
      googleAmenitiesClient,
      fengshuiClient,
      renovationScheduler,
      messagingHub,
      webSocketBuilder
    ).orNotFound
