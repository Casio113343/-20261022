package messaging.model


import identity.model.UserId
import io.circe.{Encoder, Json}
import io.circe.generic.semiauto.deriveEncoder
import shared.TimeCodecs

import java.time.Instant

import TimeCodecs.given

sealed trait ServerMessagingEvent:
  def conversationId: ConversationId
  def occurredAt: Instant

object ServerMessagingEvent:
  final case class MessageCreated(
    conversationId: ConversationId,
    message: ConversationMessage,
    occurredAt: Instant
  ) extends ServerMessagingEvent

  final case class MessagesSeen(
    conversationId: ConversationId,
    readerId: UserId,
    seenAt: Instant,
    occurredAt: Instant
  ) extends ServerMessagingEvent

  final case class TypingChanged(
    conversationId: ConversationId,
    userId: UserId,
    typing: Boolean,
    occurredAt: Instant
  ) extends ServerMessagingEvent

  final case class ErrorEvent(
    conversationId: ConversationId,
    message: String,
    occurredAt: Instant
  ) extends ServerMessagingEvent

  given Encoder[ServerMessagingEvent] = Encoder.instance {
    case event: MessageCreated =>
      deriveEncoder[MessageCreated].mapJson(_.deepMerge(Json.obj("type" -> Json.fromString("message_created"))))(event)
    case event: MessagesSeen =>
      deriveEncoder[MessagesSeen].mapJson(_.deepMerge(Json.obj("type" -> Json.fromString("messages_seen"))))(event)
    case event: TypingChanged =>
      deriveEncoder[TypingChanged].mapJson(_.deepMerge(Json.obj("type" -> Json.fromString("typing_changed"))))(event)
    case event: ErrorEvent =>
      deriveEncoder[ErrorEvent].mapJson(_.deepMerge(Json.obj("type" -> Json.fromString("error"))))(event)
  }
