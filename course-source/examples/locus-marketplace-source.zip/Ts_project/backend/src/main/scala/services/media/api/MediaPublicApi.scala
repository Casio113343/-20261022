package media.api

import cats.effect.IO
import identity.model.UserId
import listings.model.ListingId
import media.model.{PropertyImage, PropertyImageInput}
import media.tables.property_images.PropertyImagesTable
import shared.{AppResult, ListingMediaStorage}

import java.sql.Connection

object MediaPublicApi:

  def syncListingImages(
    connection: Connection,
    listingId: ListingId,
    agentId: UserId,
    requestedImages: List[PropertyImageInput]
  ): IO[AppResult[List[RemovedListingImage]]] =
    PropertyImagesTable
      .syncListingImages(connection, listingId, agentId, requestedImages)
      .map(_.map(_.map(record => RemovedListingImage(record.objectKey))))

  def listListingImages(
    connection: Connection,
    storage: ListingMediaStorage,
    listingId: ListingId
  ): IO[AppResult[List[PropertyImage]]] =
    PropertyImagesTable.listListingImages(connection, listingId, storage.publicUrl)
