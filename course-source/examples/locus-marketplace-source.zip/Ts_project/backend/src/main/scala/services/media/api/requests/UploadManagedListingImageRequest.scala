package media.api.requests
import identity.model.*
import listings.model.*
import media.model.*


final case class UploadManagedListingImageRequest(
  fileName: String,
  contentType: String,
  bytes: Array[Byte]
)
