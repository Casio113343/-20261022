package app.api

import analytics.routes.AnalyticsRoutes
import amenities.clients.GoogleAmenitiesClient
import amenities.routes.{AmenityPhotoRoutes, AmenitiesRoutes}
import shared.{ApiMessageRouter, ApiRateLimiter, ApiServiceMessages}
import cats.effect.IO
import cats.syntax.semigroupk.*
import database.DatabaseSession
import favourites.routes.FavouriteRoutes
import fengshui.routes.FengshuiRoutes
import fengshui.clients.GeminiFengshuiClient
import identity.api.IdentityPublicApi
import identity.routes.AuthRoutes
import inspections.routes.InspectionRoutes
import listings.routes.ListingsRoutes
import media.routes.MediaRoutes
import messaging.routes.{MessagingRoutes, MessagingWebSocketHub, MessagingWebSocketRoutes}
import org.http4s.HttpRoutes
import org.http4s.server.websocket.WebSocketBuilder2
import shared.ListingMediaStorage
import renovations.api.RenovationScheduler
import renovations.routes.RenovationRoutes

object MarketplaceRouter:

  private def apiMessages(
    listingMediaStorage: ListingMediaStorage,
    googleAmenitiesClient: Option[GoogleAmenitiesClient],
    fengshuiClient: Option[GeminiFengshuiClient],
    renovationScheduler: RenovationScheduler
  ): List[ApiServiceMessages] =
    List(
      AmenitiesRoutes.apiMessages(googleAmenitiesClient),
      AuthRoutes.apiMessages(listingMediaStorage),
      ListingsRoutes.apiMessages(listingMediaStorage, renovationScheduler),
      FavouriteRoutes.apiMessages(listingMediaStorage),
      MediaRoutes.apiMessages(listingMediaStorage),
      FengshuiRoutes.apiMessages(listingMediaStorage, fengshuiClient),
      InspectionRoutes.apiMessages(listingMediaStorage),
      MessagingRoutes.apiMessages(listingMediaStorage),
      RenovationRoutes.apiMessages(listingMediaStorage),
      AnalyticsRoutes.apiMessages
    )

  def routes(
    databaseSession: DatabaseSession,
    listingMediaStorage: ListingMediaStorage,
    rateLimiter: ApiRateLimiter,
    googleAmenitiesClient: Option[GoogleAmenitiesClient],
    fengshuiClient: Option[GeminiFengshuiClient],
    renovationScheduler: RenovationScheduler,
    messagingHub: MessagingWebSocketHub,
    webSocketBuilder: WebSocketBuilder2[IO]
  ): HttpRoutes[IO] =
    MessagingWebSocketRoutes.routes(databaseSession, listingMediaStorage, messagingHub, webSocketBuilder) <+>
      AmenityPhotoRoutes.routes(googleAmenitiesClient) <+>
      ApiMessageRouter.routes(
        databaseSession,
        apiMessages(listingMediaStorage, googleAmenitiesClient, fengshuiClient, renovationScheduler),
        IdentityPublicApi,
        rateLimiter
      )
