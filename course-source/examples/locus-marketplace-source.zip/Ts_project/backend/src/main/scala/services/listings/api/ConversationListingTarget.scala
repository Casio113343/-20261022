package listings.api

import identity.model.UserId
import listings.model.ConversationListingSummary

final case class ConversationListingTarget(
  summary: ConversationListingSummary,
  agentId: UserId
)
