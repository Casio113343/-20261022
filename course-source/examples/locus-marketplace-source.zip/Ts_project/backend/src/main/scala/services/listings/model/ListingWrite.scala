package listings.model


import io.circe.{Decoder, DecodingFailure}
import io.circe.generic.semiauto.deriveDecoder

sealed trait ListingWrite:
  def title: String
  def description: String
  def transactionType: TransactionType
  def propertyType: PropertyType
  def price: Int
  def addressLine: String
  def suburb: String
  def state: String
  def postcode: String
  def bedrooms: Int
  def bathrooms: Int
  def carSpaces: Int
  def landSize: Option[Int]
  def buildingSize: Option[Int]
  def listingStatus: ListingStatus
  def renovateWithAi: Boolean
  def images: List[ListingImageInput]
  def faqs: List[ListingFaq]
  def houseSubtypeOption: Option[HouseSubtype]
  def apartmentSubtypeOption: Option[ApartmentSubtype]

object ListingWrite:
  final case class House(
    title: String,
    description: String,
    transactionType: TransactionType,
    houseSubtype: HouseSubtype,
    price: Int,
    addressLine: String,
    suburb: String,
    state: String,
    postcode: String,
    bedrooms: Int,
    bathrooms: Int,
    carSpaces: Int,
    landSize: Option[Int],
    buildingSize: Option[Int],
    listingStatus: ListingStatus,
    renovateWithAi: Boolean,
    images: List[ListingImageInput],
    faqs: List[ListingFaq]
  ) extends ListingWrite:
    val propertyType: PropertyType = PropertyType.House
    val apartmentSubtypeOption: Option[ApartmentSubtype] = None
    def houseSubtypeOption: Option[HouseSubtype] = Some(houseSubtype)

  final case class Apartment(
    title: String,
    description: String,
    transactionType: TransactionType,
    apartmentSubtype: ApartmentSubtype,
    price: Int,
    addressLine: String,
    suburb: String,
    state: String,
    postcode: String,
    bedrooms: Int,
    bathrooms: Int,
    carSpaces: Int,
    landSize: Option[Int],
    buildingSize: Option[Int],
    listingStatus: ListingStatus,
    renovateWithAi: Boolean,
    images: List[ListingImageInput],
    faqs: List[ListingFaq]
  ) extends ListingWrite:
    val propertyType: PropertyType = PropertyType.Apartment
    val houseSubtypeOption: Option[HouseSubtype] = None
    def apartmentSubtypeOption: Option[ApartmentSubtype] = Some(apartmentSubtype)

  final case class VacantLand(
    title: String,
    description: String,
    transactionType: TransactionType,
    price: Int,
    addressLine: String,
    suburb: String,
    state: String,
    postcode: String,
    bedrooms: Int,
    bathrooms: Int,
    carSpaces: Int,
    landSize: Option[Int],
    buildingSize: Option[Int],
    listingStatus: ListingStatus,
    renovateWithAi: Boolean,
    images: List[ListingImageInput],
    faqs: List[ListingFaq]
  ) extends ListingWrite:
    val propertyType: PropertyType = PropertyType.VacantLand
    val houseSubtypeOption: Option[HouseSubtype] = None
    val apartmentSubtypeOption: Option[ApartmentSubtype] = None

  given Decoder[ListingWrite] = Decoder.instance { cursor =>
    cursor.get[PropertyType]("propertyType").flatMap {
      case PropertyType.House =>
        if cursor.downField("apartmentSubtype").succeeded then
          Left(DecodingFailure("House listings cannot include apartmentSubtype", cursor.history))
        else
          deriveDecoder[House].tryDecode(cursor)
      case PropertyType.Apartment =>
        if cursor.downField("houseSubtype").succeeded then
          Left(DecodingFailure("Apartment listings cannot include houseSubtype", cursor.history))
        else
          deriveDecoder[Apartment].tryDecode(cursor)
      case PropertyType.VacantLand =>
        if cursor.downField("houseSubtype").succeeded || cursor.downField("apartmentSubtype").succeeded then
          Left(DecodingFailure("Vacant land listings cannot include property subtypes", cursor.history))
        else
          deriveDecoder[VacantLand].tryDecode(cursor)
    }
  }
