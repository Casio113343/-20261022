package messaging.tables.conversation_messages
import identity.model.*
import listings.model.*
import messaging.model.*


import cats.effect.IO
import shared.*
import messaging.tables.conversations.ConversationsTable
import messaging.tables.message_attachments.MessageAttachmentsTable
import shared.ListingMediaStorage

import java.sql.{Connection, ResultSet, Timestamp}
import java.time.Instant
import java.util.UUID

private[messaging] object ConversationMessagesTable:

  private val createSql: String =
    """
      |create table if not exists conversation_messages (
      |  id uuid primary key,
      |  conversation_id uuid not null references conversations(id) on delete cascade,
      |  sender_id uuid not null references users(id) on delete cascade,
      |  body text not null,
      |  created_at timestamptz not null,
      |  seen_at timestamptz
      |);
      |create index if not exists conversation_messages_conversation_idx on conversation_messages(conversation_id, created_at);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql))

  private final case class MessageBase(
    id: ConversationMessageId,
    conversationId: ConversationId,
    senderId: UserId,
    body: String,
    createdAt: Instant,
    seenAt: Option[Instant]
  ):
    def toMessage(attachments: List[MessageAttachment]): ConversationMessage =
      ConversationMessage(id, conversationId, senderId, body, attachments, createdAt, seenAt)

  private val listConversationMessagesSql: String =
    """
      |select id, conversation_id, sender_id, body, created_at, seen_at
      |from conversation_messages
      |where conversation_id = ?
      |order by created_at asc
      |""".stripMargin

  def listConversationMessages(
    connection: Connection,
    conversationId: ConversationId,
    storage: ListingMediaStorage
  ): IO[AppResult[List[ConversationMessage]]] =
    JdbcResources.select(connection, listConversationMessagesSql) { statement =>
      statement.setObject(1, conversationId.value)
    } { resultSet =>
      Iterator
        .continually(resultSet.next())
        .takeWhile(Predef.identity)
        .map(_ => readMessageBase(resultSet))
        .foldRight(Right(Nil): AppResult[List[MessageBase]])((next, acc) =>
          for
            head <- next
            tail <- acc
          yield head :: tail
        )
    }.flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(messages) =>
        messages.foldLeft(IO.pure(Right(Nil): AppResult[List[ConversationMessage]])) { (acc, message) =>
          for
            loaded <- acc
            next <- loaded match
              case Left(error) => IO.pure(Left(error))
              case Right(items) =>
                MessageAttachmentsTable
                  .listMessageAttachments(connection, message.id, storage)
                  .map(_.map(attachments => items :+ message.toMessage(attachments)))
          yield next
        }
    }

  private val insertMessageSql: String =
    """
      |insert into conversation_messages (id, conversation_id, sender_id, body, created_at, seen_at)
      |values (?, ?, ?, ?, ?, null)
      |""".stripMargin

  def createConversationMessage(
    connection: Connection,
    conversationId: ConversationId,
    senderId: UserId,
    body: String,
    attachmentIds: List[MessageAttachmentId],
    storage: ListingMediaStorage
  ): IO[AppResult[ConversationMessage]] =
    for
      now <- RuntimeValues.now
      messageId <- RuntimeValues.uuid.map(ConversationMessageId(_))
      _ <- insertMessage(connection, messageId, conversationId, senderId, body, now)
      attachResult <- MessageAttachmentsTable.attachUploadedFiles(connection, messageId, senderId, attachmentIds)
      message <- attachResult match
        case Left(error) => IO.pure(Left(error))
        case Right(_) =>
          MessageAttachmentsTable.listMessageAttachments(connection, messageId, storage).map(
            _.map(attachments => ConversationMessage(messageId, conversationId, senderId, body, attachments, now, None))
          )
    yield message

  private def insertMessage(
    connection: Connection,
    messageId: ConversationMessageId,
    conversationId: ConversationId,
    senderId: UserId,
    body: String,
    createdAt: Instant
  ): IO[Unit] =
    JdbcResources.update(connection, insertMessageSql) { messageStatement =>
      messageStatement.setObject(1, messageId.value)
      messageStatement.setObject(2, conversationId.value)
      messageStatement.setObject(3, senderId.value)
      messageStatement.setString(4, body)
      messageStatement.setTimestamp(5, Timestamp.from(createdAt))
      messageStatement.executeUpdate()
    }.void *> ConversationsTable.touch(connection, conversationId, createdAt)

  private val markConversationMessagesSeenSql: String =
    """
      |update conversation_messages
      |set seen_at = ?
      |where conversation_id = ?
      |  and sender_id <> ?
      |  and seen_at is null
      |""".stripMargin

  def markConversationMessagesSeen(
    connection: Connection,
    conversationId: ConversationId,
    readerId: UserId
  ): IO[AppResult[Instant]] =
    for
      now <- RuntimeValues.now
      _ <- JdbcResources.update(connection, markConversationMessagesSeenSql) { statement =>
        statement.setTimestamp(1, Timestamp.from(now))
        statement.setObject(2, conversationId.value)
        statement.setObject(3, readerId.value)
        statement.executeUpdate()
      }
    yield Right(now)

  private val loadLastMessageSql: String =
    """
      |select id, conversation_id, sender_id, body, created_at, seen_at
      |from conversation_messages
      |where conversation_id = ?
      |order by created_at desc
      |limit 1
      |""".stripMargin

  def loadLastMessage(connection: Connection, conversationId: ConversationId): IO[AppResult[Option[ConversationMessage]]] =
    JdbcResources.select(connection, loadLastMessageSql) { statement =>
      statement.setObject(1, conversationId.value)
    } { resultSet =>
      if resultSet.next() then readMessageBase(resultSet).map(Some(_))
      else Right(None)
    }.flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right(None) => IO.pure(Right(None))
      case Right(Some(base)) => IO.pure(Right(Some(base.toMessage(Nil))))
    }

  private val insertIntroMessageSql: String =
    """
      |insert into conversation_messages (id, conversation_id, sender_id, body, created_at, seen_at)
      |select ?, ?, ?, ?, ?, null
      |where not exists (
      |  select 1
      |  from conversation_messages existing
      |  where existing.conversation_id = ?
      |    and existing.sender_id = ?
      |    and existing.body = ?
      |)
      |""".stripMargin

  def insertIntroMessageIfAbsent(
    connection: Connection,
    messageId: ConversationMessageId,
    conversationId: ConversationId,
    agentId: UserId,
    body: String,
    createdAt: Instant
  ): IO[Unit] =
    JdbcResources.update(connection, insertIntroMessageSql) { statement =>
      statement.setObject(1, messageId.value)
      statement.setObject(2, conversationId.value)
      statement.setObject(3, agentId.value)
      statement.setString(4, body)
      statement.setTimestamp(5, Timestamp.from(createdAt))
      statement.setObject(6, conversationId.value)
      statement.setObject(7, agentId.value)
      statement.setString(8, body)
      statement.executeUpdate()
    }.void

  private val insertSystemMessageSql: String =
    """
      |insert into conversation_messages (id, conversation_id, sender_id, body, created_at, seen_at)
      |values (?, ?, ?, ?, ?, null)
      |""".stripMargin

  def insertSystemMessage(
    connection: Connection,
    messageId: ConversationMessageId,
    conversationId: ConversationId,
    senderId: UserId,
    body: String,
    occurredAt: Instant
  ): IO[Unit] =
    JdbcResources.update(connection, insertSystemMessageSql) { statement =>
      statement.setObject(1, messageId.value)
      statement.setObject(2, conversationId.value)
      statement.setObject(3, senderId.value)
      statement.setString(4, body)
      statement.setTimestamp(5, Timestamp.from(occurredAt))
      statement.executeUpdate()
    }.void

  private def readMessageBase(resultSet: ResultSet): AppResult[MessageBase] =
    Option(resultSet.getString("body"))
      .toRight(AppError.Decoding("Message body is missing"))
      .map(body =>
        MessageBase(
          id = ConversationMessageId(resultSet.getObject("id", classOf[UUID])),
          conversationId = ConversationId(resultSet.getObject("conversation_id", classOf[UUID])),
          senderId = UserId(resultSet.getObject("sender_id", classOf[UUID])),
          body = body,
          createdAt = resultSet.getTimestamp("created_at").toInstant,
          seenAt = Option(resultSet.getTimestamp("seen_at")).map(_.toInstant)
        )
      )
