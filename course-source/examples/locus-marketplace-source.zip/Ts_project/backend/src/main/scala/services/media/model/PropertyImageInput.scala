package media.model


import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class PropertyImageInput(
  id: PropertyImageId,
  altText: Option[String],
  isFloorPlan: Boolean
)

object PropertyImageInput:
  given Encoder[PropertyImageInput] = deriveEncoder[PropertyImageInput]
  given Decoder[PropertyImageInput] = deriveDecoder[PropertyImageInput]
