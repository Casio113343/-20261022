package listings.model


import io.circe.{Decoder, Encoder}

enum ListingStatus:
  case Active
  case Sold
  case Leased
  case Archived

object ListingStatus:
  def fromString(value: String): Either[String, ListingStatus] =
    value.trim.toLowerCase match
      case "active" => Right(ListingStatus.Active)
      case "sold" => Right(ListingStatus.Sold)
      case "leased" => Right(ListingStatus.Leased)
      case "archived" => Right(ListingStatus.Archived)
      case other => Left(s"Unsupported listing status: $other")

  def toString(value: ListingStatus): String =
    value match
      case ListingStatus.Active => "active"
      case ListingStatus.Sold => "sold"
      case ListingStatus.Leased => "leased"
      case ListingStatus.Archived => "archived"

  given Encoder[ListingStatus] = Encoder.encodeString.contramap(toString)
  given Decoder[ListingStatus] = Decoder.decodeString.emap(fromString)
