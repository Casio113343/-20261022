package inspections.api.responses
import identity.model.*
import listings.model.*
import messaging.model.ConversationId


import inspections.model.PublicInspectionSlot
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class ChangeInspectionBookingResponse(previousSlot: PublicInspectionSlot, slot: PublicInspectionSlot)

object ChangeInspectionBookingResponse:
  given Encoder[ChangeInspectionBookingResponse] = deriveEncoder[ChangeInspectionBookingResponse]
