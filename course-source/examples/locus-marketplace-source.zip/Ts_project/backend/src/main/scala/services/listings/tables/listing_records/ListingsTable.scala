package listings.tables.listing_records
import identity.model.*
import listings.model.*
import media.model.*


import cats.effect.IO
import shared.SchemaSupport

import java.sql.Connection

private[listings] object ListingsTable:

  private val createSql: String =
    """
      |create table if not exists listings (
      |  id uuid primary key,
      |  title varchar(220) not null,
      |  description text not null,
      |  transaction_type varchar(16) not null check (transaction_type in ('sale', 'rent')),
      |  property_type varchar(24) not null check (property_type in ('house', 'apartment', 'vacant_land')),
      |  house_subtype varchar(32) check (house_subtype in ('free_standing', 'duplex', 'terrace', 'villa', 'off_the_plan')),
      |  apartment_subtype varchar(32) check (apartment_subtype in ('standard', 'unit', 'penthouse', 'studio', 'off_the_plan')),
      |  price int not null,
      |  address_line varchar(220) not null,
      |  suburb varchar(120) not null,
      |  state varchar(16) not null,
      |  postcode varchar(8) not null,
      |  bedrooms int not null,
      |  bathrooms int not null,
      |  car_spaces int not null,
      |  land_size int,
      |  building_size int,
      |  listing_status varchar(24) not null check (listing_status in ('active', 'sold', 'leased', 'archived')),
      |  renovate_with_ai boolean not null default false,
      |  faqs jsonb not null default '[]'::jsonb,
      |  agent_id uuid not null references users(id),
      |  created_at timestamptz not null,
      |  updated_at timestamptz not null
      |);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql)) *> migrate(connection)

  private val migrationSql: List[String] =
    List(
      """
        |alter table listings
        |add column if not exists faqs jsonb not null default '[]'::jsonb;
        |""".stripMargin,
      """
        |alter table listings
        |add column if not exists renovate_with_ai boolean not null default false;
        |""".stripMargin,
      """
        |alter table listings
        |drop constraint if exists listings_property_condition_check;
        |""".stripMargin,
      """
        |alter table listings
        |drop column if exists property_condition;
        |""".stripMargin,
      """
        |alter table listings
        |add column if not exists house_subtype varchar(32);
        |""".stripMargin,
      """
        |alter table listings
        |add column if not exists apartment_subtype varchar(32);
        |""".stripMargin,
      """
        |alter table listings
        |drop constraint if exists listings_apartment_subtype_check;
        |""".stripMargin,
      """
        |alter table listings
        |drop constraint if exists listings_listing_status_check;
        |""".stripMargin,
      """
        |update listings
        |set listing_status = 'sold'
        |where transaction_type = 'sale' and listing_status = 'archived';
        |""".stripMargin,
      """
        |update listings
        |set listing_status = 'leased'
        |where transaction_type = 'rent' and listing_status = 'archived';
        |""".stripMargin,
      """
        |update listings
        |set property_type = 'house',
        |    house_subtype = coalesce(house_subtype, 'terrace')
        |where property_type = 'townhouse';
        |""".stripMargin,
      """
        |update listings
        |set property_type = 'apartment',
        |    apartment_subtype = coalesce(apartment_subtype, 'unit')
        |where property_type = 'unit';
        |""".stripMargin,
      """
        |alter table listings
        |drop constraint if exists listings_property_type_check;
        |""".stripMargin,
      """
        |alter table listings
        |add constraint listings_property_type_check
        |check (property_type in ('house', 'apartment', 'vacant_land'));
        |""".stripMargin,
      """
        |alter table listings
        |drop constraint if exists listings_house_subtype_check;
        |""".stripMargin,
      """
        |alter table listings
        |add constraint listings_listing_status_check
        |check (listing_status in ('active', 'sold', 'leased', 'archived'));
        |""".stripMargin,
      """
        |alter table listings
        |add constraint listings_house_subtype_check
        |check (house_subtype is null or house_subtype in ('free_standing', 'duplex', 'terrace', 'villa', 'off_the_plan'));
        |""".stripMargin,
      """
        |alter table listings
        |add constraint listings_apartment_subtype_check
        |check (apartment_subtype is null or apartment_subtype in ('standard', 'unit', 'penthouse', 'studio', 'off_the_plan'));
        |""".stripMargin,
      """
        |update listings
        |set house_subtype = 'free_standing'
        |where property_type = 'house' and house_subtype is null;
        |""".stripMargin,
      """
        |update listings
        |set apartment_subtype = 'standard'
        |where property_type = 'apartment' and apartment_subtype is null;
        |""".stripMargin,
      """
        |alter table listings
        |drop constraint if exists listings_property_subtype_consistency_check;
        |""".stripMargin,
      """
        |alter table listings
        |add constraint listings_property_subtype_consistency_check
        |check (
        |  (property_type = 'house' and house_subtype is not null and apartment_subtype is null) or
        |  (property_type = 'apartment' and apartment_subtype is not null and house_subtype is null) or
        |  (property_type = 'vacant_land' and house_subtype is null and apartment_subtype is null)
        |);
        |""".stripMargin
    )

  private def migrate(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, migrationSql)
