package favourites.routes
import identity.model.*
import listings.model.*

import shared.ApiServiceMessages
import favourites.api.messages.{ListFavouriteListingsApiMessage, SetFavouriteListingApiMessage}
import shared.ListingMediaStorage

object FavouriteRoutes:

  def apiMessages(storage: ListingMediaStorage): ApiServiceMessages =
    ApiServiceMessages("favourites", List(
      ListFavouriteListingsApiMessage(storage),
      SetFavouriteListingApiMessage(storage)
    ))
