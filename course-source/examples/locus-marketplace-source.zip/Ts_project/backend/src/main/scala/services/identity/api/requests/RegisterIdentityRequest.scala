package identity.api.requests
import identity.model.*


import io.circe.Decoder
import io.circe.generic.semiauto.deriveDecoder
import identity.model.UserRole

final case class RegisterIdentityRequest(
  fullName: String,
  email: String,
  password: String,
  role: UserRole,
  agencyName: Option[String],
  phone: Option[String]
)

object RegisterIdentityRequest:
  given Decoder[RegisterIdentityRequest] = deriveDecoder[RegisterIdentityRequest]
