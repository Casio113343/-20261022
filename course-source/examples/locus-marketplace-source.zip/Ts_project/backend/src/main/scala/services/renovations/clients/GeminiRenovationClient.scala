package renovations.clients

import cats.effect.IO
import io.circe.{Json, parser}
import io.circe.syntax.*
import org.typelevel.log4cats.slf4j.Slf4jLogger
import shared.{AppError, AppResult}

import java.net.URI
import java.net.http.{HttpClient, HttpRequest, HttpResponse}
import java.util.Base64
import scala.util.Try

final class GeminiRenovationClient private (
  apiKey: String,
  httpClient: HttpClient
):

  def generate(
    imageContentType: String,
    imageBytes: Array[Byte]
  ): IO[AppResult[GeneratedRenovation]] =
    val request =
      HttpRequest
        .newBuilder(GeminiRenovationClient.endpoint)
        .header("Content-Type", "application/json")
        .header("x-goog-api-key", apiKey)
        .POST(HttpRequest.BodyPublishers.ofString(
          GeminiRenovationClient.requestBody(imageContentType, imageBytes).noSpaces
        ))
        .build()

    IO.blocking(httpClient.send(request, HttpResponse.BodyHandlers.ofString())).attempt.flatMap {
      case Left(error) =>
        GeminiRenovationClient.logger
          .warn(error)("Unable to reach Gemini image generation")
          .as(Left(AppError.Unexpected("Unable to generate the renovation concept right now.")))
      case Right(response) if response.statusCode() / 100 != 2 =>
        GeminiRenovationClient.logger
          .warn(s"Gemini renovation request failed with ${response.statusCode()}: ${response.body()}")
          .as(Left(AppError.Unexpected("Unable to generate the renovation concept right now.")))
      case Right(response) =>
        IO.pure(GeminiRenovationClient.decodeResponse(response.body()))
    }

object GeminiRenovationClient:

  private val logger = Slf4jLogger.getLogger[IO]

  private val endpoint =
    URI.create("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-image:generateContent")

  val configured: IO[Option[GeminiRenovationClient]] =
    IO.delay(sys.env.get("GEMINI_API_KEY").map(_.trim).filter(_.nonEmpty)).flatMap {
      case None => IO.pure(None)
      case Some(apiKey) =>
        IO.delay(HttpClient.newHttpClient()).map(client => Some(GeminiRenovationClient(apiKey, client)))
    }

  private val prompt: String =
    """Create a photorealistic contemporary renovation concept for this exact property photo.
      |Preserve the existing room geometry, camera position, walls, windows, doors, ceiling height,
      |built-in structures, exterior openings, and visible spatial proportions.
      |Renovate only finishes, flooring, paint, lighting, cabinetry, fixtures, decor, landscaping,
      |and furniture where appropriate. Do not add rooms, windows, doors, stairs, pools, views,
      |or structural features that are not present. Keep the result realistic, restrained, bright,
      |and suitable for a premium real-estate listing. Return one edited image.
      |""".stripMargin

  private def requestBody(contentType: String, bytes: Array[Byte]): Json =
    Json.obj(
      "contents" -> Json.arr(
        Json.obj(
          "parts" -> Json.arr(
            Json.obj("text" -> Json.fromString(prompt)),
            Json.obj(
              "inline_data" -> Json.obj(
                "mime_type" -> Json.fromString(contentType),
                "data" -> Json.fromString(Base64.getEncoder.encodeToString(bytes))
              )
            )
          )
        )
      ),
      "generationConfig" -> Json.obj(
        "responseModalities" -> Json.arr(
          Json.fromString("TEXT"),
          Json.fromString("IMAGE")
        ),
        "imageConfig" -> Json.obj(
          "imageSize" -> Json.fromString("1K")
        )
      )
    )

  private def decodeResponse(body: String): AppResult[GeneratedRenovation] =
    for
      response <- parser.parse(body).left.map(_ => AppError.Decoding("Unable to read the Gemini image response."))
      parts <- response.hcursor
        .downField("candidates")
        .downArray
        .downField("content")
        .get[List[Json]]("parts")
        .left
        .map(_ => AppError.Decoding("Gemini did not return an image."))
      imagePart <- parts
        .find(part =>
          part.hcursor.downField("inlineData").succeeded ||
            part.hcursor.downField("inline_data").succeeded
        )
        .toRight(AppError.Decoding("Gemini did not return an image."))
      cursor =
        if imagePart.hcursor.downField("inlineData").succeeded then imagePart.hcursor.downField("inlineData")
        else imagePart.hcursor.downField("inline_data")
      contentType <- cursor
        .get[String]("mimeType")
        .orElse(cursor.get[String]("mime_type"))
        .left
        .map(_ => AppError.Decoding("Gemini returned an image without a content type."))
      encoded <- cursor
        .get[String]("data")
        .left
        .map(_ => AppError.Decoding("Gemini returned an empty image."))
      bytes <- Try(Base64.getDecoder.decode(encoded))
        .toEither
        .left
        .map(_ => AppError.Decoding("Gemini returned invalid image data."))
    yield GeneratedRenovation(bytes, contentType)
