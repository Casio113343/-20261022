package analytics.api.messages

import analytics.api.requests.RecordListingAnalyticsEventsRequest
import analytics.api.responses.RecordListingAnalyticsEventsResponse
import analytics.tables.listing_analytics_events.ListingAnalyticsEventsTable
import cats.effect.IO
import shared.{ApiTransaction, AppError, AppResult, JsonApiMessage, RuntimeValues}

import java.sql.Connection

object RecordListingAnalyticsEventsApiMessage
    extends JsonApiMessage[RecordListingAnalyticsEventsRequest, RecordListingAnalyticsEventsResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadWrite

  override def plan(
    request: RecordListingAnalyticsEventsRequest,
    connection: Connection
  ): IO[AppResult[RecordListingAnalyticsEventsResponse]] =
    val cleanEvents = request.events.take(160)

    if cleanEvents.isEmpty then
      IO.pure(Right(RecordListingAnalyticsEventsResponse(0)))
    else
      RuntimeValues.now
        .flatMap(ListingAnalyticsEventsTable.insertEvents(connection, cleanEvents, _))
        .map(count => Right(RecordListingAnalyticsEventsResponse(count)))
        .handleError(error => Left(AppError.Unexpected(error.getMessage)))
