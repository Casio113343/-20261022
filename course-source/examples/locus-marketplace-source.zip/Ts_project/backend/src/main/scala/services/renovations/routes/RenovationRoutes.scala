package renovations.routes

import renovations.api.messages.ListListingRenovationsApiMessage
import shared.{ApiServiceMessages, ListingMediaStorage}

object RenovationRoutes:
  def apiMessages(storage: ListingMediaStorage): ApiServiceMessages =
    ApiServiceMessages("renovations", List(ListListingRenovationsApiMessage(storage)))
