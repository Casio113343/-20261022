package fengshui.api.responses
import identity.model.*
import listings.model.*
import media.model.*


import fengshui.model.FengshuiAnalysis
import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class AnalyseFloorPlanResponse(analysis: FengshuiAnalysis)

object AnalyseFloorPlanResponse:
  given Encoder[AnalyseFloorPlanResponse] = deriveEncoder[AnalyseFloorPlanResponse]
