package inspections.tables.inspection_bookings
import identity.model.*
import cats.effect.IO
import inspections.model.*
import shared.*

import java.sql.{Connection, Timestamp}
import java.time.Instant

private[inspections] object InspectionBookingsTable:

  private val createSql: String =
    """
      |create table if not exists inspection_bookings (
      |  id uuid primary key,
      |  slot_id uuid not null unique references inspection_slots(id) on delete cascade,
      |  listing_id uuid not null references listings(id) on delete cascade,
      |  buyer_id uuid not null references users(id) on delete cascade,
      |  created_at timestamptz not null
      |);
      |create index if not exists inspection_bookings_buyer_idx on inspection_bookings(buyer_id, created_at);
      |""".stripMargin

  def initialize(connection: Connection): IO[Unit] =
    SchemaSupport.executeStatements(connection, List(createSql))

  private val bookSlotSql: String =
    """
      |insert into inspection_bookings (id, slot_id, listing_id, buyer_id, created_at)
      |select ?, s.id, s.listing_id, ?, ?
      |from inspection_slots s
      |where s.id = ?
      |  and s.starts_at > now()
      |  and not exists (select 1 from inspection_bookings b where b.slot_id = s.id)
      |""".stripMargin

  def bookSlot(
    connection: Connection,
    bookingId: InspectionBookingId,
    buyerId: UserId,
    slotId: InspectionSlotId,
    createdAt: Instant
  ): IO[Int] =
    JdbcResources.update(connection, bookSlotSql) { statement =>
      statement.setObject(1, bookingId.value)
      statement.setObject(2, buyerId.value)
      statement.setTimestamp(3, Timestamp.from(createdAt))
      statement.setObject(4, slotId.value)
      statement.executeUpdate()
    }

  private val changeBookingSql: String =
    """
      |update inspection_bookings b
      |set slot_id = next_slot.id,
      |    listing_id = next_slot.listing_id,
      |    created_at = ?
      |from inspection_slots current_slot, inspection_slots next_slot
      |where b.buyer_id = ?
      |  and b.slot_id = current_slot.id
      |  and current_slot.id = ?
      |  and next_slot.id = ?
      |  and next_slot.listing_id = current_slot.listing_id
      |  and current_slot.starts_at > now()
      |  and next_slot.starts_at > now()
      |  and not exists (
      |    select 1
      |    from inspection_bookings occupied
      |    where occupied.slot_id = next_slot.id
      |  )
      |""".stripMargin

  def changeBooking(
    connection: Connection,
    buyerId: UserId,
    currentSlotId: InspectionSlotId,
    nextSlotId: InspectionSlotId,
    changedAt: Instant
  ): IO[Int] =
    JdbcResources.update(connection, changeBookingSql) { statement =>
      statement.setTimestamp(1, Timestamp.from(changedAt))
      statement.setObject(2, buyerId.value)
      statement.setObject(3, currentSlotId.value)
      statement.setObject(4, nextSlotId.value)
      statement.executeUpdate()
    }

  private val cancelBookingSql: String =
    """
      |delete from inspection_bookings b
      |using inspection_slots s
      |where b.buyer_id = ?
      |  and b.slot_id = ?
      |  and s.id = b.slot_id
      |  and s.starts_at > now()
      |""".stripMargin

  def cancelBooking(connection: Connection, buyerId: UserId, slotId: InspectionSlotId): IO[Int] =
    JdbcResources.update(connection, cancelBookingSql) { statement =>
      statement.setObject(1, buyerId.value)
      statement.setObject(2, slotId.value)
      statement.executeUpdate()
    }
