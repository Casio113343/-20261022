package media.model


import io.circe.{Decoder, Encoder}

import java.util.UUID
import scala.util.Try

final case class PropertyImageId(value: UUID)

object PropertyImageId:
  given Encoder[PropertyImageId] = Encoder.encodeString.contramap(_.value.toString)
  given Decoder[PropertyImageId] = Decoder.decodeString.emap(parseUuid(_, "propertyImageId").map(PropertyImageId(_)))

  private def parseUuid(value: String, label: String): Either[String, UUID] =
    Try(UUID.fromString(value)).toEither.left.map(_ => s"Invalid $label")
