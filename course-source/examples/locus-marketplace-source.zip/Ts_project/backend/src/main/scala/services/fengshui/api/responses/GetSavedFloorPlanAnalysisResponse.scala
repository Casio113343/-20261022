package fengshui.api.responses
import identity.model.*
import listings.model.*
import media.model.*


import io.circe.Encoder
import io.circe.generic.semiauto.deriveEncoder

final case class GetSavedFloorPlanAnalysisResponse(
  savedAnalysis: Option[SavedFengshuiAnalysis]
)

object GetSavedFloorPlanAnalysisResponse:
  given Encoder[GetSavedFloorPlanAnalysisResponse] = deriveEncoder[GetSavedFloorPlanAnalysisResponse]
