package fengshui.api.messages
import identity.model.*
import listings.model.*
import media.model.*


import shared.{ApiTransaction, ApiWithTokenMessage}
import cats.effect.IO
import fengshui.api.requests.GetSavedFloorPlanAnalysisRequest
import fengshui.api.responses.{GetSavedFloorPlanAnalysisResponse, SavedFengshuiAnalysis}
import fengshui.tables.fengshui_analyses.FengshuiAnalysesTable
import shared.AppResult
import shared.AuthenticatedPrincipal

import java.sql.Connection

object GetSavedFloorPlanAnalysisApiMessage
    extends ApiWithTokenMessage[GetSavedFloorPlanAnalysisRequest, GetSavedFloorPlanAnalysisResponse]:

  override val transaction: ApiTransaction = ApiTransaction.ReadOnly

  override def plan(
    request: GetSavedFloorPlanAnalysisRequest,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[GetSavedFloorPlanAnalysisResponse]] =
    FengshuiAnalysesTable
      .findSavedAnalysis(connection, principal.userId, request.listingId)
      .map(_.map(savedAnalysis =>
        GetSavedFloorPlanAnalysisResponse(
          savedAnalysis.map(saved => SavedFengshuiAnalysis(saved.analysis))
        )
      ))
