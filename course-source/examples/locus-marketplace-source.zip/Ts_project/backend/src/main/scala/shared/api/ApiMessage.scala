package shared

import cats.effect.IO
import database.TransactionSuccess
import io.circe.{Decoder, Encoder, Json}
import org.http4s.multipart.Multipart

import java.sql.Connection

sealed trait ApiSessionDirective

object ApiSessionDirective:
  case object None extends ApiSessionDirective
  final case class Create(sessionToken: String, csrfToken: String) extends ApiSessionDirective
  case object Clear extends ApiSessionDirective

final case class SessionCreatedResponse[Body](
  body: Body,
  sessionToken: String,
  csrfToken: String
)

object SessionCreatedResponse:
  given [Body: Encoder]: Encoder[SessionCreatedResponse[Body]] =
    summon[Encoder[Body]].contramap(_.body)

trait SessionClearedResponse

final case class ApiResponse(
  body: Json,
  sessionDirective: ApiSessionDirective = ApiSessionDirective.None
)

enum ApiAuthorization:
  case Public
  case OptionalPrincipal
  case RequiredPrincipal

enum ResolvedApiAuthorization:
  case Public
  case OptionalPrincipal(principal: Option[AuthenticatedPrincipal])
  case RequiredPrincipal(principal: AuthenticatedPrincipal, sessionToken: String)

enum ApiTransaction:
  case ReadWrite
  case ReadOnly
  case AfterCommit

sealed trait ApiMessage:
  def apiName: String =
    ApiMessage.deriveApiName(this)

  def authorization: ApiAuthorization

  def transaction: ApiTransaction

  def decodeJson(json: Json): AppResult[ApiMessage.Request]

  def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]]

private[shared] trait MultipartMessage extends ApiMessage:
  def decodeMultipartAny(multipart: Multipart[IO]): IO[AppResult[ApiMessage.Request]]

trait JsonApiMessage[Request: Decoder, Response: Encoder] extends ApiMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.Public

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    ApiMessage.decode[Request](json)

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.Public =>
        plan(request.asInstanceOf[Request], connection).map(_.map(ApiMessage.encode(_)))
      case _ => IO.pure(Left(AppError.Unexpected("Public API received authenticated execution context")))

  def plan(request: Request, connection: Connection): IO[AppResult[Response]]

trait ApiWithTokenMessage[Request: Decoder, Response: Encoder] extends ApiMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.RequiredPrincipal

  protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    Right(principal)

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    ApiMessage.decode[Request](json)

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.RequiredPrincipal(principal, _) =>
        authorizePrincipal(principal) match
          case Right(authorizedPrincipal) =>
            plan(request.asInstanceOf[Request], authorizedPrincipal, connection)
              .map(_.map(ApiMessage.encode(_)))
          case Left(error) => IO.pure(Left(error))
      case _ => IO.pure(Left(AppError.Unauthorized("You must be signed in")))

  def plan(
    request: Request,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[Response]]

trait OptionalTokenApiMessage[Request: Decoder, Response: Encoder] extends ApiMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.OptionalPrincipal

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    ApiMessage.decode[Request](json)

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.OptionalPrincipal(principal) =>
        plan(request.asInstanceOf[Request], principal, connection).map(_.map(ApiMessage.encode(_)))
      case _ => IO.pure(Left(AppError.Unexpected("Optional-user API received invalid execution context")))

  def plan(
    request: Request,
    principal: Option[AuthenticatedPrincipal],
    connection: Connection
  ): IO[AppResult[Response]]

trait NoRequestMessage[Response: Encoder] extends ApiMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.Public

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    Right(())

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.Public =>
        plan(connection).map(_.map(ApiMessage.encode(_)))
      case _ => IO.pure(Left(AppError.Unexpected("Public API received authenticated execution context")))

  def plan(connection: Connection): IO[AppResult[Response]]

trait NoRequestWithTokenMessage[Response: Encoder] extends ApiMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.RequiredPrincipal

  protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    Right(principal)

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    Right(())

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.RequiredPrincipal(principal, _) =>
        authorizePrincipal(principal) match
          case Right(authorizedPrincipal) => plan(authorizedPrincipal, connection).map(_.map(ApiMessage.encode(_)))
          case Left(error) => IO.pure(Left(error))
      case _ => IO.pure(Left(AppError.Unauthorized("You must be signed in")))

  def plan(principal: AuthenticatedPrincipal, connection: Connection): IO[AppResult[Response]]

trait NoRequestWithSessionTokenMessage[Response: Encoder] extends ApiMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.RequiredPrincipal

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    Right(())

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.RequiredPrincipal(_, sessionToken) =>
        plan(sessionToken, connection).map(_.map(ApiMessage.encode(_)))
      case _ => IO.pure(Left(AppError.Unauthorized("You must be signed in")))

  def plan(sessionToken: String, connection: Connection): IO[AppResult[Response]]

trait MultipartWithTokenMessage[Request, Response: Encoder] extends MultipartMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.RequiredPrincipal

  protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    Right(principal)

  def decodeMultipart(multipart: Multipart[IO]): IO[AppResult[Request]]

  final override def decodeMultipartAny(
    multipart: Multipart[IO]
  ): IO[AppResult[ApiMessage.Request]] =
    decodeMultipart(multipart).map(_.map(_.asInstanceOf[ApiMessage.Request]))

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    Left(AppError.Decoding(s"$apiName expects multipart input"))

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.RequiredPrincipal(principal, _) =>
        authorizePrincipal(principal) match
          case Right(authorizedPrincipal) =>
            plan(request.asInstanceOf[Request], authorizedPrincipal, connection)
              .map(_.map(ApiMessage.encode(_)))
          case Left(error) => IO.pure(Left(error))
      case _ => IO.pure(Left(AppError.Unauthorized("You must be signed in")))

  def plan(
    request: Request,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[Response]]

trait AfterCommitApiWithTokenMessage[Request: Decoder, Response: Encoder] extends ApiMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.RequiredPrincipal
  final override val transaction: ApiTransaction = ApiTransaction.AfterCommit

  protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    Right(principal)

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    ApiMessage.decode[Request](json)

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.RequiredPrincipal(principal, _) =>
        authorizePrincipal(principal) match
          case Right(authorizedPrincipal) =>
            plan(request.asInstanceOf[Request], authorizedPrincipal, connection)
              .map(_.map(ApiMessage.encodeTransaction(_)))
          case Left(error) => IO.pure(Left(error))
      case _ => IO.pure(Left(AppError.Unauthorized("You must be signed in")))

  def plan(
    request: Request,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[TransactionSuccess[Response]]]

trait AfterCommitMultipartApiMessage[Request, Response: Encoder] extends MultipartMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.Public
  final override val transaction: ApiTransaction = ApiTransaction.AfterCommit

  def decodeMultipart(multipart: Multipart[IO]): IO[AppResult[Request]]

  final override def decodeMultipartAny(
    multipart: Multipart[IO]
  ): IO[AppResult[ApiMessage.Request]] =
    decodeMultipart(multipart).map(_.map(_.asInstanceOf[ApiMessage.Request]))

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    Left(AppError.Decoding(s"$apiName expects multipart input"))

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.Public =>
        plan(request.asInstanceOf[Request], connection).map(_.map(ApiMessage.encodeTransaction(_)))
      case _ => IO.pure(Left(AppError.Unexpected("Public API received authenticated execution context")))

  def plan(request: Request, connection: Connection): IO[AppResult[TransactionSuccess[Response]]]

trait AfterCommitMultipartWithTokenMessage[Request, Response: Encoder] extends MultipartMessage:
  final override val authorization: ApiAuthorization = ApiAuthorization.RequiredPrincipal
  final override val transaction: ApiTransaction = ApiTransaction.AfterCommit

  protected def authorizePrincipal(principal: AuthenticatedPrincipal): AppResult[AuthenticatedPrincipal] =
    Right(principal)

  def decodeMultipart(multipart: Multipart[IO]): IO[AppResult[Request]]

  final override def decodeMultipartAny(
    multipart: Multipart[IO]
  ): IO[AppResult[ApiMessage.Request]] =
    decodeMultipart(multipart).map(_.map(_.asInstanceOf[ApiMessage.Request]))

  final override def decodeJson(json: Json): AppResult[ApiMessage.Request] =
    Left(AppError.Decoding(s"$apiName expects multipart input"))

  final override def planAny(
    request: ApiMessage.Request,
    authorization: ResolvedApiAuthorization,
    connection: Connection
  ): IO[AppResult[ApiMessage.Response]] =
    authorization match
      case ResolvedApiAuthorization.RequiredPrincipal(principal, _) =>
        authorizePrincipal(principal) match
          case Right(authorizedPrincipal) =>
            plan(request.asInstanceOf[Request], authorizedPrincipal, connection)
              .map(_.map(ApiMessage.encodeTransaction(_)))
          case Left(error) => IO.pure(Left(error))
      case _ => IO.pure(Left(AppError.Unauthorized("You must be signed in")))

  def plan(
    request: Request,
    principal: AuthenticatedPrincipal,
    connection: Connection
  ): IO[AppResult[TransactionSuccess[Response]]]

final case class ApiServiceMessages(serviceName: String, messages: List[ApiMessage])

object ApiMessage:
  type Request = Any
  type Response = TransactionSuccess[ApiResponse]

  private[shared] def decode[Request: Decoder](json: Json): AppResult[Request] =
    summon[Decoder[Request]]
      .decodeJson(json)
      .left
      .map(error => AppError.Decoding(error.getMessage))

  private[shared] def encode[Response: Encoder](response: Response): ApiMessage.Response =
    TransactionSuccess(ApiResponse(summon[Encoder[Response]](response), sessionDirective(response)))

  private[shared] def encodeTransaction[Response: Encoder](
    transaction: TransactionSuccess[Response]
  ): ApiMessage.Response =
    transaction.copy(value = ApiResponse(summon[Encoder[Response]](transaction.value), sessionDirective(transaction.value)))

  private def sessionDirective(response: Any): ApiSessionDirective =
    response match
      case created: SessionCreatedResponse[?] =>
        ApiSessionDirective.Create(created.sessionToken, created.csrfToken)
      case _: SessionClearedResponse =>
        ApiSessionDirective.Clear
      case _ =>
        ApiSessionDirective.None

  def deriveApiName(message: ApiMessage): String =
    deriveApiNameFromClassName(message.getClass.getSimpleName)

  def deriveApiNameFromClassName(className: String): String =
    className
      .stripSuffix("$")
      .stripSuffix("ApiMessage")
      .replaceAll("([a-z0-9])([A-Z])", "$1-$2")
      .toLowerCase
