package messaging.api
import identity.model.*
import listings.model.*
import messaging.model.*


import cats.effect.IO
import shared.AppResult
import identity.model.UserId
import listings.model.ListingId
import messaging.application.MessagingApplication
import shared.ListingMediaStorage

import java.sql.Connection
import java.time.Instant

object MessagingPublicApi:

  def findOrCreateInspectionConversation(
    connection: Connection,
    storage: ListingMediaStorage,
    listingId: ListingId,
    buyerId: UserId
  ): IO[AppResult[ConversationId]] =
    MessagingApplication
      .findOrCreateConversation(connection, storage, listingId, buyerId)
      .map(_.map(_.id))

  def addListingBuyerSystemMessage(
    connection: Connection,
    listingId: ListingId,
    buyerId: UserId,
    agentId: UserId,
    body: String,
    occurredAt: Instant
  ): IO[AppResult[Unit]] =
    MessagingApplication.addListingBuyerSystemMessage(connection, listingId, buyerId, agentId, body, occurredAt)
