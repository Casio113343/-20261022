package identity.api.requests

import identity.model.UserRole

final case class RegisterWithProfilePictureRequest(
  fullName: String,
  email: String,
  password: String,
  role: UserRole,
  agencyName: Option[String],
  phone: Option[String],
  fileName: String,
  contentType: String,
  bytes: Array[Byte]
)
