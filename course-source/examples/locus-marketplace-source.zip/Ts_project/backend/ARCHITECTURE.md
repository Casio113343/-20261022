# System Overview

The backend is a modular monolith. It runs as one deployable application and uses one shared database connection layer, but the code is organised under `backend/src/main/scala/services` into domain modules with clear responsibilities and domain-owned tables.

## Modules

### Identity Module
- Responsibility: user registration, authentication, session lifecycle
- Internal components:
  - `identity.routes.AuthRoutes` registers identity API messages
  - `identity.api.messages.*` contains executable API message units
  - `identity.application.IdentityApplication` performs registration, authentication, session, and profile-picture workflows
  - identity table modules own `users`, `agent_profiles`, and `user_sessions`

### Listing Module
- Responsibility: listing search, listing detail reads, agent listing management
- Internal components:
  - listing routes register public and agent listing API messages
  - `listings.api.messages.*` contains executable API message units
  - `listings.application.ListingApplication` coordinates validation, listing tables, identity public APIs, media public APIs, and response enrichment
  - `listings.tables.listing_records` owns listing persistence

### Favourites Module
- Responsibility: user favourite listing lifecycle
- Internal components:
  - favourite routes register favourite API messages
  - favourite API messages call `favourites.tables.favourite_records.FavouritesTable`
  - `favourites.tables.favourite_records` owns favourite persistence

### Media Module
- Responsibility: listing image metadata and object-storage coordination
- Internal components:
  - media API messages expose image upload/delete workflows
  - shared storage infrastructure handles MinIO object operations
  - `media.tables.property_images` owns `property_images` persistence

### Messaging Module
- Responsibility: buyer-agent conversations, messages, and attachments
- Internal components:
  - messaging API messages expose conversation and attachment workflows
  - `MessagingRoutes` owns websocket transport
  - `messaging.application.MessagingWebSocketEventHandler` coordinates websocket events
  - messaging table modules own `conversations`, `conversation_messages`, and `message_attachments`

### Inspections Module
- Responsibility: inspection slot and booking lifecycle
- Internal components:
  - inspection API messages expose slot and booking workflows
  - inspection table modules own `inspection_slots` and `inspection_bookings`

### Fengshui Module
- Responsibility: floor-plan analysis and saved analysis lifecycle
- Internal components:
  - fengshui API messages expose analysis workflows
  - `fengshui.clients.GeminiFengshuiClient` owns the external Gemini integration
  - `fengshui.tables.fengshui_analyses` owns saved analysis persistence

### Renovations Module
- Responsibility: AI renovation generation, generation lifecycle, and buyer-facing renovation results
- Internal components:
  - renovation routes register renovation API messages
  - `renovations.api.RenovationScheduler` is the public scheduling boundary used by listings
  - `renovations.application.RenovationWorker` owns background generation orchestration
  - `renovations.clients.GeminiRenovationClient` owns the external Gemini image integration
  - `renovations.tables.renovation_images` owns renovation generation persistence

## Transport Model

- Business endpoints are organised as explicit request/response message contracts rather than REST-style action routes.
- Every API operation is represented by a backend `XxxApiMessage.scala` file with a direct `plan(...)` method.
- Frontend API callers live under `frontend/src/apis/<service>/api/messages` and mirror backend message files one-to-one where practical.
- Request and response transport types are separated under `api/requests` and `api/responses`.
- Backend service routes expose each service's supported message list; the top-level router merges those lists.
- Backend table definitions live under `services/<service>/tables`; the system schema initializer composes them but does not own their SQL.
- `shared.ApiMessageRouter` handles message lookup, request decoding, token resolution, plan execution, and response encoding.
- Application modules exist only where service-owned workflow coordination is clearer than repeating logic in API messages.
- Route parameters and query-string driven business APIs have been replaced with message payloads so the contract remains typed, versionable, and easy to mirror in the frontend.

## Boundary Rationale

- Identity logic remains together because password hashing, session tokens, and session lookup change together and form one cohesive authentication boundary.
- Listing logic remains together because listing search, listing detail reads, listing writes, and property images share the same read/write model.
- Favourites remain separate at the code level because they depend on authenticated users and listing identifiers, but their lifecycle is narrower than listing authoring.

## Persistence Model

- The backend currently uses one database and one shared connection/session layer.
- Domain modules live under `backend/src/main/scala/services` and own their table definitions under their own `tables` packages.
- `shared.Schema` is only an initialization composer; it does not define business tables directly.
- PostgreSQL stores structured listing and image metadata only.
- MinIO stores the listing photo bytes and serves them through bucket/object paths.
- Listings are no longer seeded at startup; buyer-visible property data comes from agent-created records.
- Module boundaries are enforced in code organisation, table ownership, and public API calls, not in separate databases or separate deployable services.
- If the system is split further in the future, these module boundaries are the intended starting point.
