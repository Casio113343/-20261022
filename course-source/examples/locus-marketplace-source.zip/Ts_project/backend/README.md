# LOCUS Backend

一个基于 Scala 3、Cats Effect、http4s、Circe、PostgreSQL 和 MinIO 的后端项目。

当前后端以 `services/*` 领域模块为主，采用模块化单体结构：

- `src/main/scala/app`: 应用入口、服务启动配置和顶层 HTTP 路由组合
- `src/main/scala/services/<service>/api/messages`: 每个业务 API 的可执行 message 文件
- `src/main/scala/services/<service>/api/requests|responses`: 与前端镜像对应的 API 传输类型
- `src/main/scala/services/<service>/routes`: 服务级 API message 注册与非 message transport（例如 websocket）
- `src/main/scala/services/<service>/application`: 需要跨表协调时的服务内 application/use-case 编排
- `src/main/scala/services/<service>/tables`: 服务拥有的 schema、SQL、row mapping 和 table helpers
- `src/main/scala/services/<service>/model`: 服务领域模型和值类型
- `src/main/scala/shared`: API message 基础设施、通用错误、schema composer、storage 和 codec 工具
- `src/main/scala/database`: 连接池、配置和事务管理

## 运行

支持的本地工具基线：

- JDK 21 LTS
- Scala 3.3.3
- sbt 1.10.1, declared in `project/build.properties`

Create local backend environment settings from the safe template when needed:

```bash
cp .env.example .env
```

The backend reads environment variables from the process environment. If your shell does not load `.env`
automatically, export the values before running `sbt run`.

```bash
sbt run
```

默认监听：

- `http://0.0.0.0:8080`

也可以通过环境变量覆盖：

- `BACKEND_HOST`
- `BACKEND_PORT`
- `SESSION_COOKIE_SECURE=true` should be set in HTTPS production deployments so auth cookies include the `Secure` attribute. Local HTTP development can leave it unset.

默认数据库连接：

- `host = 127.0.0.1`
- `port = 5432`
- `databaseName = 当前项目目录名，把 '-' 自动转成 '_'`
- `user = db`
- `password = root`

也可以通过环境变量覆盖：

- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USER`
- `DB_PASSWORD`
- `DB_MAX_POOL_SIZE`
- `DB_CONNECTION_TIMEOUT_MS`

默认 MinIO 连接：

- `MINIO_ENDPOINT = http://127.0.0.1:9000`
- `MINIO_PUBLIC_BASE_URL = http://127.0.0.1:9000`
- `MINIO_ACCESS_KEY = minioadmin`
- `MINIO_SECRET_KEY = minioadmin`
- `MINIO_BUCKET = listing-media`

也可以通过环境变量覆盖：

- `MINIO_ENDPOINT`
- `MINIO_PUBLIC_BASE_URL`
- `MINIO_ACCESS_KEY`
- `MINIO_SECRET_KEY`
- `MINIO_BUCKET`

Gemini 功能使用：

- `GEMINI_API_KEY`

同一个 key 同时支持户型 Feng Shui 分析和 Renovate with AI。Renovate with AI 调用
`gemini-3.1-flash-image`，因此该 key 所属 Google 项目必须启用 Gemini Developer API
付费访问。生成结果写入 MinIO；每个 listing 最多处理 15 张非 floor-plan 图片，已完成的图片不会在普通保存时重复生成。

Listing amenity search, place details, place photos, and travel-time summaries use server-side Google Maps Platform calls:

- `GOOGLE_MAPS_API_KEY`
- fallback: `GOOGLE_PLACES_API_KEY`

The frontend `VITE_GOOGLE_MAPS_API_KEY` is only for the browser Maps JavaScript SDK. Places Web Service and Routes API calls are mediated by the backend so request shape, response normalization, and spend controls remain server-owned.

## API 示例

### 健康检查

```bash
curl http://127.0.0.1:8080/api/health
```

其余业务接口见 `ARCHITECTURE.md`。

业务 API 以显式消息契约组织：

- 每个接口都有一个后端 `XxxApiMessage.scala`，公开 `plan(...)` 作为业务执行入口
- 前端 `frontend/src/apis/<service>/api/messages/XxxApi.ts` 与后端 message 文件一一对应
- 请求和响应类型分别位于 `api/requests` 与 `api/responses`
- 服务级 `routes` 只注册本服务支持的 API messages
- 顶层 `app.api.MarketplaceRouter` 合并各服务的 message 注册列表
- `shared.ApiMessageRouter` 负责查找 message、解析请求、解析 token、执行 `plan`、序列化响应
- API route name 由 API class/object 名统一派生

图片上传流程：

- 先调用 media 服务的 upload message 上传文件到 MinIO
- 后端在 PostgreSQL 中保存对象元数据
- 再调用 listing 服务的 save message，提交图片 `id` 列表和排序；创建时省略 `listingId`，更新时带上 `listingId`

当前不会在启动时自动插入 demo listings 或 demo 图片。买家端看到的房源来自 agent portal 中实际创建的记录。

## 日志

服务启动后可以在控制台看到：

- 服务启动日志
- API 访问日志
- http4s 中间件输出的请求日志和响应日志
