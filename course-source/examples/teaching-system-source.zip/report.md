# 项目介绍

这是一个线上教学系统，有课程、通知、作业、考试、问卷、聊天等多个板块。


## 分工

单人组，全自己完成


## 类型与系统架构

有六个微服务，见 `frontend/src/microservices/` 和 `backend/src/main/scala/microservices/`，分别是
- auth, 负责用户身份相关事务，如登录注册等；
- assignment, 作业相关事务；
- course, 课程相关事务，如创建课程、成员加入及退出等，另外公告和聊天本身比较小，也放在这里；
- dashboard, 负责主页消息汇总整理，如待办数、系统通知等；
- exam, 考试相关事务；
- questionnaire, 问卷相关事务。

类型系统如下：

- assignment
  - Assignment, 作业
  - AssignmentSubmission, 一份作业提交
  - AssignmentReview, 一份作业批改
- auth
  - UserRole, 枚举 Teacher/Student
  - UserAccount, 用户信息
  - TeacherProfile/StudentProfile, 作为老师/学生独有的信息，是 UserAccount 的可选组成部分
  - PublicUser, 就是把 UserAccount 中的密码字段去掉，用于在系统中对外展示
- course
  - Course, 一个课程
  - CourseAnnoucement, 课程公告
  - CourseChatMessage, 聊天消息
  - CourseMemberEvent, 成员加入/离开课程的记录
  - CourseMemberAction, 枚举加入/离开课程，是 CourseMemberEvent 的组成部分
- dashboard
  - SystemNotification, 系统通知，比如说用户创建了一个课程，系统就会告知这条信息
- exam
  - OfflineExam, 一场考试
  - OfflineExamQuestion, 考试中的一道题目
  - ExamQuestionScoring, 一道题的评分方式，包括分值、仲裁方式等等许多信息，是 OfflineExamQuestion 的组成部分
  - ExamAnswerSheet, 某个学生某道题的作答
  - ExamQuestionGrading, 一份批改
  - ExamQuestionArbitration, 一份仲裁
  - ExamQuestionAppeal, 一份申诉
  - ExamAppealStatus, 枚举申诉状态是待处理还是已完成，是 ExamQuestionAppeal 的组成部分
- questionnaire
  - Questionnaire, 一份问卷
  - QuestionnaireQuestion, 问卷中的一道题，是 Questionnaire 的组成部分
  - QuestionnaireQuestionType, 枚举题目类型，单选/多选/简答，是 QuestionnaireQuestion 的组成部分
  - QuestionnaireSubmission, 一份问卷提交
  - QuestionnaireAnswer, 一道简答题的回答，是 QuestionnaireSubmission 的组成部分

其他关于文件结构的一些说明：

- 后端 `scala/` 目录下
  - `infrastructure/`是公用基础设施，例如 `storage/` 是 minio 处理附件的实现。另外也接入了 redis 和 kafka 等，但我不怎么了解，实际应用比较少。
  - `routes/` 是路由汇总，既有微服务的 ApiRouter 也有其他基础设施相关路由。
  - `shared/` 是跨微服务共用的小工具，和 `infrastructuer/` 不同在于它是和教学业务有关的。
- 前端 `src/` 目录下
  - `infrastructure/`, `shared/` 地位和后端相似
  - `stores/` 是多个页面共用的全局 hooks
  - 其他目录不言自明


## 主要功能

- 登录、注册，修改密码、头像和其他个人信息。
- 教师创建课程，添加学生。任何人可退出课程，教师可删除课程。可查看课程成员进出历史。
- 发布通知。
- 布置作业、设置答案、提交、批改、收到反馈。作业可设分值，之后能看到均分。
- 创建考试、导入答卷、分配批改任务、批改并发布成绩、收到反馈，其中还有复杂的仲裁和申诉机制。
- 创建问卷、添加题目、作答、收到结果。自动统计选项占比。
- 实时聊天，可删除或撤回消息。
- 通知、作业、聊天都支持上传附件，minio 实现。
- 当你加入/退出/创建/删除了一个课程后，会收到系统通知。
- 首页显示通知、作业、考试、问卷、聊天的待办数，以及提供教师进入批改任务的快捷入口。切换课程便捷，其他课程的待办也会有提示。


## 亮点

非常接近真实可用的系统。作业和考试的机制和流程和我们高中用的软件一样，并且覆盖了全部所需功能。


## 额外的关于 api 和读写的说明

api 的接收和返回对象放在 api/request/ 和 api/response/ 里。各微服务的 tables 没完全做成 private，跨微服务读实在太广泛了，就直接使用了别的表的读操作。写操作保护起来了，跨微服务写表都包了一层 api 暴露给外界，api/boudary/ 就是这些东西。理论上这些对前端没有用，为了形式对齐方便看还是都写上了。除了注销账户这种例外，它几乎要把每个表都动一遍，就直接让它写别的表了。