export class IO<T> {
  private readonly effect: () => Promise<T> | T

  constructor(effect: () => Promise<T> | T) {
    this.effect = effect
  }

  static of<T>(value: T): IO<T> {
    return new IO(() => value)
  }

  static from<T>(effect: () => Promise<T> | T): IO<T> {
    return new IO(effect)
  }

  map<U>(transform: (value: T) => U): IO<U> {
    return new IO(async () => transform(await this.run()))
  }

  flatMap<U>(transform: (value: T) => IO<U>): IO<U> {
    return new IO(async () => transform(await this.run()).run())
  }

  async attempt(): Promise<{ ok: true; value: T } | { ok: false; error: Error }> {
    try {
      return { ok: true, value: await this.run() }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error : new Error('Unknown IO failure') }
    }
  }

  run(): Promise<T> {
    return Promise.resolve(this.effect())
  }
}
