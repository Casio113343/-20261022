const API_BASE = import.meta.env.VITE_API_BASE_URL ?? ''

export function resolveAssetUrl(value: string) {
  if (!value) return value
  if (value.startsWith('http://') || value.startsWith('https://') || value.startsWith('data:') || value.startsWith('blob:')) {
    return value
  }
  if (value.startsWith('/')) {
    return `${API_BASE}${value}`
  }
  return value
}
