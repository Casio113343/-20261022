export class Attachment {
  constructor(
    public fileName: string,
    public dataUrl: string,
  ) {}
}
