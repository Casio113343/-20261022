import { Attachment } from '@/infrastructure/storage/Attachment'

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? ''

export async function uploadAttachment(userId: string, file: File) {
  const preparedFile = file.type.startsWith('image/') ? await compressImageFile(file) : file
  return uploadPreparedFile(userId, preparedFile)
}

export async function uploadAttachments(userId: string, files: File[]) {
  return Promise.all(files.map((file) => uploadAttachment(userId, file)))
}

export async function prepareImageAttachments(files: File[]) {
  return Promise.all(files.map(async (file) => {
    const preparedFile = await compressImageFile(file)
    return new Attachment(preparedFile.name, await fileToDataUrl(preparedFile))
  }))
}

export function isUploadedAttachment(attachment: Attachment | null | undefined) {
  return Boolean(attachment?.dataUrl && !attachment.dataUrl.startsWith('data:'))
}

async function uploadPreparedFile(userId: string, file: File) {
  const formData = new FormData()
  formData.append('file', file, file.name)

  let response: Response

  try {
    response = await fetch(`${API_BASE}/assets?userId=${encodeURIComponent(userId)}`, {
      method: 'POST',
      body: formData,
    })
  } catch {
    throw new Error('无法连接后端服务。请先启动 backend，或检查前端代理配置。')
  }

  if (!response.ok) {
    const body = await response.json().catch(() => null)
    const message = body && typeof body === 'object' && 'error' in body && typeof body.error === 'string' ? body.error : `上传失败: ${response.status}`
    throw new Error(message)
  }

  const payload = await response.json() as { fileName?: unknown; dataUrl?: unknown }
  if (typeof payload.fileName !== 'string' || typeof payload.dataUrl !== 'string') {
    throw new Error('上传响应格式错误')
  }

  return new Attachment(payload.fileName, payload.dataUrl)
}

async function compressImageFile(file: File): Promise<File> {
  const image = await loadImage(file)
  const maxDimension = 1600
  const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight))
  if (scale === 1 && file.size <= 400 * 1024) return file

  const width = Math.max(1, Math.round(image.naturalWidth * scale))
  const height = Math.max(1, Math.round(image.naturalHeight * scale))
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const context = canvas.getContext('2d')
  if (!context) return file
  context.drawImage(image, 0, 0, width, height)

  const outputType = file.type === 'image/png' && file.size <= 400 * 1024 && scale === 1 ? 'image/png' : 'image/jpeg'
  const blob = await canvasToBlob(canvas, outputType, 0.82)
  if (!blob || blob.size >= file.size) return file
  return new File([blob], renameFileForContentType(file.name, outputType), { type: outputType, lastModified: file.lastModified })
}

function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image()
    const objectUrl = URL.createObjectURL(file)
    image.onload = () => {
      URL.revokeObjectURL(objectUrl)
      resolve(image)
    }
    image.onerror = () => {
      URL.revokeObjectURL(objectUrl)
      reject(new Error('图片解析失败'))
    }
    image.src = objectUrl
  })
}

function canvasToBlob(canvas: HTMLCanvasElement, contentType: string, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), contentType, quality))
}

function renameFileForContentType(fileName: string, contentType: string) {
  const extension = contentType === 'image/png' ? '.png' : '.jpg'
  const lastDot = fileName.lastIndexOf('.')
  const baseName = lastDot > 0 ? fileName.slice(0, lastDot) : fileName
  return `${baseName}${extension}`
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result)
      else reject(new Error('图片读取失败'))
    }
    reader.onerror = () => reject(new Error('图片读取失败'))
    reader.readAsDataURL(file)
  })
}
