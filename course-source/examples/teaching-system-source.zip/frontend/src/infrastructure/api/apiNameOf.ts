import type { APIMessage } from '@/infrastructure/api/APIMessage'

export function apiNameOf(message: APIMessage<unknown>) {
  const className = message.constructor.name
  const baseName = className.endsWith('APIMessage') ? className.slice(0, -'APIMessage'.length) : className
  return `${baseName}Api`.toLowerCase()
}
