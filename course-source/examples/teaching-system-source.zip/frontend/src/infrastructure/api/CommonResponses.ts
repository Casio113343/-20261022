export type ApiError = {
  error: string
}

export type ActionResponse = {
  message: string
}
