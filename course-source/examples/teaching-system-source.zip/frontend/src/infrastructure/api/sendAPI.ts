import { APIMessage } from '@/infrastructure/api/APIMessage'
import { apiNameOf } from '@/infrastructure/api/apiNameOf'
import { requestJson } from '@/infrastructure/http/requestJson'

export function sendAPI<Response>(message: APIMessage<Response>) {
  return requestJson<Response>(`/api/${apiNameOf(message)}`, {
    method: 'POST',
    body: JSON.stringify(message),
  })
}
