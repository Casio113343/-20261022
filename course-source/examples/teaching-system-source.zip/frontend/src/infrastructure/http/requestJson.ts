import { IO } from '@/infrastructure/io/io'

import type { ApiError } from '@/infrastructure/api/CommonResponses'

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? ''

export function requestJson<TResponse>(path: string, init?: RequestInit): IO<TResponse> {
  return IO.from(async () => {
    let response: Response

    try {
      response = await fetch(`${API_BASE}${path}`, {
        ...init,
        headers: {
          'Content-Type': 'application/json',
          ...(init?.headers ?? {}),
        },
      })
    } catch {
      throw new Error('无法连接后端服务。请先启动 backend，或检查前端代理配置。')
    }

    if (!response.ok) {
      const errorBody = await readApiError(response)
      throw new Error(errorBody?.error ?? `请求失败: ${response.status}`)
    }

    return (await response.json()) as TResponse
  })
}

async function readApiError(response: Response): Promise<ApiError | null> {
  const body = await response.json().catch(() => null)

  if (!body || typeof body !== 'object' || !('error' in body) || typeof body.error !== 'string') {
    return null
  }

  return { error: body.error }
}
