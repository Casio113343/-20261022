import { Navigate } from 'react-router-dom'

import { Button, Input, Label, Textarea } from '@/components/ui'
import { CourseFormShell, InlineError, InlineSuccess } from '@/shared/forms/FormHelpers'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { useCourseCreatePage } from './hooks/useCourseCreatePage'

export default function CourseCreatePage() {
  const page = useCourseCreatePage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />

  return (
    <CourseFormShell title="创建课程" description="课程信息在提交后立即持久化。">
      <form className="space-y-4" onSubmit={page.handleSubmit}>
        <div className="space-y-2">
          <Label>课程名称</Label>
          <Input value={page.title} onChange={(event) => page.setTitle(event.target.value)} />
        </div>
        <div className="space-y-2">
          <Label>课程简介</Label>
          <Textarea value={page.description} onChange={(event) => page.setDescription(event.target.value)} />
        </div>
        <Button type="submit" disabled={page.isBusy}>创建课程</Button>
        {page.errorMessage ? <InlineError message={page.errorMessage} /> : null}
        {page.successMessage ? <InlineSuccess message={page.successMessage} /> : null}
      </form>
    </CourseFormShell>
  )
}
