import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { CreateCourseAPIMessage } from '@/microservices/course/api/CreateCourseAPIMessage'
import { FetchDashboardAPIMessage } from '@/microservices/dashboard/api/FetchDashboardAPIMessage'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { useCourseSelectionStore } from '@/stores/dashboard/useCourseSelectionStore'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'

export function useCourseCreatePage() {
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const setSession = useSessionStore((state) => state.setSession)
  const setSelectedCourseId = useCourseSelectionStore((state) => state.setSelectedCourseId)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)

  useHydrateSession()
  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!currentUser) return
    setErrorMessage('')
    setSuccessMessage('')
    setIsBusy(true)
    try {
      const course = await sendAPI(new CreateCourseAPIMessage(currentUser.id, { title: title.trim(), description: description.trim() })).run()
      const nextDashboard = await sendAPI(new FetchDashboardAPIMessage(currentUser.id)).run()
      setSelectedCourseId(currentUser.id, course.course.id)
      setSession(nextDashboard)
      setSuccessMessage('课程创建成功。')
      setTimeout(() => navigate(AppRoutePath.Dashboard), 500)
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '创建课程失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    currentUser,
    description,
    errorMessage,
    isBusy,
    successMessage,
    title,
    handleSubmit,
    setDescription,
    setTitle,
  }
}
