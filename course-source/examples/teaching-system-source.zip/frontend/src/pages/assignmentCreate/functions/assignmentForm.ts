export function toDatetimeLocal(value: string) {
  const date = new Date(value)
  const pad = (input: number) => String(input).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
}

export function parseDatetimeLocal(value: string, emptyMessage: string, invalidMessage: string) {
  if (!value.trim()) {
    return { error: emptyMessage, value: null }
  }
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) {
    return { error: invalidMessage, value: null }
  }
  return { error: '', value: date.toISOString() }
}
