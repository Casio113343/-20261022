import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { Attachment } from '@/infrastructure/storage/Attachment'
import { uploadAttachment } from '@/infrastructure/storage/uploadAsset'
import { CreateAssignmentAPIMessage } from '@/microservices/assignment/api/CreateAssignmentAPIMessage'
import { UpdateAssignmentAPIMessage } from '@/microservices/assignment/api/UpdateAssignmentAPIMessage'
import { Assignment } from '@/microservices/assignment/objects/Assignment'
import { FetchCourseDetailAPIMessage } from '@/microservices/course/api/FetchCourseDetailAPIMessage'
import { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoute } from '@/shared/routing/AppRoutes'
import { syncCourseDetailMutation } from '@/stores/session/functions/courseDetailSession'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { parseDatetimeLocal, toDatetimeLocal } from '../functions/assignmentForm'

export function useAssignmentCreatePage() {
  const { courseId, assignmentId } = useParams<{ courseId: string; assignmentId?: string }>()
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser, dashboard, setSession } = useEnsureDashboard(navigate)

  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [attachment, setAttachment] = useState<Attachment | null>(null)
  const [answerAttachment, setAnswerAttachment] = useState<Attachment | null>(null)
  const [answerRevealMode, setAnswerRevealMode] = useState('after-submit')
  const [answerPublishedAt, setAnswerPublishedAt] = useState('')
  const [allowLateSubmission, setAllowLateSubmission] = useState(false)
  const [maxScore, setMaxScore] = useState('')
  const [graderTeacherId, setGraderTeacherId] = useState('')
  const [dueAt, setDueAt] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)
  const [isUploadingAttachment, setIsUploadingAttachment] = useState(false)
  const [course, setCourse] = useState<CourseDetailResponse | null | undefined>(undefined)

  const assignment = useMemo(() => course?.assignments.find((item) => item.id === assignmentId) ?? null, [assignmentId, course])

  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  useEffect(() => {
    if (!courseId || !currentUser) return
    void sendAPI(new FetchCourseDetailAPIMessage(courseId, currentUser.id)).run()
      .then(setCourse)
      .catch(() => setCourse(null))
  }, [courseId, currentUser?.id])

  useEffect(() => {
    if (!assignment) return
    setTitle(assignment.title)
    setContent(assignment.content)
    setAttachment(assignment.attachment ?? null)
    setAnswerAttachment(assignment.answerAttachment ?? null)
    setAnswerPublishedAt(assignment.answerPublishedAt ? toDatetimeLocal(assignment.answerPublishedAt) : '')
    setAnswerRevealMode(assignment.answerPublishedAt ? 'time' : 'after-submit')
    setAllowLateSubmission(assignment.allowLateSubmission)
    setMaxScore(assignment.maxScore?.toString() ?? '')
    setGraderTeacherId(assignment.graderTeacherId)
    setDueAt(toDatetimeLocal(assignment.dueAt))
  }, [assignment])

  useEffect(() => {
    if (assignment || !course || course.course.teachers.length !== 1) return
    setGraderTeacherId(course.course.teachers[0].id)
  }, [assignment, course])

  const handleAttachmentSelect = async (file: File | null) => {
    if (!currentUser) return
    if (!file) {
      setAttachment(null)
      return
    }
    setErrorMessage('')
    setIsUploadingAttachment(true)
    try {
      setAttachment(await uploadAttachment(currentUser.id, file))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '附件上传失败')
    } finally {
      setIsUploadingAttachment(false)
    }
  }

  const handleAnswerAttachmentSelect = async (file: File | null) => {
    if (!currentUser) return
    if (!file) {
      setAnswerAttachment(null)
      setAnswerRevealMode('after-submit')
      setAnswerPublishedAt('')
      return
    }
    setErrorMessage('')
    setIsUploadingAttachment(true)
    try {
      setAnswerAttachment(await uploadAttachment(currentUser.id, file))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '答案附件上传失败')
    } finally {
      setIsUploadingAttachment(false)
    }
  }

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!courseId || !currentUser) return
    setErrorMessage('')
    setSuccessMessage('')
    if (!content.trim() && !attachment) {
      setErrorMessage('作业内容和附件至少填写一项。')
      return
    }
    const dueAtResult = parseDatetimeLocal(dueAt, '请选择作业截止时间。', '请选择有效的作业截止时间。')
    if (dueAtResult.error || !dueAtResult.value) {
      setErrorMessage(dueAtResult.error)
      return
    }
    const answerPublishedAtResult = answerAttachment && answerRevealMode === 'time'
      ? parseDatetimeLocal(answerPublishedAt, '请选择答案公布时间。', '请选择有效的答案公布时间。')
      : { error: '', value: null }
    if (answerPublishedAtResult.error) {
      setErrorMessage(answerPublishedAtResult.error)
      return
    }
    setIsBusy(true)
    try {
      const payload = new Assignment(
        assignmentId ?? '',
        courseId,
        title.trim(),
        content.trim(),
        allowLateSubmission,
        graderTeacherId,
        dueAtResult.value,
        currentUser.id,
        assignment?.createdAt ?? new Date().toISOString(),
        attachment ?? undefined,
        maxScore ? Number(maxScore) : undefined,
        answerAttachment ?? undefined,
        answerPublishedAtResult.value ?? undefined,
      )
      const nextCourse = assignmentId
        ? await sendAPI(new UpdateAssignmentAPIMessage(courseId, assignmentId, currentUser.id, payload)).run()
        : await sendAPI(new CreateAssignmentAPIMessage(courseId, currentUser.id, payload)).run()
      syncCourseDetailMutation(dashboard, nextCourse, setSession, setCourse)
      setSuccessMessage(assignmentId ? '作业更新成功。' : '作业发布成功。')
      navigate(AppRoute.CourseWorkspace(nextCourse.course.id))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : assignmentId ? '作业更新失败' : '作业发布失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    allowLateSubmission,
    assignment,
    assignmentId,
    attachment,
    answerAttachment,
    answerRevealMode,
    answerPublishedAt,
    content,
    course,
    courseId,
    currentUser,
    dueAt,
    errorMessage,
    graderTeacherId,
    isBusy,
    isUploadingAttachment,
    maxScore,
    successMessage,
    title,
    handleAnswerAttachmentSelect,
    handleAttachmentSelect,
    handleSubmit,
    setAllowLateSubmission,
    setAnswerAttachment,
    setAnswerPublishedAt,
    setAnswerRevealMode,
    setAttachment,
    setContent,
    setDueAt,
    setGraderTeacherId,
    setMaxScore,
    setTitle,
  }
}
