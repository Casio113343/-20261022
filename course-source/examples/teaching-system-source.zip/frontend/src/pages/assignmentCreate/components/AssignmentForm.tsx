import { Button, Input, Label, Select, SelectContent, SelectItem, SelectTrigger, SelectValue, Textarea } from '@/components/ui'
import { CheckboxText, FilePicker, InlineError, InlineSuccess } from '@/shared/forms/FormHelpers'

import type { useAssignmentCreatePage } from '../hooks/useAssignmentCreatePage'

class AssignmentFormProps {
  page!: ReturnType<typeof useAssignmentCreatePage>
}

export function AssignmentForm({ page }: AssignmentFormProps) {
  return (
    <form className="grid gap-4 md:grid-cols-2" onSubmit={page.handleSubmit}>
      <div className="space-y-2"><Label>标题</Label><Input value={page.title} onChange={(event) => page.setTitle(event.target.value)} /></div>
      <div />
      <div className="space-y-2 md:col-span-2"><Label>内容</Label><Textarea value={page.content} onChange={(event) => page.setContent(event.target.value)} /></div>
      <div className="flex flex-wrap items-center gap-3 md:col-span-2">
        <FilePicker accept="*/*" label="添加附件" onChange={(event) => void page.handleAttachmentSelect(event.target.files?.[0] ?? null)} />
        {page.attachment ? (
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <span>已选择 {page.attachment.fileName}</span>
            <Button type="button" variant="ghost" size="sm" onClick={() => page.setAttachment(null)}>移除</Button>
          </div>
        ) : null}
      </div>
      <div className="space-y-2"><Label>截止日期</Label><Input type="datetime-local" value={page.dueAt} onChange={(event) => page.setDueAt(event.target.value)} /></div>
      <div className="flex items-end pb-2">
        <CheckboxText checked={page.allowLateSubmission} label="允许补交" onChange={page.setAllowLateSubmission} />
      </div>
      <div className="space-y-2">
        <Label>负责批改教师</Label>
        <Select value={page.graderTeacherId} onValueChange={page.setGraderTeacherId}>
          <SelectTrigger className="bg-white"><SelectValue placeholder="请选择老师" /></SelectTrigger>
          <SelectContent>{page.course?.course.teachers.map((teacher) => <SelectItem key={teacher.id} value={teacher.id}>{teacher.displayName}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>作业分值</Label>
        <Input type="number" min={1} value={page.maxScore} onChange={(event) => page.setMaxScore(event.target.value)} placeholder="选填" />
      </div>
      <div className="flex flex-wrap items-center gap-3 md:col-span-2">
        <FilePicker accept="*/*" label="添加答案" onChange={(event) => void page.handleAnswerAttachmentSelect(event.target.files?.[0] ?? null)} />
        {page.answerAttachment ? (
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <span>已选择 {page.answerAttachment.fileName}</span>
            <Button type="button" variant="ghost" size="sm" onClick={() => {
              page.setAnswerAttachment(null)
              page.setAnswerPublishedAt('')
            }}>移除</Button>
          </div>
        ) : null}
      </div>
      {page.answerAttachment ? (
        <div className="space-y-2">
          <Label>答案显示规则</Label>
          <Select value={page.answerRevealMode} onValueChange={(value) => {
            page.setAnswerRevealMode(value)
            if (value === 'after-submit') page.setAnswerPublishedAt('')
          }}>
            <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="after-submit">学生提交后自动显示答案</SelectItem>
              <SelectItem value="time">设置公布答案时间</SelectItem>
            </SelectContent>
          </Select>
        </div>
      ) : null}
      {page.answerAttachment && page.answerRevealMode === 'time' ? (
        <div className="space-y-2">
          <Label>公布答案时间</Label>
          <Input type="datetime-local" value={page.answerPublishedAt} onChange={(event) => page.setAnswerPublishedAt(event.target.value)} />
        </div>
      ) : null}
      <div className="space-y-3 md:col-span-2">
        <Button type="submit" disabled={page.isBusy || page.isUploadingAttachment}>{page.isUploadingAttachment ? '上传附件中...' : page.assignmentId ? '保存作业' : '发布作业'}</Button>
        {page.errorMessage ? <InlineError message={page.errorMessage} /> : null}
        {page.successMessage ? <InlineSuccess message={page.successMessage} /> : null}
      </div>
    </form>
  )
}
