import { Navigate } from 'react-router-dom'

import { CourseFormShell } from '@/shared/forms/FormHelpers'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'

import { AssignmentForm } from './components/AssignmentForm'
import { useAssignmentCreatePage } from './hooks/useAssignmentCreatePage'

export default function AssignmentCreatePage() {
  const page = useAssignmentCreatePage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (page.course === null) return <Navigate replace to={AppRoutePath.Dashboard} />
  if (page.assignmentId && page.course && !page.assignment) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <CourseFormShell title={page.assignmentId ? '编辑作业' : '布置作业'} description={page.course ? `课程：${page.course.course.title}` : '正在加载课程信息。'} backTo={page.courseId ? AppRoute.CourseWorkspace(page.courseId) : AppRoutePath.Dashboard} backLabel="返回课程工作区">
      <AssignmentForm page={page} />
    </CourseFormShell>
  )
}
