import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import { UserRole } from '@/microservices/auth/objects/UserRole'

import { AssignmentScoreSummary } from '../objects/AssignmentScoreSummary'
import { ResolvedAssignmentDetail } from '../objects/ResolvedAssignmentDetail'

export function formatAssignmentDateTime(value: string) {
  return new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
}

export function resolveAssignmentDetail(course: CourseDetailResponse | null, assignmentId: string | undefined, currentUserId: string | undefined) {
  if (!course || !assignmentId) return null
  const assignment = course.assignments.find((item) => item.id === assignmentId)
  if (!assignment) return null
  const submission = course.submissions.find((item) => item.assignmentId === assignmentId && item.studentId === currentUserId)
  const review = submission ? course.reviews.find((item) => item.submissionId === submission.id) ?? null : null
  return new ResolvedAssignmentDetail(course, assignment, submission ?? null, review)
}

export function isTeacherUser(user: PublicUser) {
  return user.role === UserRole.Teacher
}

export function buildAssignmentScoreSummary(detail: ResolvedAssignmentDetail) {
  const review = detail.review
  if (!review) return null
  if (detail.assignment.maxScore === null || detail.assignment.maxScore === undefined) {
    return new AssignmentScoreSummary(null, null, null, `评语：${review.comment?.trim() ? review.comment : '无'}`)
  }

  const reviewedScores = detail.course.reviews.flatMap((submissionReview) => submissionReview.score ?? [])
  const highestScore = reviewedScores.length ? Math.max(...reviewedScores) : null
  const averageScore = reviewedScores.length ? reviewedScores.reduce((sum, score) => sum + score, 0) / reviewedScores.length : null

  return new AssignmentScoreSummary(
    review.score !== null && review.score !== undefined ? `得分：${review.score} / ${detail.assignment.maxScore}` : '得分：无',
    `班级最高分：${highestScore !== null ? highestScore : '暂无'}`,
    `班级平均分：${averageScore !== null ? averageScore.toFixed(1) : '暂无'}`,
    `评语：${review.comment?.trim() ? review.comment : '无'}`,
  )
}

export function canViewAssignmentAnswer(detail: ResolvedAssignmentDetail) {
  if (!detail.assignment.answerAttachment || !detail.submission) return false
  if (!detail.assignment.answerPublishedAt) return true
  return new Date(detail.assignment.answerPublishedAt).getTime() <= Date.now()
}

export function buildAssignmentAnswerHint(detail: ResolvedAssignmentDetail) {
  if (!detail.assignment.answerAttachment) return null
  if (!detail.submission) {
    if (detail.assignment.answerPublishedAt) return `答案将在 ${formatAssignmentDateTime(detail.assignment.answerPublishedAt)} 后公布。`
    return '答案将在提交作业后公布。'
  }
  if (detail.assignment.answerPublishedAt && new Date(detail.assignment.answerPublishedAt).getTime() > Date.now()) {
    return `答案将在 ${formatAssignmentDateTime(detail.assignment.answerPublishedAt)} 后公布。`
  }
  return null
}
