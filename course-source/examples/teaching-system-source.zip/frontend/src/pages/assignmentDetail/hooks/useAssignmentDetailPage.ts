import { useEffect, useEffectEvent, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { uploadAttachment } from '@/infrastructure/storage/uploadAsset'
import { Attachment } from '@/infrastructure/storage/Attachment'
import { CreateSubmissionAPIMessage } from '@/microservices/assignment/api/CreateSubmissionAPIMessage'
import { FetchAssignmentCourseDetailAPIMessage } from '@/microservices/assignment/api/FetchAssignmentCourseDetailAPIMessage'
import { MarkReviewedAssignmentReadAPIMessage } from '@/microservices/assignment/api/MarkReviewedAssignmentReadAPIMessage'
import { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import { FetchDashboardAPIMessage } from '@/microservices/dashboard/api/FetchDashboardAPIMessage'
import { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { syncAssignmentCourseDetailMutation } from '@/stores/session/functions/assignmentSession'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'

import { buildAssignmentAnswerHint, buildAssignmentScoreSummary, canViewAssignmentAnswer, isTeacherUser, resolveAssignmentDetail } from '../functions/assignmentDetail'

export function useAssignmentDetailPage() {
  const { assignmentId } = useParams<{ assignmentId: string }>()
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const dashboard = useSessionStore((state) => state.dashboard)
  const setSession = useSessionStore((state) => state.setSession)
  const clearSession = useSessionStore((state) => state.clearSession)
  const [content, setContent] = useState('')
  const [attachment, setAttachment] = useState<Attachment | null>(null)
  const [errorMessage, setErrorMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)
  const [isUploadingAttachment, setIsUploadingAttachment] = useState(false)
  const [courseDetail, setCourseDetail] = useState<CourseDetailResponse | null | undefined>(undefined)

  useHydrateSession()
  useAutoDismissMessage(errorMessage, setErrorMessage)

  const ensureDashboard = useEffectEvent(async (operatorUserId: string) => {
    try {
      const nextDashboard = await sendAPI(new FetchDashboardAPIMessage(operatorUserId)).run()
      setSession(nextDashboard)
    } catch {
      clearSession()
      navigate(AppRoutePath.Login)
    }
  })

  useEffect(() => {
    if (!currentUser || dashboard) return
    void ensureDashboard(currentUser.id)
  }, [currentUser?.id, dashboard])

  useEffect(() => {
    if (!currentUser || !assignmentId) return
    void sendAPI(new FetchAssignmentCourseDetailAPIMessage(assignmentId, currentUser.id)).run()
      .then(setCourseDetail)
      .catch(() => setCourseDetail(null))
  }, [assignmentId, currentUser?.id])

  const detail = useMemo(() => {
    if (courseDetail === undefined) return undefined
    return resolveAssignmentDetail(courseDetail, assignmentId, currentUser?.id)
  }, [assignmentId, courseDetail, currentUser?.id])
  const isTeacher = currentUser ? isTeacherUser(currentUser) : false
  const scoreSummary = useMemo(() => detail ? buildAssignmentScoreSummary(detail) : null, [detail])
  const canViewAnswer = Boolean(detail && canViewAssignmentAnswer(detail))
  const answerHint = detail ? buildAssignmentAnswerHint(detail) : null

  const markReviewedAssignmentRead = useEffectEvent(async (nextAssignmentId: string, operatorUserId: string) => {
    try {
      const nextDashboard = await sendAPI(new MarkReviewedAssignmentReadAPIMessage(nextAssignmentId, operatorUserId)).run()
      setSession(nextDashboard)
    } catch {
      return undefined
    }
  })

  useEffect(() => {
    if (!currentUser || !detail || isTeacher || !detail.review) return
    if ((currentUser.readReviewedAssignmentIds ?? []).includes(detail.assignment.id)) return
    void markReviewedAssignmentRead(detail.assignment.id, currentUser.id)
  }, [currentUser?.id, currentUser?.readReviewedAssignmentIds, detail, isTeacher])

  const isExpired = detail ? new Date(detail.assignment.dueAt).getTime() < Date.now() : false
  const canLateSubmit = Boolean(detail && isExpired && detail.assignment.allowLateSubmission)
  const isLocked = Boolean(detail && isExpired && !detail.assignment.allowLateSubmission)
  const hasScore = Boolean(detail && detail.assignment.maxScore !== null && detail.assignment.maxScore !== undefined)

  const submit = async () => {
    if (!currentUser || !detail) return
    if (!content.trim() && !attachment) {
      setErrorMessage('提交文本和附件至少填写一项。')
      return
    }
    if (isLocked) {
      setErrorMessage('作业已过期，当前不允许补交。')
      return
    }
    setIsBusy(true)
    setErrorMessage('')
    try {
      const payload = new AssignmentSubmission('', detail.assignment.id, currentUser.id, content.trim(), new Date().toISOString(), attachment ?? undefined)
      const nextCourse = await sendAPI(new CreateSubmissionAPIMessage(detail.assignment.id, currentUser.id, payload)).run()
      setCourseDetail(nextCourse)
      syncAssignmentCourseDetailMutation(dashboard, nextCourse, setSession)
      navigate(AppRoute.CourseWorkspace(nextCourse.course.id))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '提交失败')
    } finally {
      setIsBusy(false)
    }
  }

  const selectAttachment = async (file: File) => {
    if (!currentUser) return
    setErrorMessage('')
    setIsUploadingAttachment(true)
    try {
      setAttachment(await uploadAttachment(currentUser.id, file))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '附件上传失败')
    } finally {
      setIsUploadingAttachment(false)
    }
  }

  return {
    assignmentId,
    currentUser,
    detail,
    isTeacher,
    content,
    attachment,
    errorMessage,
    isBusy: isBusy || isUploadingAttachment,
    isLocked,
    canLateSubmit,
    hasScore,
    scoreSummary,
    canViewAnswer,
    answerHint,
    setContent,
    clearAttachment: () => setAttachment(null),
    selectAttachment,
    submit,
  }
}
