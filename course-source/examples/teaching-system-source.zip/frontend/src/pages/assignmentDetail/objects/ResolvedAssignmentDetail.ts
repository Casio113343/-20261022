import { Assignment } from '@/microservices/assignment/objects/Assignment'
import { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import { SubmissionReview } from '@/microservices/assignment/objects/SubmissionReview'
import { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class ResolvedAssignmentDetail {
  constructor(
    public course: CourseDetailResponse,
    public assignment: Assignment,
    public submission: AssignmentSubmission | null,
    public review: SubmissionReview | null,
  ) {}
}
