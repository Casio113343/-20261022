export class AssignmentScoreSummary {
  constructor(
    public scoreText: string | null,
    public highestScoreText: string | null,
    public averageScoreText: string | null,
    public reviewCommentText: string,
  ) {}
}
