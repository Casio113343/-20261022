import { Button, Label, Textarea } from '@/components/ui'
import { FilePicker } from '@/shared/forms/FormHelpers'

import type { Attachment } from '@/infrastructure/storage/Attachment'
import { formatAssignmentDateTime } from '../functions/assignmentDetail'
import { ResolvedAssignmentDetail } from '../objects/ResolvedAssignmentDetail'

class SubmissionSectionProps {
  detail!: ResolvedAssignmentDetail
  content = ''
  attachment: Attachment | null = null
  isLocked = false
  canLateSubmit = false
  isBusy = false
  onContentChange: (value: string) => void = () => undefined
  onAttachmentChange: (file: File) => void = () => undefined
  onAttachmentClear: () => void = () => undefined
  onSubmit: () => void = () => undefined
}

export function SubmissionSection({
  detail,
  content,
  attachment,
  isLocked,
  canLateSubmit,
  isBusy,
  onContentChange,
  onAttachmentChange,
  onAttachmentClear,
  onSubmit,
}: SubmissionSectionProps) {
  if (detail.submission) {
    return (
      <div className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
        <div className="text-sm text-slate-500">已提交于 {formatAssignmentDateTime(detail.submission.submittedAt)}</div>
        {detail.submission.content.trim() ? <div className="rounded-xl bg-white p-3 text-sm leading-7 text-slate-700">{detail.submission.content}</div> : null}
        {detail.submission.attachment ? <a className="text-sm text-sky-700 underline underline-offset-4 hover:text-sky-800" href={detail.submission.attachment.dataUrl} download={detail.submission.attachment.fileName}>下载已提交附件：{detail.submission.attachment.fileName}</a> : null}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>提交内容</Label>
        <Textarea value={content} onChange={(event) => onContentChange(event.target.value)} />
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <FilePicker accept="*/*" onChange={(event) => {
          const file = event.target.files?.[0]
          if (file) onAttachmentChange(file)
        }} />
        {attachment ? (
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <span>已选择 {attachment.fileName}</span>
            <Button type="button" variant="ghost" size="sm" onClick={onAttachmentClear}>移除</Button>
          </div>
        ) : null}
      </div>
      <Button disabled={isBusy || isLocked} onClick={onSubmit}>{canLateSubmit ? '补交作业' : '提交作业'}</Button>
    </div>
  )
}
