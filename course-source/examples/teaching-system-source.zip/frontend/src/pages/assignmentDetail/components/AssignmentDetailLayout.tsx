import { Link } from 'react-router-dom'
import type { ReactNode } from 'react'
import { ChevronLeft } from 'lucide-react'

import { Alert, AlertDescription, Button } from '@/components/ui'

class AssignmentDetailLayoutProps {
  backTo = ''
  errorMessage = ''
  children: ReactNode = null
}

export function AssignmentDetailLayout({
  backTo,
  errorMessage,
  children,
}: AssignmentDetailLayoutProps) {
  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-4xl px-5 py-8 lg:px-8">
        <Button asChild variant="outline" className="mb-6">
          <Link to={backTo}>
            <ChevronLeft className="size-4" />
            返回课程工作区
          </Link>
        </Button>
        {errorMessage ? <Alert variant="destructive" className="mb-6 border-rose-200 bg-rose-50 text-rose-700"><AlertDescription className="text-rose-700">{errorMessage}</AlertDescription></Alert> : null}
        {children}
      </div>
    </main>
  )
}
