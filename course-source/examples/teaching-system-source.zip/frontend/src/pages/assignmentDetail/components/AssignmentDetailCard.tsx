import { Badge, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'

import { formatAssignmentDateTime } from '../functions/assignmentDetail'
import { AssignmentScoreSummary } from '../objects/AssignmentScoreSummary'
import { ResolvedAssignmentDetail } from '../objects/ResolvedAssignmentDetail'

class AssignmentDetailCardProps {
  detail!: ResolvedAssignmentDetail
  isTeacher = false
  isLocked = false
  canLateSubmit = false
  hasScore = false
  scoreSummary: AssignmentScoreSummary | null = null
  canViewAnswer = false
  answerHint: string | null = null
  children!: React.ReactNode
}

export function AssignmentDetailCard({ detail, isTeacher, isLocked, canLateSubmit, hasScore, scoreSummary, canViewAnswer, answerHint, children }: AssignmentDetailCardProps) {
  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <div className="flex items-center justify-between gap-3">
          <div>
            <CardTitle className="text-2xl">{detail.assignment.title}</CardTitle>
            <CardDescription>{detail.course.course.title} / 截止 {formatAssignmentDateTime(detail.assignment.dueAt)}（{detail.assignment.allowLateSubmission ? '允许补交' : '不允许补交'}）</CardDescription>
          </div>
          {!isTeacher && detail.submission ? <Badge variant={detail.review ? 'secondary' : 'outline'}>{detail.review ? '已批' : '未批'}</Badge> : null}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {detail.assignment.content.trim() ? <div className="text-sm leading-8 text-slate-700">{detail.assignment.content}</div> : null}
        {detail.assignment.attachment ? (
          <div className="pt-2">
            <a className="text-sm text-sky-700 underline underline-offset-4 hover:text-sky-800" href={detail.assignment.attachment.dataUrl} download={detail.assignment.attachment.fileName}>下载作业附件：{detail.assignment.attachment.fileName}</a>
          </div>
        ) : null}
        {hasScore || (!detail.submission && (isLocked || canLateSubmit)) ? (
          <div className="flex flex-wrap gap-x-8 gap-y-2 text-sm text-slate-500">
            {hasScore ? <span>{`满分：${detail.assignment.maxScore}`}</span> : null}
            {!detail.submission && isLocked ? <span>已过期</span> : null}
            {!detail.submission && canLateSubmit ? <span>当前可补交</span> : null}
          </div>
        ) : null}
        {scoreSummary ? (
          <div className="space-y-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
            {scoreSummary.scoreText || scoreSummary.highestScoreText || scoreSummary.averageScoreText ? (
              <div className="flex flex-wrap gap-x-8 gap-y-2">
                {scoreSummary.scoreText ? <span>{scoreSummary.scoreText}</span> : null}
                {scoreSummary.highestScoreText ? <span>{scoreSummary.highestScoreText}</span> : null}
                {scoreSummary.averageScoreText ? <span>{scoreSummary.averageScoreText}</span> : null}
              </div>
            ) : null}
            <div>{scoreSummary.reviewCommentText}</div>
          </div>
        ) : null}
        {!isTeacher && detail.assignment.answerAttachment && canViewAnswer ? (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800">
            <a className="font-medium text-emerald-800 underline-offset-4 hover:underline" href={detail.assignment.answerAttachment.dataUrl} download={detail.assignment.answerAttachment.fileName}>下载作业答案：{detail.assignment.answerAttachment.fileName}</a>
          </div>
        ) : null}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0 flex-1">{children}</div>
          {!isTeacher && answerHint ? (
            <div className="pb-1 text-right text-sm text-slate-500">{answerHint}</div>
          ) : null}
        </div>
      </CardContent>
    </Card>
  )
}
