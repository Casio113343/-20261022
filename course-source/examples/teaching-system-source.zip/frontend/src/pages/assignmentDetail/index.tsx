import { Navigate } from 'react-router-dom'

import { Card, CardContent } from '@/components/ui'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'

import { AssignmentDetailCard } from './components/AssignmentDetailCard'
import { AssignmentDetailLayout } from './components/AssignmentDetailLayout'
import { SubmissionSection } from './components/SubmissionSection'
import { useAssignmentDetailPage } from './hooks/useAssignmentDetailPage'

export default function AssignmentDetailPage() {
  const page = useAssignmentDetailPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.assignmentId) return <Navigate replace to={AppRoutePath.Dashboard} />
  if (page.detail === null) return <Navigate replace to={AppRoutePath.Dashboard} />

  if (page.detail === undefined) {
    return (
      <AssignmentDetailLayout backTo={AppRoutePath.Dashboard} errorMessage={page.errorMessage}>
        <Card className="border-slate-200 bg-white">
          <CardContent className="p-8 text-sm text-slate-500">正在加载作业内容。</CardContent>
        </Card>
      </AssignmentDetailLayout>
    )
  }

  if (page.isTeacher) return <Navigate replace to={AppRoute.ReviewBoard(page.detail.assignment.id)} />

  return (
    <AssignmentDetailLayout backTo={AppRoute.CourseWorkspace(page.detail.course.course.id)} errorMessage={page.errorMessage}>
      <AssignmentDetailCard
        detail={page.detail}
        isTeacher={page.isTeacher}
        isLocked={page.isLocked}
        canLateSubmit={page.canLateSubmit}
        hasScore={page.hasScore}
        scoreSummary={page.scoreSummary}
        canViewAnswer={page.canViewAnswer}
        answerHint={page.answerHint}
      >
        <SubmissionSection
          detail={page.detail}
          content={page.content}
          attachment={page.attachment}
          isLocked={page.isLocked}
          canLateSubmit={page.canLateSubmit}
          isBusy={page.isBusy}
          onContentChange={page.setContent}
          onAttachmentChange={(file) => void page.selectAttachment(file)}
          onAttachmentClear={page.clearAttachment}
          onSubmit={() => void page.submit()}
        />
      </AssignmentDetailCard>
    </AssignmentDetailLayout>
  )
}
