export function formatDateTime(value: string) {
  return new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
}

export function formatQuestionLabel(position: number, title?: string | null) {
  return title && title.trim() ? `第 ${position} 题 · ${title}` : `第 ${position} 题`
}
