import { Navigate } from 'react-router-dom'

import { AppRoutePath } from '@/shared/routing/AppRoutes'

import { ExamReviewWorkspace } from './components/ExamReviewWorkspace'
import { ReviewBoardHeader } from './components/ReviewBoardHeader'
import { useExamReviewBoardPage } from './hooks/useExamReviewBoardPage'

export default function ExamReviewBoardPage() {
  const page = useExamReviewBoardPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.examId || !page.questionId) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(45,212,191,0.16),transparent_26%),linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-6xl px-5 py-8 lg:px-8">
        <ReviewBoardHeader board={page.board} examId={page.examId} />
        <ExamReviewWorkspace page={page} />
      </div>
    </main>
  )
}
