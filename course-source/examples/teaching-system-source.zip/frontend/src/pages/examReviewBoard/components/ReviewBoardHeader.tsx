import { Link } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Button } from '@/components/ui'
import { AppRoute } from '@/shared/routing/AppRoutes'
import type { ExamReviewBoardResponse } from '@/microservices/exam/api/responses/ExamReviewBoardResponse'

import { formatQuestionLabel } from '../functions/examReviewBoard'

class ReviewBoardHeaderProps {
  board!: ExamReviewBoardResponse | null
  examId!: string
}

export function ReviewBoardHeader({ board, examId }: ReviewBoardHeaderProps) {
  return (
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <div>
        <div className="mb-2 text-sm text-slate-500">{board?.course.title}</div>
        <h1 className="text-3xl font-semibold tracking-tight">{board ? formatQuestionLabel(board.question.position, board.question.title) : '加载中'}</h1>
      </div>
      <Button asChild variant="outline">
        <Link to={board ? AppRoute.CourseWorkspace(board.course.id) : AppRoute.ExamDetail(examId)}>
          <ChevronLeft className="size-4" />
          返回课程工作区
        </Link>
      </Button>
    </div>
  )
}
