import { Badge, Button, Card, CardContent, CardHeader, CardTitle, Input, Label } from '@/components/ui'
import { ExamReviewOperation, getExamReviewOperationLabel } from '@/pages/objects/ExamReviewWorkflow'
import { ExamAnswerImageGallery } from '@/pages/examDetail/components/ExamAnswerImageGallery'

import type { useExamReviewBoardPage } from '../hooks/useExamReviewBoardPage'

class ExamReviewWorkspaceProps {
  page!: ReturnType<typeof useExamReviewBoardPage>
}

export function ExamReviewWorkspace({ page }: ExamReviewWorkspaceProps) {
  const maxScore = page.board?.question.scoring.fullScore ?? 0

  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <CardTitle className="text-lg">{page.board ? `${getExamReviewOperationLabel(page.mode)} / 满分 ${page.board.question.scoring.fullScore}` : '加载中'}</CardTitle>
          <div className="flex gap-2">
            <Badge variant="outline">未批 {page.board?.pendingItems.length ?? 0}</Badge>
            <Badge variant="secondary">已批 {page.board?.completedItems.length ?? 0}</Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {page.selectedItem ? (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="text-sm text-slate-500">{page.selectedItem.label}</div>
              <div className="flex gap-3">
                <Button type="button" variant="outline" disabled={page.selectedIndex <= 0} onClick={() => page.moveSelection(-1)}>上一份</Button>
                <Button type="button" variant="outline" disabled={page.selectedIndex < 0 || page.selectedIndex >= page.allItems.length - 1} onClick={() => page.moveSelection(1)}>下一份</Button>
              </div>
            </div>
            <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_15rem] lg:items-start">
              <div className="space-y-4">
                <ExamAnswerImageGallery images={page.selectedItem.images} emptyText="当前没有可处理答卷。" maxHeightClass="max-h-[720px]" />
              </div>
              <div className="space-y-4 lg:sticky lg:top-6">
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <div className="space-y-2">
                    <Label>分数</Label>
                    <Input
                      type="number"
                      min={0}
                      max={maxScore}
                      value={page.score}
                      onChange={(event) => page.setScore(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === 'Enter') {
                          event.preventDefault()
                          if (!page.isBusy) void page.saveScore()
                        }
                      }}
                    />
                  </div>
                  {page.errorMessage ? <div className="mt-2 text-xs font-medium text-rose-600">{page.errorMessage}</div> : null}
                  {page.board?.pendingItems.length === 0 ? <div className="mt-3 text-xs font-medium text-emerald-700">当前题目已批完</div> : null}
                </div>
                {page.mode === ExamReviewOperation.Arbitration ? (
                  <div className="rounded-2xl border border-sky-200 bg-sky-50 p-4 text-sm text-sky-900">
                    原始得分：{page.selectedItem.graderScores.length ? page.selectedItem.graderScores.join('、') : '暂无'}
                  </div>
                ) : null}
                {page.mode === ExamReviewOperation.Appeal && page.selectedItem.appeal ? (
                  <div className="space-y-2 rounded-2xl border border-teal-200 bg-teal-50 p-4 text-sm text-teal-900">
                    <div>原始得分：{page.selectedItem.score ?? page.selectedItem.graderScores.at(-1) ?? '--'}</div>
                    <div>期望得分：{page.selectedItem.appeal.expectedScore}</div>
                    <div>申诉理由：{page.selectedItem.appeal.reason}</div>
                  </div>
                ) : null}
              </div>
            </div>
          </>
        ) : (
          <div className="rounded-xl border border-dashed border-slate-300 p-6 text-sm text-slate-500">当前没有可处理答卷。</div>
        )}
      </CardContent>
    </Card>
  )
}
