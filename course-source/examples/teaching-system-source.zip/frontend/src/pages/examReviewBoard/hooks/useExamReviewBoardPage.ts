import { useEffect, useEffectEvent, useMemo, useState } from 'react'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { ExamReviewBoardAPIMessage } from '@/microservices/exam/api/ExamReviewBoardAPIMessage'
import { ReviewExamAnswerAPIMessage } from '@/microservices/exam/api/ReviewExamAnswerAPIMessage'
import type { ExamReviewBoardResponse } from '@/microservices/exam/api/responses/ExamReviewBoardResponse'
import { ExamReviewOperation } from '@/pages/objects/ExamReviewWorkflow'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { syncExamReviewBoardMutation } from '@/stores/session/functions/examSession'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'

export function useExamReviewBoardPage() {
  const { examId, questionId } = useParams<{ examId: string; questionId: string }>()
  const [searchParams] = useSearchParams()
  const mode = searchParams.get('mode') ?? ExamReviewOperation.Grading
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const dashboard = useSessionStore((state) => state.dashboard)
  const setSession = useSessionStore((state) => state.setSession)

  const [board, setBoard] = useState<ExamReviewBoardResponse | null>(null)
  const [selectedAnswerSheetId, setSelectedAnswerSheetId] = useState('')
  const [score, setScore] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)

  useHydrateSession()
  useAutoDismissMessage(errorMessage, setErrorMessage)

  const loadBoard = useEffectEvent(async (nextExamId: string, nextQuestionId: string, operatorUserId: string, nextMode: string) => {
    try {
      const response = await sendAPI(new ExamReviewBoardAPIMessage(nextExamId, nextQuestionId, operatorUserId, nextMode)).run()
      setBoard(response)
      setSelectedAnswerSheetId(response.currentItem?.answerSheetId ?? '')
      setErrorMessage('')
    } catch {
      navigate(AppRoutePath.Dashboard)
    }
  })

  useEffect(() => {
    if (!currentUser || !examId || !questionId) return
    void loadBoard(examId, questionId, currentUser.id, mode)
  }, [currentUser?.id, examId, mode, questionId])

  const allItems = useMemo(() => board ? board.pendingItems.concat(board.completedItems) : [], [board])
  const selectedItem = allItems.find((item) => item.answerSheetId === selectedAnswerSheetId) ?? board?.currentItem ?? null
  const selectedIndex = selectedItem ? allItems.findIndex((item) => item.answerSheetId === selectedItem.answerSheetId) : -1

  useEffect(() => {
    if (!selectedItem) return
    setSelectedAnswerSheetId(selectedItem.answerSheetId)
    setScore(selectedItem.score?.toString() ?? '')
  }, [selectedItem])

  const saveScore = async () => {
    if (!selectedItem || !examId || !questionId || !currentUser) return
    const maxScore = board?.question.scoring.fullScore ?? 0
    const nextScore = Number(score)
    if (!Number.isFinite(nextScore) || nextScore < 0 || nextScore > maxScore) {
      setErrorMessage(`分数必须在 0 到 ${maxScore} 之间`)
      return
    }
    setErrorMessage('')
    setIsBusy(true)
    try {
      const nextBoard = await sendAPI(new ReviewExamAnswerAPIMessage(examId, questionId, selectedItem.answerSheetId, currentUser.id, mode, {
        score: nextScore,
      })).run()
      setBoard(nextBoard)
      setSelectedAnswerSheetId(nextBoard.currentItem?.answerSheetId ?? nextBoard.completedItems[0]?.answerSheetId ?? '')
      syncExamReviewBoardMutation(dashboard, nextBoard, setSession)
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '保存批改失败')
    } finally {
      setIsBusy(false)
    }
  }

  const moveSelection = (offset: number) => {
    if (selectedIndex < 0) return
    const nextItem = allItems[selectedIndex + offset]
    if (nextItem) setSelectedAnswerSheetId(nextItem.answerSheetId)
  }

  return {
    allItems,
    board,
    currentUser,
    errorMessage,
    examId,
    isBusy,
    mode,
    questionId,
    score,
    selectedIndex,
    selectedItem,
    moveSelection,
    saveScore,
    setScore,
  }
}
