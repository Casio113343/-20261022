import { ClipboardList } from 'lucide-react'

import { Badge, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'
import type { ExamTeacherTask } from '@/microservices/exam/api/responses/ExamTeacherTask'

type GroupedExamTask = {
  examId: string
  examTitle: string
  pendingCount: number
}

function groupExamTasks(examReviewTasks: ExamTeacherTask[]): GroupedExamTask[] {
  return Object.values(
    examReviewTasks.filter((task) => task.pendingCount > 0).reduce<Record<string, GroupedExamTask>>((acc, task) => {
      const current = acc[task.examId]
      acc[task.examId] = current
        ? { ...current, pendingCount: current.pendingCount + task.pendingCount }
        : { examId: task.examId, examTitle: task.examTitle, pendingCount: task.pendingCount }
      return acc
    }, {}),
  )
}

export function ExamTaskCard({
  examReviewTasks,
  scopeLabel,
  onOpenExam,
}: {
  examReviewTasks: ExamTeacherTask[]
  scopeLabel: string
  onOpenExam: (examId: string) => void
}) {
  const groupedExamTasks = groupExamTasks(examReviewTasks)

  return (
    <Card className="border-teal-100 bg-[linear-gradient(180deg,rgba(255,255,255,0.92),rgba(240,253,250,0.86))]">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl">
          <ClipboardList className="size-5" />
          考试批改与申诉
        </CardTitle>
        <CardDescription>{scopeLabel ? `任务范围：${scopeLabel}` : '当前没有考试任务。'}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {groupedExamTasks.length ? groupedExamTasks.map((task) => (
          <button
            key={task.examId}
            type="button"
            className="flex w-full items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-left transition hover:bg-teal-50"
            onClick={() => onOpenExam(task.examId)}
          >
            <div className="font-medium">{task.examTitle}</div>
            <Badge variant="secondary">{task.pendingCount}</Badge>
          </button>
        )) : (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-sm text-slate-500">当前没有考试任务。</div>
        )}
      </CardContent>
    </Card>
  )
}
