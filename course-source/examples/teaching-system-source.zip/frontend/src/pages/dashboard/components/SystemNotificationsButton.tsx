import { Bell } from 'lucide-react'
import { useState } from 'react'

import { Button, Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui'
import type { SystemNotificationSummary } from '@/microservices/dashboard/api/responses/SystemNotificationSummary'

import { formatSystemNotificationDateTime } from '@/microservices/dashboard/lib/systemNotificationHelpers'

export function SystemNotificationsButton({
  notifications,
  unreadCount,
  onOpen,
}: {
  notifications: SystemNotificationSummary[]
  unreadCount: number
  onOpen: () => void
}) {
  const [isOpen, setIsOpen] = useState(false)

  const handleOpenChange = (nextOpen: boolean) => {
    setIsOpen(nextOpen)
    if (nextOpen && unreadCount > 0) {
      onOpen()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <Button type="button" variant="outline" className="relative" onClick={() => handleOpenChange(true)}>
        <Bell className="size-4" />
        系统通知
        {unreadCount ? <span className="absolute -top-2 -right-2 inline-flex min-w-5 items-center justify-center rounded-full bg-rose-500 px-1.5 text-[11px] text-white">{unreadCount}</span> : null}
      </Button>
      <DialogContent className="max-h-[75vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>系统通知</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {notifications.length ? notifications.map((notification) => (
            <div key={notification.id} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">
              <div className="text-slate-500">{formatSystemNotificationDateTime(notification.createdAt)}</div>
              <div className="mt-1">{notification.message}</div>
            </div>
          )) : <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">当前没有系统通知。</div>}
        </div>
      </DialogContent>
    </Dialog>
  )
}
