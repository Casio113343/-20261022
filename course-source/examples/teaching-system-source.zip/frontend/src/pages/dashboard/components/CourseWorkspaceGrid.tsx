import { Bell, BookOpen, ClipboardCheck, ClipboardList } from 'lucide-react'
import type { ReactNode } from 'react'

import { Badge, Card, CardContent } from '@/components/ui'
import type { DashboardCourseSummary } from '@/microservices/dashboard/api/responses/DashboardCourseSummary'

export function CourseWorkspaceGrid({
  currentUserId,
  courseSummaries,
  onOpenCourse,
}: {
  currentUserId: string
  courseSummaries: DashboardCourseSummary[]
  onOpenCourse: (courseId: string) => void
}) {
  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">课程总览</h2>
        </div>
        <Badge variant="secondary">{courseSummaries.length} 门课程</Badge>
      </div>
      {courseSummaries.length ? (
        <div className="space-y-3">
          {courseSummaries.map((summary) => (
            <button
              key={summary.course.id}
              type="button"
              className="block w-full text-left"
              onClick={() => onOpenCourse(summary.course.id)}
            >
              <Card className="border-emerald-100 bg-lime-50/50 shadow-[0_14px_36px_rgba(15,23,42,0.06)] transition hover:border-emerald-200 hover:bg-emerald-50">
                <CardContent className="flex flex-col gap-3 px-4 py-1 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0 space-y-1 pl-2">
                  <div className="truncate text-lg font-semibold text-slate-950">{summary.course.title}</div>
                </div>
                <div className="flex flex-wrap items-center gap-2 sm:justify-end sm:pr-6">
                  <SummaryPill
                    icon={<Bell className="size-4" />}
                    label="公告"
                    value={summary.unreadAnnouncementCount}
                  />
                  <SummaryPill
                    icon={<BookOpen className="size-4" />}
                    label="作业"
                    value={summary.course.teachers.some((teacher) => teacher.id === currentUserId) ? summary.pendingReviewCount : summary.pendingAssignmentCount + summary.unreadReviewedAssignmentCount}
                  />
                  <SummaryPill
                    icon={<ClipboardList className="size-4" />}
                    label="考试"
                    value={summary.course.teachers.some((teacher) => teacher.id === currentUserId) ? summary.pendingExamTaskCount : summary.unreadPublishedExamCount + summary.pendingExamReviewCount}
                  />
                  <SummaryPill
                    icon={<ClipboardCheck className="size-4" />}
                    label="问卷"
                    value={summary.pendingQuestionnaireCount}
                  />
                </div>
                </CardContent>
              </Card>
            </button>
          ))}
        </div>
      ) : (
        <Card className="border-dashed border-slate-300 bg-slate-50">
          <CardContent className="p-8 text-sm text-slate-500">
            当前还没有可见课程。
          </CardContent>
        </Card>
      )}
    </section>
  )
}

function SummaryPill({
  icon,
  label,
  value,
}: {
  icon: ReactNode
  label: string
  value: number
}) {
  return (
    <div className="inline-flex min-w-18 items-center gap-2 px-1 py-1">
      <div className="flex items-center gap-2 text-sm text-slate-500">
        {icon}
        {label}
      </div>
      <div className="text-sm font-semibold text-sky-600">{value}</div>
    </div>
  )
}
