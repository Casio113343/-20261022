import { PlusCircle } from 'lucide-react'

import { Button, Card, CardContent, CardHeader, CardTitle } from '@/components/ui'

export function CreateCourseCard({ onOpenCourseCreate }: { onOpenCourseCreate: () => void }) {
  return (
    <Card className="border-cyan-100 bg-[linear-gradient(160deg,rgba(255,255,255,0.92),rgba(236,254,255,0.84),rgba(240,253,250,0.82))]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-xl">
          <PlusCircle className="size-5" />
          创建课程
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <Button className="w-auto px-4" onClick={onOpenCourseCreate}>进入创建页</Button>
      </CardContent>
    </Card>
  )
}
