import { GraduationCap, UserCog } from 'lucide-react'

import { Avatar, AvatarFallback, AvatarImage, Button } from '@/components/ui'
import type { SystemNotificationSummary } from '@/microservices/dashboard/api/responses/SystemNotificationSummary'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

import { roleHeading } from '../functions/dashboardHelpers'
import { countUnreadSystemNotifications } from '@/microservices/dashboard/lib/systemNotificationHelpers'
import { SystemNotificationsButton } from './SystemNotificationsButton'

export function DashboardHero({
  currentUser,
  isTeacher,
  totalReviews,
  systemNotifications,
  onOpenProfile,
  onReadSystemNotifications,
}: {
  currentUser: PublicUser
  isTeacher: boolean
  totalReviews: number
  systemNotifications: SystemNotificationSummary[]
  onOpenProfile: () => void
  onReadSystemNotifications: () => Promise<void>
}) {
  void totalReviews
  const unreadNotificationCount = countUnreadSystemNotifications(systemNotifications, currentUser)
  const avatarSrc = currentUser.avatarDataUrl ?? undefined

  return (
    <header className={`mb-6 overflow-hidden rounded-[2rem] border p-6 shadow-[0_24px_70px_rgba(15,23,42,0.10)] backdrop-blur ${
      isTeacher
        ? 'border-sky-100 bg-[radial-gradient(circle_at_top_left,rgba(125,211,252,0.24),transparent_32%),linear-gradient(135deg,rgba(239,246,255,0.96),rgba(255,255,255,0.92),rgba(224,242,254,0.94))]'
        : 'border-teal-100 bg-[radial-gradient(circle_at_top_left,rgba(45,212,191,0.22),transparent_32%),linear-gradient(135deg,rgba(240,253,250,0.96),rgba(255,255,255,0.92),rgba(207,250,254,0.9))]'
    }`}>
      <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
        <div className="flex items-start gap-4">
          <Avatar className="mt-1 size-16 border border-white/80 shadow-sm">
            <AvatarImage key={avatarSrc ?? 'empty'} src={avatarSrc} alt={currentUser.displayName} />
            <AvatarFallback className="text-xl">{currentUser.displayName.slice(0, 1)}</AvatarFallback>
          </Avatar>
          <div className="space-y-3">
            <div className="inline-flex items-center gap-3 rounded-full bg-white/80 px-4 py-2 text-sm shadow-sm">
              <GraduationCap className="size-4" />
              {roleHeading(currentUser.role)}
            </div>
            <h1 className="text-3xl font-semibold tracking-tight lg:text-4xl">{currentUser.displayName}，你好</h1>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <SystemNotificationsButton notifications={systemNotifications} unreadCount={unreadNotificationCount} onOpen={() => { void onReadSystemNotifications() }} />
          <Button variant="outline" onClick={onOpenProfile}>
            <UserCog className="size-4" />
            个人中心
          </Button>
        </div>
      </div>
    </header>
  )
}
