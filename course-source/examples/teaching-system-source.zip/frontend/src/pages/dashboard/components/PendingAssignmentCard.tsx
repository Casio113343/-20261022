import { Badge, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'

type GroupedReviewTask = {
  assignmentId: string
  assignmentTitle: string
  pendingCount: number
}

export function PendingAssignmentCard({
  groupedReviewTasks,
  scopeLabel,
  onOpenReviewAssignment,
}: {
  groupedReviewTasks: GroupedReviewTask[]
  scopeLabel: string
  onOpenReviewAssignment: (assignmentId: string) => void
}) {
  return (
    <Card className="border-sky-100 bg-[linear-gradient(180deg,rgba(255,255,255,0.92),rgba(236,254,255,0.82))]">
      <CardHeader>
        <CardTitle className="text-xl">作业批改</CardTitle>
        <CardDescription>{scopeLabel ? `任务范围：${scopeLabel}` : '当前没有批改范围。'}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {groupedReviewTasks.length ? groupedReviewTasks.map((task) => (
          <button
            key={task.assignmentId}
            type="button"
            className="flex w-full items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-left transition hover:bg-cyan-50"
            onClick={() => onOpenReviewAssignment(task.assignmentId)}
          >
            <span className="font-medium">{task.assignmentTitle}</span>
            <Badge variant="secondary">{task.pendingCount}</Badge>
          </button>
        )) : (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-sm text-slate-500">当前没有待批改作业。</div>
        )}
      </CardContent>
    </Card>
  )
}
