import type { ExamTeacherTask } from '@/microservices/exam/api/responses/ExamTeacherTask'

import { CreateCourseCard } from './CreateCourseCard'
import { ExamTaskCard } from './ExamTaskCard'
import { PendingAssignmentCard } from './PendingAssignmentCard'

export function TeacherOverview({
  groupedReviewTasks,
  examReviewTasks,
  scopeLabel,
  onOpenCourseCreate,
  onOpenReviewAssignment,
  onOpenExam,
}: {
  groupedReviewTasks: { assignmentId: string; assignmentTitle: string; pendingCount: number }[]
  examReviewTasks: ExamTeacherTask[]
  scopeLabel: string
  onOpenCourseCreate: () => void
  onOpenReviewAssignment: (assignmentId: string) => void
  onOpenExam: (examId: string) => void
}) {
  return (
    <div className="mb-6 grid gap-4 xl:grid-cols-3">
      <CreateCourseCard onOpenCourseCreate={onOpenCourseCreate} />
      <PendingAssignmentCard groupedReviewTasks={groupedReviewTasks} scopeLabel={scopeLabel} onOpenReviewAssignment={onOpenReviewAssignment} />
      <ExamTaskCard examReviewTasks={examReviewTasks} scopeLabel={scopeLabel} onOpenExam={onOpenExam} />
    </div>
  )
}
