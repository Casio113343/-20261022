import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { UserRole } from '@/microservices/auth/objects/UserRole'

export function formatDateTime(value: string) {
  return new Intl.DateTimeFormat('zh-CN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value))
}

export function roleHeading(role: string) {
  return role === UserRole.Teacher ? '教师工作台' : '学生学习台'
}

export function countPendingAssignments(course: CourseDetailResponse, currentUserId: string) {
  return course.assignments.filter(
    (assignment) =>
      (new Date(assignment.dueAt).getTime() >= Date.now() || assignment.allowLateSubmission) &&
      !course.submissions.some(
        (submission) => submission.assignmentId === assignment.id && submission.studentId === currentUserId,
      ),
  ).length
}
