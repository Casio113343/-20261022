import type { ChangeEvent } from 'react'

import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { AssignmentReviewTask } from '@/microservices/dashboard/api/responses/AssignmentReviewTask'
import { Attachment } from '@/infrastructure/storage/Attachment'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

import { formatDateTime } from './dashboardHelpers'

export function groupReviewTasks(reviewTasks: AssignmentReviewTask[]) {
  return Object.values(
    reviewTasks.reduce<Record<string, { assignmentId: string; assignmentTitle: string; pendingCount: number }>>((acc, task) => {
      const current = acc[task.assignment.id]
      acc[task.assignment.id] = current
        ? { ...current, pendingCount: current.pendingCount + 1 }
        : { assignmentId: task.assignment.id, assignmentTitle: task.assignment.title, pendingCount: 1 }
      return acc
    }, {}),
  )
}

export function hasUnreadAnnouncements(course: CourseDetailResponse, currentUser: PublicUser) {
  return course.announcements.some((item) => item.publisher.id !== currentUser.id && !(currentUser.readAnnouncementIds ?? []).includes(item.id))
}

export function countUnreadReviewedAssignments(course: CourseDetailResponse, currentUserId: string, currentUser: PublicUser) {
  const readIds = currentUser.readReviewedAssignmentIds ?? []
  return course.assignments.filter((assignment) => {
    const submission = course.submissions.find((item) => item.assignmentId === assignment.id && item.studentId === currentUserId)
    return Boolean(submission) && course.reviews.some((review) => review.submissionId === submission?.id) && !readIds.includes(assignment.id)
  }).length
}

export function hasUnreadReviewedAssignment(course: CourseDetailResponse, currentUserId: string, currentUser: PublicUser) {
  return countUnreadReviewedAssignments(course, currentUserId, currentUser) > 0
}

export function countUnreadPublishedExams(course: CourseDetailResponse, currentUser: PublicUser) {
  const readIds = currentUser.readPublishedExamIds ?? []
  return course.exams.filter((exam) => exam.publishedAt && !readIds.includes(exam.id)).length
}

export function hasUnreadPublishedExam(course: CourseDetailResponse, currentUser: PublicUser) {
  return countUnreadPublishedExams(course, currentUser) > 0
}

export function formatAssignmentDueText(assignment: Assignment) {
  return `${formatDateTime(assignment.dueAt)}（${assignment.allowLateSubmission ? '允许补交' : '不允许补交'}）`
}

export function isLateOpen(assignment: Assignment) {
  return new Date(assignment.dueAt).getTime() < Date.now() && assignment.allowLateSubmission
}

export function isLateLocked(assignment: Assignment) {
  return new Date(assignment.dueAt).getTime() < Date.now() && !assignment.allowLateSubmission
}

export function splitStudentAssignments(assignments: Assignment[], submissions: AssignmentSubmission[], currentUserId: string) {
  const submitted = assignments.filter((assignment) => submissions.some((item) => item.assignmentId === assignment.id && item.studentId === currentUserId))
  const pending = assignments.filter((assignment) => !submissions.some((item) => item.assignmentId === assignment.id && item.studentId === currentUserId))

  return { submitted, pending }
}

export function readAttachments(onLoaded: (attachments: Attachment[]) => void) {
  return (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? [])
    void Promise.all(files.map(readFileAsDataUrl)).then((attachments) => {
      onLoaded(attachments)
      event.target.value = ''
    })
  }
}

function readFileAsDataUrl(file: File): Promise<Attachment> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(new Attachment(file.name, String(reader.result ?? '')))
    reader.onerror = () => reject(new Error(`读取文件失败：${file.name}`))
    reader.readAsDataURL(file)
  })
}
