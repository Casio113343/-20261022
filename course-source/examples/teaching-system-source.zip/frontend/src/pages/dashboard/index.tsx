import { Navigate } from 'react-router-dom'

import { DashboardHero } from '@/pages/dashboard/components/DashboardHero'
import { CourseWorkspaceGrid } from '@/pages/dashboard/components/CourseWorkspaceGrid'
import { TeacherOverview } from '@/pages/dashboard/components/TeacherOverview'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { useDashboardPage } from './hooks/useDashboardPage'

export default function DashboardPage() {
  const page = useDashboardPage()

  if (!page.currentUser) {
    return <Navigate replace to={AppRoutePath.Login} />
  }

  if (!page.dashboard) {
    return (
      <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] p-8 text-sm text-slate-500">
        正在加载总览...
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(14,165,233,0.16),transparent_28%),radial-gradient(circle_at_80%_0%,rgba(45,212,191,0.18),transparent_24%),linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-5xl px-5 py-8 lg:px-7">
        <DashboardHero
          currentUser={page.currentUser}
          isTeacher={Boolean(page.isTeacher)}
          totalReviews={page.dashboard.reviewTasks.length}
          systemNotifications={page.dashboard.systemNotifications}
          onOpenProfile={page.openProfile}
          onReadSystemNotifications={page.readSystemNotifications}
        />
        {page.isTeacher ? (
          <TeacherOverview
            groupedReviewTasks={page.groupedReviewTasks}
            examReviewTasks={page.dashboard.examReviewTasks}
            scopeLabel="全部课程"
            onOpenCourseCreate={page.openCourseCreate}
            onOpenReviewAssignment={page.openReviewAssignment}
            onOpenExam={page.openExam}
          />
        ) : null}
        <CourseWorkspaceGrid
          currentUserId={page.currentUser.id}
          courseSummaries={page.dashboard.courseSummaries}
          onOpenCourse={page.openCourse}
        />
      </div>
    </main>
  )
}
