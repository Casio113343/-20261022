import { useNavigate } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { UserRole } from '@/microservices/auth/objects/UserRole'
import { MarkSystemNotificationsReadAPIMessage } from '@/microservices/dashboard/api/MarkSystemNotificationsReadAPIMessage'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { groupReviewTasks } from '../functions/dashboardViewHelpers'

export function useDashboardPage() {
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser, dashboard, setSession } = useEnsureDashboard(navigate)
  const isTeacher = currentUser?.role === UserRole.Teacher

  const readSystemNotifications = async () => {
    if (!currentUser) return
    const nextDashboard = await sendAPI(
      new MarkSystemNotificationsReadAPIMessage(currentUser.id),
    ).run()
    setSession(nextDashboard)
  }

  return {
    currentUser,
    dashboard,
    groupedReviewTasks: groupReviewTasks(dashboard?.reviewTasks ?? []),
    isTeacher,
    openCourse: (courseId: string) => navigate(AppRoute.CourseWorkspace(courseId)),
    openCourseCreate: () => navigate(AppRoutePath.CourseCreate),
    openExam: (examId: string) => navigate(AppRoute.ExamDetail(examId)),
    openProfile: () => navigate(AppRoutePath.Profile),
    openReviewAssignment: (assignmentId: string) => navigate(AppRoute.ReviewBoardPending(assignmentId)),
    readSystemNotifications,
  }
}
