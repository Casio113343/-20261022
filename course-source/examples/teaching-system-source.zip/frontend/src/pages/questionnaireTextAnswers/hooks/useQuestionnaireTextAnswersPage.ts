import { useEffect, useEffectEvent, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { FetchQuestionnaireTextAnswersAPIMessage } from '@/microservices/questionnaire/api/FetchQuestionnaireTextAnswersAPIMessage'
import type { QuestionnaireTextAnswer } from '@/microservices/questionnaire/api/responses/QuestionnaireTextAnswer'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'

export function useQuestionnaireTextAnswersPage() {
  const { questionnaireId, questionId } = useParams<{ questionnaireId: string; questionId: string }>()
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const [answers, setAnswers] = useState<QuestionnaireTextAnswer[]>([])
  const [errorMessage, setErrorMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  useHydrateSession()

  const loadAnswers = useEffectEvent(async (nextQuestionnaireId: string, nextQuestionId: string, operatorUserId: string) => {
    setIsLoading(true)
    setErrorMessage('')
    try {
      setAnswers(await sendAPI(new FetchQuestionnaireTextAnswersAPIMessage(nextQuestionnaireId, nextQuestionId, operatorUserId)).run())
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '加载简答回答失败')
    } finally {
      setIsLoading(false)
    }
  })

  useEffect(() => {
    if (!questionnaireId || !questionId || !currentUser) return
    void loadAnswers(questionnaireId, questionId, currentUser.id)
  }, [currentUser?.id, questionnaireId, questionId])

  return {
    answers,
    currentUser,
    errorMessage,
    isLoading,
    questionnaireId,
    goBack: () => {
      if (questionnaireId) navigate(AppRoute.QuestionnaireDetail(questionnaireId))
      else navigate(AppRoutePath.Dashboard)
    },
  }
}
