import { Navigate } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Button, Card, CardContent, CardHeader, CardTitle } from '@/components/ui'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { useQuestionnaireTextAnswersPage } from './hooks/useQuestionnaireTextAnswersPage'

export default function QuestionnaireTextAnswersPage() {
  const page = useQuestionnaireTextAnswersPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-3xl px-5 py-8 lg:px-8">
        <Button type="button" variant="outline" className="mb-6" onClick={page.goBack}>
          <ChevronLeft className="size-4" />
          返回问卷
        </Button>
        <Card>
          <CardHeader><CardTitle>简答回答</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {page.errorMessage ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{page.errorMessage}</div> : null}
            {page.isLoading ? <div className="text-sm text-slate-500">正在加载回答。</div> : null}
            {!page.isLoading && page.answers.length ? page.answers.map((answer) => (
              <div key={answer.submissionId} className="rounded-xl border border-slate-200 bg-white px-4 py-3">
                <div className="whitespace-pre-wrap text-sm text-slate-700">{answer.student ? `${answer.student.displayName}：` : ''}{answer.text}</div>
              </div>
            )) : null}
            {!page.isLoading && !page.answers.length ? <div className="text-sm text-slate-500">暂无简答回答。</div> : null}
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
