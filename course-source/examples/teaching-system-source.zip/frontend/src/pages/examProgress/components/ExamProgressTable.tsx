import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui'

import { formatProgressQuestionLabel } from '../functions/examProgress'
import type { useExamProgressPage } from '../hooks/useExamProgressPage'

class ExamProgressTableProps {
  page!: ReturnType<typeof useExamProgressPage>
}

export function ExamProgressTable({ page }: ExamProgressTableProps) {
  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <CardTitle className="text-xl">{page.detail?.exam.title} 批改进度</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {page.progressItems.map((item) => (
          <div key={item.questionId} className="rounded-xl bg-slate-50 px-6 py-3 text-sm text-slate-700">
            {item.graders.length ? item.graders.map((progress, index) => (
              <div key={progress.grader.id} className="grid items-center gap-x-6 gap-y-2 py-1 md:grid-cols-[minmax(160px,1fr)_minmax(120px,1fr)_minmax(80px,0.8fr)_minmax(80px,0.8fr)_minmax(80px,0.8fr)]">
                <span className={index === 0 ? 'font-medium text-slate-900' : 'hidden md:block'}>{index === 0 ? formatProgressQuestionLabel(item.position, item.title) : null}</span>
                <span>批改教师：{progress.grader.displayName}</span>
                <span>已批改 {progress.gradedCount}</span>
                <span>未批改 {progress.pendingGradingCount}</span>
                {index === 0 ? <span>未导入 {progress.missingImportCount}</span> : null}
              </div>
            )) : (
              <div className="grid items-center gap-x-6 gap-y-2 py-1 md:grid-cols-[minmax(160px,1fr)_minmax(120px,1fr)_minmax(80px,0.8fr)_minmax(80px,0.8fr)_minmax(80px,0.8fr)]">
                <span className="font-medium text-slate-900">{formatProgressQuestionLabel(item.position, item.title)}</span>
                <span>批改教师：未设置</span>
                <span>已批改 0</span>
                <span>未批改 0</span>
                <span>未导入 0</span>
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
