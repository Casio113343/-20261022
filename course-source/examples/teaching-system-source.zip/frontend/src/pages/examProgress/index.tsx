import { Navigate } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Alert, AlertDescription, Button, Card, CardContent } from '@/components/ui'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { ExamProgressTable } from './components/ExamProgressTable'
import { useExamProgressPage } from './hooks/useExamProgressPage'

export default function ExamProgressPage() {
  const page = useExamProgressPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.examId) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-4xl px-5 py-8 lg:px-8">
        <Button type="button" variant="outline" className="mb-6" onClick={page.goBackToExam}><ChevronLeft className="size-4" />返回考试页</Button>
        {!page.detail ? (
          <Card className="border-slate-200 bg-white">
            <CardContent className="p-8 text-sm text-slate-500">正在加载批改进度。</CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <ExamProgressTable page={page} />
            <div className="flex flex-wrap items-center gap-3">
              <Button type="button" disabled={page.isBusy || !page.detail.canPublish || page.detail.exam.publishedAt !== null} onClick={() => void page.publishExam()}>{page.detail.exam.publishedAt ? '已发布' : '发布考试成绩'}</Button>
              {!page.detail.canPublish ? <div className="text-sm text-slate-500">所有题目都完成导入和批改后才可发布。</div> : null}
            </div>
            {page.errorMessage ? <Alert variant="destructive" className="border-rose-200 bg-rose-50 text-rose-700"><AlertDescription className="text-rose-700">{page.errorMessage}</AlertDescription></Alert> : null}
          </div>
        )}
      </div>
    </main>
  )
}
