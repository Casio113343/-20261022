import { useEffect, useEffectEvent, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { ExamDetailAPIMessage } from '@/microservices/exam/api/ExamDetailAPIMessage'
import { PublishExamAPIMessage } from '@/microservices/exam/api/PublishExamAPIMessage'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { syncExamDetailMutation } from '@/stores/session/functions/examSession'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'
import { buildExamQuestionGradingProgress } from '../functions/examProgress'

export function useExamProgressPage() {
  const { examId } = useParams<{ examId: string }>()
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const dashboard = useSessionStore((state) => state.dashboard)
  const setSession = useSessionStore((state) => state.setSession)
  const [detail, setDetail] = useState<ExamDetailResponse | null>(null)
  const [errorMessage, setErrorMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)

  useHydrateSession()

  const loadDetail = useEffectEvent(async (nextExamId: string, operatorUserId: string) => {
    try {
      setDetail(await sendAPI(new ExamDetailAPIMessage(nextExamId, operatorUserId)).run())
    } catch {
      navigate(AppRoutePath.Dashboard)
    }
  })

  useEffect(() => {
    if (!currentUser || !examId) return
    void loadDetail(examId, currentUser.id)
  }, [currentUser?.id, examId])

  const progressItems = useMemo(() => detail ? buildExamQuestionGradingProgress(detail) : [], [detail])

  const publishExam = async () => {
    if (!detail || !currentUser) return
    setErrorMessage('')
    setIsBusy(true)
    try {
      const nextDetail = await sendAPI(new PublishExamAPIMessage(detail.exam.id, currentUser.id)).run()
      setDetail(nextDetail)
      syncExamDetailMutation(dashboard, nextDetail, setSession)
      navigate(AppRoute.ExamDetail(nextDetail.exam.id))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '发布失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    currentUser,
    detail,
    errorMessage,
    examId,
    isBusy,
    progressItems,
    goBackToExam: () => {
      if (examId) navigate(AppRoute.ExamDetail(examId))
    },
    publishExam,
  }
}
