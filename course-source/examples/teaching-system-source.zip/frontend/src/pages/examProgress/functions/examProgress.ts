import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

export function buildExamQuestionGradingProgress(detail: ExamDetailResponse) {
  return (detail.gradingProgress ?? [])
    .slice()
    .sort((left, right) => left.position - right.position)
}

export function formatProgressQuestionLabel(position: number, title?: string | null) {
  return title && title.trim() ? `第 ${position} 题 · ${title}` : `第 ${position} 题`
}
