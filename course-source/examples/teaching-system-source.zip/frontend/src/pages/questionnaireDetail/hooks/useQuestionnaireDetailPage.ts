import { useEffect, useEffectEvent, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { UserRole } from '@/microservices/auth/objects/UserRole'
import { DashboardCourseSummary } from '@/microservices/dashboard/api/responses/DashboardCourseSummary'
import { UserDashboardResponse } from '@/microservices/dashboard/api/responses/UserDashboardResponse'
import { DeleteQuestionnaireAPIMessage } from '@/microservices/questionnaire/api/DeleteQuestionnaireAPIMessage'
import { FetchQuestionnaireDetailAPIMessage } from '@/microservices/questionnaire/api/FetchQuestionnaireDetailAPIMessage'
import { MarkQuestionnaireReadAPIMessage } from '@/microservices/questionnaire/api/MarkQuestionnaireReadAPIMessage'
import { SubmitQuestionnaireAnswersAPIMessage } from '@/microservices/questionnaire/api/SubmitQuestionnaireAnswersAPIMessage'
import { QuestionnaireSubmissionInput } from '@/microservices/questionnaire/api/requests/QuestionnaireSubmissionInput'
import type { QuestionnaireDetailResponse } from '@/microservices/questionnaire/api/responses/QuestionnaireDetailResponse'
import { QuestionnaireAnswer } from '@/microservices/questionnaire/objects/QuestionnaireAnswer'
import { QuestionnaireQuestionType } from '@/microservices/questionnaire/objects/QuestionnaireQuestionType'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'

export function useQuestionnaireDetailPage() {
  const { questionnaireId } = useParams<{ questionnaireId: string }>()
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const dashboard = useSessionStore((state) => state.dashboard)
  const setSession = useSessionStore((state) => state.setSession)
  const [detail, setDetail] = useState<QuestionnaireDetailResponse | null>(null)
  const [answers, setAnswers] = useState<Record<string, QuestionnaireAnswer>>({})
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [isDeleteOpen, setIsDeleteOpen] = useState(false)
  const [isBusy, setIsBusy] = useState(false)

  useHydrateSession()
  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  const loadDetail = useEffectEvent(async (nextQuestionnaireId: string, operatorUserId: string) => {
    try {
      const response = await sendAPI(new FetchQuestionnaireDetailAPIMessage(nextQuestionnaireId, operatorUserId)).run()
      setDetail(response)
      setAnswers(Object.fromEntries((response.currentUserSubmission?.answers ?? []).map((answer) => [answer.questionId, answer])))
    } catch {
      navigate(AppRoutePath.Dashboard)
    }
  })

  useEffect(() => {
    if (!questionnaireId || !currentUser) return
    void loadDetail(questionnaireId, currentUser.id)
  }, [currentUser?.id, questionnaireId])

  const markQuestionnaireRead = useEffectEvent(async (nextQuestionnaireId: string, operatorUserId: string) => {
    try {
      setSession(await sendAPI(new MarkQuestionnaireReadAPIMessage(nextQuestionnaireId, operatorUserId)).run())
    } catch {
      // 已读标记失败不影响详情查看。
    }
  })

  useEffect(() => {
    if (!detail || !currentUser || currentUser.role !== UserRole.Teacher) return
    if (detail.questionnaire.createdByTeacherId === currentUser.id) return
    if ((currentUser.readQuestionnaireIds ?? []).includes(detail.questionnaire.id)) return
    void markQuestionnaireRead(detail.questionnaire.id, currentUser.id)
  }, [currentUser?.id, currentUser?.readQuestionnaireIds, detail?.questionnaire.createdByTeacherId, detail?.questionnaire.id])

  const isTeacher = currentUser?.role === UserRole.Teacher
  const isExpired = detail ? new Date(detail.questionnaire.dueAt).getTime() < Date.now() : false
  const canSubmit = Boolean(detail && !isTeacher && !detail.currentUserSubmission && !isExpired)

  const setAnswer = (questionId: string, answer: QuestionnaireAnswer) => {
    setAnswers((current) => ({ ...current, [questionId]: answer }))
  }

  const submit = async () => {
    if (!detail || !currentUser || !questionnaireId) return
    setErrorMessage('')
    setSuccessMessage('')
    const normalizedAnswers = detail.questionnaire.questions.map((question) => {
      const current = answers[question.id] ?? new QuestionnaireAnswer(question.id, [], null)
      if (question.questionType === QuestionnaireQuestionType.Text) {
        return new QuestionnaireAnswer(question.id, [], current.text?.trim() || undefined)
      }
      return new QuestionnaireAnswer(question.id, current.selectedOptions, undefined)
    })
    const invalidQuestion = detail.questionnaire.questions.find((question) => {
      if (!question.required) return false
      const answer = normalizedAnswers.find((item) => item.questionId === question.id)
      return question.questionType === QuestionnaireQuestionType.Text ? !answer?.text : !answer?.selectedOptions.length
    })
    if (invalidQuestion) {
      setErrorMessage(`${invalidQuestion.title} 为必填题。`)
      return
    }
    setIsBusy(true)
    try {
      const nextDetail = await sendAPI(new SubmitQuestionnaireAnswersAPIMessage(questionnaireId, currentUser.id, new QuestionnaireSubmissionInput(normalizedAnswers))).run()
      setDetail(nextDetail)
      decrementQuestionnaireCount(dashboard, nextDetail.course.id, setSession)
      navigate(AppRoute.CourseWorkspace(nextDetail.course.id))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '提交问卷失败')
    } finally {
      setIsBusy(false)
    }
  }

  const answersByQuestionId = useMemo(() => answers, [answers])

  const deleteQuestionnaire = async () => {
    if (!detail || !currentUser || !questionnaireId) return
    setIsBusy(true)
    try {
      await sendAPI(new DeleteQuestionnaireAPIMessage(questionnaireId, currentUser.id)).run()
      navigate(AppRoute.CourseWorkspace(detail.course.id))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '删除问卷失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    answersByQuestionId,
    canSubmit,
    currentUser,
    detail,
    errorMessage,
    isBusy,
    isDeleteOpen,
    isExpired,
    isTeacher,
    questionnaireId,
    successMessage,
    goBackToCourse: () => {
      if (detail) navigate(AppRoute.CourseWorkspace(detail.course.id))
    },
    openTextAnswers: (questionId: string) => {
      if (questionnaireId) navigate(AppRoute.QuestionnaireTextAnswers(questionnaireId, questionId))
    },
    deleteQuestionnaire,
    setAnswer,
    setIsDeleteOpen,
    submit,
  }
}

function decrementQuestionnaireCount(
  dashboard: UserDashboardResponse | null,
  courseId: string,
  setSession: (dashboard: UserDashboardResponse) => void,
) {
  if (!dashboard) return
  setSession(new UserDashboardResponse(
    dashboard.currentUser,
    dashboard.courseSummaries.map((summary) => (
      summary.course.id === courseId
        ? new DashboardCourseSummary(
          summary.course,
          summary.unreadAnnouncementCount,
          summary.pendingAssignmentCount,
          summary.unreadReviewedAssignmentCount,
          summary.unreadPublishedExamCount,
          summary.pendingReviewCount,
          summary.pendingExamReviewCount,
          summary.pendingExamTaskCount,
          Math.max(0, summary.pendingQuestionnaireCount - 1),
          summary.latestChatSentAt,
        )
        : summary
    )),
    dashboard.reviewTasks,
    dashboard.examReviewTasks,
    dashboard.systemNotifications,
  ))
}
