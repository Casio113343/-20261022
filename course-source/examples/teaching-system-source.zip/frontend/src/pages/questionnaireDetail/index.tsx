import { useState } from 'react'
import { Link, Navigate } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Badge, Button, Card, CardContent, CardHeader, CardTitle, Checkbox, Textarea } from '@/components/ui'
import { ConfirmDialog } from '@/components/ui/confirmDialog'
import { QuestionnaireAnswer } from '@/microservices/questionnaire/objects/QuestionnaireAnswer'
import { QuestionnaireQuestionType } from '@/microservices/questionnaire/objects/QuestionnaireQuestionType'
import type { QuestionnaireChoiceOptionResult } from '@/microservices/questionnaire/api/responses/QuestionnaireChoiceOptionResult'
import { InlineError, InlineSuccess } from '@/shared/forms/FormHelpers'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { formatDateTime } from '@/pages/dashboard/functions/dashboardHelpers'
import { useQuestionnaireDetailPage } from './hooks/useQuestionnaireDetailPage'

export default function QuestionnaireDetailPage() {
  const page = useQuestionnaireDetailPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.questionnaireId) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(45,212,191,0.14),transparent_28%),linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-4xl px-5 py-8 lg:px-8">
        <Button asChild variant="outline" className="mb-6">
          <Link to={page.detail ? AppRoute.CourseWorkspace(page.detail.course.id) : AppRoutePath.Dashboard}>
            <ChevronLeft className="size-4" />
            返回课程工作区
          </Link>
        </Button>
        {!page.detail ? (
          <Card><CardContent className="p-8 text-sm text-slate-500">正在加载问卷。</CardContent></Card>
        ) : (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <CardTitle>{page.detail.questionnaire.title}</CardTitle>
                    <div className="mt-2 text-sm text-slate-500">截止 {formatDateTime(page.detail.questionnaire.dueAt)} / {page.detail.questionnaire.anonymous ? '匿名' : '实名'}</div>
                  </div>
                  {page.isTeacher ? <Badge variant="secondary">已填 {page.detail.filledCount} / 未填 {page.detail.unfilledCount}</Badge> : <Badge variant={page.detail.currentUserSubmission ? 'secondary' : 'outline'}>{page.detail.currentUserSubmission ? '已填写' : page.isExpired ? '已截止' : '待填写'}</Badge>}
                </div>
              </CardHeader>
              {page.detail.questionnaire.overview ? <CardContent className="pt-0 text-sm text-slate-600">{page.detail.questionnaire.overview}</CardContent> : null}
            </Card>

            {page.isTeacher ? (
              <div className="space-y-4">
                {page.detail.results?.map((result, index) => (
                  <Card key={result.question.id}>
                    <CardHeader><CardTitle className="text-base">{formatQuestionTitle(index, result.question.questionType, result.question.title)}</CardTitle></CardHeader>
                    <CardContent className="space-y-3">
                      {result.question.questionType === QuestionnaireQuestionType.Text ? (
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-slate-600">收到回答 {result.textAnswerCount} 条</span>
                          <Button type="button" variant="outline" onClick={() => page.openTextAnswers(result.question.id)}>查看回答</Button>
                        </div>
                      ) : <ChoiceQuestionResults options={result.options} />}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {page.detail.questionnaire.questions.map((question, index) => {
                  const answer = page.answersByQuestionId[question.id] ?? new QuestionnaireAnswer(question.id, [], null)
                  return (
                    <Card key={question.id}>
                      <CardHeader><CardTitle className="text-base">{formatQuestionTitle(index, question.questionType, question.title)}{question.required ? ' *' : ''}</CardTitle></CardHeader>
                      <CardContent className="space-y-3">
                        {question.questionType === QuestionnaireQuestionType.Text ? (
                          <Textarea disabled={!page.canSubmit} value={answer.text ?? ''} onChange={(event) => page.setAnswer(question.id, new QuestionnaireAnswer(question.id, [], event.target.value))} />
                        ) : question.options.map((option) => {
                          const checked = answer.selectedOptions.includes(option)
                          return (
                            <label key={option} className="flex items-center gap-2 text-sm">
                              <Checkbox
                                disabled={!page.canSubmit}
                                checked={checked}
                                onCheckedChange={(nextChecked) => {
                                  const selectedOptions = question.questionType === QuestionnaireQuestionType.SingleChoice
                                    ? (nextChecked ? [option] : [])
                                    : nextChecked ? answer.selectedOptions.concat(option) : answer.selectedOptions.filter((item) => item !== option)
                                  page.setAnswer(question.id, new QuestionnaireAnswer(question.id, selectedOptions, undefined))
                                }}
                              />
                              {option}
                            </label>
                          )
                        })}
                      </CardContent>
                    </Card>
                  )
                })}
                {page.canSubmit ? <Button type="button" disabled={page.isBusy} onClick={() => void page.submit()}>{page.isBusy ? '提交中...' : '提交问卷'}</Button> : null}
                {page.errorMessage ? <InlineError message={page.errorMessage} /> : null}
                {page.successMessage ? <InlineSuccess message={page.successMessage} /> : null}
              </div>
            )}
            {page.isTeacher ? (
              <div className="flex justify-end">
                <Button type="button" variant="destructive" disabled={page.isBusy} onClick={() => page.setIsDeleteOpen(true)}>删除问卷</Button>
              </div>
            ) : null}
            <ConfirmDialog
              open={page.isDeleteOpen}
              title="确认删除问卷？"
              description="删除后，问卷和所有学生填写结果都会被永久移除。"
              confirmLabel="确认删除"
              onOpenChange={page.setIsDeleteOpen}
              onConfirm={() => void page.deleteQuestionnaire()}
            />
          </div>
        )}
      </div>
    </main>
  )
}

function ChoiceQuestionResults({ options }: { options: QuestionnaireChoiceOptionResult[] }) {
  const [openedOption, setOpenedOption] = useState<string | null>(null)
  const totalSelections = options.reduce((total, option) => total + option.selectedCount, 0)

  return (
    <>
      {options.map((option) => {
        const ratio = totalSelections ? option.selectedCount / totalSelections : 0
        const showStudents = openedOption === option.option && Boolean(option.students?.length)
        return (
          <button
            key={option.option}
            type="button"
            className="block w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-left transition hover:bg-slate-50"
            onClick={() => setOpenedOption((current) => current === option.option ? null : option.option)}
          >
            <div className="grid items-center gap-x-4 gap-y-3 md:grid-cols-[minmax(0,max-content)_minmax(180px,1fr)_92px]">
              <span className="min-w-0 truncate text-sm text-slate-800">{option.option}</span>
              <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                <div className="h-full rounded-full bg-emerald-500" style={{ width: `${Math.round(ratio * 100)}%` }} />
              </div>
              <span className="text-sm text-slate-600">{option.selectedCount} 人 {Math.round(ratio * 100)}%</span>
            </div>
            {showStudents ? <div className="mt-2 text-sm text-slate-500">{option.students?.map((student) => student.displayName).join('、')}</div> : null}
          </button>
        )
      })}
    </>
  )
}

function formatQuestionTitle(index: number, questionType: string, title: string) {
  return `第${index + 1}题：（${formatQuestionType(questionType)}）${title}`
}

function formatQuestionType(questionType: string) {
  if (questionType === QuestionnaireQuestionType.SingleChoice) return '单选'
  if (questionType === QuestionnaireQuestionType.MultipleChoice) return '多选'
  return '简答'
}
