import { Navigate } from 'react-router-dom'

import { Card, CardContent } from '@/components/ui'
import { ConfirmDialog } from '@/components/ui/confirmDialog'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { AnnouncementBackButton } from './components/AnnouncementBackButton'
import { AnnouncementDetailCard } from './components/AnnouncementDetailCard'
import { useAnnouncementDetailPage } from './hooks/useAnnouncementDetailPage'

export default function AnnouncementDetailPage() {
  const page = useAnnouncementDetailPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.announcementId) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-4xl px-5 py-8 lg:px-8">
        <AnnouncementBackButton page={page} />

        {page.detail === undefined ? (
          <Card className="border-slate-200 bg-white">
            <CardContent className="p-8 text-sm text-slate-500">正在加载通知内容。</CardContent>
          </Card>
        ) : page.detail === null ? (
          <Navigate replace to={AppRoutePath.Dashboard} />
        ) : (
          <AnnouncementDetailCard page={page} />
        )}
        <ConfirmDialog
          open={page.isDeleteOpen}
          title="确认删除通知？"
          description="删除后，这条通知会从系统中永久移除。"
          confirmLabel="确认删除"
          onOpenChange={page.setIsDeleteOpen}
          onConfirm={() => void page.deleteAnnouncement()}
        />
      </div>
    </main>
  )
}
