import { useEffect, useEffectEvent, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { UserRole } from '@/microservices/auth/objects/UserRole'
import { DeleteAnnouncementAPIMessage } from '@/microservices/course/api/DeleteAnnouncementAPIMessage'
import { FetchAnnouncementCourseDetailAPIMessage } from '@/microservices/course/api/FetchAnnouncementCourseDetailAPIMessage'
import { MarkAnnouncementsReadAPIMessage } from '@/microservices/course/api/MarkAnnouncementsReadAPIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { AppRoute } from '@/shared/routing/AppRoutes'
import { syncCourseDetailMutation } from '@/stores/session/functions/courseDetailSession'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { resolveAnnouncementDetail } from '../functions/announcementDetail'

export function useAnnouncementDetailPage() {
  const { announcementId } = useParams<{ announcementId: string }>()
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser, dashboard, setSession } = useEnsureDashboard(navigate)
  const [isDeleteOpen, setIsDeleteOpen] = useState(false)
  const [courseDetail, setCourseDetail] = useState<CourseDetailResponse | null | undefined>(undefined)

  const detail = useMemo(() => resolveAnnouncementDetail(courseDetail, announcementId), [announcementId, courseDetail])

  useEffect(() => {
    if (!currentUser || !announcementId) return
    void sendAPI(new FetchAnnouncementCourseDetailAPIMessage(announcementId, currentUser.id)).run()
      .then(setCourseDetail)
      .catch(() => setCourseDetail(null))
  }, [announcementId, currentUser?.id])

  const markCurrentAnnouncementRead = useEffectEvent(async (courseId: string, operatorUserId: string) => {
    try {
      const nextDashboard = await sendAPI(new MarkAnnouncementsReadAPIMessage(courseId, operatorUserId)).run()
      setSession(nextDashboard)
    } catch {}
  })

  useEffect(() => {
    if (!currentUser || !detail) return
    const hasRead = (currentUser.readAnnouncementIds ?? []).includes(detail.announcement.id)
    if (hasRead) return
    void markCurrentAnnouncementRead(detail.course.course.id, currentUser.id)
  }, [currentUser?.id, currentUser?.readAnnouncementIds, detail?.announcement.id, detail?.course.course.id])

  const deleteAnnouncement = async () => {
    if (!detail || !currentUser) return
    const nextCourse = await sendAPI(new DeleteAnnouncementAPIMessage(detail.course.course.id, detail.announcement.id, currentUser.id)).run()
    syncCourseDetailMutation(dashboard, nextCourse, setSession, setCourseDetail)
    navigate(AppRoute.CourseWorkspace(nextCourse.course.id))
  }

  return {
    announcementId,
    currentUser,
    detail,
    isDeleteOpen,
    isTeacher: currentUser?.role === UserRole.Teacher,
    deleteAnnouncement,
    editAnnouncement: () => {
      if (detail) navigate(AppRoute.AnnouncementEdit(detail.course.course.id, detail.announcement.id))
    },
    setIsDeleteOpen,
  }
}
