import { Button, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'

import { formatAnnouncementDateTime } from '../functions/announcementDetail'
import type { useAnnouncementDetailPage } from '../hooks/useAnnouncementDetailPage'

class AnnouncementDetailCardProps {
  page!: ReturnType<typeof useAnnouncementDetailPage>
}

export function AnnouncementDetailCard({ page }: AnnouncementDetailCardProps) {
  const detail = page.detail
  if (!detail) return null

  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        {page.isTeacher ? (
          <div className="flex justify-end gap-2">
            <Button type="button" onClick={page.editAnnouncement}>编辑通知</Button>
            <Button type="button" variant="destructive" onClick={() => page.setIsDeleteOpen(true)}>删除通知</Button>
          </div>
        ) : null}
        <CardTitle className="text-2xl">{detail.announcement.title}</CardTitle>
        <CardDescription>{detail.course.course.title} / {detail.announcement.publisher.displayName} / {formatAnnouncementDateTime(detail.announcement.createdAt)}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm leading-8 text-slate-700">{detail.announcement.content}</div>
        {detail.announcement.attachment ? (
          <a className="text-sm text-sky-700 underline underline-offset-4 hover:text-sky-800" href={detail.announcement.attachment.dataUrl} download={detail.announcement.attachment.fileName}>
            下载附件：{detail.announcement.attachment.fileName}
          </a>
        ) : null}
      </CardContent>
    </Card>
  )
}
