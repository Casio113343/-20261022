import { Link } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Button } from '@/components/ui'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'

import type { useAnnouncementDetailPage } from '../hooks/useAnnouncementDetailPage'

class AnnouncementBackButtonProps {
  page!: ReturnType<typeof useAnnouncementDetailPage>
}

export function AnnouncementBackButton({ page }: AnnouncementBackButtonProps) {
  return (
    <Button asChild variant="outline" className="mb-6">
      <Link to={page.detail ? AppRoute.CourseWorkspace(page.detail.course.course.id) : AppRoutePath.Dashboard}>
        <ChevronLeft className="size-4" />
        返回课程工作区
      </Link>
    </Button>
  )
}
