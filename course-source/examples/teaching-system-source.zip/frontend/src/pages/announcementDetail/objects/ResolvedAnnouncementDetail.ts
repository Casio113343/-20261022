import type { CourseAnnouncement } from '@/microservices/course/api/responses/CourseAnnouncement'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class ResolvedAnnouncementDetail {
  constructor(
    public course: CourseDetailResponse,
    public announcement: CourseAnnouncement,
  ) {}
}
