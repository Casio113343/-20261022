import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

import { ResolvedAnnouncementDetail } from '../objects/ResolvedAnnouncementDetail'

export function formatAnnouncementDateTime(value: string) {
  return new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
}

export function resolveAnnouncementDetail(courseDetail: CourseDetailResponse | null | undefined, announcementId: string | undefined) {
  if (courseDetail === undefined) return undefined
  if (!courseDetail || !announcementId) return null
  const announcement = courseDetail.announcements.find((item) => item.id === announcementId)
  if (announcement) return new ResolvedAnnouncementDetail(courseDetail, announcement)
  return null
}
