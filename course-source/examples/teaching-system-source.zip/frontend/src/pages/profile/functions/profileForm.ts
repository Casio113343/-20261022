import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class ProfileFormState {
  constructor(
    public displayName: string,
    public currentPassword: string,
    public newPassword: string,
    public subject: string,
    public office: string,
    public grade: string,
    public major: string,
    public avatarDataUrl: string,
    public clearAvatar: boolean,
  ) {}
}

export function buildProfileFormState(user: PublicUser): ProfileFormState {
  return new ProfileFormState(
    user.displayName,
    '',
    '',
    user.teacherProfile?.subject ?? '',
    user.teacherProfile?.office ?? '',
    user.studentProfile?.grade ?? '',
    user.studentProfile?.major ?? '',
    user.avatarDataUrl ?? '',
    false,
  )
}

export function profileInitials(name: string) {
  return name.trim().slice(0, 1) || 'U'
}
