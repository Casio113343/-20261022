import { Link } from 'react-router-dom'
import { ChevronLeft, UserCog } from 'lucide-react'

import { Button } from '@/components/ui'
import { AppRoutePath } from '@/shared/routing/AppRoutes'

export function ProfileHeader() {
  return (
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 rounded-full bg-white/80 px-4 py-2 text-sm shadow-sm">
          <UserCog className="size-4" />
          个人中心
        </div>
        <h1 className="text-3xl font-semibold tracking-tight">维护账号资料与安全设置</h1>
      </div>
      <Button asChild variant="outline">
        <Link to={AppRoutePath.Dashboard}>
          <ChevronLeft className="size-4" />
          返回工作台
        </Link>
      </Button>
    </div>
  )
}
