import type { RefObject, ChangeEvent } from 'react'
import { Camera, LogOut, Trash2 } from 'lucide-react'

import { Avatar, AvatarFallback, AvatarImage, Badge, Button, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

import type { ProfileFormState } from '../functions/profileForm'
import { profileInitials } from '../functions/profileForm'

export function ProfileSummaryCard({
  currentUser,
  formState,
  isTeacher,
  fileInputRef,
  onAvatarChange,
  onClearAvatar,
  onOpenLogout,
  onOpenDelete,
}: {
  currentUser: PublicUser
  formState: ProfileFormState
  isTeacher: boolean
  fileInputRef: RefObject<HTMLInputElement | null>
  onAvatarChange: (event: ChangeEvent<HTMLInputElement>) => void
  onClearAvatar: () => void
  onOpenLogout: () => void
  onOpenDelete: () => void
}) {
  const avatarSrc = formState.avatarDataUrl || undefined

  return (
    <Card className="order-2 border-white/80 bg-white/88 lg:order-2">
      <CardHeader>
        <CardTitle>账号概览</CardTitle>
        <CardDescription>账号为纯数字，注册后不可修改。</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="flex flex-col items-center gap-4 rounded-[1.75rem] border border-slate-200 bg-slate-50/80 p-6">
          <Avatar className="size-28 border border-slate-200">
            <AvatarImage key={avatarSrc ?? 'empty'} src={avatarSrc} alt={currentUser.displayName} />
            <AvatarFallback className="text-3xl">{profileInitials(currentUser.displayName)}</AvatarFallback>
          </Avatar>
          <div className="space-y-1 text-center">
            <div className="text-xl font-semibold">{currentUser.displayName}</div>
          </div>
          <Button type="button" variant="outline" className="bg-white hover:bg-slate-50" onClick={() => fileInputRef.current?.click()}>
            <Camera className="size-4" />
            添加头像
          </Button>
          <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={onAvatarChange} />
          {formState.avatarDataUrl ? (
            <Button type="button" variant="ghost" onClick={onClearAvatar}>
              移除头像
            </Button>
          ) : null}
        </div>

        <div className="flex flex-wrap gap-2">
          <Badge variant="outline">{isTeacher ? '教师身份' : '学生身份'}</Badge>
          <Badge variant="outline" className="bg-white hover:bg-white">账号 {currentUser.username}</Badge>
        </div>

        <div className="space-y-3 rounded-[1.5rem] border border-slate-200 bg-slate-50/70 p-4">
          <div className="text-sm font-medium">安全操作</div>
          <Button type="button" variant="outline" className="w-full justify-start bg-white hover:bg-slate-50" onClick={onOpenLogout}>
            <LogOut className="size-4" />
            退出登录
          </Button>
          <Button type="button" variant="destructive" className="w-full justify-start" onClick={onOpenDelete}>
            <Trash2 className="size-4" />
            注销账号
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
