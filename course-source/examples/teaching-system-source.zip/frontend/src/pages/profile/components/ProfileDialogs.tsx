import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui'

export function ProfileDialogs({
  isLogoutOpen,
  isDeleteOpen,
  onLogoutOpenChange,
  onDeleteOpenChange,
  onLogout,
  onDelete,
}: {
  isLogoutOpen: boolean
  isDeleteOpen: boolean
  onLogoutOpenChange: (open: boolean) => void
  onDeleteOpenChange: (open: boolean) => void
  onLogout: () => void
  onDelete: () => void
}) {
  return (
    <>
      <AlertDialog open={isLogoutOpen} onOpenChange={onLogoutOpenChange}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认退出登录？</AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={onLogout}>确认退出</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={isDeleteOpen} onOpenChange={onDeleteOpenChange}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认注销账号？</AlertDialogTitle>
            <AlertDialogDescription>注销后会删除当前账号及其关联资料，此操作不可恢复。</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={onDelete} className="bg-rose-600 hover:bg-rose-700">
              确认注销
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
