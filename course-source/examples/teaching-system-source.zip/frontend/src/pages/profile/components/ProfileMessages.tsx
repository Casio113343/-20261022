import { Alert, AlertDescription } from '@/components/ui'

class ProfileMessagesProps {
  errorMessage = ''
  successMessage = ''
}

export function ProfileMessages({ errorMessage, successMessage }: ProfileMessagesProps) {
  return (
    <>
      {errorMessage ? (
        <Alert variant="destructive" className="mb-6 border-rose-200 bg-rose-50 text-rose-700">
          <AlertDescription className="text-rose-700">{errorMessage}</AlertDescription>
        </Alert>
      ) : null}

      {successMessage ? (
        <Alert className="mb-6 border-emerald-200 bg-emerald-50 text-emerald-700">
          <AlertDescription>{successMessage}</AlertDescription>
        </Alert>
      ) : null}
    </>
  )
}
