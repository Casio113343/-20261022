import type { FormEvent } from 'react'

import { Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Input, Label } from '@/components/ui'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

import type { ProfileFormState } from '../functions/profileForm'

export function ProfileEditForm({
  currentUser,
  formState,
  isTeacher,
  isBusy,
  onUpdateField,
  onSubmit,
}: {
  currentUser: PublicUser
  formState: ProfileFormState
  isTeacher: boolean
  isBusy: boolean
  onUpdateField: (key: keyof ProfileFormState, value: string) => void
  onSubmit: (event: FormEvent<HTMLFormElement>) => void
}) {
  return (
    <Card className="order-1 border-white/80 bg-white/88 lg:order-1">
      <CardHeader>
        <CardTitle>编辑资料</CardTitle>
        <CardDescription>姓名、密码和其他资料修改后会立即持久化到后端。</CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-5" onSubmit={onSubmit}>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="username">账号</Label>
              <Input id="username" value={currentUser.username} disabled />
            </div>
            <div className="space-y-2">
              <Label htmlFor="displayName">姓名</Label>
              <Input id="displayName" value={formState.displayName} onChange={(event) => onUpdateField('displayName', event.target.value)} />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="current-password">原密码</Label>
            <Input id="current-password" type="password" value={formState.currentPassword} onChange={(event) => onUpdateField('currentPassword', event.target.value)} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-password">新密码</Label>
            <Input id="new-password" type="password" value={formState.newPassword} onChange={(event) => onUpdateField('newPassword', event.target.value)} />
            <p className="text-xs text-slate-500">只改资料时可不填密码；改密码时必须先输入原密码。</p>
          </div>

          {isTeacher ? (
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="subject">学科</Label>
                <Input id="subject" value={formState.subject} onChange={(event) => onUpdateField('subject', event.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="office">办公地点</Label>
                <Input id="office" value={formState.office} onChange={(event) => onUpdateField('office', event.target.value)} />
              </div>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="grade">年级</Label>
                <Input id="grade" value={formState.grade} onChange={(event) => onUpdateField('grade', event.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="major">专业</Label>
                <Input id="major" value={formState.major} onChange={(event) => onUpdateField('major', event.target.value)} />
              </div>
            </div>
          )}
          <Button type="submit" size="lg" className="h-11 rounded-xl" disabled={isBusy}>
            {isBusy ? '保存中...' : '保存个人资料'}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
