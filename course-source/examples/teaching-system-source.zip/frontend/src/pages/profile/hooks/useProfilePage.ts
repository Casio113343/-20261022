import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { DeleteAccountAPIMessage } from '@/microservices/auth/api/DeleteAccountAPIMessage'
import { UpdateProfileAPIMessage } from '@/microservices/auth/api/UpdateProfileAPIMessage'
import { ProfileUpdate } from '@/microservices/auth/api/requests/ProfileUpdate'
import { UserRole } from '@/microservices/auth/objects/UserRole'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoutePath } from '@/shared/routing/AppRoutes'

import { useProfileDashboardSync } from './useProfileDashboardSync'
import { buildProfileFormState, ProfileFormState } from '../functions/profileForm'

export function useProfilePage() {
  const navigate = useNavigate()
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const { currentUser, setSession, clearSession } = useProfileDashboardSync(navigate)
  const [formState, setFormState] = useState<ProfileFormState | null>(currentUser ? buildProfileFormState(currentUser) : null)
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)
  const [isLogoutOpen, setIsLogoutOpen] = useState(false)
  const [isDeleteOpen, setIsDeleteOpen] = useState(false)

  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  useEffect(() => {
    if (currentUser) {
      setFormState(buildProfileFormState(currentUser))
    }
  }, [currentUser])

  const isTeacher = currentUser?.role === UserRole.Teacher
  const updateField = (key: keyof ProfileFormState, value: string) => {
    setFormState((current) => (current ? { ...current, [key]: value } : current))
  }
  const clearAvatar = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
    setFormState((current) => (current ? { ...current, avatarDataUrl: '', clearAvatar: true } : current))
  }
  const runAction = async (action: () => Promise<void>) => {
    setErrorMessage('')
    setSuccessMessage('')
    setIsBusy(true)
    try {
      await action()
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '请求失败')
    } finally {
      setIsBusy(false)
    }
  }
  const handleAvatarChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : ''
      setFormState((current) => (current ? { ...current, avatarDataUrl: result, clearAvatar: false } : current))
    }
    reader.readAsDataURL(file)
  }
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!currentUser || !formState) return
    if (formState.newPassword.trim() && !formState.currentPassword.trim()) {
      setErrorMessage('修改密码时必须先输入原密码。')
      return
    }
    if (formState.newPassword.trim() && formState.newPassword.trim().length < 6) {
      setErrorMessage('新密码至少 6 位。')
      return
    }
    await runAction(async () => {
      const nextDashboard = await sendAPI(new UpdateProfileAPIMessage(
        currentUser.id,
        new ProfileUpdate(
          formState.displayName.trim() !== currentUser.displayName ? formState.displayName.trim() : undefined,
          formState.currentPassword.trim() || undefined,
          formState.newPassword.trim() || undefined,
          !formState.clearAvatar && formState.avatarDataUrl.trim() !== (currentUser.avatarDataUrl ?? '') ? formState.avatarDataUrl.trim() || null : undefined,
          formState.clearAvatar,
          isTeacher
            ? {
                subject: formState.subject.trim() !== (currentUser.teacherProfile?.subject ?? '') ? formState.subject.trim() || null : undefined,
                office: formState.office.trim() !== (currentUser.teacherProfile?.office ?? '') ? formState.office.trim() || null : undefined,
              }
            : undefined,
          !isTeacher
            ? {
                grade: formState.grade.trim() !== (currentUser.studentProfile?.grade ?? '') ? formState.grade.trim() || null : undefined,
                major: formState.major.trim() !== (currentUser.studentProfile?.major ?? '') ? formState.major.trim() || null : undefined,
              }
            : undefined,
        ),
      )).run()
      setSession(nextDashboard)
      setFormState(buildProfileFormState(nextDashboard.currentUser))
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
      setSuccessMessage('个人资料已保存。')
    })
  }
  const logout = () => {
    clearSession()
    navigate(AppRoutePath.Login)
  }
  const deleteAccount = async () => {
    if (!currentUser) return
    await runAction(async () => {
      await sendAPI(new DeleteAccountAPIMessage(currentUser.id)).run()
      clearSession()
      navigate(AppRoutePath.Login)
    })
  }

  return {
    currentUser,
    formState,
    fileInputRef,
    errorMessage,
    successMessage,
    isBusy,
    isTeacher,
    isLogoutOpen,
    isDeleteOpen,
    updateField,
    clearAvatar,
    handleAvatarChange,
    submit,
    logout,
    deleteAccount,
    setIsLogoutOpen,
    setIsDeleteOpen,
  }
}
