import { useEffect, useEffectEvent } from 'react'
import type { NavigateFunction } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { FetchDashboardAPIMessage } from '@/microservices/dashboard/api/FetchDashboardAPIMessage'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'

export function useProfileDashboardSync(navigate: NavigateFunction) {
  const currentUser = useSessionStore((state) => state.currentUser)
  const dashboard = useSessionStore((state) => state.dashboard)
  const setSession = useSessionStore((state) => state.setSession)
  const clearSession = useSessionStore((state) => state.clearSession)

  useHydrateSession()

  const refreshDashboard = useEffectEvent(async (operatorUserId: string) => {
    try {
      const nextDashboard = await sendAPI(
        new FetchDashboardAPIMessage(operatorUserId),
      ).run()
      setSession(nextDashboard)
    } catch {
      clearSession()
      navigate(AppRoutePath.Login)
    }
  })

  useEffect(() => {
    if (!currentUser) return
    if (dashboard?.currentUser.id === currentUser.id) return
    void refreshDashboard(currentUser.id)
  }, [currentUser?.id, dashboard?.currentUser.id])

  return {
    currentUser,
    dashboard,
    setSession,
    clearSession,
  }
}
