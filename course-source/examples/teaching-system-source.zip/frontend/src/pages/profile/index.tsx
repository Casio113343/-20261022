import { Navigate } from 'react-router-dom'

import { AppRoutePath } from '@/shared/routing/AppRoutes'

import { ProfileDialogs } from './components/ProfileDialogs'
import { ProfileEditForm } from './components/ProfileEditForm'
import { ProfileHeader } from './components/ProfileHeader'
import { ProfileMessages } from './components/ProfileMessages'
import { ProfileSummaryCard } from './components/ProfileSummaryCard'
import { useProfilePage } from './hooks/useProfilePage'

export default function ProfilePage() {
  const page = useProfilePage()

  if (!page.currentUser || !page.formState) {
    return <Navigate replace to={AppRoutePath.Login} />
  }

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#f6f0e6_0%,#edf5ff_100%)] text-slate-900">
      <div className="mx-auto max-w-5xl px-6 py-8 lg:px-8">
        <ProfileHeader />
        <ProfileMessages errorMessage={page.errorMessage} successMessage={page.successMessage} />

        <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <ProfileSummaryCard
            currentUser={page.currentUser}
            formState={page.formState}
            isTeacher={page.isTeacher}
            fileInputRef={page.fileInputRef}
            onAvatarChange={page.handleAvatarChange}
            onClearAvatar={page.clearAvatar}
            onOpenLogout={() => page.setIsLogoutOpen(true)}
            onOpenDelete={() => page.setIsDeleteOpen(true)}
          />
          <ProfileEditForm
            currentUser={page.currentUser}
            formState={page.formState}
            isTeacher={page.isTeacher}
            isBusy={page.isBusy}
            onUpdateField={page.updateField}
            onSubmit={page.submit}
          />
        </div>

        <ProfileDialogs
          isLogoutOpen={page.isLogoutOpen}
          isDeleteOpen={page.isDeleteOpen}
          onLogoutOpenChange={page.setIsLogoutOpen}
          onDeleteOpenChange={page.setIsDeleteOpen}
          onLogout={page.logout}
          onDelete={() => void page.deleteAccount()}
        />
      </div>
    </main>
  )
}
