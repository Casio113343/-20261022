export const ReviewBoardTab = {
  Content: 'content',
  Unsubmitted: 'unsubmitted',
  Pending: 'pending',
  Graded: 'graded',
} as const

export const ReviewBoardSource = {
  Pending: 'pending',
  Graded: 'graded',
} as const
