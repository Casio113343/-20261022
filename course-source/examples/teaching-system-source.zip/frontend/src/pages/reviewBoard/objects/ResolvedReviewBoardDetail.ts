import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import type { SubmissionReview } from '@/microservices/assignment/objects/SubmissionReview'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class ReviewBoardSubmissionEntry {
  constructor(
    public submission: AssignmentSubmission,
    public student: PublicUser,
    public review: SubmissionReview | null,
  ) {}
}

export class ResolvedReviewBoardDetail {
  constructor(
    public course: CourseDetailResponse,
    public assignment: Assignment,
    public pending: ReviewBoardSubmissionEntry[],
    public graded: ReviewBoardSubmissionEntry[],
    public unsubmitted: PublicUser[],
    public classAverageScore: string | null,
  ) {}
}
