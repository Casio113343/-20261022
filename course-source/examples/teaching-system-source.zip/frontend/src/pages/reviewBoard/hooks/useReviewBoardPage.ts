import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { DeleteAssignmentAPIMessage } from '@/microservices/assignment/api/DeleteAssignmentAPIMessage'
import { FetchAssignmentCourseDetailAPIMessage } from '@/microservices/assignment/api/FetchAssignmentCourseDetailAPIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { AppRoute } from '@/shared/routing/AppRoutes'
import { syncCourseDetailMutation } from '@/stores/session/functions/courseDetailSession'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { ReviewBoardTab } from '../objects/AssignmentReviewWorkflow'
import { resolveReviewBoardDetail } from '../functions/reviewBoard'

export function useReviewBoardPage() {
  const { assignmentId } = useParams<{ assignmentId: string }>()
  const [searchParams] = useSearchParams()
  const defaultTab = searchParams.get('tab') ?? ReviewBoardTab.Content
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser, dashboard, setSession } = useEnsureDashboard(navigate)
  const [isDeleteOpen, setIsDeleteOpen] = useState(false)
  const [courseDetail, setCourseDetail] = useState<CourseDetailResponse | null | undefined>(undefined)

  useEffect(() => {
    if (!currentUser || !assignmentId) return
    void sendAPI(new FetchAssignmentCourseDetailAPIMessage(assignmentId, currentUser.id)).run()
      .then(setCourseDetail)
      .catch(() => setCourseDetail(null))
  }, [assignmentId, currentUser?.id])

  const detail = useMemo(() => {
    if (courseDetail === undefined) return undefined
    return resolveReviewBoardDetail(courseDetail, assignmentId)
  }, [assignmentId, courseDetail])

  const deleteAssignment = async () => {
    if (!detail || !currentUser) return
    const nextCourse = await sendAPI(new DeleteAssignmentAPIMessage(detail.course.course.id, detail.assignment.id, currentUser.id)).run()
    syncCourseDetailMutation(dashboard, nextCourse, setSession, setCourseDetail)
    navigate(AppRoute.CourseWorkspace(nextCourse.course.id))
  }

  return {
    assignmentId,
    currentUser,
    defaultTab,
    detail,
    isDeleteOpen,
    deleteAssignment,
    editAssignment: () => {
      if (detail) navigate(AppRoute.AssignmentEdit(detail.course.course.id, detail.assignment.id))
    },
    navigate,
    setIsDeleteOpen,
  }
}
