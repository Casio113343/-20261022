import { Navigate } from 'react-router-dom'

import { Button, Card, CardContent } from '@/components/ui'
import { ConfirmDialog } from '@/components/ui/confirmDialog'
import { AppRoutePath } from '@/shared/routing/AppRoutes'

import { ReviewBoardHeader } from './components/ReviewBoardHeader'
import { ReviewBoardTabs } from './components/ReviewBoardTabs'
import { useReviewBoardPage } from './hooks/useReviewBoardPage'

export default function ReviewBoardPage() {
  const page = useReviewBoardPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.assignmentId) return <Navigate replace to={AppRoutePath.Dashboard} />
  if (page.detail === null) return <Navigate replace to={AppRoutePath.Dashboard} />

  if (page.detail === undefined) {
    return (
      <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
        <div className="mx-auto max-w-5xl px-5 py-8 lg:px-8">
          <ReviewBoardHeader page={page} />
          <Card className="border-slate-200 bg-white">
            <CardContent className="p-8 text-sm text-slate-500">正在加载批改列表。</CardContent>
          </Card>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-5xl px-5 py-8 lg:px-8">
        <ReviewBoardHeader page={page} />
        <ReviewBoardTabs assignment={page.detail.assignment} pending={page.detail.pending} graded={page.detail.graded} unsubmitted={page.detail.unsubmitted} classAverageScore={page.detail.classAverageScore} defaultTab={page.defaultTab} navigate={page.navigate} />
        <div className="mt-6 flex justify-end gap-2">
          <Button type="button" onClick={page.editAssignment}>编辑作业</Button>
          <Button type="button" variant="destructive" onClick={() => page.setIsDeleteOpen(true)}>删除作业</Button>
        </div>
        <ConfirmDialog
          open={page.isDeleteOpen}
          title="确认删除作业？"
          description="删除后，这份作业、所有提交和批改记录都会被永久移除。"
          confirmLabel="确认删除"
          onOpenChange={page.setIsDeleteOpen}
          onConfirm={() => void page.deleteAssignment()}
        />
      </div>
    </main>
  )
}
