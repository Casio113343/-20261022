import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

import { ResolvedReviewBoardDetail, ReviewBoardSubmissionEntry } from '../objects/ResolvedReviewBoardDetail'

export function formatReviewBoardDateTime(value: string) {
  return new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
}

export function resolveReviewBoardDetail(course: CourseDetailResponse | null, assignmentId: string | undefined) {
  if (!course || !assignmentId) return null
  const assignment = course.assignments.find((item) => item.id === assignmentId)
  if (!assignment) return null
  const submissionEntries = course.submissions
    .filter((item) => item.assignmentId === assignmentId)
    .map((submission) => {
      const student = course.course.students.find((item) => item.id === submission.studentId)
      if (!student) return null
      return new ReviewBoardSubmissionEntry(
        submission,
        student,
        course.reviews.find((review) => review.submissionId === submission.id) ?? null,
      )
    })
    .filter((item): item is ReviewBoardSubmissionEntry => item !== null)
  const pending = submissionEntries.filter((item) => !item.review)
  const graded = submissionEntries.filter((item) => item.review)
  const gradedScores = graded.flatMap((item) => item.review?.score ?? [])
  const classAverageScore = gradedScores.length ? (gradedScores.reduce((sum, score) => sum + score, 0) / gradedScores.length).toFixed(1) : null
  const unsubmitted = course.course.students
    .filter((student) => wasCourseMemberAt(course, student.id, assignment.createdAt))
    .filter((student) => !submissionEntries.some((item) => item.student.id === student.id))
  return new ResolvedReviewBoardDetail(course, assignment, pending, graded, unsubmitted, classAverageScore)
}

export function wasCourseMemberAt(course: CourseDetailResponse, userId: string, at: string) {
  const timestamp = new Date(at).getTime()
  const events = course.memberHistory
    .filter((event) => event.user.id === userId)
    .sort((left, right) => new Date(left.occurredAt).getTime() - new Date(right.occurredAt).getTime())
  let joined = false
  for (const event of events) {
    if (new Date(event.occurredAt).getTime() > timestamp) break
    joined = event.action === 'joined'
  }
  return joined
}
