import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui'

type ReviewBoardCardProps = {
  title: string
  children: React.ReactNode
}

export function ReviewBoardCard({ title, children }: ReviewBoardCardProps) {
  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">{children}</CardContent>
    </Card>
  )
}

export function EmptyTip({ message }: { message: string }) {
  return <div className="rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">{message}</div>
}
