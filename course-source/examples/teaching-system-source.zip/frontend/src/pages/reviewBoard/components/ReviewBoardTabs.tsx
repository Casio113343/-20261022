import type { NavigateFunction } from 'react-router-dom'

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui'
import { ReviewBoardSource, ReviewBoardTab } from '@/pages/reviewBoard/objects/AssignmentReviewWorkflow'
import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import type { SubmissionReview } from '@/microservices/assignment/objects/SubmissionReview'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import { AppRoute } from '@/shared/routing/AppRoutes'

import { EmptyTip, ReviewBoardCard } from './ReviewBoardCard'
import { formatReviewBoardDateTime } from '../functions/reviewBoard'

export function ReviewBoardTabs({
  assignment,
  pending,
  graded,
  unsubmitted,
  classAverageScore,
  defaultTab,
  navigate,
}: {
  assignment: Assignment
  pending: Array<{ submission: AssignmentSubmission; student: PublicUser; review: SubmissionReview | null }>
  graded: Array<{ submission: AssignmentSubmission; student: PublicUser; review: SubmissionReview | null }>
  unsubmitted: PublicUser[]
  classAverageScore: string | null
  defaultTab: string
  navigate: NavigateFunction
}) {
  return (
    <Tabs defaultValue={defaultTab} className="space-y-4">
      <TabsList className="h-auto flex-wrap rounded-2xl bg-slate-100 p-1">
        <TabsTrigger value={ReviewBoardTab.Content}>作业内容</TabsTrigger>
        <TabsTrigger value={ReviewBoardTab.Unsubmitted}>未交名单 <span className="ml-1">{unsubmitted.length}</span></TabsTrigger>
        <TabsTrigger value={ReviewBoardTab.Pending}>未批改 <span className="ml-1">{pending.length}</span></TabsTrigger>
        <TabsTrigger value={ReviewBoardTab.Graded}>已批改 <span className="ml-1">{graded.length}</span></TabsTrigger>
      </TabsList>

      <TabsContent value={ReviewBoardTab.Content}>
        <ReviewBoardCard title="作业内容">
          <div className="space-y-4">
            {assignment.content.trim() ? <div className="text-sm leading-8 text-slate-700">{assignment.content}</div> : null}
            <div className="text-sm text-slate-500">
              截止 {formatReviewBoardDateTime(assignment.dueAt)}（{assignment.allowLateSubmission ? '允许补交' : '不允许补交'}）
              {assignment.maxScore !== null && assignment.maxScore !== undefined ? ` / 满分 ${assignment.maxScore}` : ''}
            </div>
            {assignment.attachment ? <a className="text-sm text-sky-700 underline underline-offset-4 hover:text-sky-800" href={assignment.attachment.dataUrl} download={assignment.attachment.fileName}>下载作业附件：{assignment.attachment.fileName}</a> : null}
          </div>
        </ReviewBoardCard>
      </TabsContent>

      <TabsContent value={ReviewBoardTab.Unsubmitted}>
        <ReviewBoardCard title="未交名单">
          {unsubmitted.length ? <div className="text-sm leading-8 text-slate-700">{unsubmitted.map((student) => student.displayName).join('、')}</div> : <EmptyTip message="当前没有未交学生。" />}
        </ReviewBoardCard>
      </TabsContent>

      <TabsContent value={ReviewBoardTab.Pending}>
        <ReviewBoardCard title="未批改">
          {pending.length ? (
            <div className="flex flex-wrap gap-3">
              {pending.map(({ submission, student }) => (
                <button
                  key={submission.id}
                  type="button"
                  className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-left transition hover:bg-slate-50"
                  onClick={() => navigate(AppRoute.ReviewDetail(assignment.id, submission.id, ReviewBoardSource.Pending))}
                >
                  <div className="text-sm font-medium text-slate-800">{student.displayName}</div>
                </button>
              ))}
            </div>
          ) : <EmptyTip message="当前没有待批提交。" />}
        </ReviewBoardCard>
      </TabsContent>

      <TabsContent value={ReviewBoardTab.Graded}>
        <ReviewBoardCard title="已批改">
          {assignment.maxScore !== null && assignment.maxScore !== undefined && classAverageScore !== null ? (
            <div className="mb-4 text-sm text-slate-500">班级平均分：{classAverageScore}</div>
          ) : null}
          {graded.length ? (
            <div className="flex flex-wrap gap-3">
              {graded.map(({ submission, student, review }) => (
                <button
                  key={submission.id}
                  type="button"
                  className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-left transition hover:bg-slate-50"
                  onClick={() => navigate(AppRoute.ReviewDetail(assignment.id, submission.id, ReviewBoardSource.Graded))}
                >
                  {review?.score !== null && review?.score !== undefined ? (
                    <div className="flex items-center justify-between gap-3 text-sm">
                      <span className="font-medium text-slate-800">{student.displayName}</span>
                      <span className="text-slate-500">{review.score} 分</span>
                    </div>
                  ) : (
                    <div className="text-sm font-medium text-slate-800">{student.displayName}</div>
                  )}
                </button>
              ))}
            </div>
          ) : <EmptyTip message="当前没有已批提交。" />}
        </ReviewBoardCard>
      </TabsContent>
    </Tabs>
  )
}
