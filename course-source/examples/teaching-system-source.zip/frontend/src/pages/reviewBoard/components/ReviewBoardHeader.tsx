import { Link } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Button } from '@/components/ui'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { formatReviewBoardDateTime } from '../functions/reviewBoard'
import type { useReviewBoardPage } from '../hooks/useReviewBoardPage'

class ReviewBoardHeaderProps {
  page!: ReturnType<typeof useReviewBoardPage>
}

export function ReviewBoardHeader({ page }: ReviewBoardHeaderProps) {
  const detail = page.detail
  return (
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <div>
        <div className="mb-2 text-sm text-slate-500">{detail ? detail.course.course.title : '正在加载课程信息'}</div>
        <h1 className="text-3xl font-semibold tracking-tight">{detail ? detail.assignment.title : '加载中'}</h1>
        {detail ? (
          <div className="mt-2 text-sm text-slate-500">
            截止 {formatReviewBoardDateTime(detail.assignment.dueAt)}
            {detail.assignment.maxScore !== null && detail.assignment.maxScore !== undefined ? ` / 满分 ${detail.assignment.maxScore}` : ''}
          </div>
        ) : null}
      </div>
      <Button asChild variant="outline">
        <Link to={detail ? AppRoute.CourseWorkspace(detail.course.course.id) : AppRoutePath.Dashboard}>
          <ChevronLeft className="size-4" />
          返回课程工作区
        </Link>
      </Button>
    </div>
  )
}
