import { useEffect, useEffectEvent, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import type { Attachment } from '@/infrastructure/storage/Attachment'
import { uploadAttachments } from '@/infrastructure/storage/uploadAsset'
import { ExamDetailAPIMessage } from '@/microservices/exam/api/ExamDetailAPIMessage'
import { UploadExamAnswerImagesAPIMessage } from '@/microservices/exam/api/UploadExamAnswerImagesAPIMessage'
import { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { syncExamDetailMutation } from '@/stores/session/functions/examSession'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'
import { resolveQuestionSheets } from '../functions/examImport'

export function useExamImportPage() {
  const { examId } = useParams<{ examId: string }>()
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const dashboard = useSessionStore((state) => state.dashboard)
  const setSession = useSessionStore((state) => state.setSession)
  const [detail, setDetail] = useState<ExamDetailResponse | null>(null)
  const [selectedQuestionId, setSelectedQuestionId] = useState('')
  const [selectedStudentId, setSelectedStudentId] = useState('')
  const [images, setImages] = useState<Attachment[]>([])
  const [formError, setFormError] = useState('')
  const [isBusy, setIsBusy] = useState(false)
  const [isUploadingImages, setIsUploadingImages] = useState(false)

  useHydrateSession()

  const loadDetail = useEffectEvent(async (nextExamId: string, operatorUserId: string) => {
    try {
      const response = await sendAPI(new ExamDetailAPIMessage(nextExamId, operatorUserId)).run()
      setDetail(response)
      setSelectedQuestionId(response.questions[0]?.id ?? '')
      setSelectedStudentId(response.participantStudents[0]?.id ?? '')
    } catch {
      navigate(AppRoutePath.Dashboard)
    }
  })

  useEffect(() => {
    if (!currentUser || !examId) return
    void loadDetail(examId, currentUser.id)
  }, [currentUser?.id, examId])

  useEffect(() => {
    setFormError('')
  }, [selectedQuestionId, selectedStudentId])

  const selectedQuestion = detail?.questions.find((question: ExamDetailResponse['questions'][number]) => question.id === selectedQuestionId) ?? null
  const questionSheets = useMemo(() => resolveQuestionSheets(detail, selectedQuestionId), [detail, selectedQuestionId])

  const handleUpload = async () => {
    if (!detail || !selectedQuestion || !selectedStudentId || !images.length || !currentUser) {
      setFormError('请选择题目、学生并上传答题图片。')
      return
    }
    setIsBusy(true)
    setFormError('')
    try {
      const nextDetail = await sendAPI(new UploadExamAnswerImagesAPIMessage(detail.exam.id, selectedQuestion.id, currentUser.id, {
        studentId: selectedStudentId,
        images,
      })).run()
      setDetail(nextDetail)
      setImages([])
      syncExamDetailMutation(dashboard, nextDetail, setSession)
    } catch (error) {
      setFormError(error instanceof Error ? error.message : '导入失败')
    } finally {
      setIsBusy(false)
    }
  }

  const handleImagesSelect = async (files: FileList | null) => {
    if (!currentUser) return
    if (!files?.length) {
      setImages([])
      return
    }
    setFormError('')
    setIsUploadingImages(true)
    try {
      setImages(await uploadAttachments(currentUser.id, Array.from(files)))
    } catch (error) {
      setFormError(error instanceof Error ? error.message : '图片上传失败')
      setImages([])
    } finally {
      setIsUploadingImages(false)
    }
  }

  return {
    currentUser,
    detail,
    examId,
    formError,
    images,
    isBusy,
    isUploadingImages,
    questionSheets,
    selectedQuestion,
    selectedQuestionId,
    selectedStudentId,
    handleImagesSelect,
    handleUpload,
    setImages,
    setSelectedQuestionId,
    setSelectedStudentId,
  }
}
