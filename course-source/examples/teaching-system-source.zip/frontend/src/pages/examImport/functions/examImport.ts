import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

export function formatQuestionLabel(position: number, title?: string | null) {
  return title && title.trim() ? `第 ${position} 题 · ${title}` : `第 ${position} 题`
}

export function resolveQuestionSheets(detail: ExamDetailResponse | null, selectedQuestionId: string) {
  return detail?.answerSheets.filter((sheet) => sheet.questionId === selectedQuestionId) ?? []
}
