import { Link, Navigate } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Button, Card, CardContent } from '@/components/ui'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'

import { ExamImportForm } from './components/ExamImportForm'
import { ImportedSheetsPanel } from './components/ImportedSheetsPanel'
import { useExamImportPage } from './hooks/useExamImportPage'

export default function ExamImportPage() {
  const page = useExamImportPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.examId) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-6xl px-5 py-8 lg:px-8">
        <Button asChild variant="outline" className="mb-6">
          <Link to={AppRoute.ExamDetail(page.examId)}>
            <ChevronLeft className="size-4" />
            返回考试页
          </Link>
        </Button>
        {!page.detail ? (
          <Card className="border-slate-200 bg-white">
            <CardContent className="p-8 text-sm text-slate-500">正在加载导入页面。</CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 xl:grid-cols-[0.96fr_1.04fr]">
            <ExamImportForm
              detail={page.detail}
              selectedQuestionId={page.selectedQuestionId}
              selectedStudentId={page.selectedStudentId}
              images={page.images}
              formError={page.formError}
              formSuccess=""
              isBusy={page.isBusy || page.isUploadingImages}
              onQuestionChange={page.setSelectedQuestionId}
              onStudentChange={page.setSelectedStudentId}
              onImagesChange={page.setImages}
              onImagesSelect={(files) => void page.handleImagesSelect(files)}
              onSubmit={() => void page.handleUpload()}
            />
            <ImportedSheetsPanel selectedQuestion={page.selectedQuestion} questionSheets={page.questionSheets} />
          </div>
        )}
      </div>
    </main>
  )
}
