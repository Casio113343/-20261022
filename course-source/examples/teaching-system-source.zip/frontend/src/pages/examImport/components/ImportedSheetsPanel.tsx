import { FileUp } from 'lucide-react'

import { Badge, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'
import type { ExamAnswerSheet } from '@/microservices/exam/api/responses/ExamAnswerSheet'
import type { ExamQuestion } from '@/microservices/exam/api/responses/ExamQuestion'
import { resolveAssetUrl } from '@/infrastructure/storage/assetUrl'

import { formatQuestionLabel } from '../functions/examImport'

class ImportedSheetsPanelProps {
  selectedQuestion!: ExamQuestion | null
  questionSheets!: ExamAnswerSheet[]
}

export function ImportedSheetsPanel({ selectedQuestion, questionSheets }: ImportedSheetsPanelProps) {
  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <CardTitle className="text-lg">当前题目已导入情况</CardTitle>
        <CardDescription>{selectedQuestion ? formatQuestionLabel(selectedQuestion.position, selectedQuestion.title) : '请先选择题目'}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {questionSheets.length ? questionSheets.map((sheet) => (
          <div key={sheet.id} className="flex flex-wrap items-center gap-4 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5">
            <div className="min-w-24 font-medium">{sheet.student.displayName}</div>
            <div className="flex flex-wrap gap-3">
              {sheet.images.map((image) => (
                <a key={`${sheet.id}-${image.fileName}`} className="inline-flex items-center gap-1 text-sm text-sky-700 underline underline-offset-4 hover:text-sky-800" href={resolveAssetUrl(image.dataUrl)} download={image.fileName}>
                  <FileUp className="size-4" />
                  {image.fileName}
                </a>
              ))}
            </div>
            <Badge className="ml-auto" variant="secondary">{sheet.images.length} 张</Badge>
          </div>
        )) : <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-sm text-slate-500">当前题目还没有导入任何答题图片。</div>}
      </CardContent>
    </Card>
  )
}
