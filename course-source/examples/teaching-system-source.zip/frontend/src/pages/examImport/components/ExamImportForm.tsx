import { Alert, AlertDescription, Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Label, Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui'
import { FilePicker } from '@/shared/forms/FormHelpers'
import type { Attachment } from '@/infrastructure/storage/Attachment'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

import { formatQuestionLabel } from '../functions/examImport'

class ExamImportFormProps {
  detail!: ExamDetailResponse
  selectedQuestionId!: string
  selectedStudentId!: string
  images!: Attachment[]
  formError!: string
  formSuccess!: string
  isBusy!: boolean
  onQuestionChange!: (value: string) => void
  onStudentChange!: (value: string) => void
  onImagesChange!: (attachments: Attachment[]) => void
  onImagesSelect!: (files: FileList | null) => void
  onSubmit!: () => void
}

export function ExamImportForm({
  detail,
  selectedQuestionId,
  selectedStudentId,
  images,
  formError,
  formSuccess,
  isBusy,
  onQuestionChange,
  onStudentChange,
  onImagesChange,
  onImagesSelect,
  onSubmit,
}: ExamImportFormProps) {
  const selectedQuestion = detail.questions.find((question) => question.id === selectedQuestionId) ?? null

  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <CardTitle className="text-lg">导入答题图片</CardTitle>
        <CardDescription>按“题目 + 学生”手动导入扫描图片。</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>选择题目</Label>
          <Select value={selectedQuestionId} onValueChange={onQuestionChange}>
            <SelectTrigger className="bg-white"><SelectValue placeholder="请选择题目" /></SelectTrigger>
            <SelectContent>{detail.questions.map((question) => <SelectItem key={question.id} value={question.id}>{formatQuestionLabel(question.position, question.title)}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>选择学生</Label>
          <Select value={selectedStudentId} onValueChange={onStudentChange}>
            <SelectTrigger className="bg-white"><SelectValue placeholder="请选择学生" /></SelectTrigger>
            <SelectContent>{detail.participantStudents.map((student) => <SelectItem key={student.id} value={student.id}>{student.displayName}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-2 mt-10">
          <Label>答题图片</Label>
          <FilePicker accept="image/*" multiple onChange={(event) => onImagesSelect(event.target.files)} />
          {images.length ? (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-600">
              <div>已选择 {images.length} 张图片：{images.map((image) => image.fileName).join('、')}</div>
              <Button type="button" variant="ghost" size="sm" onClick={() => onImagesChange([])}>清空图片</Button>
            </div>
          ) : null}
        </div>
        {selectedQuestion ? <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-600">满分 {selectedQuestion.scoring.fullScore} 分，批改教师：{selectedQuestion.scoring.graders.map((teacher) => teacher.displayName).join('、')}</div> : null}
        <Button disabled={isBusy || detail.exam.publishedAt !== null} onClick={onSubmit}>保存答题图片</Button>
        {formError ? <Alert variant="destructive" className="border-rose-200 bg-rose-50 text-rose-700"><AlertDescription className="text-rose-700">{formError}</AlertDescription></Alert> : null}
        {formSuccess ? <Alert className="border-emerald-200 bg-emerald-50 text-emerald-700"><AlertDescription>{formSuccess}</AlertDescription></Alert> : null}
      </CardContent>
    </Card>
  )
}
