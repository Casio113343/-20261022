import { Link } from 'react-router-dom'

import { Alert, AlertDescription, Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Input, Label, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui'
import { UserRole } from '@/microservices/auth/objects/UserRole'

import type { RegisterFormState } from '../functions/registerForm'

type RegisterFormCardProps = {
  role: string
  formState: RegisterFormState
  errorMessage: string
  isSubmitting: boolean
  onRoleChange: (value: string) => void
  onFieldChange: (key: keyof RegisterFormState, value: string) => void
  onSubmit: React.FormEventHandler<HTMLFormElement>
}

export function RegisterFormCard({
  role,
  formState,
  errorMessage,
  isSubmitting,
  onRoleChange,
  onFieldChange,
  onSubmit,
}: RegisterFormCardProps) {
  return (
    <Card className="border-white/70 bg-white/88 shadow-[0_24px_80px_rgba(15,23,42,0.12)] backdrop-blur">
      <CardHeader className="space-y-3">
        <CardTitle className="text-2xl">创建教学账号</CardTitle>
        <CardDescription>先选择身份，再填写对应信息。</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={role} onValueChange={onRoleChange} className="space-y-5">
          <TabsList className="grid h-auto grid-cols-2 rounded-2xl bg-slate-100 p-1">
            <TabsTrigger value={UserRole.Teacher}>教师端</TabsTrigger>
            <TabsTrigger value={UserRole.Student}>学生端</TabsTrigger>
          </TabsList>

          <form className="space-y-5" onSubmit={onSubmit}>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="display-name">姓名</Label>
                <Input id="display-name" value={formState.displayName} onChange={(event) => onFieldChange('displayName', event.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">账号</Label>
                <Input id="username" inputMode="numeric" value={formState.username} onChange={(event) => onFieldChange('username', event.target.value)} />
                <p className="text-xs text-slate-500">仅支持数字，注册完成后不可修改。</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">密码</Label>
                <Input id="password" type="password" value={formState.password} onChange={(event) => onFieldChange('password', event.target.value)} />
              </div>
            </div>

            <TabsContent value={UserRole.Teacher} className="mt-0 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="subject">学科</Label>
                <Input id="subject" placeholder="选填" value={formState.subject} onChange={(event) => onFieldChange('subject', event.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="office">办公地点</Label>
                <Input id="office" placeholder="选填" value={formState.office} onChange={(event) => onFieldChange('office', event.target.value)} />
              </div>
            </TabsContent>

            <TabsContent value={UserRole.Student} className="mt-0 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="grade">年级</Label>
                <Input id="grade" placeholder="选填" value={formState.grade} onChange={(event) => onFieldChange('grade', event.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="major">专业</Label>
                <Input id="major" placeholder="选填" value={formState.major} onChange={(event) => onFieldChange('major', event.target.value)} />
              </div>
            </TabsContent>

            {errorMessage ? (
              <Alert variant="destructive" className="border-rose-200 bg-rose-50 text-rose-700">
                <AlertDescription className="text-rose-700">{errorMessage}</AlertDescription>
              </Alert>
            ) : null}

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <Button type="submit" size="lg" className="h-11 rounded-xl" disabled={isSubmitting}>
                {isSubmitting ? '注册中...' : role === UserRole.Teacher ? '注册教师账号' : '注册学生账号'}
              </Button>
              <Link className="text-sm text-slate-600 underline-offset-4 hover:underline" to="/login">
                已有账号，去登录
              </Link>
            </div>
          </form>
        </Tabs>
      </CardContent>
    </Card>
  )
}
