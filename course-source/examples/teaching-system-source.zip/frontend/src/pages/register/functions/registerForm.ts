import { UserRole } from '@/microservices/auth/objects/UserRole'
import { RegisterInput } from '@/microservices/auth/api/requests/RegisterInput'

export type RegisterFormState = {
  displayName: string
  username: string
  password: string
  subject: string
  office: string
  grade: string
  major: string
}

export const initialRegisterFormState: RegisterFormState = {
  displayName: '',
  username: '',
  password: '',
  subject: '',
  office: '',
  grade: '',
  major: '',
}

export function buildRegisterPayload(role: string, formState: RegisterFormState): RegisterInput {
  return new RegisterInput(
    formState.username.trim(),
    formState.password.trim(),
    formState.displayName.trim(),
    role,
    role === UserRole.Teacher
      ? {
          subject: formState.subject.trim(),
          office: formState.office.trim() || undefined,
        }
      : undefined,
    role === UserRole.Student
      ? {
          grade: formState.grade.trim(),
          major: formState.major.trim(),
        }
      : undefined,
  )
}

export function validateRegisterPayload(payload: RegisterInput): string | null {
  if (!payload.displayName || !payload.username || !payload.password) {
    return '请完整填写姓名、账号和密码。'
  }

  if (!/^\d+$/.test(payload.username)) {
    return '账号必须为纯数字，且注册后不可修改。'
  }

  return null
}
