import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { RegisterAPIMessage } from '@/microservices/auth/api/RegisterAPIMessage'
import { UserRole } from '@/microservices/auth/objects/UserRole'
import { FetchDashboardAPIMessage } from '@/microservices/dashboard/api/FetchDashboardAPIMessage'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { useSessionStore } from '@/stores/session/useSessionStore'
import { buildRegisterPayload, initialRegisterFormState, validateRegisterPayload, type RegisterFormState } from '../functions/registerForm'

export function useRegisterPage() {
  const navigate = useNavigate()
  const setSession = useSessionStore((state) => state.setSession)
  const [role, setRole] = useState<string>(UserRole.Teacher)
  const [formState, setFormState] = useState<RegisterFormState>(initialRegisterFormState)
  const [errorMessage, setErrorMessage] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  useAutoDismissMessage(errorMessage, setErrorMessage)

  const updateField = (key: keyof RegisterFormState, value: string) => {
    setFormState((current) => ({ ...current, [key]: value }))
  }

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setErrorMessage('')

    const payload = buildRegisterPayload(role, formState)
    const validationError = validateRegisterPayload(payload)
    if (validationError) {
      setErrorMessage(validationError)
      return
    }

    setIsSubmitting(true)

    try {
      const registered = await sendAPI(new RegisterAPIMessage(payload)).run()
      const dashboard = await sendAPI(new FetchDashboardAPIMessage(registered.user.id)).run()
      setSession(dashboard)
      navigate(AppRoutePath.Dashboard)
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '注册失败')
    } finally {
      setIsSubmitting(false)
    }
  }

  return {
    errorMessage,
    formState,
    isSubmitting,
    role,
    handleSubmit,
    setRole,
    updateField,
  }
}
