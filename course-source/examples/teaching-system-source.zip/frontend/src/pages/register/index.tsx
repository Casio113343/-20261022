import { RegisterFormCard } from './components/RegisterFormCard'
import { useRegisterPage } from './hooks/useRegisterPage'

export default function RegisterPage() {
  const page = useRegisterPage()

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,rgba(103,232,249,0.56)_0%,transparent_32%),radial-gradient(circle_at_20%_80%,rgba(45,212,191,0.32),transparent_28%),linear-gradient(180deg,#ecfeff_0%,#f0fdfa_48%,#eef6ff_100%)] text-slate-900">
      <div className="mx-auto flex min-h-screen max-w-3xl flex-col items-center px-6 py-12 lg:px-10">
        <h1 className="mt-8 -translate-x-[0.15em] text-center text-4xl font-semibold tracking-tight lg:text-5xl">线上教学平台</h1>

        <div className="mt-14 w-full max-w-lg">
          <RegisterFormCard
            role={page.role}
            formState={page.formState}
            errorMessage={page.errorMessage}
            isSubmitting={page.isSubmitting}
            onRoleChange={page.setRole}
            onFieldChange={page.updateField}
            onSubmit={page.handleSubmit}
          />
        </div>
      </div>
    </main>
  )
}
