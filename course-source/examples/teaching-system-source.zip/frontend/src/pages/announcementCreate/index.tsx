import { Navigate } from 'react-router-dom'

import { CourseFormShell } from '@/shared/forms/FormHelpers'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { AppRoute } from '@/shared/routing/AppRoutes'

import { AnnouncementForm } from './components/AnnouncementForm'
import { AnnouncementFormState } from './functions/announcementForm'
import { useAnnouncementCreatePage } from './hooks/useAnnouncementCreatePage'

export default function AnnouncementCreatePage() {
  const page = useAnnouncementCreatePage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (page.course === null) return <Navigate replace to={AppRoutePath.Dashboard} />
  if (page.announcementId && page.course && !page.announcement) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <CourseFormShell title={page.announcementId ? '编辑通知' : '发布通知'} description={page.course ? `课程：${page.course.course.title}` : '正在加载课程信息。'} backTo={page.courseId ? AppRoute.CourseWorkspace(page.courseId) : AppRoutePath.Dashboard} backLabel="返回课程工作区">
      <AnnouncementForm
        formState={page.formState}
        isBusy={page.isBusy}
        errorMessage={page.errorMessage}
        successMessage={page.successMessage}
        submitLabel={page.isUploadingAttachment ? '上传附件中...' : page.announcementId ? '保存通知' : '发布通知'}
        onTitleChange={(title) => page.setFormState((current) => new AnnouncementFormState(title, current.content, current.attachment))}
        onContentChange={(content) => page.setFormState((current) => new AnnouncementFormState(current.title, content, current.attachment))}
        onAttachmentChange={(attachment) => page.setFormState((current) => new AnnouncementFormState(current.title, current.content, attachment))}
        onAttachmentSelect={(file) => void page.handleAttachmentSelect(file)}
        onSubmit={page.handleSubmit}
      />
    </CourseFormShell>
  )
}
