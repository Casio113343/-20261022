import { Button, Input, Label, Textarea } from '@/components/ui'
import { FilePicker, InlineError, InlineSuccess } from '@/shared/forms/FormHelpers'

import type { AnnouncementFormState } from '../functions/announcementForm'

class AnnouncementFormProps {
  formState!: AnnouncementFormState
  isBusy!: boolean
  errorMessage!: string
  successMessage!: string
  submitLabel!: string
  onTitleChange!: (value: string) => void
  onContentChange!: (value: string) => void
  onAttachmentChange!: (next: AnnouncementFormState['attachment']) => void
  onAttachmentSelect!: (file: File | null) => void
  onSubmit!: React.FormEventHandler<HTMLFormElement>
}

export function AnnouncementForm({
  formState,
  isBusy,
  errorMessage,
  successMessage,
  submitLabel,
  onTitleChange,
  onContentChange,
  onAttachmentChange,
  onAttachmentSelect,
  onSubmit,
}: AnnouncementFormProps) {
  return (
    <form className="space-y-4" onSubmit={onSubmit}>
      <div className="space-y-2"><Label>标题</Label><Input value={formState.title} onChange={(event) => onTitleChange(event.target.value)} /></div>
      <div className="space-y-2"><Label>内容</Label><Textarea value={formState.content} onChange={(event) => onContentChange(event.target.value)} /></div>
      <div className="flex flex-wrap items-center gap-3">
        <FilePicker accept="*/*" onChange={(event) => onAttachmentSelect(event.target.files?.[0] ?? null)} />
        {formState.attachment ? (
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
            <span>已选择 {formState.attachment.fileName}</span>
            <Button type="button" variant="ghost" size="sm" onClick={() => onAttachmentChange(null)}>移除</Button>
          </div>
        ) : null}
      </div>
      <Button type="submit" disabled={isBusy}>{submitLabel}</Button>
      {errorMessage ? <InlineError message={errorMessage} /> : null}
      {successMessage ? <InlineSuccess message={successMessage} /> : null}
    </form>
  )
}
