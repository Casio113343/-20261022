import type { Attachment } from '@/infrastructure/storage/Attachment'

export class AnnouncementFormState {
  constructor(
    public title: string,
    public content: string,
    public attachment: Attachment | null,
  ) {}
}

export function emptyAnnouncementFormState() {
  return new AnnouncementFormState('', '', null)
}
