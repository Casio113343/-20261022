import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { uploadAttachment } from '@/infrastructure/storage/uploadAsset'
import { CreateAnnouncementAPIMessage } from '@/microservices/course/api/CreateAnnouncementAPIMessage'
import { FetchCourseDetailAPIMessage } from '@/microservices/course/api/FetchCourseDetailAPIMessage'
import { UpdateAnnouncementAPIMessage } from '@/microservices/course/api/UpdateAnnouncementAPIMessage'
import { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoute } from '@/shared/routing/AppRoutes'
import { syncCourseDetailMutation } from '@/stores/session/functions/courseDetailSession'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { AnnouncementFormState, emptyAnnouncementFormState } from '../functions/announcementForm'

export function useAnnouncementCreatePage() {
  const { courseId, announcementId } = useParams<{ courseId: string; announcementId?: string }>()
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser, dashboard, setSession } = useEnsureDashboard(navigate)

  const [formState, setFormState] = useState<AnnouncementFormState>(emptyAnnouncementFormState)
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)
  const [isUploadingAttachment, setIsUploadingAttachment] = useState(false)
  const [course, setCourse] = useState<CourseDetailResponse | null | undefined>(undefined)

  const announcement = useMemo(() => course?.announcements.find((item) => item.id === announcementId) ?? null, [announcementId, course])

  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  useEffect(() => {
    if (!courseId || !currentUser) return
    void sendAPI(new FetchCourseDetailAPIMessage(courseId, currentUser.id)).run()
      .then(setCourse)
      .catch(() => setCourse(null))
  }, [courseId, currentUser?.id])

  useEffect(() => {
    if (announcement) {
      setFormState(new AnnouncementFormState(
        announcement.title,
        announcement.content,
        announcement.attachment ?? null,
      ))
    }
  }, [announcement])

  const handleAttachmentSelect = async (file: File | null) => {
    if (!currentUser) return
    if (!file) {
      setFormState((current) => new AnnouncementFormState(current.title, current.content, null))
      return
    }
    setErrorMessage('')
    setIsUploadingAttachment(true)
    try {
      const attachment = await uploadAttachment(currentUser.id, file)
      setFormState((current) => new AnnouncementFormState(current.title, current.content, attachment))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '附件上传失败')
    } finally {
      setIsUploadingAttachment(false)
    }
  }

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!courseId || !currentUser) return
    setErrorMessage('')
    setSuccessMessage('')
    setIsBusy(true)
    try {
      const payload = {
        title: formState.title.trim(),
        content: formState.content.trim(),
        attachment: formState.attachment ?? undefined,
      }
      const nextCourse = announcementId
        ? await sendAPI(new UpdateAnnouncementAPIMessage(courseId, announcementId, currentUser.id, payload)).run()
        : await sendAPI(new CreateAnnouncementAPIMessage(courseId, currentUser.id, payload)).run()
      syncCourseDetailMutation(dashboard, nextCourse, setSession, setCourse)
      setSuccessMessage(announcementId ? '通知更新成功。' : '通知发布成功。')
      navigate(AppRoute.CourseWorkspace(nextCourse.course.id))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : announcementId ? '通知更新失败' : '通知发布失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    announcement,
    announcementId,
    courseId,
    course,
    currentUser,
    errorMessage,
    formState,
    isBusy,
    isUploadingAttachment,
    successMessage,
    handleAttachmentSelect,
    handleSubmit,
    setFormState,
  }
}
