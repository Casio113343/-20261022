import { Navigate } from 'react-router-dom'

import { Button, Label, Textarea } from '@/components/ui'
import { CourseFormShell, InlineError, InlineSuccess } from '@/shared/forms/FormHelpers'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { useCourseMembersManagePage } from './hooks/useCourseMembersManagePage'

export default function CourseMembersManagePage() {
  const page = useCourseMembersManagePage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (page.course === null) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <CourseFormShell title="添加课程成员" description={page.course ? `课程：${page.course.course.title}` : '正在加载课程信息。'} backTo={page.courseId ? AppRoute.CourseWorkspace(page.courseId) : AppRoutePath.Dashboard} backLabel="返回课程工作区">
      <form className="space-y-4" onSubmit={page.handleSubmit}>
        <div className="space-y-2">
          <Label>账号列表</Label>
          <Textarea
            value={page.usernames}
            onChange={(event) => page.setUsernames(event.target.value)}
          />
        </div>
        <Button type="submit" disabled={page.isBusy}>添加成员</Button>
        {page.errorMessage ? <InlineError message={page.errorMessage} /> : null}
        {page.successMessage ? <InlineSuccess message={page.successMessage} /> : null}
      </form>
    </CourseFormShell>
  )
}
