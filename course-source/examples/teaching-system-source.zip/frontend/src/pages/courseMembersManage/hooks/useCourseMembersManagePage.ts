import { useEffect, useState, type FormEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { AddCourseMembersAPIMessage } from '@/microservices/course/api/AddCourseMembersAPIMessage'
import { FetchCourseDetailAPIMessage } from '@/microservices/course/api/FetchCourseDetailAPIMessage'
import { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { syncCourseDetailMutation } from '@/stores/session/functions/courseDetailSession'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { splitMemberUsernames } from '../functions/memberManage'

export function useCourseMembersManagePage() {
  const { courseId } = useParams<{ courseId: string }>()
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser, dashboard, setSession } = useEnsureDashboard(navigate)
  const [usernames, setUsernames] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)
  const [course, setCourse] = useState<CourseDetailResponse | null | undefined>(undefined)

  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  useEffect(() => {
    if (!courseId || !currentUser) return
    void sendAPI(new FetchCourseDetailAPIMessage(courseId, currentUser.id)).run()
      .then(setCourse)
      .catch(() => setCourse(null))
  }, [courseId, currentUser?.id])

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!courseId || !currentUser) return
    setErrorMessage('')
    setSuccessMessage('')
    setIsBusy(true)
    try {
      const nextCourse = await sendAPI(new AddCourseMembersAPIMessage(courseId, currentUser.id, {
        usernames: splitMemberUsernames(usernames),
      })).run()
      syncCourseDetailMutation(dashboard, nextCourse, setSession, setCourse)
      setSuccessMessage('课程成员添加成功')
      setUsernames('')
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '添加成员失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    course,
    courseId,
    currentUser,
    errorMessage,
    isBusy,
    successMessage,
    usernames,
    handleSubmit,
    setUsernames,
  }
}
