export const ExamReviewOperation = {
  Grading: 'grading',
  Arbitration: 'arbitration',
  Appeal: 'appeal',
} as const

export const ExamAppealStatus = {
  Pending: 'pending',
  Resolved: 'resolved',
} as const

export function getExamReviewOperationLabel(mode: string) {
  if (mode === ExamReviewOperation.Arbitration) {
    return '仲裁任务'
  }

  if (mode === ExamReviewOperation.Appeal) {
    return '申诉处理任务'
  }

  return '批改任务'
}
