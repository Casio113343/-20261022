import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import type { SubmissionReview } from '@/microservices/assignment/objects/SubmissionReview'

export class ResolvedReviewDetail {
  constructor(
    public course: CourseDetailResponse,
    public assignment: Assignment,
    public submission: AssignmentSubmission,
    public review: SubmissionReview | null,
    public student: { id: string; displayName: string },
  ) {}
}
