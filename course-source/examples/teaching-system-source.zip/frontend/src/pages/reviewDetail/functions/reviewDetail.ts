import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

import { ResolvedReviewDetail } from '../objects/ResolvedReviewDetail'

export function formatDateTime(value: string) {
  return new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
}

export function resolveReviewDetail(courseDetail: CourseDetailResponse | null | undefined, assignmentId: string | undefined, submissionId: string | undefined) {
  if (courseDetail === undefined) return undefined
  if (!courseDetail || !assignmentId || !submissionId) return null
  const assignment = courseDetail.assignments.find((item) => item.id === assignmentId)
  const submission = courseDetail.submissions.find((item) => item.id === submissionId)
  const review = submission ? courseDetail.reviews.find((item) => item.submissionId === submission.id) ?? null : null
  const student = submission ? courseDetail.course.students.find((item) => item.id === submission.studentId) ?? null : null
  if (assignment && submission && student) return new ResolvedReviewDetail(courseDetail, assignment, submission, review, student)
  return null
}

export function countRemainingPending(detail: ResolvedReviewDetail, assignmentId: string) {
  const reviewedIds = new Set(detail.course.reviews.map((item) => item.submissionId))
  return detail.course.submissions
    .filter((item) => item.assignmentId === assignmentId)
    .filter((item) => (!reviewedIds.has(item.id) || item.id === detail.submission.id) && item.id !== detail.submission.id)
    .length
}
