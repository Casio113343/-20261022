import { Navigate } from 'react-router-dom'

import { Card, CardContent } from '@/components/ui'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { ReviewDetailBackButton } from './components/ReviewDetailBackButton'
import { ReviewDetailCard } from './components/ReviewDetailCard'
import { useReviewDetailPage } from './hooks/useReviewDetailPage'

export default function ReviewDetailPage() {
  const page = useReviewDetailPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.assignmentId || !page.submissionId) return <Navigate replace to={AppRoutePath.Dashboard} />
  if (page.detail === null) return <Navigate replace to={AppRoutePath.Dashboard} />

  if (page.detail === undefined) {
    return (
      <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
        <div className="mx-auto max-w-4xl px-5 py-8 lg:px-8">
          <ReviewDetailBackButton assignmentId={page.assignmentId} sourceTab={page.sourceTab} />
          <Card className="border-slate-200 bg-white">
            <CardContent className="p-8 text-sm text-slate-500">正在加载提交内容。</CardContent>
          </Card>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-4xl px-5 py-8 lg:px-8">
        <ReviewDetailBackButton assignmentId={page.assignmentId} sourceTab={page.sourceTab} />
        <ReviewDetailCard page={page} />
      </div>
    </main>
  )
}
