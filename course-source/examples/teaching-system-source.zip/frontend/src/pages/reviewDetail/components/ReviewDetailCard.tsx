import { Alert, AlertDescription, Badge, Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Input, Label, Textarea } from '@/components/ui'

import { countRemainingPending, formatDateTime } from '../functions/reviewDetail'
import type { useReviewDetailPage } from '../hooks/useReviewDetailPage'

class ReviewDetailCardProps {
  page!: ReturnType<typeof useReviewDetailPage>
}

export function ReviewDetailCard({ page }: ReviewDetailCardProps) {
  const detail = page.detail
  if (!detail || !page.assignmentId) return null

  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <div className="flex items-center justify-between gap-3">
          <div>
            <CardTitle className="text-2xl">{detail.student.displayName}</CardTitle>
            <CardDescription>{detail.assignment.title} / 提交于 {formatDateTime(detail.submission.submittedAt)}</CardDescription>
          </div>
          <Badge variant={detail.review ? 'secondary' : 'outline'}>{detail.review ? '已批' : '待批'}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {detail.submission.content.trim() ? <div className="rounded-xl bg-slate-50 p-3 text-sm leading-7 text-slate-700">{detail.submission.content}</div> : null}
        {detail.submission.attachment ? <a className="text-sm text-sky-700 underline underline-offset-4 hover:text-sky-800" href={detail.submission.attachment.dataUrl} download={detail.submission.attachment.fileName}>下载附件：{detail.submission.attachment.fileName}</a> : null}
        {detail.assignment.maxScore !== null && detail.assignment.maxScore !== undefined ? (
          <div className="space-y-2 mt-10">
            <Label>分数</Label>
            <Input type="number" min={0} max={detail.assignment.maxScore} value={page.reviewScore} onChange={(event) => page.setReviewScore(event.target.value)} />
          </div>
        ) : null}
        <div className="space-y-2">
          <Label>评语</Label>
          <Textarea value={page.reviewComment} placeholder="评语可选" onChange={(event) => page.setReviewComment(event.target.value)} />
        </div>
        <div className="flex items-center gap-3">
          <Button disabled={page.isBusy} onClick={() => void page.submitReview()}>{detail.review ? '重新批改' : '完成'}</Button>
          {!detail.review ? <div className="text-sm text-slate-500">当前剩余待处理 {countRemainingPending(detail, page.assignmentId)} 份</div> : null}
        </div>
        {page.errorMessage ? <Alert variant="destructive" className="border-rose-200 bg-rose-50 text-rose-700"><AlertDescription className="text-rose-700">{page.errorMessage}</AlertDescription></Alert> : null}
      </CardContent>
    </Card>
  )
}
