import { Link } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Button } from '@/components/ui'
import { AppRoute } from '@/shared/routing/AppRoutes'

class ReviewDetailBackButtonProps {
  assignmentId!: string
  sourceTab!: string
}

export function ReviewDetailBackButton({ assignmentId, sourceTab }: ReviewDetailBackButtonProps) {
  return (
    <Button asChild variant="outline" className="mb-6">
      <Link to={AppRoute.ReviewBoard(assignmentId, sourceTab)}>
        <ChevronLeft className="size-4" />
        返回批改列表
      </Link>
    </Button>
  )
}
