import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { FetchAssignmentCourseDetailAPIMessage } from '@/microservices/assignment/api/FetchAssignmentCourseDetailAPIMessage'
import { ReviewSubmissionAPIMessage } from '@/microservices/assignment/api/ReviewSubmissionAPIMessage'
import { SubmissionReview } from '@/microservices/assignment/objects/SubmissionReview'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { ReviewBoardSource } from '@/pages/reviewBoard/objects/AssignmentReviewWorkflow'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoute } from '@/shared/routing/AppRoutes'
import { syncAssignmentCourseDetailMutation } from '@/stores/session/functions/assignmentSession'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'
import { resolveReviewDetail } from '../functions/reviewDetail'

export function useReviewDetailPage() {
  const { assignmentId, submissionId } = useParams<{ assignmentId: string; submissionId: string }>()
  const [searchParams] = useSearchParams()
  const sourceTab = searchParams.get('from') === ReviewBoardSource.Graded ? ReviewBoardSource.Graded : ReviewBoardSource.Pending
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser, setSession } = useEnsureDashboard(navigate)
  const dashboard = useSessionStore((state) => state.dashboard)

  const [reviewComment, setReviewComment] = useState('')
  const [reviewScore, setReviewScore] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)
  const [courseDetail, setCourseDetail] = useState<CourseDetailResponse | null | undefined>(undefined)

  useAutoDismissMessage(errorMessage, setErrorMessage)

  const detail = useMemo(() => resolveReviewDetail(courseDetail, assignmentId, submissionId), [assignmentId, courseDetail, submissionId])

  useEffect(() => {
    if (!currentUser || !assignmentId) return
    void sendAPI(new FetchAssignmentCourseDetailAPIMessage(assignmentId, currentUser.id)).run()
      .then(setCourseDetail)
      .catch(() => setCourseDetail(null))
  }, [assignmentId, currentUser?.id])

  useEffect(() => {
    if (!detail) return
    setReviewComment(detail.review?.comment ?? '')
    setReviewScore(detail.review?.score?.toString() ?? '')
  }, [detail?.submission.id, detail?.review?.comment, detail?.review?.score])

  const submitReview = async () => {
    if (!detail || !currentUser || !assignmentId) return
    setIsBusy(true)
    setErrorMessage('')
    try {
      const payload = new SubmissionReview('', detail.submission.id, currentUser.id, new Date().toISOString(), reviewScore ? Number(reviewScore) : undefined, reviewComment.trim() || undefined)
      const nextCourse = await sendAPI(new ReviewSubmissionAPIMessage(detail.submission.id, currentUser.id, payload)).run()
      setCourseDetail(nextCourse)
      syncAssignmentCourseDetailMutation(dashboard, nextCourse, setSession)
      const nextReviewedIds = new Set(nextCourse.reviews.map((item) => item.submissionId))
      const nextPending = nextCourse.submissions.filter((item) => item.assignmentId === assignmentId && !nextReviewedIds.has(item.id) && item.id !== detail.submission.id)[0]
      if (nextPending) navigate(AppRoute.ReviewDetailPending(assignmentId, nextPending.id))
      else navigate(AppRoute.ReviewBoard(assignmentId, sourceTab))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '批改失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    assignmentId,
    currentUser,
    detail,
    errorMessage,
    isBusy,
    reviewComment,
    reviewScore,
    sourceTab,
    submissionId,
    setReviewComment,
    setReviewScore,
    submitReview,
  }
}
