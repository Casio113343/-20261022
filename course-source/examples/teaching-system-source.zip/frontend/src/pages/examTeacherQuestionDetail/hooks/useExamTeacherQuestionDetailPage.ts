import { useEffect, useEffectEvent, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { ExamDetailAPIMessage } from '@/microservices/exam/api/ExamDetailAPIMessage'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'
import { resolveExamTeacherQuestionState } from '../functions/examTeacherQuestionDetail'

export function useExamTeacherQuestionDetailPage() {
  const { examId, studentId, questionId } = useParams<{ examId: string; studentId: string; questionId: string }>()
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const [detail, setDetail] = useState<ExamDetailResponse | null>(null)

  useHydrateSession()

  const loadDetail = useEffectEvent(async (nextExamId: string, operatorUserId: string) => {
    try {
      const nextDetail = await sendAPI(new ExamDetailAPIMessage(nextExamId, operatorUserId)).run()
      setDetail(nextDetail)
    } catch {
      navigate(AppRoutePath.Dashboard)
    }
  })

  useEffect(() => {
    if (!currentUser || !examId) return
    void loadDetail(examId, currentUser.id)
  }, [currentUser?.id, examId])

  const questionState = useMemo(() => resolveExamTeacherQuestionState(detail, studentId, questionId), [detail, questionId, studentId])

  return {
    currentUser,
    detail,
    examId,
    questionId,
    questionState,
    studentId,
    goBackToExam: () => {
      if (examId) navigate(AppRoute.ExamDetail(examId))
    },
    goNextQuestion: () => {
      if (examId && studentId && questionState.nextQuestion) navigate(AppRoute.ExamTeacherQuestionDetail(examId, studentId, questionState.nextQuestion.questionId))
    },
    goPreviousQuestion: () => {
      if (examId && studentId && questionState.previousQuestion) navigate(AppRoute.ExamTeacherQuestionDetail(examId, studentId, questionState.previousQuestion.questionId))
    },
  }
}
