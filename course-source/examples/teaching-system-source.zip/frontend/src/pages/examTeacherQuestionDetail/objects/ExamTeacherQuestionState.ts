import type { ExamAnswerSheet } from '@/microservices/exam/api/responses/ExamAnswerSheet'
import type { ExamQuestion } from '@/microservices/exam/api/responses/ExamQuestion'
import type { ExamTeacherScoreCell } from '@/microservices/exam/api/responses/ExamTeacherScoreCell'
import type { ExamTeacherScoreRow } from '@/microservices/exam/api/responses/ExamTeacherScoreRow'

export class ExamTeacherQuestionState {
  constructor(
    public row: ExamTeacherScoreRow | null,
    public cell: ExamTeacherScoreCell | null,
    public question: ExamQuestion | null,
    public sheet: ExamAnswerSheet | null,
    public previousQuestion: ExamTeacherScoreCell | null,
    public nextQuestion: ExamTeacherScoreCell | null,
  ) {}
}
