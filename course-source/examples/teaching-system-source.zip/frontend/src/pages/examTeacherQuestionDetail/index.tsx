import { Navigate } from 'react-router-dom'

import { Card, CardContent } from '@/components/ui'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { ExamTeacherQuestionContent } from './components/ExamTeacherQuestionContent'
import { useExamTeacherQuestionDetailPage } from './hooks/useExamTeacherQuestionDetailPage'

export default function ExamTeacherQuestionDetailPage() {
  const page = useExamTeacherQuestionDetailPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.examId || !page.studentId || !page.questionId) return <Navigate replace to={AppRoutePath.Dashboard} />
  if (!page.detail) {
    return (
      <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
        <div className="mx-auto max-w-5xl px-5 py-8 lg:px-8">
          <Card className="border-slate-200 bg-white"><CardContent className="p-8 text-sm text-slate-500">正在加载答卷详情。</CardContent></Card>
        </div>
      </main>
    )
  }
  if (!page.questionState.row || !page.questionState.cell || !page.questionState.question) return <Navigate replace to={AppRoute.ExamDetail(page.examId)} />

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-5xl px-5 py-8 lg:px-8">
        <ExamTeacherQuestionContent page={page} />
      </div>
    </main>
  )
}
