import { Badge, Button, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'
import { ExamAnswerImageGallery } from '@/pages/examDetail/components/ExamAnswerImageGallery'

import { formatTeacherQuestionLabel } from '../functions/examTeacherQuestionDetail'
import type { useExamTeacherQuestionDetailPage } from '../hooks/useExamTeacherQuestionDetailPage'

class ExamTeacherQuestionContentProps {
  page!: ReturnType<typeof useExamTeacherQuestionDetailPage>
}

export function ExamTeacherQuestionContent({ page }: ExamTeacherQuestionContentProps) {
  const { cell, question, row, sheet } = page.questionState
  if (!page.detail || !row || !cell || !question) return null

  return (
    <>
      <Button type="button" variant="outline" className="mb-6" onClick={page.goBackToExam}>返回考试页</Button>
      <div className="mb-6 flex flex-wrap gap-3">
        <Button variant="outline" className="bg-white hover:bg-slate-50" disabled={!page.questionState.previousQuestion} onClick={page.goPreviousQuestion}>上一题</Button>
        <Button variant="outline" className="bg-white hover:bg-slate-50" disabled={!page.questionState.nextQuestion} onClick={page.goNextQuestion}>下一题</Button>
      </div>
      <Card className="border-slate-200 bg-white">
        <CardHeader>
          <div className="flex items-center justify-between gap-3">
            <div>
              <CardTitle className="text-2xl">{formatTeacherQuestionLabel(question.position, question.title)}</CardTitle>
              <CardDescription>{row.student.displayName} / {page.detail.exam.title}</CardDescription>
            </div>
            <Badge variant="secondary">{cell.score ?? '--'} / {cell.fullScore}</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <ExamAnswerImageGallery images={sheet?.images ?? []} emptyText="当前还没有录入这位学生的作答图片。" maxHeightClass="max-h-[560px]" />
        </CardContent>
      </Card>
    </>
  )
}
