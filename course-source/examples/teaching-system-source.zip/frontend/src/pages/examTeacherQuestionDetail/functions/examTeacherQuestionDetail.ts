import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

import { ExamTeacherQuestionState } from '../objects/ExamTeacherQuestionState'

export function formatTeacherQuestionLabel(position: number, title?: string | null) {
  return title && title.trim() ? `第 ${position} 题 · ${title}` : `第 ${position} 题`
}

export function resolveExamTeacherQuestionState(detail: ExamDetailResponse | null, studentId: string | undefined, questionId: string | undefined) {
  const row = detail?.scoreRows.find((item) => item.student.id === studentId) ?? null
  const cell = row?.questions.find((item) => item.questionId === questionId) ?? null
  const question = detail?.questions.find((item) => item.id === questionId) ?? null
  const sheet = detail?.answerSheets.find((item) => item.questionId === questionId && item.student.id === studentId) ?? null
  const currentIndex = row?.questions.findIndex((item) => item.questionId === questionId) ?? -1
  const previousQuestion = currentIndex > 0 ? row?.questions[currentIndex - 1] ?? null : null
  const nextQuestion = currentIndex >= 0 && row && currentIndex < row.questions.length - 1 ? row.questions[currentIndex + 1] : null
  return new ExamTeacherQuestionState(row, cell, question, sheet, previousQuestion, nextQuestion)
}
