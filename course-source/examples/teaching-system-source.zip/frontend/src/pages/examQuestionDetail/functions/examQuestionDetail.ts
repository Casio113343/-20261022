import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

import { ExamQuestionState } from '../objects/ExamQuestionState'

export function formatQuestionLabel(position: number, title?: string | null) {
  return title && title.trim() ? `第 ${position} 题 · ${title}` : `第 ${position} 题`
}

export function resolveExamQuestionState(detail: ExamDetailResponse | null, questionId: string | undefined, currentUserId: string | undefined) {
  const question = detail?.questions.find((item) => item.id === questionId) ?? null
  const result = detail?.studentResult?.questions.find((item) => item.questionId === questionId) ?? null
  const sheet = detail?.answerSheets.find((item) => item.questionId === questionId && item.student.id === currentUserId) ?? null
  const questionList = detail?.studentResult?.questions ?? []
  const currentQuestionIndex = questionList.findIndex((item) => item.questionId === questionId)
  const previousQuestion = currentQuestionIndex > 0 ? questionList[currentQuestionIndex - 1] : null
  const nextQuestion = currentQuestionIndex >= 0 && currentQuestionIndex < questionList.length - 1 ? questionList[currentQuestionIndex + 1] : null

  return new ExamQuestionState(
    question,
    result,
    sheet,
    previousQuestion,
    nextQuestion,
  )
}
