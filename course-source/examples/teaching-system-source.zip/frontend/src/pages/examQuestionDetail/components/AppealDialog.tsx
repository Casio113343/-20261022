import { Button, Dialog, DialogContent, DialogHeader, DialogTitle, Input, Label, Textarea } from '@/components/ui'

class AppealDialogProps {
  open!: boolean
  expectedScore!: string
  reason!: string
  questionLabel!: string
  currentScore!: number | null
  maxScore!: number
  isBusy!: boolean
  onOpenChange!: (open: boolean) => void
  onExpectedScoreChange!: (value: string) => void
  onReasonChange!: (value: string) => void
  onSubmit!: () => void
}

export function AppealDialog({
  open,
  expectedScore,
  reason,
  questionLabel,
  currentScore,
  maxScore,
  isBusy,
  onOpenChange,
  onExpectedScoreChange,
  onReasonChange,
  onSubmit,
}: AppealDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>提交申诉</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">
            {questionLabel}，满分 {maxScore} 分，当前得分 {currentScore ?? '--'} 分
          </div>
          <div className="space-y-2">
            <Label>申诉得分</Label>
            <Input type="number" min={0} max={maxScore} value={expectedScore} onChange={(event) => onExpectedScoreChange(event.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>申诉理由</Label>
            <Textarea value={reason} onChange={(event) => onReasonChange(event.target.value)} />
          </div>
          <Button type="button" disabled={isBusy} onClick={onSubmit}>提交申诉</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
