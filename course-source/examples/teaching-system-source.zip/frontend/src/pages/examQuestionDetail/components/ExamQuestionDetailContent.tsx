import { Alert, AlertDescription, Button, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'
import { ExamAppealStatus } from '@/pages/objects/ExamReviewWorkflow'

import { AppealDialog } from './AppealDialog'
import { ExamQuestionNavigation } from './ExamQuestionNavigation'
import { formatQuestionLabel } from '../functions/examQuestionDetail'
import { ExamAnswerImageGallery } from '@/pages/examDetail/components/ExamAnswerImageGallery'
import type { useExamQuestionDetailPage } from '../hooks/useExamQuestionDetailPage'

class ExamQuestionDetailContentProps {
  page!: ReturnType<typeof useExamQuestionDetailPage>
}

export function ExamQuestionDetailContent({ page }: ExamQuestionDetailContentProps) {
  const detail = page.detail
  const questionState = page.questionState
  if (!detail) return null
  const question = questionState.question
  if (!question) {
    return null
  }
  const result = questionState.result
  const appeal = result?.appeal
  const canShowExpiredAppeal = Boolean(
    detail.studentResult?.published &&
    question.scoring.appealEnabled &&
    detail.exam.appealDueAt &&
    new Date(detail.exam.appealDueAt).getTime() < Date.now() &&
    !appeal &&
    !result?.canAppeal,
  )

  return (
    <>
      <Button type="button" variant="outline" className="mb-6" onClick={page.goBackToExam}>返回考试页</Button>

      <ExamQuestionNavigation
        hasPrevious={Boolean(questionState.previousQuestion)}
        hasNext={Boolean(questionState.nextQuestion)}
        onPrevious={page.goPreviousQuestion}
        onNext={page.goNextQuestion}
      />

      <Card className="border-slate-200 bg-white">
        <CardHeader>
            <div className="flex items-center justify-between gap-3">
              <div>
                <CardTitle className="text-2xl">
                  {formatQuestionLabel(question.position, question.title)}
                  <span className="ml-6">{detail.studentResult?.published ? `${result?.score ?? '--'} / ${result?.fullScore ?? question.scoring.fullScore}` : '未发布'}</span>
                </CardTitle>
                <CardDescription>{detail.exam.title}</CardDescription>
              </div>
            </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <ExamAnswerImageGallery images={questionState.sheet?.images ?? []} emptyText="当前还没有录入你的作答图片。" />

          {result?.canAppeal && !appeal ? <Button type="button" onClick={() => page.setAppealDialogOpen(true)}>申诉</Button> : null}
          {appeal?.status === ExamAppealStatus.Pending ? (
            <div className="rounded-2xl border border-teal-200 bg-teal-50 px-4 py-3 text-sm text-teal-900">
              <span>申诉已提交，等待处理</span>
              <span className="ml-8">期望得分：{appeal.expectedScore}</span>
              <span className="ml-8">理由：{appeal.reason}</span>
            </div>
          ) : null}
          {appeal?.status === ExamAppealStatus.Resolved ? (
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">申诉已处理</div>
          ) : null}
          {canShowExpiredAppeal ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">申诉已过期</div>
          ) : null}
          {page.errorMessage ? <Alert variant="destructive" className="border-rose-200 bg-rose-50 text-rose-700"><AlertDescription className="text-rose-700">{page.errorMessage}</AlertDescription></Alert> : null}
          {page.successMessage ? <Alert className="border-emerald-200 bg-emerald-50 text-emerald-700"><AlertDescription>{page.successMessage}</AlertDescription></Alert> : null}
        </CardContent>
      </Card>
      <AppealDialog
        open={page.appealDialogOpen}
        expectedScore={page.expectedScore}
        reason={page.reason}
        questionLabel={formatQuestionLabel(question.position, question.title)}
        currentScore={questionState.result?.score ?? null}
        maxScore={question.scoring.fullScore}
        isBusy={page.isBusy}
        onOpenChange={page.setAppealDialogOpen}
        onExpectedScoreChange={page.setExpectedScore}
        onReasonChange={page.setReason}
        onSubmit={() => void page.submitAppeal()}
      />
    </>
  )
}
