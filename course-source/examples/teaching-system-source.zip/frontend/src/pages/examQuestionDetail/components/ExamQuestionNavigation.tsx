import { Button } from '@/components/ui'
import { ChevronLeft, ChevronRight } from 'lucide-react'

class ExamQuestionNavigationProps {
  hasPrevious!: boolean
  hasNext!: boolean
  onPrevious!: () => void
  onNext!: () => void
}

export function ExamQuestionNavigation({ hasPrevious, hasNext, onPrevious, onNext }: ExamQuestionNavigationProps) {
  return (
    <div className="mb-6 flex flex-wrap gap-3">
      <Button variant="outline" className="bg-white hover:bg-slate-50" disabled={!hasPrevious} onClick={onPrevious}>
        <ChevronLeft className="size-4" />
        上一题
      </Button>
      <Button variant="outline" className="bg-white hover:bg-slate-50" disabled={!hasNext} onClick={onNext}>
        下一题
        <ChevronRight className="size-4" />
      </Button>
    </div>
  )
}
