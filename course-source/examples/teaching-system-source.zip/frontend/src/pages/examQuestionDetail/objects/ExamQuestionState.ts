import type { ExamAnswerSheet } from '@/microservices/exam/api/responses/ExamAnswerSheet'
import type { ExamQuestion } from '@/microservices/exam/api/responses/ExamQuestion'
import type { ExamQuestionResult } from '@/microservices/exam/api/responses/ExamQuestionResult'

export class ExamQuestionState {
  constructor(
    public question: ExamQuestion | null,
    public result: ExamQuestionResult | null,
    public sheet: ExamAnswerSheet | null,
    public previousQuestion: ExamQuestionResult | null,
    public nextQuestion: ExamQuestionResult | null,
  ) {}
}
