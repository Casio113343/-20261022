import { Navigate } from 'react-router-dom'

import { Card, CardContent } from '@/components/ui'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'

import { ExamQuestionDetailContent } from './components/ExamQuestionDetailContent'
import { useExamQuestionDetailPage } from './hooks/useExamQuestionDetailPage'

export default function ExamQuestionDetailPage() {
  const page = useExamQuestionDetailPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.examId || !page.questionId || page.hasLoadFailed) return <Navigate replace to={AppRoutePath.Dashboard} />

  if (!page.detail) {
    return (
      <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
        <div className="mx-auto max-w-5xl px-5 py-8 lg:px-8">
          <Card className="border-slate-200 bg-white">
            <CardContent className="p-8 text-sm text-slate-500">正在加载题目详情。</CardContent>
          </Card>
        </div>
      </main>
    )
  }

  if (!page.detail.studentResult?.published) return <Navigate replace to={AppRoute.ExamDetail(page.examId)} />
  if (!page.questionState.question) return <Navigate replace to={AppRoute.ExamDetail(page.examId)} />

  return (
    <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-5xl px-5 py-8 lg:px-8">
        <ExamQuestionDetailContent page={page} />
      </div>
    </main>
  )
}
