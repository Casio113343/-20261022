import { useEffect, useEffectEvent, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { ExamDetailAPIMessage } from '@/microservices/exam/api/ExamDetailAPIMessage'
import { MarkPublishedExamReadAPIMessage } from '@/microservices/exam/api/MarkPublishedExamReadAPIMessage'
import { SubmitExamAppealAPIMessage } from '@/microservices/exam/api/SubmitExamAppealAPIMessage'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoute } from '@/shared/routing/AppRoutes'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'
import { resolveExamQuestionState } from '../functions/examQuestionDetail'

export function useExamQuestionDetailPage() {
  const { examId, questionId } = useParams<{ examId: string; questionId: string }>()
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const setSession = useSessionStore((state) => state.setSession)
  const [detail, setDetail] = useState<ExamDetailResponse | null>(null)
  const [hasLoadFailed, setHasLoadFailed] = useState(false)
  const [expectedScore, setExpectedScore] = useState('')
  const [reason, setReason] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [appealDialogOpen, setAppealDialogOpen] = useState(false)
  const [isBusy, setIsBusy] = useState(false)

  useHydrateSession()
  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  const loadDetail = useEffectEvent(async (nextExamId: string, operatorUserId: string) => {
    setHasLoadFailed(false)
    try {
      const nextDetail = await sendAPI(new ExamDetailAPIMessage(nextExamId, operatorUserId)).run()
      setDetail(nextDetail)
    } catch {
      setHasLoadFailed(true)
    }
  })

  useEffect(() => {
    if (!currentUser || !examId) return
    void loadDetail(examId, currentUser.id)
  }, [currentUser?.id, examId])

  const questionState = useMemo(() => resolveExamQuestionState(detail, questionId, currentUser?.id), [currentUser?.id, detail, questionId])

  const markPublishedExamRead = useEffectEvent(async (nextExamId: string, operatorUserId: string) => {
    try {
      const nextDashboard = await sendAPI(new MarkPublishedExamReadAPIMessage(nextExamId, operatorUserId)).run()
      setSession(nextDashboard)
    } catch {
      return undefined
    }
  })

  useEffect(() => {
    setErrorMessage('')
    setSuccessMessage('')
    setAppealDialogOpen(false)
  }, [questionId])

  useEffect(() => {
    if (!currentUser || !detail?.exam.publishedAt) return
    if ((currentUser.readPublishedExamIds ?? []).includes(detail.exam.id)) return
    void markPublishedExamRead(detail.exam.id, currentUser.id)
  }, [currentUser?.id, currentUser?.readPublishedExamIds, detail?.exam.id, detail?.exam.publishedAt])

  const submitAppeal = async () => {
    if (!examId || !questionId || !currentUser) return
    setErrorMessage('')
    setSuccessMessage('')
    setIsBusy(true)
    try {
      const nextDetail = await sendAPI(new SubmitExamAppealAPIMessage(examId, questionId, currentUser.id, {
        expectedScore: Number(expectedScore),
        reason: reason.trim(),
      })).run()
      setDetail(nextDetail)
      setExpectedScore('')
      setReason('')
      setSuccessMessage('申诉已提交，等待老师处理。')
      setAppealDialogOpen(false)
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '提交申诉失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    appealDialogOpen,
    currentUser,
    detail,
    errorMessage,
    examId,
    expectedScore,
    hasLoadFailed,
    isBusy,
    questionId,
    questionState,
    reason,
    successMessage,
    goBackToExam: () => {
      if (examId) navigate(AppRoute.ExamDetail(examId))
    },
    goNextQuestion: () => {
      if (examId && questionState.nextQuestion) navigate(AppRoute.ExamQuestionDetail(examId, questionState.nextQuestion.questionId))
    },
    goPreviousQuestion: () => {
      if (examId && questionState.previousQuestion) navigate(AppRoute.ExamQuestionDetail(examId, questionState.previousQuestion.questionId))
    },
    setAppealDialogOpen,
    setExpectedScore,
    setReason,
    submitAppeal,
  }
}
