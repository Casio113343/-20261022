import { useEffect, useEffectEvent, useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { LoginAPIMessage } from '@/microservices/auth/api/LoginAPIMessage'
import { LoginInput } from '@/microservices/auth/api/requests/LoginInput'
import { UserRole } from '@/microservices/auth/objects/UserRole'
import { FetchDashboardAPIMessage } from '@/microservices/dashboard/api/FetchDashboardAPIMessage'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoutePath } from '@/shared/routing/AppRoutes'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'
import { validateLoginFields } from '../functions/loginForm'

export function useLoginPage() {
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const setSession = useSessionStore((state) => state.setSession)

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [roleTab, setRoleTab] = useState<string>(UserRole.Teacher)

  useHydrateSession()
  useAutoDismissMessage(errorMessage, setErrorMessage)

  useEffect(() => {
    if (currentUser) {
      navigate(AppRoutePath.Dashboard)
    }
  }, [currentUser?.id, navigate])

  const loadDashboard = useEffectEvent(async (operatorUserId: string) => {
    const dashboard = await sendAPI(new FetchDashboardAPIMessage(operatorUserId)).run()
    setSession(dashboard)
    navigate(AppRoutePath.Dashboard)
  })

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()

    const validationError = validateLoginFields(username, password)
    if (validationError) {
      setErrorMessage(validationError)
      return
    }

    setIsSubmitting(true)
    setErrorMessage('')

    try {
      const auth = await sendAPI(new LoginAPIMessage(new LoginInput(username.trim(), password.trim(), roleTab))).run()
      await loadDashboard(auth.user.id)
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '登录失败')
    } finally {
      setIsSubmitting(false)
    }
  }

  return {
    errorMessage,
    isSubmitting,
    password,
    roleTab,
    username,
    handleSubmit,
    setPassword,
    setRoleTab,
    setUsername,
  }
}
