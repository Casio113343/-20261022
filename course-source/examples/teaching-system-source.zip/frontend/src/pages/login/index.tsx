import { LoginFormCard } from './components/LoginFormCard'
import { useLoginPage } from './hooks/useLoginPage'

export default function LoginPage() {
  const page = useLoginPage()

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_18%_18%,rgba(14,165,233,0.18),transparent_28%),radial-gradient(circle_at_82%_12%,rgba(45,212,191,0.18),transparent_26%),linear-gradient(135deg,#ecfeff_0%,#f0fdfa_48%,#eef6ff_100%)] text-slate-900">
      <div className="mx-auto flex min-h-screen max-w-3xl flex-col items-center px-6 py-12 lg:px-10">
        <h1 className="mt-8 text-center text-4xl font-semibold tracking-tight text-slate-950 lg:text-5xl">线上教学平台</h1>
        <div className="mt-14 w-full max-w-md">
          <LoginFormCard
            username={page.username}
            password={page.password}
            roleTab={page.roleTab}
            errorMessage={page.errorMessage}
            isSubmitting={page.isSubmitting}
            onUsernameChange={page.setUsername}
            onPasswordChange={page.setPassword}
            onRoleChange={page.setRoleTab}
            onSubmit={page.handleSubmit}
          />
        </div>
      </div>
    </main>
  )
}
