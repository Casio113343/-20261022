import { KeyRound, UserRound } from 'lucide-react'
import { Link } from 'react-router-dom'

import { Alert, AlertDescription, Button, Card, CardContent, CardDescription, CardHeader, CardTitle, Input, Label, Tabs, TabsList, TabsTrigger } from '@/components/ui'
import { UserRole } from '@/microservices/auth/objects/UserRole'

type LoginFormCardProps = {
  username: string
  password: string
  roleTab: string
  errorMessage: string
  isSubmitting: boolean
  onUsernameChange: (value: string) => void
  onPasswordChange: (value: string) => void
  onRoleChange: (value: string) => void
  onSubmit: React.FormEventHandler<HTMLFormElement>
}

export function LoginFormCard({
  username,
  password,
  roleTab,
  errorMessage,
  isSubmitting,
  onUsernameChange,
  onPasswordChange,
  onRoleChange,
  onSubmit,
}: LoginFormCardProps) {
  return (
    <Card className="border-white/70 bg-white/88 shadow-[0_24px_80px_rgba(15,23,42,0.12)] backdrop-blur">
      <CardHeader className="space-y-3">
        <CardTitle className="text-2xl">账号登录</CardTitle>
        <CardDescription>教师端与学生端会做真实身份校验，选错身份将无法登录。</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={roleTab} onValueChange={onRoleChange} className="space-y-5">
          <TabsList className="grid h-auto grid-cols-2 rounded-2xl bg-slate-100 p-1">
            <TabsTrigger value={UserRole.Teacher}>教师端</TabsTrigger>
            <TabsTrigger value={UserRole.Student}>学生端</TabsTrigger>
          </TabsList>

          <form className="space-y-5" autoComplete="off" onSubmit={onSubmit}>
            <div className="space-y-2">
              <Label htmlFor="username">账号</Label>
              <div className="relative">
                <UserRound className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-slate-400" />
                <Input
                  id="username"
                  name="teaching-login-username"
                  value={username}
                  inputMode="numeric"
                  autoComplete="off"
                  className="h-11 rounded-xl bg-white pl-10"
                  onChange={(event) => onUsernameChange(event.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">密码</Label>
              <div className="relative">
                <KeyRound className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-slate-400" />
                <Input
                  id="password"
                  name="teaching-login-password"
                  type="password"
                  value={password}
                  autoComplete="new-password"
                  className="h-11 rounded-xl bg-white pl-10"
                  onChange={(event) => onPasswordChange(event.target.value)}
                />
              </div>
            </div>

            {errorMessage ? (
              <Alert variant="destructive" className="border-rose-200 bg-rose-50 text-rose-700">
                <AlertDescription className="text-rose-700">{errorMessage}</AlertDescription>
              </Alert>
            ) : null}

            <Button type="submit" size="lg" className="h-11 w-full rounded-xl" disabled={isSubmitting}>
              {isSubmitting ? '登录中...' : '进入系统'}
            </Button>
            <Link className="block text-center text-sm text-slate-600 underline-offset-4 hover:underline" to="/register">
              没有账号？去注册教师或学生账户
            </Link>
          </form>
        </Tabs>
      </CardContent>
    </Card>
  )
}
