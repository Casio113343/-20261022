import { Badge } from '@/components/ui'

export type DemoAccount = {
  role: string
  username: string
  password: string
}

type DemoAccountGridProps = {
  accounts: readonly DemoAccount[]
  onSelectAccount: (account: DemoAccount) => void
}

export function DemoAccountGrid({ accounts, onSelectAccount }: DemoAccountGridProps) {
  return (
    <div className="mt-28 grid max-w-2xl gap-4 sm:grid-cols-2 lg:mt-24">
      {accounts.map((account) => (
        <button
          key={account.username}
          type="button"
          className="rounded-[1.5rem] border border-slate-200 bg-white/82 p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
          onClick={() => onSelectAccount(account)}
        >
          <div className="mb-2 flex items-center justify-between">
            <Badge variant="secondary">{account.role}</Badge>
            <span className="text-xs text-slate-500">点击填充</span>
          </div>
          <div className="text-lg font-semibold">{account.username}</div>
          <div className="mt-1 text-sm text-slate-500">{account.password}</div>
        </button>
      ))}
    </div>
  )
}
