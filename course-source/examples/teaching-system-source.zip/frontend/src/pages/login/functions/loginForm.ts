export function validateLoginFields(username: string, password: string): string | null {
  if (!username.trim() || !password.trim()) {
    return '请输入账号和密码。'
  }

  if (!/^\d+$/.test(username.trim())) {
    return '账号必须为纯数字。'
  }

  return null
}
