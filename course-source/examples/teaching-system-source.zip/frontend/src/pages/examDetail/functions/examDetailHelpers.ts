import { readImageAttachments } from '@/shared/forms/FormHelpers'
import type { Attachment } from '@/infrastructure/storage/Attachment'

export function formatExamDateTime(value: string) {
  return new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
}

export function readExamAttachments(onLoaded: (attachments: Attachment[]) => void) {
  return readImageAttachments(onLoaded)
}
