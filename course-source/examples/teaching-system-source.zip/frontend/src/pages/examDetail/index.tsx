import { Link, Navigate } from 'react-router-dom'
import { ChevronLeft } from 'lucide-react'

import { Button, Card, CardContent } from '@/components/ui'
import { ConfirmDialog } from '@/components/ui/confirmDialog'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'

import { ExamHeaderCard } from './components/ExamHeaderCard'
import { StudentExamPanel } from './components/StudentExamPanel'
import { TeacherExamPanel } from './components/TeacherExamPanel'
import { useExamDetailPage } from './hooks/useExamDetailPage'

export default function ExamDetailPage() {
  const page = useExamDetailPage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (!page.examId) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(45,212,191,0.14),transparent_28%),linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className={`mx-auto px-5 py-8 lg:px-8 ${page.isTeacher ? 'max-w-5xl' : 'max-w-3xl'}`}>
        <Button asChild variant="outline" className="mb-6">
          <Link to={page.detail ? AppRoute.CourseWorkspace(page.detail.course.id) : AppRoutePath.Dashboard}>
            <ChevronLeft className="size-4" />
            返回课程工作区
          </Link>
        </Button>

        {!page.detail ? (
          <Card className="border-slate-200 bg-white">
            <CardContent className="p-8 text-sm text-slate-500">正在加载考试信息。</CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <ExamHeaderCard detail={page.detail} isTeacher={page.isTeacher} />
            {page.isTeacher ? (
              <TeacherExamPanel
                detail={page.detail}
                publishError={page.publishError}
                isBusy={page.isBusy}
              />
            ) : (
              <StudentExamPanel detail={page.detail} />
            )}
            {page.isTeacher ? (
              <div className="flex justify-end gap-2">
                <Button type="button" onClick={page.editExam}>编辑考试</Button>
                <Button type="button" variant="destructive" onClick={() => page.setIsDeleteOpen(true)}>删除考试</Button>
              </div>
            ) : null}
            <ConfirmDialog
              open={page.isDeleteOpen}
              title="确认删除考试？"
              description="删除后，这场考试、题目、答卷、批改和申诉信息都会被永久移除。"
              confirmLabel="确认删除"
              onOpenChange={page.setIsDeleteOpen}
              onConfirm={() => void page.deleteExam()}
            />
          </div>
        )}
      </div>
    </main>
  )
}
