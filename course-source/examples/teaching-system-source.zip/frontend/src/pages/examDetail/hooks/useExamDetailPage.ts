import { useEffect, useEffectEvent, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { UserRole } from '@/microservices/auth/objects/UserRole'
import { DeleteExamAPIMessage } from '@/microservices/exam/api/DeleteExamAPIMessage'
import { ExamDetailAPIMessage } from '@/microservices/exam/api/ExamDetailAPIMessage'
import { MarkPublishedExamReadAPIMessage } from '@/microservices/exam/api/MarkPublishedExamReadAPIMessage'
import { PublishExamAPIMessage } from '@/microservices/exam/api/PublishExamAPIMessage'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { syncCourseDetailMutation } from '@/stores/session/functions/courseDetailSession'
import { syncExamDetailMutation } from '@/stores/session/functions/examSession'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { useSessionStore } from '@/stores/session/useSessionStore'

export function useExamDetailPage() {
  const { examId } = useParams<{ examId: string }>()
  const navigate = useNavigate()
  const currentUser = useSessionStore((state) => state.currentUser)
  const dashboard = useSessionStore((state) => state.dashboard)
  const setSession = useSessionStore((state) => state.setSession)
  const [detail, setDetail] = useState<ExamDetailResponse | null>(null)
  const [publishError, setPublishError] = useState('')
  const [isDeleteOpen, setIsDeleteOpen] = useState(false)
  const [isBusy, setIsBusy] = useState(false)

  useHydrateSession()

  const loadDetail = useEffectEvent(async (nextExamId: string, operatorUserId: string) => {
    try {
      const response = await sendAPI(new ExamDetailAPIMessage(nextExamId, operatorUserId)).run()
      setDetail(response)
    } catch {
      navigate(AppRoutePath.Dashboard)
    }
  })

  useEffect(() => {
    if (!currentUser || !examId) return
    void loadDetail(examId, currentUser.id)
  }, [currentUser?.id, examId])

  const isTeacher = currentUser?.role === UserRole.Teacher

  const markPublishedExamRead = useEffectEvent(async (nextExamId: string, operatorUserId: string) => {
    try {
      const nextDashboard = await sendAPI(new MarkPublishedExamReadAPIMessage(nextExamId, operatorUserId)).run()
      setSession(nextDashboard)
    } catch {
      return undefined
    }
  })

  useEffect(() => {
    if (!currentUser || isTeacher || !detail?.exam.publishedAt) return
    if ((currentUser.readPublishedExamIds ?? []).includes(detail.exam.id)) return
    void markPublishedExamRead(detail.exam.id, currentUser.id)
  }, [currentUser?.id, currentUser?.readPublishedExamIds, detail?.exam.id, detail?.exam.publishedAt, isTeacher])

  const publishExam = async () => {
    if (!detail || !currentUser) return
    setPublishError('')
    setIsBusy(true)
    try {
      const nextDetail = await sendAPI(new PublishExamAPIMessage(detail.exam.id, currentUser.id)).run()
      setDetail(nextDetail)
      syncExamDetailMutation(dashboard, nextDetail, setSession)
    } catch (error) {
      setPublishError(error instanceof Error ? error.message : '发布失败')
    } finally {
      setIsBusy(false)
    }
  }

  const deleteExam = async () => {
    if (!detail || !currentUser) return
    const nextCourse = await sendAPI(new DeleteExamAPIMessage(detail.course.id, detail.exam.id, currentUser.id)).run()
    syncCourseDetailMutation(dashboard, nextCourse, setSession)
    navigate(AppRoute.CourseWorkspace(nextCourse.course.id))
  }

  return {
    currentUser,
    detail,
    examId,
    isBusy,
    isDeleteOpen,
    isTeacher,
    publishError,
    deleteExam,
    editExam: () => {
      if (detail) navigate(AppRoute.ExamEdit(detail.course.id, detail.exam.id))
    },
    publishExam,
    setIsDeleteOpen,
  }
}
