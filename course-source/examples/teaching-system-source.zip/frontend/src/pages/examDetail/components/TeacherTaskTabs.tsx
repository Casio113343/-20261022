import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

import { Badge, Button, Card, CardContent, CardHeader, CardTitle, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'
import { ExamReviewOperation } from '@/pages/objects/ExamReviewWorkflow'
import { AppRoute } from '@/shared/routing/AppRoutes'

export function TeacherTaskTabs({ detail }: { detail: ExamDetailResponse }) {
  const navigate = useNavigate()
  const gradingTasks = detail.teacherTasks.filter((task) => task.mode === ExamReviewOperation.Grading)
  const arbitrationTasks = detail.teacherTasks.filter((task) => task.mode === ExamReviewOperation.Arbitration)
  const appealTasks = detail.teacherTasks.filter((task) => task.mode === ExamReviewOperation.Appeal)
  const availableTabs = [
    gradingTasks.length ? { key: ExamReviewOperation.Grading, label: '批改', tasks: gradingTasks } : null,
    arbitrationTasks.length ? { key: ExamReviewOperation.Arbitration, label: '仲裁', tasks: arbitrationTasks } : null,
    appealTasks.length ? { key: ExamReviewOperation.Appeal, label: '申诉', tasks: appealTasks } : null,
  ].filter(Boolean) as { key: string; label: string; tasks: ExamDetailResponse['teacherTasks'] }[]
  const firstPendingTab = availableTabs.find((tab) => tab.tasks.some((task) => task.pendingCount > 0))
  const [selectedTab, setSelectedTab] = useState(firstPendingTab?.key ?? availableTabs[0]?.key ?? ExamReviewOperation.Grading)

  if (!availableTabs.length) return null
  if (availableTabs.length === 1) {
    const tab = availableTabs[0]
    return <TaskCard title={`待${tab.label}`} tasks={tab.tasks} examId={detail.exam.id} showProgressLink={tab.key === ExamReviewOperation.Grading} navigate={navigate} />
  }

  return (
    <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
      <TabsList className="h-auto flex-wrap rounded-2xl bg-slate-100 p-1">
        {availableTabs.map((tab) => <TabsTrigger key={tab.key} value={tab.key}>{tab.label}</TabsTrigger>)}
      </TabsList>
      {availableTabs.map((tab) => (
        <TabsContent key={tab.key} value={tab.key}>
          <TaskCard title={`待${tab.label}`} tasks={tab.tasks} examId={detail.exam.id} showProgressLink={tab.key === ExamReviewOperation.Grading} navigate={navigate} />
        </TabsContent>
      ))}
    </Tabs>
  )
}

export function TeacherAppealTasks({ detail }: { detail: ExamDetailResponse }) {
  const navigate = useNavigate()
  const appealTasks = detail.teacherTasks.filter((task) => task.mode === ExamReviewOperation.Appeal)
  if (!appealTasks.length) return null
  return <TaskCard title="待处理申诉" tasks={appealTasks} examId={detail.exam.id} navigate={navigate} />
}

function TaskCard({
  title,
  tasks,
  examId,
  showProgressLink = false,
  navigate,
}: {
  title: string
  tasks: ExamDetailResponse['teacherTasks']
  examId: string
  showProgressLink?: boolean
  navigate: ReturnType<typeof useNavigate>
}) {
  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {tasks.map((task) => (
          <button key={`${task.mode}-${task.questionId}`} type="button" className="flex w-full items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-left transition hover:bg-slate-100" onClick={() => navigate(AppRoute.ExamReviewBoard(examId, task.questionId, task.mode))}>
            <div>
              <div className="font-medium">{formatQuestionLabel(task.position, task.questionTitle)}</div>
            </div>
            <div className="flex gap-2">
              <Badge variant="outline">待处理 {task.pendingCount}</Badge>
              <Badge variant="secondary">已完成 {task.completedCount}</Badge>
            </div>
          </button>
        ))}
        {showProgressLink ? (
          <div className="pt-1">
            <Button type="button" onClick={() => navigate(AppRoute.ExamProgress(examId))}>查看批改进度</Button>
          </div>
        ) : null}
      </CardContent>
    </Card>
  )
}

function formatQuestionLabel(position: number, title?: string | null) {
  return title && title.trim() ? `第 ${position} 题 · ${title}` : `第 ${position} 题`
}
