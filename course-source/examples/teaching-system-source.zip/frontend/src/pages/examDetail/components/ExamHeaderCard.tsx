import { Link } from 'react-router-dom'

import { Button, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'
import { AppRoute } from '@/shared/routing/AppRoutes'

import { formatExamDateTime } from '../functions/examDetailHelpers'

export function ExamHeaderCard({ detail, isTeacher }: { detail: ExamDetailResponse; isTeacher: boolean }) {
  const allAnswerSheetsImported = detail.questions.every((question) =>
    detail.answerSheets.filter((sheet) => sheet.questionId === question.id).length >= detail.participantStudents.length,
  )

  return (
    <Card className="relative border-slate-200 bg-white">
      <CardHeader>
        <div className="flex items-start justify-between gap-3 pr-40">
          <div>
            <CardTitle className="text-2xl">{detail.exam.title}</CardTitle>
            <CardDescription>{detail.course.title} / 创建于 {formatExamDateTime(detail.exam.createdAt)}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="text-sm text-slate-500">
          共 {detail.questions.length} 题，由 {detail.exam.createdBy.displayName} 创建。
          {detail.exam.appealDueAt ? ` 申诉截止：${formatExamDateTime(detail.exam.appealDueAt)}` : ''}
        </div>
      </CardContent>
      {isTeacher && !detail.exam.publishedAt ? (
        <div className="absolute right-6 bottom-6 flex flex-col items-end gap-1">
          <Button type="button">
            <Link to={AppRoute.ExamImport(detail.exam.id)}>导入答题图片</Link>
          </Button>
          {allAnswerSheetsImported ? <span className="text-sm text-emerald-700">已全部导入完成</span> : null}
        </div>
      ) : null}
    </Card>
  )
}
