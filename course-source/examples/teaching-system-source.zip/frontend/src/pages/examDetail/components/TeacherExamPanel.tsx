import { useNavigate } from 'react-router-dom'

import { Alert, AlertDescription, Button } from '@/components/ui'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'
import { ExamReviewOperation } from '@/pages/objects/ExamReviewWorkflow'
import { AppRoute } from '@/shared/routing/AppRoutes'
import { TeacherAppealTasks, TeacherTaskTabs } from './TeacherTaskTabs'
import { TeacherScoreboard } from './TeacherScoreboard'

export function TeacherExamPanel({
  detail,
  publishError,
  isBusy,
}: {
  detail: ExamDetailResponse
  publishError: string
  isBusy: boolean
}) {
  void isBusy
  const navigate = useNavigate()
  const hasGradingTask = detail.teacherTasks.some((task) => task.mode === ExamReviewOperation.Grading)

  return (
    <div className="space-y-6">
      {!detail.exam.publishedAt ? <TeacherTaskTabs detail={detail} /> : null}
      {!detail.exam.publishedAt && !hasGradingTask ? (
        <Button type="button" onClick={() => navigate(AppRoute.ExamProgress(detail.exam.id))}>查看批改进度</Button>
      ) : null}
      {detail.exam.publishedAt ? <TeacherAppealTasks detail={detail} /> : null}

      {!detail.exam.publishedAt ? (
        publishError ? <Alert variant="destructive" className="border-rose-200 bg-rose-50 text-rose-700"><AlertDescription className="text-rose-700">{publishError}</AlertDescription></Alert> : null
      ) : null}

      {detail.exam.publishedAt ? <TeacherScoreboard detail={detail} /> : null}
    </div>
  )
}
