import { useNavigate } from 'react-router-dom'

import { Badge, Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

export function StudentExamPanel({ detail }: { detail: ExamDetailResponse }) {
  const navigate = useNavigate()

  return (
    <Card className="border-cyan-100 bg-white">
      <CardHeader>
        <CardTitle className="text-lg">考试成绩</CardTitle>
        <CardDescription>发布前仅显示未发布状态；发布后展示总分和每题分数。</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-2xl border border-cyan-100 bg-cyan-50 p-4">
          <div className="text-sm text-slate-500">总分</div>
          <div className="mt-1 text-2xl font-semibold">
            {detail.studentResult?.published ? `${detail.studentResult.totalScore ?? '--'} / ${detail.studentResult.totalFullScore}` : '未发布'}
          </div>
        </div>
        {detail.studentResult?.questions.map((question) => (
          <button key={question.questionId} type="button" disabled={!detail.studentResult?.published} className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 text-left transition enabled:hover:bg-teal-50 disabled:cursor-not-allowed disabled:opacity-70" onClick={() => detail.studentResult?.published ? navigate(`/exams/${detail.exam.id}/questions/${question.questionId}`) : undefined}>
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="font-medium">{formatQuestionLabel(question.position, question.title)}</div>
                <div className="mt-1 text-sm text-slate-500">{detail.studentResult?.published ? `${question.score ?? '--'} / ${question.fullScore}` : '未发布'}</div>
              </div>
              {question.canAppeal ? <Badge variant="outline">可申诉</Badge> : null}
            </div>
          </button>
        ))}
      </CardContent>
    </Card>
  )
}

function formatQuestionLabel(position: number, title?: string | null) {
  return title && title.trim() ? `第 ${position} 题 · ${title}` : `第 ${position} 题`
}
