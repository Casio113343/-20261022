import type { Attachment } from '@/infrastructure/storage/Attachment'
import { resolveAssetUrl } from '@/infrastructure/storage/assetUrl'

export function ExamAnswerImageGallery({
  images,
  emptyText,
  maxHeightClass = 'max-h-[680px]',
}: {
  images: Attachment[]
  emptyText: string
  maxHeightClass?: string
}) {
  if (!images.length) {
    return <div className="rounded-xl border border-dashed border-slate-300 p-6 text-sm text-slate-500">{emptyText}</div>
  }

  return (
    <div className="space-y-4">
      {images.map((image) => (
        <a key={image.fileName} href={resolveAssetUrl(image.dataUrl)} target="_blank" rel="noreferrer">
          <img src={resolveAssetUrl(image.dataUrl)} alt="" className={`${maxHeightClass} w-full object-contain`} />
        </a>
      ))}
    </div>
  )
}
