import { useNavigate } from 'react-router-dom'

import { Card, CardContent, CardDescription, CardHeader, CardTitle, Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

export function TeacherScoreboard({ detail }: { detail: ExamDetailResponse }) {
  const navigate = useNavigate()
  const totalScores = detail.scoreRows.flatMap((row) => row.totalScore ?? [])
  const classAverageScore = totalScores.length ? (totalScores.reduce((sum, score) => sum + Number(score), 0) / totalScores.length).toFixed(1) : null
  const totalFullScore = detail.questions.reduce((sum, question) => sum + question.scoring.fullScore, 0)

  return (
    <Card className="border-slate-200 bg-white">
      <CardHeader>
        <CardTitle className="text-lg">学生成绩单</CardTitle>
        <CardDescription>每行一位学生，点击小题分数可查看该生该题作答。</CardDescription>
      </CardHeader>
      <CardContent>
        {classAverageScore !== null ? <div className="mb-4 text-sm text-slate-500">班级平均分：{classAverageScore} / {totalFullScore}</div> : null}
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>姓名</TableHead>
                <TableHead>总分</TableHead>
                {detail.questions.map((question) => <TableHead key={question.id}>{formatQuestionLabel(question.position, question.title)} / {question.scoring.fullScore}</TableHead>)}
              </TableRow>
            </TableHeader>
            <TableBody>
              {detail.scoreRows.map((row) => (
                <TableRow key={row.student.id}>
                  <TableCell>{row.student.displayName}</TableCell>
                  <TableCell>{row.totalScore ?? '--'}</TableCell>
                  {row.questions.map((cell) => (
                    <TableCell key={`${row.student.id}-${cell.questionId}`}>
                      <button type="button" className="text-sky-700 underline-offset-4 hover:underline" onClick={() => navigate(`/exams/${detail.exam.id}/students/${row.student.id}/questions/${cell.questionId}`)}>
                        {cell.score ?? '--'}
                      </button>
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

function formatQuestionLabel(position: number, title?: string | null) {
  return title && title.trim() ? `第 ${position} 题 · ${title}` : `第 ${position} 题`
}
