import { useEffect, useState, type FormEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { FetchCourseDetailAPIMessage } from '@/microservices/course/api/FetchCourseDetailAPIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { CreateQuestionnaireAPIMessage } from '@/microservices/questionnaire/api/CreateQuestionnaireAPIMessage'
import { QuestionnaireInput } from '@/microservices/questionnaire/api/requests/QuestionnaireInput'
import { QuestionnaireQuestion } from '@/microservices/questionnaire/objects/QuestionnaireQuestion'
import { QuestionnaireQuestionType } from '@/microservices/questionnaire/objects/QuestionnaireQuestionType'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoute } from '@/shared/routing/AppRoutes'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'

function emptyQuestion() {
  return new QuestionnaireQuestion('', '', QuestionnaireQuestionType.SingleChoice, true, ['', ''])
}

function parseDatetimeLocal(value: string) {
  if (!value.trim()) return { error: '请选择问卷截止时间。', value: '' }
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return { error: '请选择有效的问卷截止时间。', value: '' }
  return { error: '', value: date.toISOString() }
}

export function useQuestionnaireCreatePage() {
  const { courseId } = useParams<{ courseId: string }>()
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser } = useEnsureDashboard(navigate)
  const [course, setCourse] = useState<CourseDetailResponse | null | undefined>(undefined)
  const [title, setTitle] = useState('')
  const [overview, setOverview] = useState('')
  const [anonymous, setAnonymous] = useState(false)
  const [dueAt, setDueAt] = useState('')
  const [questions, setQuestions] = useState<QuestionnaireQuestion[]>([emptyQuestion()])
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)

  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  useEffect(() => {
    if (!courseId || !currentUser) return
    void sendAPI(new FetchCourseDetailAPIMessage(courseId, currentUser.id)).run()
      .then(setCourse)
      .catch(() => setCourse(null))
  }, [courseId, currentUser?.id])

  const updateQuestion = (index: number, nextQuestion: QuestionnaireQuestion) => {
    setQuestions((current) => current.map((question, itemIndex) => itemIndex === index ? nextQuestion : question))
  }

  const updateOption = (questionIndex: number, optionIndex: number, value: string) => {
    setQuestions((current) => current.map((question, itemIndex) => {
      if (itemIndex !== questionIndex) return question
      return new QuestionnaireQuestion(question.id, question.title, question.questionType, question.required, question.options.map((option, currentOptionIndex) => currentOptionIndex === optionIndex ? value : option))
    }))
  }

  const addOption = (questionIndex: number) => {
    setQuestions((current) => current.map((question, itemIndex) => itemIndex === questionIndex ? new QuestionnaireQuestion(question.id, question.title, question.questionType, question.required, question.options.concat('')) : question))
  }

  const removeOption = (questionIndex: number, optionIndex: number) => {
    setQuestions((current) => current.map((question, itemIndex) => {
      if (itemIndex !== questionIndex || question.options.length <= 2) return question
      return new QuestionnaireQuestion(question.id, question.title, question.questionType, question.required, question.options.filter((_, currentOptionIndex) => currentOptionIndex !== optionIndex))
    }))
  }

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!courseId || !currentUser) return
    setErrorMessage('')
    setSuccessMessage('')
    if (!title.trim()) {
      setErrorMessage('问卷标题不能为空。')
      return
    }
    const dueAtResult = parseDatetimeLocal(dueAt)
    if (dueAtResult.error) {
      setErrorMessage(dueAtResult.error)
      return
    }
    const normalizedQuestions = questions.map((question) => new QuestionnaireQuestion(
      question.id,
      question.title.trim(),
      question.questionType,
      question.required,
      question.questionType === QuestionnaireQuestionType.Text ? [] : question.options.map((option) => option.trim()).filter(Boolean),
    ))
    const invalidQuestionIndex = normalizedQuestions.findIndex((question) => !question.title || (question.questionType !== QuestionnaireQuestionType.Text && question.options.length < 2))
    if (invalidQuestionIndex >= 0) {
      setErrorMessage(`第 ${invalidQuestionIndex + 1} 题填写不完整。`)
      return
    }
    setIsBusy(true)
    try {
      const detail = await sendAPI(new CreateQuestionnaireAPIMessage(courseId, currentUser.id, new QuestionnaireInput(title.trim(), overview.trim() || undefined, anonymous, normalizedQuestions, dueAtResult.value))).run()
      setSuccessMessage('问卷创建成功。')
      navigate(AppRoute.QuestionnaireDetail(detail.questionnaire.id))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '创建问卷失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    anonymous,
    course,
    courseId,
    currentUser,
    dueAt,
    errorMessage,
    isBusy,
    overview,
    questions,
    successMessage,
    title,
    addOption,
    addQuestion: () => setQuestions((current) => current.concat(emptyQuestion())),
    removeOption,
    removeQuestion: (index: number) => setQuestions((current) => current.length === 1 ? current : current.filter((_, itemIndex) => itemIndex !== index)),
    setAnonymous,
    setDueAt,
    setOverview,
    setTitle,
    submit,
    updateOption,
    updateQuestion,
  }
}
