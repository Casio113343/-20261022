import { Navigate } from 'react-router-dom'

import { Button, Checkbox, Input, Label, Select, SelectContent, SelectItem, SelectTrigger, SelectValue, Textarea } from '@/components/ui'
import { QuestionnaireQuestionType } from '@/microservices/questionnaire/objects/QuestionnaireQuestionType'
import { CourseFormShell, InlineError, InlineSuccess } from '@/shared/forms/FormHelpers'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { useQuestionnaireCreatePage } from './hooks/useQuestionnaireCreatePage'

export default function QuestionnaireCreatePage() {
  const page = useQuestionnaireCreatePage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (page.course === null) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <CourseFormShell title="创建问卷" description={page.course ? `课程：${page.course.course.title}` : '正在加载课程信息。'} backTo={page.courseId ? AppRoute.CourseWorkspace(page.courseId) : AppRoutePath.Dashboard} backLabel="返回课程工作区">
      <form className="space-y-5" onSubmit={page.submit}>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2"><Label>标题</Label><Input value={page.title} onChange={(event) => page.setTitle(event.target.value)} /></div>
          <div className="space-y-2"><Label>截止日期</Label><Input type="datetime-local" value={page.dueAt} onChange={(event) => page.setDueAt(event.target.value)} /></div>
          <div className="space-y-2 md:col-span-2"><Label>概述</Label><Textarea value={page.overview} onChange={(event) => page.setOverview(event.target.value)} placeholder="选填" /></div>
          <label className="flex items-center gap-2 text-sm">
            <Checkbox checked={page.anonymous} onCheckedChange={(checked) => page.setAnonymous(Boolean(checked))} />
            匿名问卷
          </label>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>题目</Label>
            <Button type="button" variant="outline" onClick={page.addQuestion}>添加题目</Button>
          </div>
          {page.questions.map((question, index) => (
            <div key={`question-${index}`} className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="flex items-center justify-between">
                <div className="font-medium">第 {index + 1} 题</div>
                <Button type="button" variant="ghost" onClick={() => page.removeQuestion(index)}>删除</Button>
              </div>
              <div className="grid gap-4 md:grid-cols-[1fr_12rem]">
                <div className="space-y-2"><Label>题目</Label><Input value={question.title} onChange={(event) => page.updateQuestion(index, { ...question, title: event.target.value })} /></div>
                <div className="space-y-2">
                  <Label>类型</Label>
                  <Select value={question.questionType} onValueChange={(value) => page.updateQuestion(index, { ...question, questionType: value, options: value === QuestionnaireQuestionType.Text ? [] : question.options.length >= 2 ? question.options : ['', ''] })}>
                    <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={QuestionnaireQuestionType.SingleChoice}>单选</SelectItem>
                      <SelectItem value={QuestionnaireQuestionType.MultipleChoice}>多选</SelectItem>
                      <SelectItem value={QuestionnaireQuestionType.Text}>简答</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={question.required} onCheckedChange={(checked) => page.updateQuestion(index, { ...question, required: Boolean(checked) })} />
                必填
              </label>
              {question.questionType !== QuestionnaireQuestionType.Text ? (
                <div className="space-y-2">
                  <Label>选项</Label>
                  {question.options.map((option, optionIndex) => (
                    <div key={`option-${optionIndex}`} className="flex gap-2">
                      <Input value={option} onChange={(event) => page.updateOption(index, optionIndex, event.target.value)} />
                      <Button type="button" variant="ghost" onClick={() => page.removeOption(index, optionIndex)}>移除</Button>
                    </div>
                  ))}
                  <Button type="button" variant="outline" onClick={() => page.addOption(index)}>添加选项</Button>
                </div>
              ) : null}
            </div>
          ))}
        </div>
        <Button type="submit" disabled={page.isBusy}>{page.isBusy ? '创建中...' : '创建问卷'}</Button>
        {page.errorMessage ? <InlineError message={page.errorMessage} /> : null}
        {page.successMessage ? <InlineSuccess message={page.successMessage} /> : null}
      </form>
    </CourseFormShell>
  )
}
