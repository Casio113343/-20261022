import { Navigate } from 'react-router-dom'

import { Button, Checkbox, Input, Label } from '@/components/ui'
import { CourseFormShell, InlineError, InlineSuccess } from '@/shared/forms/FormHelpers'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { BulkSettingsPanel } from './components/BulkSettingsPanel'
import { QuestionEditor } from './components/QuestionEditor'
import { useExamCreatePage } from './hooks/useExamCreatePage'

export default function ExamCreatePage() {
  const page = useExamCreatePage()

  if (!page.currentUser) return <Navigate replace to={AppRoutePath.Login} />
  if (page.course === null) return <Navigate replace to={AppRoutePath.Dashboard} />

  return (
    <CourseFormShell title={page.examId ? '编辑线下考试' : '创建线下考试'} description={page.course ? `课程：${page.course.course.title}` : '正在加载课程信息。'} backTo={page.examId ? AppRoute.ExamDetail(page.examId) : page.courseId ? AppRoute.CourseWorkspace(page.courseId) : AppRoutePath.Dashboard} backLabel={page.examId ? '返回考试详情' : '返回课程工作区'}>
      <form className="space-y-5" onSubmit={page.handleSubmit}>
        <div className="space-y-2"><Label>考试名称</Label><Input value={page.title} onChange={(event) => page.setTitle(event.target.value)} /></div>

        <div className="space-y-4">
          <div className="flex items-center justify-between mt-10">
            <Label>题目配置</Label>
          </div>
          
          <BulkSettingsPanel
            open={page.bulkEditorOpen}
            bulkQuestion={page.bulkQuestion}
            onBulkQuestionChange={page.setBulkQuestion}
            onApply={page.applyBulkSettings}
            onOpen={page.openBulkSettings}
            onCancel={page.cancelBulkSettings}
            courseTeacherOptions={page.course?.course.teachers ?? []}
          />

          {page.questions.map((question, index) => (
            <div key={question.questionId ?? `question-${index}`} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {page.bulkEditorOpen ? <Checkbox checked={page.selectedQuestionIndexes.includes(index)} onCheckedChange={(checked) => page.toggleQuestionSelected(index, Boolean(checked))} /> : null}
                  <div className="font-medium">第 {index + 1} 题</div>
                </div>
                <Button type="button" variant="ghost" onClick={() => page.removeQuestion(index)}>删除</Button>
              </div>
              <QuestionEditor courseTeacherOptions={page.course?.course.teachers ?? []} question={question} onChange={(nextQuestion) => page.updateQuestion(index, nextQuestion)} showTitle />
            </div>
          ))}
        </div>
        <div className="flex justify-end">
          <Button type="button" variant="outline" onClick={page.addQuestion}>添加题目</Button>
        </div>
        <div className="space-y-2 "><Label>申诉截止时间</Label><Input type="datetime-local" value={page.appealDueAt} onChange={(event) => page.setAppealDueAt(event.target.value)} /></div>
        <Button type="submit" className="mt-4" disabled={page.isBusy}>{page.examId ? '保存考试' : '创建考试'}</Button>
        {page.errorMessage ? <InlineError message={page.errorMessage} /> : null}
        {page.successMessage ? <InlineSuccess message={page.successMessage} /> : null}
      </form>
    </CourseFormShell>
  )
}
