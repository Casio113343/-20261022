import type { ExamQuestionInput } from '@/microservices/exam/api/requests/ExamQuestionInput'

export function emptyQuestion(): ExamQuestionInput {
  return {
    questionId: null,
    title: '',
    fullScore: 0,
    graderTeacherIds: [''],
    arbitrationEnabled: false,
    arbitrationScoreDiffThreshold: null,
    arbitrationTeacherId: null,
    appealEnabled: false,
    appealTeacherId: null,
  }
}

export function getGraderCount(question: ExamQuestionInput) {
  return question.graderTeacherIds.length >= 2 ? 2 : 1
}

export function buildGraderSlots(current: string[], count: number) {
  return Array.from({ length: count }, (_, index) => current[index] ?? '')
}

export function normalizeQuestionForTeachers(question: ExamQuestionInput, teachers: { id: string }[]) {
  if (teachers.length === 1) {
    return {
      ...question,
      graderTeacherIds: [teachers[0].id],
      arbitrationEnabled: false,
      arbitrationScoreDiffThreshold: null,
      arbitrationTeacherId: null,
      appealTeacherId: question.appealEnabled ? teachers[0].id : null,
    }
  }

  if (teachers.length === 2 && getGraderCount(question) === 2) {
    return {
      ...question,
      graderTeacherIds: [teachers[0].id, teachers[1].id],
    }
  }

  return question
}

export function toDatetimeLocal(value: string) {
  const date = new Date(value)
  const pad = (input: number) => String(input).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
}

export function parseDatetimeLocal(value: string, emptyMessage: string, invalidMessage: string) {
  if (!value.trim()) {
    return { error: emptyMessage, value: null }
  }
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) {
    return { error: invalidMessage, value: null }
  }
  return { error: '', value: date.toISOString() }
}
