import { useEffect, useEffectEvent, useState, type FormEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { CreateExamAPIMessage } from '@/microservices/exam/api/CreateExamAPIMessage'
import { ExamDetailAPIMessage } from '@/microservices/exam/api/ExamDetailAPIMessage'
import { UpdateExamAPIMessage } from '@/microservices/exam/api/UpdateExamAPIMessage'
import type { ExamQuestionInput } from '@/microservices/exam/api/requests/ExamQuestionInput'
import { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { FetchCourseDetailAPIMessage } from '@/microservices/course/api/FetchCourseDetailAPIMessage'
import { useAutoDismissMessage } from '@/shared/hooks/useAutoDismissMessage'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { syncCourseDetailMutation } from '@/stores/session/functions/courseDetailSession'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'
import { emptyQuestion, normalizeQuestionForTeachers, parseDatetimeLocal, toDatetimeLocal } from '../functions/examCreateHelpers'

export function useExamCreatePage() {
  const { courseId, examId } = useParams<{ courseId: string; examId?: string }>()
  const navigate = useNavigate()
  useHydrateSession()
  const { currentUser, dashboard, setSession } = useEnsureDashboard(navigate)

  const [title, setTitle] = useState('')
  const [appealDueAt, setAppealDueAt] = useState('')
  const [questions, setQuestions] = useState<ExamQuestionInput[]>([emptyQuestion()])
  const [bulkEditorOpen, setBulkEditorOpen] = useState(false)
  const [selectedQuestionIndexes, setSelectedQuestionIndexes] = useState<number[]>([])
  const [bulkQuestion, setBulkQuestion] = useState<ExamQuestionInput>(emptyQuestion())
  const [errorMessage, setErrorMessage] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const [isBusy, setIsBusy] = useState(false)
  const [course, setCourse] = useState<CourseDetailResponse | null | undefined>(undefined)

  useAutoDismissMessage(errorMessage, setErrorMessage)
  useAutoDismissMessage(successMessage, setSuccessMessage)

  useEffect(() => {
    if (!courseId || !currentUser) return
    void sendAPI(new FetchCourseDetailAPIMessage(courseId, currentUser.id)).run()
      .then(setCourse)
      .catch(() => setCourse(null))
  }, [courseId, currentUser?.id])

  const loadExamDetail = useEffectEvent(async (nextExamId: string, operatorUserId: string) => {
    try {
      const detail = await sendAPI(new ExamDetailAPIMessage(nextExamId, operatorUserId)).run()
      setTitle(detail.exam.title)
      setAppealDueAt(detail.exam.appealDueAt ? toDatetimeLocal(detail.exam.appealDueAt) : '')
      setQuestions(detail.questions.map((question) => ({
        questionId: question.id,
        title: question.title,
        fullScore: question.scoring.fullScore,
        graderTeacherIds: question.scoring.graders.map((grader) => grader.id),
        arbitrationEnabled: question.scoring.arbitrationEnabled,
        arbitrationScoreDiffThreshold: question.scoring.arbitrationScoreDiffThreshold ?? null,
        arbitrationTeacherId: question.scoring.arbitrationTeacher?.id ?? null,
        appealEnabled: question.scoring.appealEnabled,
        appealTeacherId: question.scoring.appealTeacher?.id ?? null,
      })))
    } catch {
      navigate(AppRoutePath.Dashboard)
    }
  })

  useEffect(() => {
    if (!examId || !currentUser) return
    void loadExamDetail(examId, currentUser.id)
  }, [currentUser?.id, examId])

  useEffect(() => {
    if (!course) return
    const teachers = course.course.teachers
    setQuestions((current) => current.map((question) => normalizeQuestionForTeachers(question, teachers)))
    setBulkQuestion((current) => normalizeQuestionForTeachers(current, teachers))
  }, [course])

  const updateQuestion = (index: number, nextQuestion: ExamQuestionInput) => {
    setQuestions((current) => current.map((item, itemIndex) => itemIndex === index ? normalizeQuestionForTeachers(nextQuestion, course?.course.teachers ?? []) : item))
  }

  const addQuestion = () => {
    setQuestions((current) => current.concat(normalizeQuestionForTeachers(emptyQuestion(), course?.course.teachers ?? [])))
  }

  const removeQuestion = (index: number) => {
    setQuestions((current) => current.length === 1 ? current : current.filter((_, itemIndex) => itemIndex !== index))
    setSelectedQuestionIndexes((current) => current.filter((item) => item !== index))
  }

  const toggleQuestionSelected = (index: number, checked: boolean) => {
    setSelectedQuestionIndexes((current) => checked
      ? Array.from(new Set(current.concat(index)))
      : current.filter((item) => item !== index))
  }

  const cancelBulkSettings = () => {
    setBulkEditorOpen(false)
    setSelectedQuestionIndexes([])
  }

  const applyBulkSettings = () => {
    if (!selectedQuestionIndexes.length) {
      setErrorMessage('请先选择要批量设置的题目。')
      return
    }
    setQuestions((current) => current.map((question, index) => {
      if (!selectedQuestionIndexes.includes(index)) return question
      return {
        ...normalizeQuestionForTeachers(question, course?.course.teachers ?? []),
        fullScore: bulkQuestion.fullScore,
        graderTeacherIds: [...bulkQuestion.graderTeacherIds],
        arbitrationEnabled: bulkQuestion.arbitrationEnabled,
        arbitrationScoreDiffThreshold: bulkQuestion.arbitrationScoreDiffThreshold,
        arbitrationTeacherId: bulkQuestion.arbitrationTeacherId,
        appealEnabled: bulkQuestion.appealEnabled,
        appealTeacherId: bulkQuestion.appealTeacherId,
      }
    }))
    setErrorMessage('')
  }

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!courseId || !currentUser) return

    const duplicateQuestion = questions.find((question) => {
      const normalized = question.graderTeacherIds.map((item) => item.trim()).filter(Boolean)
      return normalized.length !== new Set(normalized).size
    })
    const hasAppealQuestion = questions.some((question) => question.appealEnabled)
    if (duplicateQuestion) {
      setErrorMessage('同一道题的两位批改教师必须不同。')
      return
    }
    if (hasAppealQuestion && !appealDueAt) {
      setErrorMessage('存在允许申诉的题目时，必须设置申诉截止时间。')
      return
    }
    const appealDueAtResult = appealDueAt
      ? parseDatetimeLocal(appealDueAt, '请选择申诉截止时间。', '请选择有效的申诉截止时间。')
      : { error: '', value: null }
    if (appealDueAtResult.error) {
      setErrorMessage(appealDueAtResult.error)
      return
    }

    setErrorMessage('')
    setSuccessMessage('')
    setIsBusy(true)
    try {
      const payload = {
        title: title.trim(),
        questions,
        appealDueAt: appealDueAtResult.value ?? undefined,
      }
      const nextCourse = examId
        ? await sendAPI(new UpdateExamAPIMessage(courseId, examId, currentUser.id, payload)).run()
        : await sendAPI(new CreateExamAPIMessage(courseId, currentUser.id, payload)).run()
      syncCourseDetailMutation(dashboard, nextCourse, setSession, setCourse)
      setSuccessMessage(examId ? '考试更新成功。' : '考试创建成功。')
      navigate(examId ? AppRoute.ExamDetail(examId) : AppRoute.CourseWorkspace(nextCourse.course.id), { state: { optimisticCourseDetail: nextCourse } })
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : examId ? '考试更新失败' : '考试创建失败')
    } finally {
      setIsBusy(false)
    }
  }

  return {
    course,
    courseId,
    currentUser,
    examId,
    title,
    appealDueAt,
    questions,
    bulkEditorOpen,
    selectedQuestionIndexes,
    bulkQuestion,
    errorMessage,
    successMessage,
    isBusy,
    setTitle,
    setAppealDueAt,
    setBulkQuestion,
    openBulkSettings: () => setBulkEditorOpen(true),
    cancelBulkSettings,
    applyBulkSettings,
    addQuestion,
    removeQuestion,
    updateQuestion,
    toggleQuestionSelected,
    handleSubmit,
  }
}
