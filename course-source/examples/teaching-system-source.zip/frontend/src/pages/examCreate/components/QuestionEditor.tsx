import { Input, Label, Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui'
import type { ExamQuestionInput } from '@/microservices/exam/api/requests/ExamQuestionInput'
import { CheckboxText } from '@/shared/forms/FormHelpers'

import { buildGraderSlots, getGraderCount, normalizeQuestionForTeachers } from '../functions/examCreateHelpers'

class QuestionEditorProps {
  question!: ExamQuestionInput
  onChange!: (nextQuestion: ExamQuestionInput) => void
  courseTeacherOptions!: { id: string; displayName: string }[]
  showTitle?: boolean
}

export function QuestionEditor({
  question,
  onChange,
  courseTeacherOptions,
  showTitle = false,
}: QuestionEditorProps) {
  const teacherCount = courseTeacherOptions.length
  const questionWithTeacherDefaults = normalizeQuestionForTeachers(question, courseTeacherOptions)
  const graderCount = getGraderCount(questionWithTeacherDefaults)
  const setDoubleGrading = (enabled: boolean) => {
    onChange(normalizeQuestionForTeachers({
      ...questionWithTeacherDefaults,
      graderTeacherIds: buildGraderSlots(questionWithTeacherDefaults.graderTeacherIds, enabled ? 2 : 1),
      arbitrationEnabled: enabled ? questionWithTeacherDefaults.arbitrationEnabled : false,
      arbitrationScoreDiffThreshold: enabled ? questionWithTeacherDefaults.arbitrationScoreDiffThreshold : null,
      arbitrationTeacherId: enabled ? questionWithTeacherDefaults.arbitrationTeacherId : null,
    }, courseTeacherOptions))
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {showTitle ? <div className="space-y-2"><Label>题目名称</Label><Input placeholder="选填" value={questionWithTeacherDefaults.title} onChange={(event) => onChange({ ...questionWithTeacherDefaults, title: event.target.value })} /></div> : null}
      <div className="space-y-2"><Label>分值</Label><Input type="number" min={1} value={questionWithTeacherDefaults.fullScore > 0 ? String(questionWithTeacherDefaults.fullScore) : ''} onChange={(event) => onChange({ ...questionWithTeacherDefaults, fullScore: Number(event.target.value || 0) })} /></div>
      {Array.from({ length: graderCount }).map((_, graderIndex) => (
        <div key={`grader-${graderIndex}`} className="space-y-2">
          <Label>{graderCount === 1 ? '批改教师' : `批改教师 ${graderIndex + 1}`}</Label>
          <Select value={questionWithTeacherDefaults.graderTeacherIds[graderIndex] ?? ''} disabled={teacherCount <= 1 || (teacherCount === 2 && graderCount === 2)} onValueChange={(value) => onChange({ ...questionWithTeacherDefaults, graderTeacherIds: buildGraderSlots(questionWithTeacherDefaults.graderTeacherIds, graderCount).map((item, indexValue) => indexValue === graderIndex ? value : item) })}>
            <SelectTrigger className="bg-white"><SelectValue placeholder="请选择老师" /></SelectTrigger>
            <SelectContent>{courseTeacherOptions.map((teacher) => <SelectItem key={`${teacher.id}-${graderIndex}`} value={teacher.id}>{teacher.displayName}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      ))}
      {teacherCount > 1 ? (
        <div className="flex items-end gap-6 pb-2 md:col-span-2">
          <CheckboxText checked={graderCount === 2} label="双批" onChange={setDoubleGrading} />
          {graderCount === 2 ? <CheckboxText checked={questionWithTeacherDefaults.arbitrationEnabled} label="开启仲裁" onChange={(checked) => onChange({ ...questionWithTeacherDefaults, arbitrationEnabled: checked, arbitrationScoreDiffThreshold: checked ? questionWithTeacherDefaults.arbitrationScoreDiffThreshold : null, arbitrationTeacherId: checked ? questionWithTeacherDefaults.arbitrationTeacherId : null })} /> : null}
        </div>
      ) : null}
      {graderCount === 2 && questionWithTeacherDefaults.arbitrationEnabled ? (
        <>
          <div className="space-y-2">
            <Label>仲裁教师</Label>
            <Select value={questionWithTeacherDefaults.arbitrationTeacherId ?? ''} onValueChange={(value) => onChange({ ...questionWithTeacherDefaults, arbitrationTeacherId: value })}>
              <SelectTrigger className="bg-white"><SelectValue placeholder="请选择老师" /></SelectTrigger>
              <SelectContent>{courseTeacherOptions.map((teacher) => <SelectItem key={`arb-${teacher.id}`} value={teacher.id}>{teacher.displayName}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-2"><Label>分差阈值</Label><Input type="number" min={0} value={questionWithTeacherDefaults.arbitrationScoreDiffThreshold ?? ''} onChange={(event) => onChange({ ...questionWithTeacherDefaults, arbitrationScoreDiffThreshold: event.target.value === '' ? null : Number(event.target.value) })} /></div>
        </>
      ) : null}
      <div className="flex items-end pb-2 md:col-span-2">
        <CheckboxText checked={questionWithTeacherDefaults.appealEnabled} label="允许申诉" onChange={(checked) => onChange(normalizeQuestionForTeachers({ ...questionWithTeacherDefaults, appealEnabled: checked, appealTeacherId: checked ? questionWithTeacherDefaults.appealTeacherId : null }, courseTeacherOptions))} />
      </div>
      {questionWithTeacherDefaults.appealEnabled ? (
        <div className="space-y-2 md:col-span-2">
          <Label>申诉处理教师</Label>
          <Select value={questionWithTeacherDefaults.appealTeacherId ?? ''} disabled={teacherCount === 1} onValueChange={(value) => onChange({ ...questionWithTeacherDefaults, appealTeacherId: value })}>
            <SelectTrigger className="bg-white"><SelectValue placeholder="请选择老师" /></SelectTrigger>
            <SelectContent>{courseTeacherOptions.map((teacher) => <SelectItem key={`appeal-${teacher.id}`} value={teacher.id}>{teacher.displayName}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      ) : null}
    </div>
  )
}
