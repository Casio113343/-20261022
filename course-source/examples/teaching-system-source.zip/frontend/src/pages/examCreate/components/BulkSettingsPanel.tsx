import { Button, Label } from '@/components/ui'
import type { ExamQuestionInput } from '@/microservices/exam/api/requests/ExamQuestionInput'

import { QuestionEditor } from './QuestionEditor'

class BulkSettingsPanelProps {
  open!: boolean
  bulkQuestion!: ExamQuestionInput
  onBulkQuestionChange!: (next: ExamQuestionInput) => void
  onApply!: () => void
  onOpen!: () => void
  onCancel!: () => void
  courseTeacherOptions!: { id: string; displayName: string }[]
}

export function BulkSettingsPanel({
  open,
  bulkQuestion,
  onBulkQuestionChange,
  onApply,
  onOpen,
  onCancel,
  courseTeacherOptions,
}: BulkSettingsPanelProps) {
  if (!open) return <Button type="button" variant="outline" onClick={onOpen}>打开批量设置</Button>

  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
      <div className="mb-4 flex items-center justify-between">
        <Label>批量设置选中题目</Label>
        <Button type="button" variant="outline" onClick={onCancel}>取消批量设置</Button>
      </div>
      <QuestionEditor courseTeacherOptions={courseTeacherOptions} question={bulkQuestion} onChange={onBulkQuestionChange} />
      <div className="mt-4">
        <Button type="button" variant="outline" onClick={onApply}>应用到选中题目</Button>
      </div>
    </div>
  )
}
