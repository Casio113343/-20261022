import { useEffect } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { CreateCourseChatMessageAPIMessage } from '@/microservices/course/api/CreateCourseChatMessageAPIMessage'
import { DeleteCourseAPIMessage } from '@/microservices/course/api/DeleteCourseAPIMessage'
import { LeaveCourseAPIMessage } from '@/microservices/course/api/LeaveCourseAPIMessage'
import { RevokeCourseChatMessageAPIMessage } from '@/microservices/course/api/RevokeCourseChatMessageAPIMessage'
import { UserRole } from '@/microservices/auth/objects/UserRole'
import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'
import { useChatPreferencesStore } from '@/stores/course/useChatPreferencesStore'
import { useCourseSelectionStore, useSelectedCourseId } from '@/stores/dashboard/useCourseSelectionStore'
import { useDashboardUiStore } from '@/stores/dashboard/useDashboardUiStore'
import { useEnsureDashboard } from '@/stores/session/useEnsureDashboard'
import { useHydrateSession } from '@/stores/session/useHydrateSession'

import { useCourseWorkspaceData } from './useCourseWorkspaceData'

export function useCourseWorkspacePage() {
  const { courseId } = useParams<{ courseId: string }>()
  const navigate = useNavigate()
  const location = useLocation()
  useHydrateSession()

  const { currentUser, dashboard, setSession } = useEnsureDashboard(navigate)
  const currentUserId = currentUser?.id ?? ''
  const persistedCourseId = useSelectedCourseId(currentUserId)
  const persistSelectedCourseId = useCourseSelectionStore((state) => state.setSelectedCourseId)
  const selectedTab = useDashboardUiStore((state) => state.selectedTab)
  const setSelectedTab = useDashboardUiStore((state) => state.setSelectedTab)
  const hideChatMessage = useChatPreferencesStore((state) => state.hideChatMessage)
  const markChatSeen = useChatPreferencesStore((state) => state.markChatSeen)

  const availableCourseIds = new Set(dashboard?.courseSummaries.map((item) => item.course.id) ?? [])
  const fallbackCourseId = availableCourseIds.has(persistedCourseId)
    ? persistedCourseId
    : dashboard?.courseSummaries[0]?.course.id ?? ''
  const selectedCourseId = courseId && availableCourseIds.has(courseId) ? courseId : fallbackCourseId

  useEffect(() => {
    if (!currentUserId || !selectedCourseId) return
    persistSelectedCourseId(currentUserId, selectedCourseId)
  }, [currentUserId, persistSelectedCourseId, selectedCourseId])

  const courseData = useCourseWorkspaceData(currentUserId, selectedCourseId, location.state, dashboard, setSession)
  const isTeacher = currentUser?.role === UserRole.Teacher
  const selectedCourseTitle = courseData.selectedCourseWithChat?.course.title ?? '课程工作区'

  return {
    currentUser,
    dashboard,
    courseId,
    selectedCourseId,
    selectedCourseTitle,
    selectedTab,
    setSelectedTab,
    isTeacher,
    courseData,
    openDashboard: () => navigate(AppRoutePath.Dashboard),
    openProfile: () => navigate(AppRoutePath.Profile),
    openSelectedCourse: () => {
      if (selectedCourseId) navigate(AppRoute.CourseWorkspace(selectedCourseId))
    },
    openCourse: (nextCourseId: string) => navigate(AppRoute.CourseWorkspace(nextCourseId)),
    openAnnouncement: (announcementId: string) => navigate(AppRoute.AnnouncementDetail(announcementId)),
    openAssignment: (assignmentId: string) => navigate(isTeacher ? AppRoute.ReviewBoard(assignmentId) : AppRoute.AssignmentDetail(assignmentId)),
    openExam: (examId: string) => navigate(AppRoute.ExamDetail(examId)),
    openQuestionnaire: (questionnaireId: string) => navigate(AppRoute.QuestionnaireDetail(questionnaireId)),
    openAnnouncementCreate: (nextCourseId: string) => navigate(AppRoute.AnnouncementCreate(nextCourseId)),
    openAssignmentCreate: (nextCourseId: string) => navigate(AppRoute.AssignmentCreate(nextCourseId)),
    openMemberManage: (nextCourseId: string) => navigate(AppRoute.CourseMembersManage(nextCourseId)),
    openExamCreate: (nextCourseId: string) => navigate(AppRoute.ExamCreate(nextCourseId)),
    openQuestionnaireCreate: (nextCourseId: string) => navigate(AppRoute.QuestionnaireCreate(nextCourseId)),
    leaveCourse: async (nextCourseId: string) => {
      if (!currentUser) return
      const nextDashboard = await sendAPI(new LeaveCourseAPIMessage(nextCourseId, currentUser.id)).run()
      setSession(nextDashboard)
      navigate(AppRoutePath.Dashboard)
    },
    deleteCourse: async (nextCourseId: string) => {
      if (!currentUser) return
      const nextDashboard = await sendAPI(new DeleteCourseAPIMessage(nextCourseId, currentUser.id)).run()
      setSession(nextDashboard)
      navigate(AppRoutePath.Dashboard)
    },
    createChatMessage: async (nextCourseId: string, payload: ConstructorParameters<typeof CreateCourseChatMessageAPIMessage>[2]) => {
      if (!currentUser) throw new Error('未登录')
      const nextMessage = await sendAPI(new CreateCourseChatMessageAPIMessage(nextCourseId, currentUser.id, payload)).run()
      return courseData.appendChatMessage(nextCourseId, nextMessage)
    },
    revokeChatMessage: async (nextCourseId: string, messageId: string) => {
      if (!currentUser) throw new Error('未登录')
      const nextMessage = await sendAPI(new RevokeCourseChatMessageAPIMessage(nextCourseId, messageId, currentUser.id)).run()
      return courseData.replaceChatMessage(nextCourseId, nextMessage)
    },
    hideChatMessage: (nextCourseId: string, messageId: string) => {
      if (!currentUser) return
      hideChatMessage(currentUser.id, nextCourseId, messageId)
    },
    readChatMessages: (nextCourseId: string, latestTimestamp: string) => {
      if (!currentUser) return
      markChatSeen(currentUser.id, nextCourseId, latestTimestamp)
    },
    loadOlderChatMessages: async (nextCourseId: string) => {
      if (nextCourseId !== selectedCourseId) return
      await courseData.loadOlderChatMessages()
    },
  }
}
