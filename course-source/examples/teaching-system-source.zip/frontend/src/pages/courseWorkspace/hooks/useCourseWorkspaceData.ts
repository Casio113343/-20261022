import { useEffect, useState } from 'react'

import { sendAPI } from '@/infrastructure/api/sendAPI'
import { FetchCourseChatTimelineAPIMessage } from '@/microservices/course/api/FetchCourseChatTimelineAPIMessage'
import { FetchCourseDetailAPIMessage } from '@/microservices/course/api/FetchCourseDetailAPIMessage'
import { buildCourseWebSocketUrl, CourseRealtimeEvent } from '@/microservices/course/lib/courseRealtime'
import { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { CourseChatMessage } from '@/microservices/course/api/responses/CourseChatMessage'
import type { UserDashboardResponse } from '@/microservices/dashboard/api/responses/UserDashboardResponse'
import {
  appendDashboardCourseChatMessage,
  replaceDashboardCourseChatMessage,
} from '@/stores/session/functions/chatSession'

const CHAT_PAGE_SIZE = 20

export function useCourseWorkspaceData(
  currentUserId: string,
  selectedCourseId: string,
  locationState: unknown,
  dashboard: UserDashboardResponse | null,
  setSession: (dashboard: UserDashboardResponse) => void,
) {
  const [selectedCourse, setSelectedCourse] = useState<CourseDetailResponse | null>(null)
  const [chatMessages, setChatMessages] = useState<CourseChatMessage[]>([])
  const [chatNextCursorSentAt, setChatNextCursorSentAt] = useState<string | null>(null)
  const [chatNextCursorRowIndex, setChatNextCursorRowIndex] = useState<number | null>(null)
  const [isLoadingChatInitial, setIsLoadingChatInitial] = useState(false)
  const [isLoadingChatHistory, setIsLoadingChatHistory] = useState(false)

  useEffect(() => {
    if (!currentUserId || !selectedCourseId) {
      setSelectedCourse(null)
      setChatMessages([])
      setChatNextCursorSentAt(null)
      setChatNextCursorRowIndex(null)
      setIsLoadingChatInitial(false)
      setIsLoadingChatHistory(false)
      return
    }

    let cancelled = false
    const optimisticDetail = readOptimisticCourseDetail(locationState, selectedCourseId)
    if (optimisticDetail) {
      setSelectedCourse(optimisticDetail)
      setChatMessages(optimisticDetail.chatMessages)
    } else {
      const summary = dashboard?.courseSummaries.find((item) => item.course.id === selectedCourseId)
      if (summary) {
        setSelectedCourse(new CourseDetailResponse(summary.course, [], [], [], [], [], [], []))
        setChatMessages([])
      }
    }
    setIsLoadingChatInitial(true)

    const detailRequest = sendAPI(new FetchCourseDetailAPIMessage(selectedCourseId, currentUserId)).run()
    const chatRequest = sendAPI(
      new FetchCourseChatTimelineAPIMessage(
        selectedCourseId,
        currentUserId,
        CHAT_PAGE_SIZE,
      ),
    ).run()

    void detailRequest
      .then((detail) => {
        if (cancelled) return
        const preferredDetail = preferOptimisticCourseDetail(
          optimisticDetail,
          detail,
        )
        setSelectedCourse(preferredDetail)
      })
      .catch(() => {
        if (cancelled) return
        setSelectedCourse(null)
        setChatMessages([])
        setChatNextCursorSentAt(null)
        setChatNextCursorRowIndex(null)
        setIsLoadingChatInitial(false)
      })

    void chatRequest
      .then((firstPage) => {
        if (cancelled) return
        setChatMessages(firstPage.messages)
        setChatNextCursorSentAt(firstPage.nextCursorSentAt)
        setChatNextCursorRowIndex(firstPage.nextCursorRowIndex)
      })
      .catch(() => {
        if (cancelled) return
        setChatNextCursorSentAt(null)
        setChatNextCursorRowIndex(null)
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoadingChatInitial(false)
        }
      })

    return () => {
      cancelled = true
    }
  }, [currentUserId, locationState, selectedCourseId])

  useEffect(() => {
    if (!selectedCourseId) return

    const socket = new WebSocket(buildCourseWebSocketUrl(selectedCourseId))
    socket.onmessage = (event) => {
      const payload = JSON.parse(event.data) as CourseRealtimeEvent
      if (payload.courseId !== selectedCourseId || !payload.chatMessage) return

      const eventMessage = payload.chatMessage
      const nextDashboard = payload.eventType === 'chat.message.revoked'
        ? replaceDashboardCourseChatMessage(
            dashboard,
            payload.courseId,
            eventMessage,
          )
        : appendDashboardCourseChatMessage(
            dashboard,
            payload.courseId,
            eventMessage,
          )
      if (nextDashboard) {
        setSession(nextDashboard)
      }

      setChatMessages((current) => {
        if (payload.eventType === 'chat.message.revoked') {
          return current.map((message) =>
            message.id === eventMessage.id ? eventMessage : message,
          )
        }
        return current.some((message) => message.id === eventMessage.id)
          ? current.map((message) =>
              message.id === eventMessage.id ? eventMessage : message,
            )
          : [...current, eventMessage].sort((left, right) =>
              left.sentAt.localeCompare(right.sentAt),
            )
      })
    }

    return () => {
      socket.close()
    }
  }, [dashboard, selectedCourseId, setSession])

  const selectedCourseWithChat = selectedCourse
    ? new CourseDetailResponse(
        selectedCourse.course,
        selectedCourse.announcements,
        selectedCourse.assignments,
        selectedCourse.submissions,
        selectedCourse.reviews,
        selectedCourse.exams,
        chatMessages,
        selectedCourse.memberHistory,
      )
    : null

  const appendChatMessage = (courseId: string, message: CourseChatMessage) => {
    const nextDashboard = appendDashboardCourseChatMessage(
      dashboard,
      courseId,
      message,
    )
    if (!nextDashboard) return message
    setSession(nextDashboard)
    setChatMessages((current) =>
      current.some((item) => item.id === message.id)
        ? current.map((item) => (item.id === message.id ? message : item))
        : [...current, message].sort((left, right) =>
            left.sentAt.localeCompare(right.sentAt),
          ),
    )
    return message
  }

  const replaceChatMessage = (courseId: string, message: CourseChatMessage) => {
    const nextDashboard = replaceDashboardCourseChatMessage(
      dashboard,
      courseId,
      message,
    )
    if (!nextDashboard) return message
    setSession(nextDashboard)
    setChatMessages((current) =>
      current.map((item) => (item.id === message.id ? message : item)),
    )
    return message
  }

  const loadOlderChatMessages = async () => {
    if (isLoadingChatInitial || isLoadingChatHistory) return
    if (!chatNextCursorSentAt || chatNextCursorRowIndex == null) return

    setIsLoadingChatHistory(true)
    try {
      const page = await sendAPI(
        new FetchCourseChatTimelineAPIMessage(
          selectedCourseId,
          currentUserId,
          CHAT_PAGE_SIZE,
          chatNextCursorSentAt,
          chatNextCursorRowIndex,
        ),
      ).run()
      setChatMessages((current) => {
        const currentIds = new Set(current.map((message) => message.id))
        const olderMessages = page.messages.filter(
          (message) => !currentIds.has(message.id),
        )
        return [...olderMessages, ...current]
      })
      setChatNextCursorSentAt(page.nextCursorSentAt)
      setChatNextCursorRowIndex(page.nextCursorRowIndex)
    } finally {
      setIsLoadingChatHistory(false)
    }
  }

  return {
    selectedCourseWithChat,
    chatInitialLoading: isLoadingChatInitial,
    chatHistoryLoading: isLoadingChatHistory,
    chatHasOlderMessages:
      chatNextCursorSentAt !== null && chatNextCursorRowIndex !== null,
    appendChatMessage,
    replaceChatMessage,
    loadOlderChatMessages,
  }
}

function readOptimisticCourseDetail(
  state: unknown,
  selectedCourseId: string,
) {
  if (
    !state ||
    typeof state !== 'object' ||
    !('optimisticCourseDetail' in state)
  ) {
    return null
  }
  const optimisticCourseDetail = (
    state as { optimisticCourseDetail?: CourseDetailResponse | null }
  ).optimisticCourseDetail
  return optimisticCourseDetail?.course.id === selectedCourseId
    ? optimisticCourseDetail
    : null
}

function preferOptimisticCourseDetail(
  optimisticDetail: CourseDetailResponse | null,
  fetchedDetail: CourseDetailResponse,
) {
  if (!optimisticDetail || optimisticDetail.course.id !== fetchedDetail.course.id) {
    return fetchedDetail
  }

  const fetchedExamIds = new Set(fetchedDetail.exams.map((exam) => exam.id))
  const hasMissingOptimisticExam = optimisticDetail.exams.some(
    (exam) => !fetchedExamIds.has(exam.id),
  )
  return hasMissingOptimisticExam ? optimisticDetail : fetchedDetail
}
