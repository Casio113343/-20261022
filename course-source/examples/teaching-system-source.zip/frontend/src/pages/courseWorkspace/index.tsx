import { Navigate } from 'react-router-dom'

import { AppRoute, AppRoutePath } from '@/shared/routing/AppRoutes'

import { CourseWorkspaceHeader } from './components/CourseWorkspaceHeader'
import { CourseWorkspacePanel } from './components/CourseWorkspacePanel'
import { useCourseWorkspacePage } from './hooks/useCourseWorkspacePage'

export default function CourseWorkspacePage() {
  const page = useCourseWorkspacePage()

  if (!page.currentUser) {
    return <Navigate replace to={AppRoutePath.Login} />
  }

  if (!page.dashboard) {
    return (
      <main className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] p-8 text-sm text-slate-500">
        正在加载课程工作区...
      </main>
    )
  }

  if (!page.dashboard.courseSummaries.length || !page.selectedCourseId) {
    return <Navigate replace to={AppRoutePath.Dashboard} />
  }

  if (page.courseId !== page.selectedCourseId) {
    return <Navigate replace to={AppRoute.CourseWorkspace(page.selectedCourseId)} />
  }

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(14,165,233,0.16),transparent_28%),radial-gradient(circle_at_80%_0%,rgba(45,212,191,0.18),transparent_24%),linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] text-slate-900">
      <div className="mx-auto max-w-5xl px-5 py-8 lg:px-7">
        <CourseWorkspaceHeader
          courseTitle={page.selectedCourseTitle}
          onBack={page.openDashboard}
          onOpenProfile={page.openProfile}
        />
        <CourseWorkspacePanel
          currentUser={page.currentUser}
          selectedCourse={page.courseData.selectedCourseWithChat}
          courseSummaries={page.dashboard.courseSummaries}
          selectedCourseId={page.selectedCourseId}
          setSelectedCourseId={page.openCourse}
          selectedTab={page.selectedTab}
          setSelectedTab={page.setSelectedTab}
          currentUserId={page.currentUser.id}
          isTeacher={page.isTeacher}
          onOpenAnnouncement={page.openAnnouncement}
          onOpenAssignment={page.openAssignment}
          onOpenExam={page.openExam}
          onOpenQuestionnaire={page.openQuestionnaire}
          onOpenAnnouncementCreate={page.openAnnouncementCreate}
          onOpenAssignmentCreate={page.openAssignmentCreate}
          onOpenMemberManage={page.openMemberManage}
          onOpenExamCreate={page.openExamCreate}
          onOpenQuestionnaireCreate={page.openQuestionnaireCreate}
          onLeaveCourse={page.leaveCourse}
          onDeleteCourse={page.deleteCourse}
          onCreateChatMessage={page.createChatMessage}
          onRevokeChatMessage={page.revokeChatMessage}
          onHideChatMessage={page.hideChatMessage}
          onReadChatMessages={page.readChatMessages}
          onLoadOlderChatMessages={page.loadOlderChatMessages}
          chatInitialLoading={page.courseData.chatInitialLoading}
          chatHistoryLoading={page.courseData.chatHistoryLoading}
          chatHasOlderMessages={page.courseData.chatHasOlderMessages}
        />
      </div>
    </main>
  )
}
