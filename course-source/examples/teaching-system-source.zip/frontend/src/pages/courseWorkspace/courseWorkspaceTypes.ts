import type { CourseChatMessageInput } from '@/microservices/course/api/requests/CourseChatMessageInput'
import type { CourseChatMessage } from '@/microservices/course/api/responses/CourseChatMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { DashboardCourseSummary } from '@/microservices/dashboard/api/responses/DashboardCourseSummary'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export type CourseWorkspaceViewProps = {
  currentUser: PublicUser
  selectedCourse: CourseDetailResponse | null
  courseSummaries: DashboardCourseSummary[]
  selectedCourseId: string
  setSelectedCourseId: (courseId: string) => void
  selectedTab: string
  setSelectedTab: (tab: string) => void
  currentUserId: string
  isTeacher: boolean
  onOpenAnnouncement: (announcementId: string) => void
  onOpenAssignment: (assignmentId: string) => void
  onOpenExam: (examId: string) => void
  onOpenQuestionnaire: (questionnaireId: string) => void
  onOpenAnnouncementCreate: (courseId: string) => void
  onOpenAssignmentCreate: (courseId: string) => void
  onOpenMemberManage: (courseId: string) => void
  onOpenExamCreate: (courseId: string) => void
  onOpenQuestionnaireCreate: (courseId: string) => void
  onLeaveCourse: (courseId: string) => Promise<void>
  onDeleteCourse: (courseId: string) => Promise<void>
  onCreateChatMessage: (
    courseId: string,
    payload: CourseChatMessageInput,
  ) => Promise<CourseChatMessage>
  onRevokeChatMessage: (
    courseId: string,
    messageId: string,
  ) => Promise<CourseChatMessage>
  onHideChatMessage: (courseId: string, messageId: string) => void
  onReadChatMessages: (courseId: string, latestTimestamp: string) => void
  onLoadOlderChatMessages: (courseId: string) => Promise<void>
  chatInitialLoading: boolean
  chatHistoryLoading: boolean
  chatHasOlderMessages: boolean
}
