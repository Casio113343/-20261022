import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export function countUnreadReviewedAssignments(
  course: CourseDetailResponse,
  currentUserId: string,
  currentUser: PublicUser,
) {
  const readIds = currentUser.readReviewedAssignmentIds ?? []
  return course.assignments.filter((assignment) => {
    const submission = course.submissions.find(
      (item) =>
        item.assignmentId === assignment.id && item.studentId === currentUserId,
    )
    return Boolean(submission) &&
      course.reviews.some((review) => review.submissionId === submission?.id) &&
      !readIds.includes(assignment.id)
  }).length
}

export function countUnreadPublishedExams(
  course: CourseDetailResponse,
  currentUser: PublicUser,
) {
  const readIds = currentUser.readPublishedExamIds ?? []
  return course.exams.filter(
    (exam) => exam.publishedAt && !readIds.includes(exam.id),
  ).length
}
