import { resolveUnreadChatCountFromLatestTimestamp } from '@/microservices/course/lib/chatHelpers'
import type { DashboardCourseSummary } from '@/microservices/dashboard/api/responses/DashboardCourseSummary'
import { getSeenChatTimestamp } from '@/stores/course/useChatPreferencesStore'

export function courseHasUpdates(
  course: DashboardCourseSummary,
  currentUserId: string,
) {
  const unreadChatCount = resolveUnreadChatCountFromLatestTimestamp(
    course.latestChatSentAt,
    getSeenChatTimestamp(currentUserId, course.course.id),
  )

  return course.unreadAnnouncementCount > 0 ||
    unreadChatCount > 0 ||
    course.pendingAssignmentCount > 0 ||
    course.unreadReviewedAssignmentCount > 0 ||
    course.unreadPublishedExamCount > 0 ||
    course.pendingQuestionnaireCount > 0 ||
    course.pendingReviewCount > 0 ||
    course.pendingExamReviewCount > 0
}
