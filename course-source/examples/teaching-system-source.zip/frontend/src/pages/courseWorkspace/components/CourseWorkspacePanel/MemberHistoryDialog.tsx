import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

import { describeMemberHistoryEvent } from '@/microservices/course/lib/memberHistoryHelpers'

export function MemberHistoryDialog({
  selectedCourse,
  currentUserId,
  open,
  onOpenChange,
}: {
  selectedCourse: CourseDetailResponse
  currentUserId: string
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[80vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-4">
            <span>{selectedCourse.course.title}</span>
            <span>成员历史</span>
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {selectedCourse.memberHistory.length ? selectedCourse.memberHistory.map((event) => (
            <div key={`${event.user.id}-${event.action}-${event.occurredAt}`} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">
              <div>{describeMemberHistoryEvent(selectedCourse, event, currentUserId)}</div>
            </div>
          )) : <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">当前没有可见的成员历史记录。</div>}
        </div>
      </DialogContent>
    </Dialog>
  )
}
