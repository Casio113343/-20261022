import { Badge } from '@/components/ui'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import type { ExamSummary } from '@/microservices/exam/api/responses/ExamSummary'

import { formatDateTime } from '@/pages/dashboard/functions/dashboardHelpers'

export function ExamSummaryCard({
  exam,
  currentUser,
  isTeacher,
  onOpenExam,
}: {
  exam: ExamSummary
  currentUser: PublicUser
  isTeacher: boolean
  onOpenExam: (examId: string) => void
}) {
  const hasUnreadPublishedNotice = !isTeacher && Boolean(exam.publishedAt) && !(currentUser.readPublishedExamIds ?? []).includes(exam.id)

  return (
    <button type="button" className="flex w-full items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-4 text-left transition hover:bg-slate-50" onClick={() => onOpenExam(exam.id)}>
      <div>
        <div className="font-medium">{exam.title}</div>
        <div className="mt-1 text-sm text-slate-500">{exam.questionCount} 题 / 创建于 {formatDateTime(exam.createdAt)}</div>
      </div>
      {isTeacher ? <Badge variant="secondary">进入考试区</Badge> : (
        <div className="flex items-center gap-3">
          {hasUnreadPublishedNotice ? <span className="size-2 rounded-full bg-rose-500" /> : null}
          <Badge variant={exam.publishedAt ? 'secondary' : 'outline'}>{exam.publishedAt ? '已发布' : '未发布'}</Badge>
        </div>
      )}
    </button>
  )
}
