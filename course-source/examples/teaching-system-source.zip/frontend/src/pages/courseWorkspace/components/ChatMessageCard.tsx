import { useState } from 'react'
import { FileUp } from 'lucide-react'

import { UserAvatar } from '@/shared/components/user/UserAvatar'
import { Dialog, DialogContent } from '@/components/ui'
import type { CourseChatMessage } from '@/microservices/course/api/responses/CourseChatMessage'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import { resolveAssetUrl } from '@/infrastructure/storage/assetUrl'

type ChatMessageCardProps = {
  courseId: string
  message: CourseChatMessage
  currentUser: PublicUser
  isBusy: boolean
  menuPosition: { x: number; y: number } | null
  onOpenMenu: (messageId: string, position: { x: number; y: number }) => void
  onCloseMenu: () => void
  onRevoke: (messageId: string) => void
  onHideMessage: (courseId: string, messageId: string) => void
}

export function ChatMessageCard({
  courseId,
  message,
  currentUser,
  isBusy,
  menuPosition,
  onOpenMenu,
  onCloseMenu,
  onRevoke,
  onHideMessage,
}: ChatMessageCardProps) {
  const isOwn = message.sender.id === currentUser.id
  const [previewImage, setPreviewImage] = useState<{ fileName: string; dataUrl: string } | null>(null)

  const sentAtText = formatChatMessageTime(message.sentAt)
  const revokedText = isOwn ? '你撤回了一条消息' : `${message.sender.displayName} 撤回了一条消息`

  return (
    <>
      <div className={`relative flex gap-3 ${isOwn ? 'justify-end' : ''}`} onContextMenu={(event) => {
        event.preventDefault()
        onOpenMenu(message.id, { x: event.clientX, y: event.clientY })
      }}>
        {!isOwn ? <UserAvatar user={message.sender} /> : null}
        <div className={`flex w-fit max-w-[78%] flex-col gap-2 ${isOwn ? 'ml-auto items-end' : ''}`}>
          {message.revokedAt ? <div className="py-1 text-center text-xs text-slate-400">{revokedText}</div> : (
            <>
              <div className={`flex items-center gap-2 text-xs text-slate-500 ${isOwn ? 'justify-end' : ''}`}>
                {!isOwn ? <span>{message.sender.displayName}</span> : null}
                <span>{sentAtText}</span>
              </div>
              <div className={`w-fit min-w-[3ch] ${message.content ? `rounded-[1.5rem] px-4 py-3 shadow-sm ${isOwn ? 'bg-sky-50' : 'bg-white'}` : ''}`}>
                <div className="space-y-3">
                  {message.content ? <div className="whitespace-pre-wrap text-sm leading-6 text-slate-700">{message.content}</div> : null}
                  {message.images.length ? (
                    <div className={`grid w-fit gap-3 ${message.images.length > 1 ? 'grid-cols-2' : 'grid-cols-1'} ${isOwn ? 'self-end' : ''}`}>
                      {message.images.map((image) => (
                        <button key={`${message.id}-${image.fileName}`} type="button" className="w-fit overflow-hidden rounded-2xl" onClick={() => setPreviewImage(image)}>
                          <img src={resolveAssetUrl(image.dataUrl)} alt={image.fileName} className="h-40 max-w-[14rem] rounded-2xl object-cover" />
                        </button>
                      ))}
                    </div>
                  ) : null}
                  {message.attachments.length ? (
                    <div className="space-y-2">
                      {message.attachments.map((attachment) => (
                        <a key={`${message.id}-${attachment.fileName}`} href={resolveAssetUrl(attachment.dataUrl)} download={attachment.fileName} className="flex items-center gap-2 text-sm text-sky-700 underline-offset-4 hover:underline">
                          <FileUp className="size-4" />
                          {attachment.fileName}
                        </a>
                      ))}
                    </div>
                  ) : null}
                </div>
              </div>
            </>
          )}
        </div>
        {isOwn ? <UserAvatar user={message.sender} /> : null}
      </div>

      {menuPosition ? (
        <div
          className="fixed z-50 min-w-32 rounded-xl border border-slate-200 bg-white p-1 shadow-lg"
          style={{ left: menuPosition.x, top: menuPosition.y }}
          onClick={(event) => event.stopPropagation()}
        >
          {isOwn && message.canRevoke && !message.revokedAt ? (
            <button
              type="button"
              className="block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-50"
              disabled={isBusy}
              onClick={() => {
                onCloseMenu()
                onRevoke(message.id)
              }}
            >
              撤回
            </button>
          ) : null}
          <button
            type="button"
            className="block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-50"
            onClick={() => {
              onCloseMenu()
              onHideMessage(courseId, message.id)
            }}
          >
            删除
          </button>
        </div>
      ) : null}

      <Dialog open={previewImage !== null} onOpenChange={(open) => {
        if (!open) setPreviewImage(null)
      }}>
        <DialogContent className="sm:max-w-4xl">
          {previewImage ? <img src={resolveAssetUrl(previewImage.dataUrl)} alt={previewImage.fileName} className="max-h-[80vh] w-full rounded-xl object-contain" /> : null}
        </DialogContent>
      </Dialog>
    </>
  )
}

function formatChatMessageTime(value: string) {
  const date = new Date(value)
  const now = new Date()
  const isSameYear = date.getFullYear() === now.getFullYear()
  const isSameDay = isSameYear && date.getMonth() === now.getMonth() && date.getDate() === now.getDate()

  if (isSameDay) {
    return new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit' }).format(date)
  }

  if (isSameYear) {
    return new Intl.DateTimeFormat('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(date)
  }

  return new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(date)
}
