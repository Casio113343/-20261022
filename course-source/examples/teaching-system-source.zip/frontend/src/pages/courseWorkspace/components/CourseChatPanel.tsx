import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { ImageIcon, Paperclip, Send } from 'lucide-react'

import { prepareImageAttachments, uploadAttachments } from '@/infrastructure/storage/uploadAsset'
import { Card, CardContent, CardHeader, CardTitle, Button } from '@/components/ui'
import type { CourseChatMessageInput } from '@/microservices/course/api/requests/CourseChatMessageInput'
import type { CourseChatMessage } from '@/microservices/course/api/responses/CourseChatMessage'
import type { Attachment } from '@/infrastructure/storage/Attachment'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import { FilePicker } from '@/shared/forms/FormHelpers'
import { useHiddenChatMessageIds } from '@/stores/course/useChatPreferencesStore'

import { ChatMessageCard } from './ChatMessageCard'

export function CourseChatPanel({
  courseId,
  currentUser,
  messages,
  hasOlderMessages,
  isInitialLoading,
  isLoadingHistory,
  onCreateChatMessage,
  onLoadOlderMessages,
  onRevokeChatMessage,
  onHideChatMessage,
  onReadMessages,
}: {
  courseId: string
  currentUser: PublicUser
  messages: CourseChatMessage[]
  hasOlderMessages: boolean
  isInitialLoading: boolean
  isLoadingHistory: boolean
  onCreateChatMessage: (courseId: string, payload: CourseChatMessageInput) => Promise<CourseChatMessage>
  onLoadOlderMessages: (courseId: string) => Promise<void>
  onRevokeChatMessage: (courseId: string, messageId: string) => Promise<CourseChatMessage>
  onHideChatMessage: (courseId: string, messageId: string) => void
  onReadMessages: (courseId: string, latestTimestamp: string) => void
}) {
  const [content, setContent] = useState('')
  const [images, setImages] = useState<Attachment[]>([])
  const [attachments, setAttachments] = useState<Attachment[]>([])
  const [isBusy, setIsBusy] = useState(false)
  const [isUploadingAssets, setIsUploadingAssets] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')
  const [localMessages, setLocalMessages] = useState(messages)
  const [activeMenu, setActiveMenu] = useState<{ messageId: string; x: number; y: number } | null>(null)
  const listRef = useRef<HTMLDivElement | null>(null)
  const lastReadTimestampRef = useRef<string | null>(null)
  const previousVisibleCountRef = useRef(0)
  const hasInitializedScrollRef = useRef(false)
  const pendingHistoryRestoreRef = useRef<{ previousHeight: number; previousTop: number } | null>(null)
  const shouldStickToBottomRef = useRef(true)
  const autoLoadTriggeredRef = useRef(false)
  const suppressAutoLoadUntilRef = useRef(0)
  const previousBoundaryRef = useRef<{ firstId: string | null; lastId: string | null; count: number }>({
    firstId: null,
    lastId: null,
    count: 0,
  })
  const hiddenMessageIds = useHiddenChatMessageIds(currentUser.id, courseId)

  useEffect(() => {
    setLocalMessages(messages)
  }, [messages])

  useEffect(() => {
    if (!activeMenu) return
    const closeMenu = () => setActiveMenu(null)
    window.addEventListener('click', closeMenu)
    window.addEventListener('scroll', closeMenu, true)
    window.addEventListener('contextmenu', closeMenu, true)
    return () => {
      window.removeEventListener('click', closeMenu)
      window.removeEventListener('scroll', closeMenu, true)
      window.removeEventListener('contextmenu', closeMenu, true)
    }
  }, [activeMenu])

  const visibleMessages = useMemo(
    () => {
      const hiddenMessageIdSet = new Set(hiddenMessageIds)
      return localMessages.filter((message) => !hiddenMessageIdSet.has(message.id))
    },
    [hiddenMessageIds, localMessages],
  )

  useEffect(() => {
    const container = listRef.current
    if (!container) return
    const updateStickiness = () => {
      const distanceToBottom = container.scrollHeight - container.scrollTop - container.clientHeight
      shouldStickToBottomRef.current = distanceToBottom < 48
      if (container.scrollTop > 40) {
        autoLoadTriggeredRef.current = false
      }
      if (Date.now() < suppressAutoLoadUntilRef.current) {
        return
      }
      if (container.scrollTop <= 40 && hasOlderMessages && !isLoadingHistory && !isInitialLoading && !autoLoadTriggeredRef.current) {
        autoLoadTriggeredRef.current = true
        void handleLoadOlderMessages()
      }
    }
    updateStickiness()
    container.addEventListener('scroll', updateStickiness)
    return () => {
      container.removeEventListener('scroll', updateStickiness)
    }
  }, [hasOlderMessages, isInitialLoading, isLoadingHistory])

  useLayoutEffect(() => {
    if (!isLoadingHistory && pendingHistoryRestoreRef.current && listRef.current) {
      const container = listRef.current
      const restore = pendingHistoryRestoreRef.current
      container.scrollTop = restore.previousTop + (container.scrollHeight - restore.previousHeight)
      pendingHistoryRestoreRef.current = null
      previousVisibleCountRef.current = visibleMessages.length
      previousBoundaryRef.current = {
        firstId: visibleMessages[0]?.id ?? null,
        lastId: visibleMessages.at(-1)?.id ?? null,
        count: visibleMessages.length,
      }
      return
    }
    const container = listRef.current
    if (!container) return
    const previousBoundary = previousBoundaryRef.current
    const nextBoundary = {
      firstId: visibleMessages[0]?.id ?? null,
      lastId: visibleMessages.at(-1)?.id ?? null,
      count: visibleMessages.length,
    }
    const prependedMessages =
      previousBoundary.count > 0 &&
      nextBoundary.count > previousBoundary.count &&
      previousBoundary.firstId !== nextBoundary.firstId &&
      previousBoundary.lastId === nextBoundary.lastId
    const appendedMessages =
      previousBoundary.count > 0 &&
      nextBoundary.count > previousBoundary.count &&
      previousBoundary.firstId === nextBoundary.firstId &&
      previousBoundary.lastId !== nextBoundary.lastId
    if (!hasInitializedScrollRef.current) {
      container.scrollTop = container.scrollHeight
      hasInitializedScrollRef.current = true
    } else if (prependedMessages) {
      previousVisibleCountRef.current = visibleMessages.length
      previousBoundaryRef.current = nextBoundary
      return
    } else if (appendedMessages && shouldStickToBottomRef.current) {
      container.scrollTop = container.scrollHeight
    }
    previousVisibleCountRef.current = visibleMessages.length
    previousBoundaryRef.current = nextBoundary
  }, [isLoadingHistory, visibleMessages])

  useEffect(() => {
    const latestTimestamp = visibleMessages.at(-1)?.sentAt
    if (!latestTimestamp) return
    if (lastReadTimestampRef.current === latestTimestamp) return
    lastReadTimestampRef.current = latestTimestamp
    onReadMessages(courseId, latestTimestamp)
  }, [courseId, onReadMessages, visibleMessages])

  const handleLoadOlderMessages = async () => {
    const container = listRef.current
    if (container) {
      pendingHistoryRestoreRef.current = {
        previousHeight: container.scrollHeight,
        previousTop: container.scrollTop,
      }
    }
    await onLoadOlderMessages(courseId)
  }

  const handleSubmit = async () => {
    const trimmedContent = content.trim()
    if (!trimmedContent && !images.length && !attachments.length) {
      setErrorMessage('消息内容、图片和附件不能同时为空')
      return
    }

    setErrorMessage('')
    setIsBusy(true)
    try {
      const payloads: CourseChatMessageInput[] = []
      if (trimmedContent) {
        payloads.push({ content: trimmedContent, images: [], attachments: [] })
      }
      if (images.length) {
        payloads.push({ content: '', images, attachments: [] })
      }
      if (attachments.length) {
        payloads.push({ content: '', images: [], attachments })
      }

      for (const payload of payloads) {
        await onCreateChatMessage(courseId, payload)
        suppressAutoLoadUntilRef.current = Date.now() + 1200
        shouldStickToBottomRef.current = true
      }
      setContent('')
      setImages([])
      setAttachments([])
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '发送消息失败')
    } finally {
      setIsBusy(false)
    }
  }

  const handleImageSelect = async (files: FileList | null) => {
    if (!files?.length) return
    setErrorMessage('')
    setIsUploadingAssets(true)
    try {
      setImages(await prepareImageAttachments(Array.from(files)))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '图片上传失败')
    } finally {
      setIsUploadingAssets(false)
    }
  }

  const handleAttachmentSelect = async (files: FileList | null) => {
    if (!files?.length) return
    setErrorMessage('')
    setIsUploadingAssets(true)
    try {
      setAttachments(await uploadAttachments(currentUser.id, Array.from(files)))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '附件上传失败')
    } finally {
      setIsUploadingAssets(false)
    }
  }

  const handleComposerKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key !== 'Enter' || event.shiftKey) return
    event.preventDefault()
    if (!isBusy) {
      void handleSubmit()
    }
  }

  const handleRevoke = async (messageId: string) => {
    setErrorMessage('')
    setIsBusy(true)
    try {
      const currentMessage = localMessages.find((message) => message.id === messageId)
      if (currentMessage) {
        setLocalMessages((current) => current.map((message) => (
          message.id === messageId
            ? { ...message, revokedAt: new Date().toISOString(), content: '', images: [], attachments: [] }
            : message
        )))
      }
      const nextMessage = await onRevokeChatMessage(courseId, messageId)
      setLocalMessages((current) => current.map((message) => message.id === nextMessage.id ? nextMessage : message))
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '撤回消息失败')
      setLocalMessages(messages)
    } finally {
      setIsBusy(false)
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_18rem] xl:grid-cols-[minmax(0,1fr)_19rem]">
      <div className="rounded-[1.75rem] border border-cyan-100 bg-[linear-gradient(180deg,#ecfeff_0%,#ffffff_38%)] p-4">
        <div className="mb-4 text-lg font-semibold">课程群聊</div>
        <div ref={listRef} className="max-h-[460px] space-y-4 overflow-y-auto pr-2">
          {isLoadingHistory ? <div className="sticky top-0 z-10 rounded-xl bg-white/95 px-3 py-2 text-center text-xs text-slate-500 shadow-sm backdrop-blur">加载历史消息中…</div> : null}
          {isInitialLoading && !visibleMessages.length ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">聊天记录加载中…</div>
          ) : null}
          {visibleMessages.length ? visibleMessages.map((message) => (
            <ChatMessageCard
              key={message.id}
              courseId={courseId}
              message={message}
              currentUser={currentUser}
              isBusy={isBusy}
              menuPosition={activeMenu?.messageId === message.id ? { x: activeMenu.x, y: activeMenu.y } : null}
              onOpenMenu={(messageId, position) => setActiveMenu({ messageId, ...position })}
              onCloseMenu={() => setActiveMenu(null)}
              onHideMessage={onHideChatMessage}
              onRevoke={(id) => void handleRevoke(id)}
            />
          )) : !isInitialLoading ? <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">课程群聊还没有消息。</div> : null}
        </div>
      </div>

      <Card className="border-teal-100 bg-white">
        <CardHeader>
          <CardTitle>发送消息</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <textarea
            className="min-h-28 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-teal-300"
            placeholder="输入消息内容"
            value={content}
            onChange={(event) => setContent(event.target.value)}
            onKeyDown={handleComposerKeyDown}
          />
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <ImageIcon className="size-4 text-slate-400" />
              <FilePicker accept="image/*" multiple label="选择图片" onChange={(event) => void handleImageSelect(event.target.files)} />
            </div>
            <div className="flex items-center gap-2">
              <Paperclip className="size-4 text-slate-400" />
              <FilePicker multiple onChange={(event) => void handleAttachmentSelect(event.target.files)} />
            </div>
          </div>
          <div className="space-y-1">
            {images.length ? (
              <div className="flex flex-wrap items-center gap-3 text-sm text-slate-500">
                <span>已选图片：{images.map((item) => item.fileName).join('、')}</span>
                <Button type="button" variant="ghost" size="sm" onClick={() => setImages([])}>清空图片</Button>
              </div>
            ) : null}
            {attachments.length ? (
              <div className="flex flex-wrap items-center gap-3 text-sm text-slate-500">
                <span>已选附件：{attachments.map((item) => item.fileName).join('、')}</span>
                <Button type="button" variant="ghost" size="sm" onClick={() => setAttachments([])}>清空附件</Button>
              </div>
            ) : null}
          </div>
          {errorMessage ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{errorMessage}</div> : null}
          <Button type="button" disabled={isBusy || isUploadingAssets} onClick={() => void handleSubmit()}>
            <Send className="size-4" />
            {isUploadingAssets ? '上传附件中…' : '发送'}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
