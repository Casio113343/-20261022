import { Label, Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui'
import type { DashboardCourseSummary } from '@/microservices/dashboard/api/responses/DashboardCourseSummary'

export function CourseWorkspaceSelector({
  courses,
  selectedCourseId,
  hasOtherCourseUpdates,
  courseIdsWithUpdates,
  onSelectCourse,
}: {
  courses: DashboardCourseSummary[]
  selectedCourseId: string
  hasOtherCourseUpdates: boolean
  courseIdsWithUpdates: string[]
  onSelectCourse: (courseId: string) => void
}) {
  return (
    <div className="space-y-2">
      <Label>当前课程</Label>
      <div className="relative">
        <Select value={selectedCourseId} onValueChange={onSelectCourse}>
          <SelectTrigger className="h-11 rounded-xl bg-white pr-10">
            <SelectValue placeholder="请选择课程" />
          </SelectTrigger>
          <SelectContent>
            {courses.map((item) => (
              <SelectItem key={item.course.id} value={item.course.id}>
                <div className="flex w-full items-center justify-between gap-4 pr-5">
                  <span>{item.course.title}</span>
                  {courseIdsWithUpdates.includes(item.course.id) ? <span className="size-2 rounded-full bg-rose-500" /> : null}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {hasOtherCourseUpdates ? <span className="absolute top-4 right-16 size-2 rounded-full bg-rose-500" /> : null}
      </div>
    </div>
  )
}
