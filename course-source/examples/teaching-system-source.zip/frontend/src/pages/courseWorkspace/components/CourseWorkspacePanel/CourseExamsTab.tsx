import { useState } from 'react'
import { Search } from 'lucide-react'

import { Button, Input } from '@/components/ui'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

import { ExamSummaryCard } from '../ExamSummaryCard'

export function CourseExamsTab({
  selectedCourse,
  currentUser,
  isTeacher,
  onCreateExam,
  onOpenExam,
}: {
  selectedCourse: CourseDetailResponse
  currentUser: PublicUser
  isTeacher: boolean
  onCreateExam: () => void
  onOpenExam: (examId: string) => void
}) {
  const [searchText, setSearchText] = useState('')
  const normalizedSearchText = searchText.trim()
  const exams = normalizedSearchText
    ? selectedCourse.exams.filter((exam) => exam.title.includes(normalizedSearchText))
    : selectedCourse.exams

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {isTeacher ? <Button onClick={onCreateExam}>创建考试</Button> : <div />}
        <div className="relative sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
          <Input className="bg-white pl-9" value={searchText} placeholder="搜索考试" onChange={(event) => setSearchText(event.target.value)} />
        </div>
      </div>
      <div className="max-h-[32rem] space-y-4 overflow-y-auto pr-2">
      {exams.length ? exams.map((exam) => (
        <ExamSummaryCard key={exam.id} exam={exam} currentUser={currentUser} isTeacher={isTeacher} onOpenExam={onOpenExam} />
      )) : <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">{normalizedSearchText ? '没有匹配的课程考试。' : '当前还没有课程考试。'}</div>}
      </div>
    </div>
  )
}
