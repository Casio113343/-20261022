import { useState } from 'react'
import { Search } from 'lucide-react'

import { Button, Input } from '@/components/ui'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

import { AssignmentSummaryCard } from '../AssignmentSummaryCard'
import { StudentAssignmentColumns } from '../StudentAssignmentColumns'

export function CourseAssignmentsTab({
  selectedCourse,
  currentUserId,
  currentUser,
  isTeacher,
  onCreateAssignment,
  onOpenAssignment,
}: {
  selectedCourse: CourseDetailResponse
  currentUserId: string
  currentUser: PublicUser
  isTeacher: boolean
  onCreateAssignment: () => void
  onOpenAssignment: (assignmentId: string) => void
}) {
  const [searchText, setSearchText] = useState('')
  const normalizedSearchText = searchText.trim()
  const assignments = normalizedSearchText
    ? selectedCourse.assignments.filter((assignment) => assignment.title.includes(normalizedSearchText))
    : selectedCourse.assignments

  if (isTeacher) {
    return (
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <Button onClick={onCreateAssignment}>布置作业</Button>
          <SearchInput value={searchText} onChange={setSearchText} placeholder="搜索作业" />
        </div>
        <div className="max-h-[32rem] space-y-4 overflow-y-auto pr-2">
          {assignments.length ? assignments.map((assignment) => <AssignmentSummaryCard key={assignment.id} assignment={assignment} onOpenAssignment={onOpenAssignment} />) : <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">{normalizedSearchText ? '没有匹配的课程作业。' : '还没有课程作业。'}</div>}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <StudentAssignmentColumns
        assignments={assignments}
        submissions={selectedCourse.submissions}
        reviews={selectedCourse.reviews}
        currentUserId={currentUserId}
        readReviewedAssignmentIds={currentUser.readReviewedAssignmentIds ?? []}
        onOpenAssignment={onOpenAssignment}
        emptyPendingText={normalizedSearchText ? '没有匹配的待提交作业。' : undefined}
        emptySubmittedText={normalizedSearchText ? '没有匹配的已提交作业。' : undefined}
        toolbarRight={<SearchInput value={searchText} onChange={setSearchText} placeholder="搜索作业" />}
      />
    </div>
  )
}

function SearchInput({
  value,
  onChange,
  placeholder,
}: {
  value: string
  onChange: (value: string) => void
  placeholder: string
}) {
  return (
    <div className="relative sm:w-72">
      <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
      <Input className="bg-white pl-9" value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} />
    </div>
  )
}
