import type { Assignment } from '@/microservices/assignment/objects/Assignment'

import { formatAssignmentDueText } from '@/pages/dashboard/functions/dashboardViewHelpers'

export function AssignmentSummaryCard({
  assignment,
  onOpenAssignment,
}: {
  assignment: Assignment
  onOpenAssignment: (assignmentId: string) => void
}) {
  return (
    <button type="button" className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-4 text-left transition hover:bg-slate-50" onClick={() => onOpenAssignment(assignment.id)}>
      <div className="font-medium">{assignment.title}</div>
      <div className="mt-1 text-sm text-slate-500">截止 {formatAssignmentDueText(assignment)}</div>
    </button>
  )
}
