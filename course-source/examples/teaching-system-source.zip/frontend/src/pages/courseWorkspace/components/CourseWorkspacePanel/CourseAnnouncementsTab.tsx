import { useState } from 'react'
import { Search } from 'lucide-react'

import { Input } from '@/components/ui'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

import { formatDateTime } from '@/pages/dashboard/functions/dashboardHelpers'

export function CourseAnnouncementsTab({
  currentUser,
  selectedCourse,
  isTeacher,
  onCreateAnnouncement,
  onOpenAnnouncement,
}: {
  currentUser: PublicUser
  selectedCourse: CourseDetailResponse
  isTeacher: boolean
  onCreateAnnouncement: () => void
  onOpenAnnouncement: (announcementId: string) => void
}) {
  const [searchText, setSearchText] = useState('')
  const normalizedSearchText = searchText.trim()
  const announcements = normalizedSearchText
    ? selectedCourse.announcements.filter((announcement) => announcement.title.includes(normalizedSearchText))
    : selectedCourse.announcements

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {isTeacher ? <button type="button" className="inline-flex h-10 items-center rounded-xl bg-primary px-4 text-sm font-medium text-primary-foreground" onClick={onCreateAnnouncement}>发布通知</button> : <div />}
        <div className="relative sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
          <Input className="bg-white pl-9" value={searchText} placeholder="搜索通知" onChange={(event) => setSearchText(event.target.value)} />
        </div>
      </div>
      <div className="max-h-[32rem] space-y-4 overflow-y-auto pr-2">
      {announcements.length ? announcements.map((announcement) => (
        <button key={announcement.id} type="button" className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-4 text-left transition hover:bg-slate-50" onClick={() => onOpenAnnouncement(announcement.id)}>
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="font-medium">{announcement.title}</div>
              <div className="mt-1 text-sm text-slate-500">{announcement.publisher.displayName} / {formatDateTime(announcement.createdAt)}</div>
            </div>
            {announcement.publisher.id !== currentUser.id && !(currentUser.readAnnouncementIds ?? []).includes(announcement.id) ? <span className="size-2 rounded-full bg-rose-500" /> : null}
          </div>
        </button>
      )) : <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">{normalizedSearchText ? '没有匹配的课程通知。' : '还没有课程通知。'}</div>}
      </div>
    </div>
  )
}
