import { ChevronLeft, UserCog } from 'lucide-react'

import { Button } from '@/components/ui'

export function CourseWorkspaceHeader({
  courseTitle,
  onBack,
  onOpenProfile,
}: {
  courseTitle: string
  onBack: () => void
  onOpenProfile: () => void
}) {
  return (
    <header className="mb-6 flex flex-wrap items-start justify-between gap-3">
      <div className="space-y-2">
        <div className="inline-flex items-center rounded-full bg-white/80 px-4 py-2 text-sm shadow-sm">
          课程工作区
        </div>
        <h1 className="text-3xl font-semibold tracking-tight text-slate-950">
          {courseTitle}
        </h1>
      </div>
      <div className="flex items-center gap-3">
        <Button variant="outline" onClick={onOpenProfile}>
          <UserCog className="size-4" />
          个人中心
        </Button>
        <Button variant="outline" onClick={onBack}>
          <ChevronLeft className="size-4" />
          返回总览
        </Button>
      </div>
    </header>
  )
}
