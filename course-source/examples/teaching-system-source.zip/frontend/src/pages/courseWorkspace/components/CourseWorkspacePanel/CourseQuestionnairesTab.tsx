import { useEffect, useState } from 'react'
import { ClipboardCheck, Search } from 'lucide-react'

import { Badge, Button, Input } from '@/components/ui'
import { sendAPI } from '@/infrastructure/api/sendAPI'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import { FetchCourseQuestionnairesAPIMessage } from '@/microservices/questionnaire/api/FetchCourseQuestionnairesAPIMessage'
import type { QuestionnaireSummary } from '@/microservices/questionnaire/api/responses/QuestionnaireSummary'

import { formatDateTime } from '@/pages/dashboard/functions/dashboardHelpers'

export function CourseQuestionnairesTab({
  courseId,
  currentUser,
  isTeacher,
  onCreateQuestionnaire,
  onOpenQuestionnaire,
}: {
  courseId: string
  currentUser: PublicUser
  isTeacher: boolean
  onCreateQuestionnaire: () => void
  onOpenQuestionnaire: (questionnaireId: string) => void
}) {
  const [questionnaires, setQuestionnaires] = useState<QuestionnaireSummary[]>([])
  const [searchText, setSearchText] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    setIsLoading(true)
    setErrorMessage('')
    void sendAPI(new FetchCourseQuestionnairesAPIMessage(courseId, currentUser.id)).run()
      .then(setQuestionnaires)
      .catch((error) => setErrorMessage(error instanceof Error ? error.message : '加载问卷失败'))
      .finally(() => setIsLoading(false))
  }, [courseId, currentUser.id])

  const normalizedSearchText = searchText.trim()
  const visibleQuestionnaires = normalizedSearchText
    ? questionnaires.filter((questionnaire) => questionnaire.title.includes(normalizedSearchText))
    : questionnaires

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {isTeacher ? <Button onClick={onCreateQuestionnaire}>创建问卷</Button> : <div />}
        <div className="relative sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" />
          <Input className="bg-white pl-9" value={searchText} placeholder="搜索问卷" onChange={(event) => setSearchText(event.target.value)} />
        </div>
      </div>
      {errorMessage ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{errorMessage}</div> : null}
      <div className="max-h-[32rem] space-y-4 overflow-y-auto pr-2">
        {isLoading ? <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">正在加载问卷。</div> : null}
        {!isLoading && visibleQuestionnaires.length ? visibleQuestionnaires.map((questionnaire) => (
          <button key={questionnaire.id} type="button" className="flex w-full items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-4 text-left transition hover:bg-slate-50" onClick={() => onOpenQuestionnaire(questionnaire.id)}>
            <div className="min-w-0">
              <div className="flex items-center gap-2 font-medium">
                <ClipboardCheck className="size-4 text-teal-600" />
                <span className="truncate">{questionnaire.title}</span>
              </div>
              <div className="mt-1 text-sm text-slate-500">{questionnaire.questionCount} 题 / 截止 {formatDateTime(questionnaire.dueAt)}</div>
              {questionnaire.overview ? <div className="mt-1 line-clamp-1 text-sm text-slate-500">{questionnaire.overview}</div> : null}
            </div>
            {isTeacher ? (
              <Badge variant="secondary">已填 {questionnaire.filledCount} / 未填 {questionnaire.unfilledCount}</Badge>
            ) : (
              <Badge variant={questionnaire.submitted ? 'secondary' : 'outline'}>{questionnaire.submitted ? '已填写' : '待填写'}</Badge>
            )}
          </button>
        )) : null}
        {!isLoading && !visibleQuestionnaires.length ? <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">{normalizedSearchText ? '没有匹配的课程问卷。' : '当前还没有课程问卷。'}</div> : null}
      </div>
    </div>
  )
}
