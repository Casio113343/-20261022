import { UserAvatar } from '@/shared/components/user/UserAvatar'
import { Badge, Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import { UserRole } from '@/microservices/auth/objects/UserRole'

export function MemberProfileDialog({
  member,
  open,
  onOpenChange,
}: {
  member: PublicUser | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>成员信息</DialogTitle>
        </DialogHeader>
        {member ? (
          <div className="space-y-5">
            <div className="flex items-center gap-4">
              <UserAvatar user={member} />
              <div>
                <div className="text-lg font-semibold text-slate-900">{member.displayName}</div>
                <div className="mt-1 flex items-center gap-2 text-sm text-slate-500">
                  <Badge variant="outline">{member.role === UserRole.Teacher ? '老师' : '学生'}</Badge>
                  <span>{member.username}</span>
                </div>
              </div>
            </div>
            {member.role === UserRole.Teacher ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <InfoCard label="学科" value={member.teacherProfile?.subject} />
                <InfoCard label="办公地点" value={member.teacherProfile?.office} />
              </div>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2">
                <InfoCard label="年级" value={member.studentProfile?.grade} />
                <InfoCard label="专业" value={member.studentProfile?.major} />
              </div>
            )}
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}

function InfoCard({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
      <div className="text-sm text-slate-500">{label}</div>
      <div className="mt-1 font-medium text-slate-900">{value?.trim() ? value : '未填写'}</div>
    </div>
  )
}
