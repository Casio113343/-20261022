import { Badge, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui'
import type { ReactNode } from 'react'
import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import type { SubmissionReview } from '@/microservices/assignment/objects/SubmissionReview'
import { useDashboardUiStore } from '@/stores/dashboard/useDashboardUiStore'

import { formatDateTime } from '@/pages/dashboard/functions/dashboardHelpers'
import {
  formatAssignmentDueText,
  isLateLocked,
  isLateOpen,
  splitStudentAssignments,
} from '@/pages/dashboard/functions/dashboardViewHelpers'

export function StudentAssignmentColumns({
  assignments,
  submissions,
  reviews,
  currentUserId,
  readReviewedAssignmentIds,
  onOpenAssignment,
  emptyPendingText = '当前没有待提交作业。',
  emptySubmittedText = '当前没有已提交作业。',
  toolbarRight,
}: {
  assignments: Assignment[]
  submissions: AssignmentSubmission[]
  reviews: SubmissionReview[]
  currentUserId: string
  readReviewedAssignmentIds: string[]
  onOpenAssignment: (assignmentId: string) => void
  emptyPendingText?: string
  emptySubmittedText?: string
  toolbarRight?: ReactNode
}) {
  const { pending, submitted } = splitStudentAssignments(assignments, submissions, currentUserId)
  const selectedTab = useDashboardUiStore((state) => state.studentAssignmentTab)
  const setStudentAssignmentTab = useDashboardUiStore((state) => state.setStudentAssignmentTab)
  const hasUnreadReviewedSubmission = submitted.some((assignment) => {
    const submission = submissions.find((item) => item.assignmentId === assignment.id && item.studentId === currentUserId)
    return Boolean(submission) && reviews.some((review) => review.submissionId === submission?.id) && !readReviewedAssignmentIds.includes(assignment.id)
  })

  return (
    <Tabs
      value={selectedTab}
      onValueChange={setStudentAssignmentTab}
      className="space-y-4"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <TabsList className="h-auto rounded-2xl bg-slate-100 p-1">
          <TabsTrigger value="pending" className="data-[state=active]:bg-white data-[state=active]:hover:bg-white">未提交</TabsTrigger>
          <TabsTrigger value="submitted" className="data-[state=active]:bg-white data-[state=active]:hover:bg-white">
            已提交
            {hasUnreadReviewedSubmission ? <span className="ml-2 size-2 rounded-full bg-rose-500" /> : null}
          </TabsTrigger>
        </TabsList>
        {toolbarRight}
      </div>
      <TabsContent value="pending">
        <div className="max-h-[32rem] space-y-4 overflow-y-auto pr-2">
        {pending.length ? pending.map((assignment) => (
          <button key={assignment.id} type="button" className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-4 text-left transition hover:bg-slate-50" onClick={() => onOpenAssignment(assignment.id)}>
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="font-medium">{assignment.title}</div>
                <div className="mt-1 text-sm text-slate-500">截止 {formatAssignmentDueText(assignment)}</div>
              </div>
              <Badge variant={isLateLocked(assignment) ? 'outline' : 'secondary'}>{isLateLocked(assignment) ? '已过期' : isLateOpen(assignment) ? '去补交' : '去提交'}</Badge>
            </div>
          </button>
        )) : <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">{emptyPendingText}</div>}
        </div>
      </TabsContent>
      <TabsContent value="submitted">
        <div className="max-h-[32rem] space-y-4 overflow-y-auto pr-2">
        {submitted.length ? submitted.map((assignment) => {
          const submission = submissions.find((item) => item.assignmentId === assignment.id && item.studentId === currentUserId)
          if (!submission) return null
          const isReviewed = reviews.some((review) => review.submissionId === submission.id)
          const hasUnreadReview = isReviewed && !readReviewedAssignmentIds.includes(assignment.id)
          return (
            <button key={assignment.id} type="button" className="flex w-full items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-4 text-left transition hover:bg-slate-50" onClick={() => onOpenAssignment(assignment.id)}>
              <div>
                <div className="font-medium">{assignment.title}</div>
                <div className="mt-1 text-sm text-slate-500">提交于 {formatDateTime(submission.submittedAt)}</div>
              </div>
              <div className="flex items-center gap-3">
                {hasUnreadReview ? <span className="size-2 rounded-full bg-rose-500" /> : null}
                <Badge variant={isReviewed ? 'secondary' : 'outline'}>{isReviewed ? '已批改' : '未批改'}</Badge>
              </div>
            </button>
          )
        }) : <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500">{emptySubmittedText}</div>}
        </div>
      </TabsContent>
    </Tabs>
  )
}
