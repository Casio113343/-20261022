import { Bell, BookOpen, ClipboardCheck, ClipboardList, MessageSquare, UserPlus } from 'lucide-react'

import { Card, CardContent, CardHeader, CardTitle, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { resolveUnreadChatCount } from '@/microservices/course/lib/chatHelpers'
import { useHiddenChatMessageIds, useSeenChatTimestamp } from '@/stores/course/useChatPreferencesStore'

import { countPendingAssignments } from '@/pages/dashboard/functions/dashboardHelpers'
import { courseHasUpdates } from '../../functions/courseWorkspaceHelpers'
import {
  countUnreadPublishedExams,
  countUnreadReviewedAssignments,
} from '../../functions/courseWorkspaceStats'
import type { CourseWorkspaceViewProps } from '../../courseWorkspaceTypes'
import { CourseChatPanel } from '../CourseChatPanel'
import { CourseAnnouncementsTab } from './CourseAnnouncementsTab'
import { CourseAssignmentsTab } from './CourseAssignmentsTab'
import { CourseExamsTab } from './CourseExamsTab'
import { CourseMembersTab } from './CourseMembersTab'
import { CourseQuestionnairesTab } from './CourseQuestionnairesTab'
import { CourseWorkspaceSelector } from './CourseWorkspaceSelector'

export function CourseWorkspacePanel(props: CourseWorkspaceViewProps) {
  const { selectedCourse, courseSummaries, selectedCourseId, setSelectedCourseId, isTeacher } = props
  const selectedIndex = courseSummaries.findIndex((item) => item.course.id === selectedCourseId)
  const otherCourses = courseSummaries.filter((_, index) => index !== selectedIndex)
  const courseIdsWithUpdates = courseSummaries
    .filter((course) => course.course.id !== selectedCourseId && courseHasUpdates(course, props.currentUserId))
    .map((course) => course.course.id)
  const hasOtherCourseUpdates = otherCourses.some((course) => courseHasUpdates(course, props.currentUserId))

  return (
    <Card className="border-emerald-100 bg-lime-50/20 shadow-[0_20px_60px_rgba(15,23,42,0.08)]">
      <CardHeader>
        <CardTitle className="text-xl">{isTeacher ? '课程工作区' : '我的课程区'}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        {courseSummaries.length ? (
          <>
            <CourseWorkspaceSelector courses={courseSummaries} selectedCourseId={selectedCourseId} hasOtherCourseUpdates={hasOtherCourseUpdates} courseIdsWithUpdates={courseIdsWithUpdates} onSelectCourse={setSelectedCourseId} />
            {selectedCourse ? <CoursePanel props={props} selectedCourse={selectedCourse} /> : null}
          </>
        ) : (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-sm text-slate-500">当前还没有可见课程。</div>
        )}
      </CardContent>
    </Card>
  )
}

function CoursePanel({
  props,
  selectedCourse,
}: {
  props: CourseWorkspaceViewProps
  selectedCourse: CourseDetailResponse
}) {
  const {
    currentUser,
    currentUserId,
    isTeacher,
    selectedTab,
    setSelectedTab,
    onOpenAnnouncement,
    onOpenAssignment,
    onOpenExam,
    onOpenQuestionnaire,
    onOpenAnnouncementCreate,
    onOpenAssignmentCreate,
    onOpenMemberManage,
    onOpenExamCreate,
    onOpenQuestionnaireCreate,
  } = props
  const selectedSummary = props.courseSummaries.find((item) => item.course.id === selectedCourse.course.id) ?? null
  const hiddenMessageIds = useHiddenChatMessageIds(currentUserId, selectedCourse.course.id)
  const seenChatTimestamp = useSeenChatTimestamp(currentUserId, selectedCourse.course.id)

  const unreadAnnouncementCount = selectedSummary?.unreadAnnouncementCount ?? selectedCourse.announcements.filter((item) => item.publisher.id !== currentUserId && !(currentUser.readAnnouncementIds ?? []).includes(item.id)).length
  const pendingAssignmentCount = selectedSummary?.pendingAssignmentCount ?? countPendingAssignments(selectedCourse, currentUserId)
  const unreadReviewedAssignmentCount = isTeacher ? 0 : selectedSummary?.unreadReviewedAssignmentCount ?? countUnreadReviewedAssignments(selectedCourse, currentUserId, currentUser)
  const assignmentIndicatorCount = isTeacher ? selectedSummary?.pendingReviewCount ?? 0 : pendingAssignmentCount + unreadReviewedAssignmentCount
  const unreadPublishedExamCount = isTeacher ? 0 : selectedSummary?.unreadPublishedExamCount ?? countUnreadPublishedExams(selectedCourse, currentUser)
  const examIndicatorCount = isTeacher ? selectedSummary?.pendingExamTaskCount ?? 0 : unreadPublishedExamCount
  const pendingQuestionnaireCount = selectedSummary?.pendingQuestionnaireCount ?? 0
  const unreadChatCount = resolveUnreadChatCount(
    selectedCourse.chatMessages,
    currentUserId,
    hiddenMessageIds,
    seenChatTimestamp,
  )

  const openAnnouncement = (announcementId: string) => {
    setSelectedTab('announcements')
    onOpenAnnouncement(announcementId)
  }
  const openAssignment = (assignmentId: string) => {
    setSelectedTab('assignments')
    onOpenAssignment(assignmentId)
  }
  const openExam = (examId: string) => {
    setSelectedTab('exams')
    onOpenExam(examId)
  }
  const openQuestionnaire = (questionnaireId: string) => {
    setSelectedTab('questionnaires')
    onOpenQuestionnaire(questionnaireId)
  }

  return (
    <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
      <TabsList className="h-auto flex-wrap rounded-2xl bg-[linear-gradient(180deg,#eef4ff_0%,#f8fafc_100%)] p-1 shadow-inner">
        <TabsTrigger value="announcements">
          <Bell className="size-4" />
          通知
          {unreadAnnouncementCount ? <span className="ml-1 inline-flex size-5 items-center justify-center rounded-full bg-rose-500 text-[11px] text-white">{unreadAnnouncementCount}</span> : null}
        </TabsTrigger>
        <TabsTrigger value="assignments">
          <BookOpen className="size-4" />
          作业
          {assignmentIndicatorCount ? <span className="ml-1 inline-flex size-5 items-center justify-center rounded-full bg-rose-500 text-[11px] text-white">{assignmentIndicatorCount}</span> : null}
        </TabsTrigger>
        <TabsTrigger value="exams">
          <ClipboardList className="size-4" />
          考试
          {examIndicatorCount ? <span className="ml-1 inline-flex size-5 items-center justify-center rounded-full bg-rose-500 text-[11px] text-white">{examIndicatorCount}</span> : null}
        </TabsTrigger>
        <TabsTrigger value="questionnaires">
          <ClipboardCheck className="size-4" />
          问卷
          {pendingQuestionnaireCount ? <span className="ml-1 inline-flex size-5 items-center justify-center rounded-full bg-rose-500 text-[11px] text-white">{pendingQuestionnaireCount}</span> : null}
        </TabsTrigger>
        <TabsTrigger value="chat">
          <MessageSquare className="size-4" />
          聊天
          {unreadChatCount ? <span className="ml-1 inline-flex min-w-5 items-center justify-center rounded-full bg-rose-500 px-1.5 text-[11px] text-white">{unreadChatCount}</span> : null}
        </TabsTrigger>
        <TabsTrigger value="members">
          <UserPlus className="size-4" />
          成员
        </TabsTrigger>
      </TabsList>

      <TabsContent value="announcements" className="space-y-4">
        <CourseAnnouncementsTab
          currentUser={currentUser}
          selectedCourse={selectedCourse}
          isTeacher={isTeacher}
          onCreateAnnouncement={() => {
            setSelectedTab('announcements')
            onOpenAnnouncementCreate(selectedCourse.course.id)
          }}
          onOpenAnnouncement={openAnnouncement}
        />
      </TabsContent>

      <TabsContent value="assignments" className="space-y-4">
        <CourseAssignmentsTab
          selectedCourse={selectedCourse}
          currentUserId={currentUserId}
          currentUser={currentUser}
          isTeacher={isTeacher}
          onCreateAssignment={() => {
            setSelectedTab('assignments')
            onOpenAssignmentCreate(selectedCourse.course.id)
          }}
          onOpenAssignment={openAssignment}
        />
      </TabsContent>

      <TabsContent value="members" className="space-y-4">
        <CourseMembersTab
          selectedCourse={selectedCourse}
          currentUserId={currentUserId}
          isTeacher={isTeacher}
          onOpenMemberManage={() => {
            setSelectedTab('members')
            onOpenMemberManage(selectedCourse.course.id)
          }}
          onLeaveCourse={props.onLeaveCourse}
          onDeleteCourse={props.onDeleteCourse}
        />
      </TabsContent>

      <TabsContent value="exams" className="space-y-4">
        <CourseExamsTab
          selectedCourse={selectedCourse}
          currentUser={currentUser}
          isTeacher={isTeacher}
          onCreateExam={() => {
            setSelectedTab('exams')
            onOpenExamCreate(selectedCourse.course.id)
          }}
          onOpenExam={openExam}
        />
      </TabsContent>

      <TabsContent value="questionnaires" className="space-y-4">
        <CourseQuestionnairesTab
          courseId={selectedCourse.course.id}
          currentUser={currentUser}
          isTeacher={isTeacher}
          onCreateQuestionnaire={() => {
            setSelectedTab('questionnaires')
            onOpenQuestionnaireCreate(selectedCourse.course.id)
          }}
          onOpenQuestionnaire={openQuestionnaire}
        />
      </TabsContent>

      <TabsContent value="chat">
        <CourseChatPanel
          courseId={selectedCourse.course.id}
          currentUser={currentUser}
          messages={selectedCourse.chatMessages}
          hasOlderMessages={props.chatHasOlderMessages}
          isInitialLoading={props.chatInitialLoading}
          isLoadingHistory={props.chatHistoryLoading}
          onCreateChatMessage={props.onCreateChatMessage}
          onLoadOlderMessages={props.onLoadOlderChatMessages}
          onRevokeChatMessage={props.onRevokeChatMessage}
          onHideChatMessage={props.onHideChatMessage}
          onReadMessages={props.onReadChatMessages}
        />
      </TabsContent>
    </Tabs>
  )
}
