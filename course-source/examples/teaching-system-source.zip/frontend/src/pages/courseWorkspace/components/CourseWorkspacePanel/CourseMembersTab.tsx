import { useState } from 'react'
import { History, LogOut, Trash2 } from 'lucide-react'

import { Button, Card, CardContent, CardHeader, CardTitle } from '@/components/ui'
import { ConfirmDialog } from '@/components/ui/confirmDialog'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import { MemberHistoryDialog } from './MemberHistoryDialog'
import { MemberProfileDialog } from './MemberProfileDialog'

export function CourseMembersTab({
  selectedCourse,
  currentUserId,
  isTeacher,
  onOpenMemberManage,
  onLeaveCourse,
  onDeleteCourse,
}: {
  selectedCourse: CourseDetailResponse
  currentUserId: string
  isTeacher: boolean
  onOpenMemberManage: () => void
  onLeaveCourse: (courseId: string) => Promise<void>
  onDeleteCourse: (courseId: string) => Promise<void>
}) {
  const [historyOpen, setHistoryOpen] = useState(false)
  const [leaveOpen, setLeaveOpen] = useState(false)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [selectedMember, setSelectedMember] = useState<PublicUser | null>(null)
  const [memberError, setMemberError] = useState('')

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {isTeacher ? <Button onClick={onOpenMemberManage}>添加成员</Button> : null}
        <Button type="button" variant="outline" onClick={() => setHistoryOpen(true)}>
          <History className="size-4" />
          成员历史
        </Button>
        <Button type="button" variant="outline" onClick={() => setLeaveOpen(true)}>
          <LogOut className="size-4" />
          退出课程
        </Button>
      </div>
      {memberError ? <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-600">{memberError}</div> : null}
      <Card className="border-slate-200 bg-white">
        <CardHeader><CardTitle className="text-lg">成员列表</CardTitle></CardHeader>
        <CardContent className="max-h-[32rem] space-y-5 overflow-y-auto pr-2">
          <div>
            <div className="mb-3 text-sm font-medium">老师</div>
            <div className="flex flex-wrap gap-2">
              {selectedCourse.course.teachers.map((teacher) => (
                <button
                  key={teacher.id}
                  type="button"
                  className="rounded-full bg-slate-50 px-3 py-2 text-sm transition hover:bg-slate-100 hover:text-sky-700"
                  onClick={() => setSelectedMember(teacher)}
                >
                  {teacher.displayName}
                </button>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-3 text-sm font-medium">学生</div>
            <div className="flex flex-wrap gap-2">
              {selectedCourse.course.students.map((student) => (
                <button
                  key={student.id}
                  type="button"
                  className="rounded-full bg-slate-50 px-3 py-2 text-sm transition hover:bg-slate-100 hover:text-sky-700"
                  onClick={() => setSelectedMember(student)}
                >
                  {student.displayName}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
      {isTeacher ? (
        <div className="flex justify-end">
          <Button type="button" variant="destructive" onClick={() => setDeleteOpen(true)}>
            <Trash2 className="size-4" />
            删除课程
          </Button>
        </div>
      ) : null}
      <MemberHistoryDialog selectedCourse={selectedCourse} currentUserId={currentUserId} open={historyOpen} onOpenChange={setHistoryOpen} />
      <MemberProfileDialog member={selectedMember} open={Boolean(selectedMember)} onOpenChange={(open) => { if (!open) setSelectedMember(null) }} />
      <ConfirmDialog
        open={leaveOpen}
        title="确认退出课程？"
        description={`退出课程《${selectedCourse.course.title}》后，你将无法再查看此课程信息。`}
        confirmLabel="确认退出"
        onOpenChange={setLeaveOpen}
        onConfirm={() => {
          void onLeaveCourse(selectedCourse.course.id)
            .then(() => setMemberError(''))
            .catch((error) => setMemberError(error instanceof Error ? error.message : '退出课程失败'))
        }}
      />
      <ConfirmDialog
        open={deleteOpen}
        title="确认删除课程？"
        description={`删除课程《${selectedCourse.course.title}》后，所有成员都将无法再查看此课程。`}
        confirmLabel="确认删除"
        onOpenChange={setDeleteOpen}
        onConfirm={() => {
          void onDeleteCourse(selectedCourse.course.id)
            .then(() => setMemberError(''))
            .catch((error) => setMemberError(error instanceof Error ? error.message : '删除课程失败'))
        }}
      />
    </div>
  )
}
