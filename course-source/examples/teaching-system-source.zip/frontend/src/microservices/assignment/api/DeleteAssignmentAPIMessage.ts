import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class DeleteAssignmentAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly assignmentId: string
  readonly operatorUserId: string

  constructor(courseId: string, assignmentId: string, operatorUserId: string) {
    super()
    this.courseId = courseId
    this.assignmentId = assignmentId
    this.operatorUserId = operatorUserId
  }}

