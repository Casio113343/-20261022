import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class UpdateAssignmentAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly assignmentId: string
  readonly operatorUserId: string
  readonly input: Assignment

  constructor(courseId: string, assignmentId: string, operatorUserId: string, input: Assignment) {
    super()
    this.courseId = courseId
    this.assignmentId = assignmentId
    this.operatorUserId = operatorUserId
    this.input = input
  }}

