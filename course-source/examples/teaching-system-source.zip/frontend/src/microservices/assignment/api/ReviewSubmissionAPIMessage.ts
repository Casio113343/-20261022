import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { SubmissionReview } from '@/microservices/assignment/objects/SubmissionReview'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class ReviewSubmissionAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly submissionId: string
  readonly operatorUserId: string
  readonly input: SubmissionReview

  constructor(submissionId: string, operatorUserId: string, input: SubmissionReview) {
    super()
    this.submissionId = submissionId
    this.operatorUserId = operatorUserId
    this.input = input
  }}

