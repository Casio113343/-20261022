import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class ClearDeletedCourseAssignmentsAPIMessage extends APIMessage<ActionResponse> {
  readonly reviewIds: string[]
  readonly submissionIds: string[]
  readonly assignmentIds: string[]

  constructor(reviewIds: string[], submissionIds: string[], assignmentIds: string[]) {
    super()
    this.reviewIds = reviewIds
    this.submissionIds = submissionIds
    this.assignmentIds = assignmentIds
  }
}
