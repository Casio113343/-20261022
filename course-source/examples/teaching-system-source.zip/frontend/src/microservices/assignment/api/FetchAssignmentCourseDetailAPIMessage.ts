import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class FetchAssignmentCourseDetailAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly assignmentId: string
  readonly userId: string

  constructor(assignmentId: string, userId: string) {
    super()
    this.assignmentId = assignmentId
    this.userId = userId
  }}

