import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { UserDashboardResponse } from '@/microservices/dashboard/api/responses/UserDashboardResponse'

export class MarkReviewedAssignmentReadAPIMessage extends APIMessage<UserDashboardResponse> {
  readonly assignmentId: string
  readonly userId: string

  constructor(assignmentId: string, userId: string) {
    super()
    this.assignmentId = assignmentId
    this.userId = userId
  }}

