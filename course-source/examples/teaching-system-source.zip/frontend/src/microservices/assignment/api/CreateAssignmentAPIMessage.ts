import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class CreateAssignmentAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly operatorUserId: string
  readonly input: Assignment

  constructor(courseId: string, operatorUserId: string, input: Assignment) {
    super()
    this.courseId = courseId
    this.operatorUserId = operatorUserId
    this.input = input
  }}

