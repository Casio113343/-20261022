import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class CreateSubmissionAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly assignmentId: string
  readonly operatorUserId: string
  readonly input: AssignmentSubmission

  constructor(assignmentId: string, operatorUserId: string, input: AssignmentSubmission) {
    super()
    this.assignmentId = assignmentId
    this.operatorUserId = operatorUserId
    this.input = input
  }}

