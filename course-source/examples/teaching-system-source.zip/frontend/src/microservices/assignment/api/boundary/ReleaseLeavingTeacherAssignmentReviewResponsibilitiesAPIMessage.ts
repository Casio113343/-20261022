import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'
import { Assignment } from '@/microservices/assignment/objects/Assignment'

export class ReleaseLeavingTeacherAssignmentReviewResponsibilitiesAPIMessage extends APIMessage<ActionResponse> {
  readonly assignments: Assignment[]

  constructor(assignments: Assignment[]) {
    super()
    this.assignments = assignments
  }
}
