import type { Attachment } from '@/infrastructure/storage/Attachment'

export class Assignment {
  constructor(
    public id: string,
    public courseId: string,
    public title: string,
    public content: string,
    public allowLateSubmission: boolean,
    public graderTeacherId: string,
    public dueAt: string,
    public createdByTeacherId: string,
    public createdAt: string,
    public attachment: Attachment | null | undefined = null,
    public maxScore: number | null | undefined = null,
    public answerAttachment: Attachment | null | undefined = null,
    public answerPublishedAt: string | null | undefined = null,
  ) {}
}
