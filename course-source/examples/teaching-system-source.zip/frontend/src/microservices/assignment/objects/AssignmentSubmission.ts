import type { Attachment } from '@/infrastructure/storage/Attachment'

export class AssignmentSubmission {
  constructor(
    public id: string,
    public assignmentId: string,
    public studentId: string,
    public content: string,
    public submittedAt: string,
    public attachment: Attachment | null | undefined = null,
  ) {}
}
