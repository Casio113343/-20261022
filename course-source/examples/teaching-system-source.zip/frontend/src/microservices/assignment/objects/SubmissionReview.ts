export class SubmissionReview {
  constructor(
    public id: string,
    public submissionId: string,
    public graderTeacherId: string,
    public reviewedAt: string,
    public score: number | null | undefined = null,
    public comment: string | null | undefined = null,
  ) {}
}
