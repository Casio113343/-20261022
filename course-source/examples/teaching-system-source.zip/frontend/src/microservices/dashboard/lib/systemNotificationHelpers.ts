import type { SystemNotificationSummary } from '@/microservices/dashboard/api/responses/SystemNotificationSummary'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export function countUnreadSystemNotifications(
  notifications: SystemNotificationSummary[],
  currentUser: PublicUser,
) {
  const readIds = currentUser.readSystemNotificationIds ?? []
  return notifications.filter((item) => !readIds.includes(item.id)).length
}

export function formatSystemNotificationDateTime(value: string) {
  return new Intl.DateTimeFormat('zh-CN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(value))
}
