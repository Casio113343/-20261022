export class SystemNotification {
  constructor(
    public id: string,
    public userId: string,
    public message: string,
    public createdAt: string,
  ) {}
}
