import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import type { ExamTeacherTask } from '@/microservices/exam/api/responses/ExamTeacherTask'
import type { AssignmentReviewTask } from './AssignmentReviewTask'
import type { DashboardCourseSummary } from './DashboardCourseSummary'
import type { SystemNotificationSummary } from './SystemNotificationSummary'

export class UserDashboardResponse {
  constructor(
    public currentUser: PublicUser,
    public courseSummaries: DashboardCourseSummary[],
    public reviewTasks: AssignmentReviewTask[],
    public examReviewTasks: ExamTeacherTask[],
    public systemNotifications: SystemNotificationSummary[],
  ) {}
}
