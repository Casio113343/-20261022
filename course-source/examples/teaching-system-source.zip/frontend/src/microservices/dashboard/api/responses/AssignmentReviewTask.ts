import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import type { CourseSummary } from '@/microservices/course/api/responses/CourseSummary'

export class AssignmentReviewTask {
  constructor(
    public submission: AssignmentSubmission,
    public assignment: Assignment,
    public course: CourseSummary,
  ) {}
}
