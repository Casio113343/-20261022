import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'
import { SystemNotification } from '@/microservices/dashboard/objects/SystemNotification'

export class PublishSystemNotificationsAPIMessage extends APIMessage<ActionResponse> {
  readonly notifications: SystemNotification[]

  constructor(notifications: SystemNotification[]) {
    super()
    this.notifications = notifications
  }
}
