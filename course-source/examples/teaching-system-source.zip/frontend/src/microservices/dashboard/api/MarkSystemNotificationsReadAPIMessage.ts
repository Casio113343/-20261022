import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { UserDashboardResponse } from '@/microservices/dashboard/api/responses/UserDashboardResponse'

export class MarkSystemNotificationsReadAPIMessage extends APIMessage<UserDashboardResponse> {
  readonly userId: string

  constructor(userId: string) {
    super()
    this.userId = userId
  }}

