import type { CourseSummary } from '@/microservices/course/api/responses/CourseSummary'

export class DashboardCourseSummary {
  constructor(
    public course: CourseSummary,
    public unreadAnnouncementCount: number,
    public pendingAssignmentCount: number,
    public unreadReviewedAssignmentCount: number,
    public unreadPublishedExamCount: number,
    public pendingReviewCount: number,
    public pendingExamReviewCount: number,
    public pendingExamTaskCount: number,
    public pendingQuestionnaireCount: number,
    public latestChatSentAt: string | null,
  ) {}
}
