export class SystemNotificationSummary {
  constructor(
    public id: string,
    public message: string,
    public createdAt: string,
  ) {}
}
