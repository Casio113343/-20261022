import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class DeleteQuestionnaireAPIMessage extends APIMessage<ActionResponse> {
  constructor(
    public questionnaireId: string,
    public userId: string,
  ) {
    super()
  }
}
