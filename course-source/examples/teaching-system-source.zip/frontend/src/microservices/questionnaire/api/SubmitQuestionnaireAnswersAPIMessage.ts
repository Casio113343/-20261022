import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { QuestionnaireSubmissionInput } from './requests/QuestionnaireSubmissionInput'
import type { QuestionnaireDetailResponse } from './responses/QuestionnaireDetailResponse'

export class SubmitQuestionnaireAnswersAPIMessage extends APIMessage<QuestionnaireDetailResponse> {
  constructor(
    public questionnaireId: string,
    public userId: string,
    public input: QuestionnaireSubmissionInput,
  ) {
    super()
  }
}
