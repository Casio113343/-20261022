export class QuestionnaireSummary {
  constructor(
    public id: string,
    public courseId: string,
    public title: string,
    public overview: string | null | undefined,
    public anonymous: boolean,
    public questionCount: number,
    public dueAt: string,
    public createdAt: string,
    public submitted: boolean,
    public filledCount: number,
    public unfilledCount: number,
  ) {}
}
