import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { QuestionnaireInput } from './requests/QuestionnaireInput'
import type { QuestionnaireDetailResponse } from './responses/QuestionnaireDetailResponse'

export class CreateQuestionnaireAPIMessage extends APIMessage<QuestionnaireDetailResponse> {
  constructor(
    public courseId: string,
    public userId: string,
    public input: QuestionnaireInput,
  ) {
    super()
  }
}
