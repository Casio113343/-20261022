import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { UserDashboardResponse } from '@/microservices/dashboard/api/responses/UserDashboardResponse'

export class MarkQuestionnaireReadAPIMessage extends APIMessage<UserDashboardResponse> {
  readonly questionnaireId: string
  readonly userId: string

  constructor(questionnaireId: string, userId: string) {
    super()
    this.questionnaireId = questionnaireId
    this.userId = userId
  }
}
