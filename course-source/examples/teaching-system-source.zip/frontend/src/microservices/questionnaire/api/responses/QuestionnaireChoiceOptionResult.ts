import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class QuestionnaireChoiceOptionResult {
  constructor(
    public option: string,
    public selectedCount: number,
    public students: PublicUser[] | null | undefined,
  ) {}
}
