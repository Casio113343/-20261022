import type { CourseSummary } from '@/microservices/course/api/responses/CourseSummary'
import type { Questionnaire } from '../../objects/Questionnaire'
import type { QuestionnaireSubmission } from '../../objects/QuestionnaireSubmission'
import type { QuestionnaireQuestionResult } from './QuestionnaireQuestionResult'

export class QuestionnaireDetailResponse {
  constructor(
    public questionnaire: Questionnaire,
    public course: CourseSummary,
    public currentUserSubmission: QuestionnaireSubmission | null | undefined,
    public filledCount: number,
    public unfilledCount: number,
    public results: QuestionnaireQuestionResult[] | null | undefined,
  ) {}
}
