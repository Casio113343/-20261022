import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { QuestionnaireDetailResponse } from './responses/QuestionnaireDetailResponse'

export class FetchQuestionnaireDetailAPIMessage extends APIMessage<QuestionnaireDetailResponse> {
  constructor(
    public questionnaireId: string,
    public userId: string,
  ) {
    super()
  }
}
