import type { QuestionnaireQuestion } from '../../objects/QuestionnaireQuestion'
import type { QuestionnaireChoiceOptionResult } from './QuestionnaireChoiceOptionResult'

export class QuestionnaireQuestionResult {
  constructor(
    public question: QuestionnaireQuestion,
    public options: QuestionnaireChoiceOptionResult[],
    public textAnswerCount: number,
  ) {}
}
