import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { QuestionnaireTextAnswer } from './responses/QuestionnaireTextAnswer'

export class FetchQuestionnaireTextAnswersAPIMessage extends APIMessage<QuestionnaireTextAnswer[]> {
  constructor(
    public questionnaireId: string,
    public questionId: string,
    public userId: string,
  ) {
    super()
  }
}
