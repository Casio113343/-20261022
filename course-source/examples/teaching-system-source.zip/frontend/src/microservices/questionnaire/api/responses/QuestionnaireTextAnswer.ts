import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class QuestionnaireTextAnswer {
  constructor(
    public submissionId: string,
    public student: PublicUser | null | undefined,
    public text: string,
  ) {}
}
