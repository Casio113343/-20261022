import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { QuestionnaireSummary } from './responses/QuestionnaireSummary'

export class FetchCourseQuestionnairesAPIMessage extends APIMessage<QuestionnaireSummary[]> {
  constructor(
    public courseId: string,
    public userId: string,
  ) {
    super()
  }
}
