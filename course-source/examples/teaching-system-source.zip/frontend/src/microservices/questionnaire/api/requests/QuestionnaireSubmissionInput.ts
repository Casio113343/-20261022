import type { QuestionnaireAnswer } from '../../objects/QuestionnaireAnswer'

export class QuestionnaireSubmissionInput {
  constructor(public answers: QuestionnaireAnswer[]) {}
}
