import type { QuestionnaireQuestion } from '../../objects/QuestionnaireQuestion'

export class QuestionnaireInput {
  constructor(
    public title: string,
    public overview: string | null | undefined,
    public anonymous: boolean,
    public questions: QuestionnaireQuestion[],
    public dueAt: string,
  ) {}
}
