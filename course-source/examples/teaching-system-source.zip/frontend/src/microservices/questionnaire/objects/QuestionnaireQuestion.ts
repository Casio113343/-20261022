export class QuestionnaireQuestion {
  constructor(
    public id: string,
    public title: string,
    public questionType: string,
    public required: boolean,
    public options: string[],
  ) {}
}
