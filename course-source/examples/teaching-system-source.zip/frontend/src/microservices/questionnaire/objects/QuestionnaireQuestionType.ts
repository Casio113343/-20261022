export const QuestionnaireQuestionType = {
  SingleChoice: 'single-choice',
  MultipleChoice: 'multiple-choice',
  Text: 'text',
} as const
