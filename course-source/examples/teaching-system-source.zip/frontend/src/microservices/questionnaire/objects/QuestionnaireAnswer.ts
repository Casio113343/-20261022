export class QuestionnaireAnswer {
  constructor(
    public questionId: string,
    public selectedOptions: string[],
    public text: string | null | undefined,
  ) {}
}
