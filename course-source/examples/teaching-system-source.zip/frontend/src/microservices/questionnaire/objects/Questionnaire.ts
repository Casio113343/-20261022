import type { QuestionnaireQuestion } from './QuestionnaireQuestion'

export class Questionnaire {
  constructor(
    public id: string,
    public courseId: string,
    public title: string,
    public overview: string | null | undefined,
    public anonymous: boolean,
    public questions: QuestionnaireQuestion[],
    public dueAt: string,
    public createdByTeacherId: string,
    public createdAt: string,
  ) {}
}
