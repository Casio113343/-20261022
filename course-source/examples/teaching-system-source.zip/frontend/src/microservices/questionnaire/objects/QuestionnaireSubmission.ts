import type { QuestionnaireAnswer } from './QuestionnaireAnswer'

export class QuestionnaireSubmission {
  constructor(
    public id: string,
    public questionnaireId: string,
    public studentId: string,
    public answers: QuestionnaireAnswer[],
    public submittedAt: string,
  ) {}
}
