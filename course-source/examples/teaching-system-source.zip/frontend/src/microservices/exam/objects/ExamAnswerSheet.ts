import type { Attachment } from '@/infrastructure/storage/Attachment'

export class ExamAnswerSheet {
  constructor(
    public id: string,
    public examId: string,
    public questionId: string,
    public studentId: string,
    public images: Attachment[],
  ) {}
}
