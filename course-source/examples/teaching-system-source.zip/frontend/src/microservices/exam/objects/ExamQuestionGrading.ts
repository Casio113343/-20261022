export class ExamQuestionGrading {
  constructor(
    public id: string,
    public answerSheetId: string,
    public graderTeacherId: string,
    public score: number,
    public gradedAt: string,
  ) {}
}
