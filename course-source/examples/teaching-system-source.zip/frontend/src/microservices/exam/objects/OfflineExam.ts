export class OfflineExam {
  constructor(
    public id: string,
    public courseId: string,
    public title: string,
    public createdByTeacherId: string,
    public createdAt: string,
    public questionIds: string[],
    public publishedAt: string | null = null,
    public appealDueAt: string | null = null,
  ) {}
}
