export class ExamQuestionAppeal {
  constructor(
    public id: string,
    public answerSheetId: string,
    public questionId: string,
    public studentId: string,
    public appealTeacherId: string,
    public expectedScore: number,
    public reason: string,
    public status: string,
    public submittedAt: string,
    public resolvedAt: string | null = null,
    public resolvedScore: number | null = null,
  ) {}
}
