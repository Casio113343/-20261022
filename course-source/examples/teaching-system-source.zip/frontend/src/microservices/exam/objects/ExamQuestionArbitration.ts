export class ExamQuestionArbitration {
  constructor(
    public id: string,
    public answerSheetId: string,
    public arbitrationTeacherId: string,
    public decidedScore: number,
    public decidedAt: string,
  ) {}
}
