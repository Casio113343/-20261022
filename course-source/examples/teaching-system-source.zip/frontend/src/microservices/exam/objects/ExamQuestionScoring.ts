export class ExamQuestionScoring {
  constructor(
    public fullScore: number,
    public graderTeacherIds: string[],
    public arbitrationEnabled: boolean,
    public appealEnabled: boolean,
    public arbitrationScoreDiffThreshold: number | null = null,
    public arbitrationTeacherId: string | null = null,
    public appealTeacherId: string | null = null,
  ) {}
}
