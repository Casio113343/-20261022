import { ExamQuestionScoring } from './ExamQuestionScoring'

export class OfflineExamQuestion {
  constructor(
    public id: string,
    public examId: string,
    public title: string,
    public position: number,
    public scoring: ExamQuestionScoring,
  ) {}
}
