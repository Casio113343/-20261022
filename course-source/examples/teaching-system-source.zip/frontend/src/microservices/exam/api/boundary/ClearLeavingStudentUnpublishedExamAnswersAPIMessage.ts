import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class ClearLeavingStudentUnpublishedExamAnswersAPIMessage extends APIMessage<ActionResponse> {
  readonly answerSheetIds: string[]
  readonly appealQuestionIds: string[]

  constructor(answerSheetIds: string[], appealQuestionIds: string[]) {
    super()
    this.answerSheetIds = answerSheetIds
    this.appealQuestionIds = appealQuestionIds
  }
}
