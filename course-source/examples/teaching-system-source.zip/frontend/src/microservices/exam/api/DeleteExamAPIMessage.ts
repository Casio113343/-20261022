import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class DeleteExamAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly examId: string
  readonly userId: string

  constructor(courseId: string, examId: string, userId: string) {
    super()
    this.courseId = courseId
    this.examId = examId
    this.userId = userId
  }}

