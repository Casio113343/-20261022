import type { ExamQuestionInput } from './ExamQuestionInput'

export class ExamInput {
  constructor(
    public title: string,
    public questions: ExamQuestionInput[],
    public appealDueAt: string | null | undefined = null,
  ) {}
}
