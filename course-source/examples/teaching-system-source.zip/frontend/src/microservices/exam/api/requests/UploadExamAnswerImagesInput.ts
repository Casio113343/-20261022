import type { Attachment } from '@/infrastructure/storage/Attachment'

export class UploadExamAnswerImagesInput {
  constructor(
    public studentId: string,
    public images: Attachment[],
  ) {}
}
