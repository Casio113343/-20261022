export class ExamQuestionInput {
  constructor(
    public title: string,
    public fullScore: number,
    public graderTeacherIds: string[],
    public arbitrationEnabled: boolean,
    public appealEnabled: boolean,
    public questionId: string | null | undefined = null,
    public arbitrationScoreDiffThreshold: number | null | undefined = null,
    public arbitrationTeacherId: string | null | undefined = null,
    public appealTeacherId: string | null | undefined = null,
  ) {}
}
