import type { ExamQuestionGraderProgress } from './ExamQuestionGraderProgress'

export class ExamQuestionGradingProgress {
  constructor(
    public questionId: string,
    public title: string,
    public position: number,
    public graders: ExamQuestionGraderProgress[],
  ) {}
}
