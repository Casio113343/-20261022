import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ExamReviewBoardResponse } from '@/microservices/exam/api/responses/ExamReviewBoardResponse'

export class ExamReviewBoardAPIMessage extends APIMessage<ExamReviewBoardResponse> {
  readonly examId: string
  readonly questionId: string
  readonly userId: string
  readonly mode: string

  constructor(examId: string, questionId: string, userId: string, mode: string) {
    super()
    this.examId = examId
    this.questionId = questionId
    this.userId = userId
    this.mode = mode
  }}

