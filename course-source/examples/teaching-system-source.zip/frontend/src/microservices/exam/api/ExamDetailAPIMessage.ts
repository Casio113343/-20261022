import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

export class ExamDetailAPIMessage extends APIMessage<ExamDetailResponse> {
  readonly examId: string
  readonly userId: string

  constructor(examId: string, userId: string) {
    super()
    this.examId = examId
    this.userId = userId
  }}

