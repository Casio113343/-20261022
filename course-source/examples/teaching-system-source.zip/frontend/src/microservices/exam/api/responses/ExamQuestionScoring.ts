import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class ExamQuestionScoring {
  constructor(
    public fullScore: number,
    public graders: PublicUser[],
    public arbitrationEnabled: boolean,
    public appealEnabled: boolean,
    public arbitrationScoreDiffThreshold: number | null = null,
    public arbitrationTeacher: PublicUser | null = null,
    public appealTeacher: PublicUser | null = null,
  ) {}
}
