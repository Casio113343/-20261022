import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { ExamInput } from '@/microservices/exam/api/requests/ExamInput'

export class CreateExamAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly userId: string
  readonly input: ExamInput

  constructor(courseId: string, userId: string, input: ExamInput) {
    super()
    this.courseId = courseId
    this.userId = userId
    this.input = input
  }}

