export class ExamTeacherScoreCell {
  constructor(
    public questionId: string,
    public title: string,
    public position: number,
    public fullScore: number,
    public status: string,
    public score: number | null = null,
  ) {}
}
