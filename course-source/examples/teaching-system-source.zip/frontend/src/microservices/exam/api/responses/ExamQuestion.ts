import type { ExamQuestionScoring } from './ExamQuestionScoring'

export class ExamQuestion {
  constructor(
    public id: string,
    public examId: string,
    public title: string,
    public position: number,
    public scoring: ExamQuestionScoring,
  ) {}
}
