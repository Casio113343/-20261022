import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class ExamQuestionGraderProgress {
  constructor(
    public grader: PublicUser,
    public gradedCount: number,
    public pendingGradingCount: number,
    public missingImportCount: number,
  ) {}
}
