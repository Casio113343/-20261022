import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import type { CourseSummary } from '@/microservices/course/api/responses/CourseSummary'

import type { ExamAnswerSheet } from './ExamAnswerSheet'
import type { ExamQuestion } from './ExamQuestion'
import type { ExamQuestionAppeal } from './ExamQuestionAppeal'
import type { ExamQuestionGradingProgress } from './ExamQuestionGradingProgress'
import type { ExamStudentResult } from './ExamStudentResult'
import type { ExamSummary } from './ExamSummary'
import type { ExamTeacherScoreRow } from './ExamTeacherScoreRow'
import type { ExamTeacherTask } from './ExamTeacherTask'

export class ExamDetailResponse {
  constructor(
    public exam: ExamSummary,
    public course: CourseSummary,
    public questions: ExamQuestion[],
    public answerSheets: ExamAnswerSheet[],
    public participantStudents: PublicUser[],
    public teacherTasks: ExamTeacherTask[],
    public gradingProgress: ExamQuestionGradingProgress[],
    public scoreRows: ExamTeacherScoreRow[],
    public appeals: ExamQuestionAppeal[],
    public canPublish: boolean,
    public studentResult: ExamStudentResult | null = null,
  ) {}
}
