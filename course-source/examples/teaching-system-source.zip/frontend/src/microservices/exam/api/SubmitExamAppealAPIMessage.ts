import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { SubmitExamAppealInput } from '@/microservices/exam/api/requests/SubmitExamAppealInput'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

export class SubmitExamAppealAPIMessage extends APIMessage<ExamDetailResponse> {
  readonly examId: string
  readonly questionId: string
  readonly userId: string
  readonly input: SubmitExamAppealInput

  constructor(examId: string, questionId: string, userId: string, input: SubmitExamAppealInput) {
    super()
    this.examId = examId
    this.questionId = questionId
    this.userId = userId
    this.input = input
  }}

