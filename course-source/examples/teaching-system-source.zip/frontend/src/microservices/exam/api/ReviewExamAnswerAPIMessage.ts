import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ReviewExamAnswerInput } from '@/microservices/exam/api/requests/ReviewExamAnswerInput'
import type { ExamReviewBoardResponse } from '@/microservices/exam/api/responses/ExamReviewBoardResponse'

export class ReviewExamAnswerAPIMessage extends APIMessage<ExamReviewBoardResponse> {
  readonly examId: string
  readonly questionId: string
  readonly answerSheetId: string
  readonly userId: string
  readonly mode: string
  readonly input: ReviewExamAnswerInput

  constructor(examId: string, questionId: string, answerSheetId: string, userId: string, mode: string, input: ReviewExamAnswerInput) {
    super()
    this.examId = examId
    this.questionId = questionId
    this.answerSheetId = answerSheetId
    this.userId = userId
    this.mode = mode
    this.input = input
  }}

