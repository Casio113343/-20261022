import type { PublicUser } from '@/microservices/auth/objects/PublicUser'
import type { ExamTeacherScoreCell } from './ExamTeacherScoreCell'

export class ExamTeacherScoreRow {
  constructor(
    public student: PublicUser,
    public questions: ExamTeacherScoreCell[],
    public totalScore: number | null = null,
  ) {}
}
