export class ExamTeacherTask {
  constructor(
    public examId: string,
    public examTitle: string,
    public questionId: string,
    public questionTitle: string,
    public position: number,
    public mode: string,
    public pendingCount: number,
    public completedCount: number,
  ) {}
}
