import type { ExamQuestionResult } from './ExamQuestionResult'

export class ExamStudentResult {
  constructor(
    public published: boolean,
    public totalFullScore: number,
    public questions: ExamQuestionResult[],
    public totalScore: number | null = null,
  ) {}
}
