export class SubmitExamAppealInput {
  constructor(
    public expectedScore: number,
    public reason: string,
  ) {}
}
