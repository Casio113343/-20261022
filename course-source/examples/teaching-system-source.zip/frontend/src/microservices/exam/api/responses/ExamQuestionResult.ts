import type { ExamQuestionAppeal } from './ExamQuestionAppeal'

export class ExamQuestionResult {
  constructor(
    public questionId: string,
    public title: string,
    public position: number,
    public fullScore: number,
    public status: string,
    public canAppeal: boolean,
    public score: number | null = null,
    public appeal: ExamQuestionAppeal | null = null,
  ) {}
}
