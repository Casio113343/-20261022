import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { UploadExamAnswerImagesInput } from '@/microservices/exam/api/requests/UploadExamAnswerImagesInput'
import type { ExamDetailResponse } from '@/microservices/exam/api/responses/ExamDetailResponse'

export class UploadExamAnswerImagesAPIMessage extends APIMessage<ExamDetailResponse> {
  readonly examId: string
  readonly questionId: string
  readonly userId: string
  readonly input: UploadExamAnswerImagesInput

  constructor(examId: string, questionId: string, userId: string, input: UploadExamAnswerImagesInput) {
    super()
    this.examId = examId
    this.questionId = questionId
    this.userId = userId
    this.input = input
  }}

