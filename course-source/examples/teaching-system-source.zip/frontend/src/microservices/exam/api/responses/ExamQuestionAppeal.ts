import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class ExamQuestionAppeal {
  constructor(
    public id: string,
    public questionId: string,
    public answerSheetId: string,
    public student: PublicUser,
    public appealTeacher: PublicUser,
    public expectedScore: number,
    public reason: string,
    public status: string,
    public submittedAt: string,
    public resolvedAt: string | null = null,
    public resolvedScore: number | null = null,
  ) {}
}
