import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class ClearDeletedCourseExamsAPIMessage extends APIMessage<ActionResponse> {
  readonly answerSheetIds: string[]
  readonly questionIds: string[]
  readonly examIds: string[]

  constructor(answerSheetIds: string[], questionIds: string[], examIds: string[]) {
    super()
    this.answerSheetIds = answerSheetIds
    this.questionIds = questionIds
    this.examIds = examIds
  }
}
