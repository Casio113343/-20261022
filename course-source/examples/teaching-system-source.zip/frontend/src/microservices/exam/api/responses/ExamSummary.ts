import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class ExamSummary {
  constructor(
    public id: string,
    public courseId: string,
    public title: string,
    public createdBy: PublicUser,
    public createdAt: string,
    public questionCount: number,
    public publishedAt: string | null = null,
    public appealDueAt: string | null = null,
  ) {}
}
