import type { Attachment } from '@/infrastructure/storage/Attachment'
import type { ExamQuestionAppeal } from './ExamQuestionAppeal'

export class ExamReviewItem {
  constructor(
    public answerSheetId: string,
    public label: string,
    public status: string,
    public images: Attachment[],
    public graderScores: number[],
    public score: number | null = null,
    public appeal: ExamQuestionAppeal | null = null,
  ) {}
}
