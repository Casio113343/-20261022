export class ReviewExamAnswerInput {
  constructor(
    public score: number,
  ) {}
}
