import type { CourseSummary } from '@/microservices/course/api/responses/CourseSummary'

import type { ExamQuestion } from './ExamQuestion'
import type { ExamReviewItem } from './ExamReviewItem'
import type { ExamSummary } from './ExamSummary'

export class ExamReviewBoardResponse {
  constructor(
    public exam: ExamSummary,
    public course: CourseSummary,
    public question: ExamQuestion,
    public mode: string,
    public pendingItems: ExamReviewItem[],
    public completedItems: ExamReviewItem[],
    public currentItem: ExamReviewItem | null = null,
  ) {}
}
