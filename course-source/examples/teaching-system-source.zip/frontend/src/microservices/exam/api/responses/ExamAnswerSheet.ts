import type { Attachment } from '@/infrastructure/storage/Attachment'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class ExamAnswerSheet {
  constructor(
    public id: string,
    public examId: string,
    public questionId: string,
    public student: PublicUser,
    public images: Attachment[],
  ) {}
}
