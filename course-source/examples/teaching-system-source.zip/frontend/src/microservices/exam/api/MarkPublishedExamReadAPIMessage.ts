import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { UserDashboardResponse } from '@/microservices/dashboard/api/responses/UserDashboardResponse'

export class MarkPublishedExamReadAPIMessage extends APIMessage<UserDashboardResponse> {
  readonly examId: string
  readonly userId: string

  constructor(examId: string, userId: string) {
    super()
    this.examId = examId
    this.userId = userId
  }}

