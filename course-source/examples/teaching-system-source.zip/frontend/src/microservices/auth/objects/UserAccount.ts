import { StudentProfile } from './StudentProfile'
import { TeacherProfile } from './TeacherProfile'

export class UserAccount {
  constructor(
    public id: string,
    public username: string,
    public password: string,
    public displayName: string,
    public role: string,
    public avatarDataUrl: string | null | undefined = null,
    public readAnnouncementIds: string[] | undefined = [],
    public readSystemNotificationIds: string[] | undefined = [],
    public readReviewedAssignmentIds: string[] | undefined = [],
    public readPublishedExamIds: string[] | undefined = [],
    public readQuestionnaireIds: string[] | undefined = [],
    public teacherProfile: TeacherProfile | null | undefined = null,
    public studentProfile: StudentProfile | null | undefined = null,
  ) {}
}
