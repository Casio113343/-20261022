export class TeacherProfile {
  constructor(
    public subject: string | null | undefined = null,
    public office: string | null | undefined = null,
  ) {}
}
