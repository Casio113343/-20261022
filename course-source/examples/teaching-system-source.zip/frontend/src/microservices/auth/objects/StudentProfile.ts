export class StudentProfile {
  constructor(
    public grade: string | null | undefined = null,
    public major: string | null | undefined = null,
  ) {}
}
