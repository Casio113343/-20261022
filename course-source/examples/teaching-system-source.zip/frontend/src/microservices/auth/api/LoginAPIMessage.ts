import { APIMessage } from '@/infrastructure/api/APIMessage'
import { LoginInput } from './requests/LoginInput'
import type { LoginOutput } from './responses/LoginOutput'

export class LoginAPIMessage extends APIMessage<LoginOutput> {
  readonly input: LoginInput

  constructor(input: LoginInput) {
    super()
    this.input = input
  }}

