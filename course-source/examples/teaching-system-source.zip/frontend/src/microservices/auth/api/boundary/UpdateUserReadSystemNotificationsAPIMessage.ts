import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class UpdateUserReadSystemNotificationsAPIMessage extends APIMessage<ActionResponse> {
  readonly userId: string
  readonly notificationIds: string[]

  constructor(userId: string, notificationIds: string[]) {
    super()
    this.userId = userId
    this.notificationIds = notificationIds
  }
}
