import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class LoginOutput {
  constructor(public user: PublicUser) {}
}
