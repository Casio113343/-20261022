import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class RegisterOutput {
  constructor(public user: PublicUser) {}
}
