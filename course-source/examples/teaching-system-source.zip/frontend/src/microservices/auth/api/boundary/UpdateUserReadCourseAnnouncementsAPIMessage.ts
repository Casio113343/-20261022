import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class UpdateUserReadCourseAnnouncementsAPIMessage extends APIMessage<ActionResponse> {
  readonly userId: string
  readonly announcementIds: string[]

  constructor(userId: string, announcementIds: string[]) {
    super()
    this.userId = userId
    this.announcementIds = announcementIds
  }
}
