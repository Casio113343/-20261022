import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class ClearDeletedExamResultReadMarkersAPIMessage extends APIMessage<ActionResponse> {
  readonly userIds: string[]
  readonly examId: string

  constructor(userIds: string[], examId: string) {
    super()
    this.userIds = userIds
    this.examId = examId
  }
}
