import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { UserDashboardResponse } from '@/microservices/dashboard/api/responses/UserDashboardResponse'
import { ProfileUpdate } from './requests/ProfileUpdate'

export class UpdateProfileAPIMessage extends APIMessage<UserDashboardResponse> {
  readonly userId: string
  readonly input: ProfileUpdate

  constructor(userId: string, input: ProfileUpdate) {
    super()
    this.userId = userId
    this.input = input
  }}

