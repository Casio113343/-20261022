import { APIMessage } from '@/infrastructure/api/APIMessage'
import { RegisterInput } from './requests/RegisterInput'
import type { RegisterOutput } from './responses/RegisterOutput'

export class RegisterAPIMessage extends APIMessage<RegisterOutput> {
  readonly input: RegisterInput

  constructor(input: RegisterInput) {
    super()
    this.input = input
  }}

