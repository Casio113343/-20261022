import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class ClearDeletedAssignmentReviewReadMarkersAPIMessage extends APIMessage<ActionResponse> {
  readonly userIds: string[]
  readonly assignmentId: string

  constructor(userIds: string[], assignmentId: string) {
    super()
    this.userIds = userIds
    this.assignmentId = assignmentId
  }
}
