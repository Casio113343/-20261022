import type { StudentProfile } from '@/microservices/auth/objects/StudentProfile'
import type { TeacherProfile } from '@/microservices/auth/objects/TeacherProfile'

export class RegisterInput {
  constructor(
    public username: string,
    public password: string,
    public displayName: string,
    public role: string,
    public teacherProfile: TeacherProfile | null | undefined = null,
    public studentProfile: StudentProfile | null | undefined = null,
  ) {}
}
