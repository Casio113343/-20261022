export class LoginInput {
  constructor(
    public username: string,
    public password: string,
    public role: string,
  ) {}
}
