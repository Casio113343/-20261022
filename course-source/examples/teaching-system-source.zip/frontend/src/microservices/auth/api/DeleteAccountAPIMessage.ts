import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class DeleteAccountAPIMessage extends APIMessage<ActionResponse> {
  readonly userId: string

  constructor(userId: string) {
    super()
    this.userId = userId
  }}

