import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class ClearDeletedAnnouncementReadMarkersAPIMessage extends APIMessage<ActionResponse> {
  readonly userIds: string[]
  readonly announcementId: string

  constructor(userIds: string[], announcementId: string) {
    super()
    this.userIds = userIds
    this.announcementId = announcementId
  }
}
