import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class UpdateUserReadPublishedExamAPIMessage extends APIMessage<ActionResponse> {
  readonly userId: string
  readonly examId: string

  constructor(userId: string, examId: string) {
    super()
    this.userId = userId
    this.examId = examId
  }
}
