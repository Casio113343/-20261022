import type { StudentProfile } from '@/microservices/auth/objects/StudentProfile'
import type { TeacherProfile } from '@/microservices/auth/objects/TeacherProfile'

export class ProfileUpdate {
  constructor(
    public displayName: string | null | undefined = null,
    public currentPassword: string | null | undefined = null,
    public newPassword: string | null | undefined = null,
    public avatarDataUrl: string | null | undefined = null,
    public clearAvatar: boolean = false,
    public teacherProfile: TeacherProfile | null | undefined = null,
    public studentProfile: StudentProfile | null | undefined = null,
  ) {}
}
