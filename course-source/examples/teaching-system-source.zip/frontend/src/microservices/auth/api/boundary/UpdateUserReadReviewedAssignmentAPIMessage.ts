import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class UpdateUserReadReviewedAssignmentAPIMessage extends APIMessage<ActionResponse> {
  readonly userId: string
  readonly assignmentId: string

  constructor(userId: string, assignmentId: string) {
    super()
    this.userId = userId
    this.assignmentId = assignmentId
  }
}
