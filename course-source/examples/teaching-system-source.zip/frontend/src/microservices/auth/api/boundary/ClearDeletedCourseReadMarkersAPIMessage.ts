import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { ActionResponse } from '@/infrastructure/api/CommonResponses'

export class ClearDeletedCourseReadMarkersAPIMessage extends APIMessage<ActionResponse> {
  readonly userIds: string[]
  readonly announcementIds: string[]
  readonly assignmentIds: string[]
  readonly examIds: string[]

  constructor(userIds: string[], announcementIds: string[], assignmentIds: string[], examIds: string[]) {
    super()
    this.userIds = userIds
    this.announcementIds = announcementIds
    this.assignmentIds = assignmentIds
    this.examIds = examIds
  }
}
