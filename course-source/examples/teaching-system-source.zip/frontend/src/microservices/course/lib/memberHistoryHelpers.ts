import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'
import type { CourseMemberHistoryEntry } from '@/microservices/course/api/responses/CourseMemberHistoryEntry'

export function isCourseCreationEvent(course: CourseDetailResponse, event: CourseMemberHistoryEntry) {
  return event.action === 'joined' &&
    event.occurredAt === course.course.createdAt &&
    event.user.id === course.course.teachers[0]?.id
}

export function describeMemberHistoryEvent(course: CourseDetailResponse, event: CourseMemberHistoryEntry, currentUserId: string) {
  const occurredAtText = new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(event.occurredAt))
  if (event.user.id === currentUserId) {
    if (isCourseCreationEvent(course, event)) {
      return `你创建了课程 / ${occurredAtText}`
    }

    return `你${event.action === 'joined' ? '加入' : '退出'}了课程 / ${occurredAtText}`
  }

  return `${event.user.displayName} / ${event.role === UserRole.Teacher ? '老师' : '学生'} / ${event.action === 'joined' ? '加入课程' : '退出课程'} / ${occurredAtText}`
}
import { UserRole } from '@/microservices/auth/objects/UserRole'
