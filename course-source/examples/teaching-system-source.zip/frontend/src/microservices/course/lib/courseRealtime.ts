import { CourseChatMessage } from '@/microservices/course/api/responses/CourseChatMessage'

export class CourseRealtimeEvent {
  constructor(
    public eventType: string,
    public courseId: string,
    public chatMessage: CourseChatMessage | null,
  ) {}
}

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? ''

export function buildCourseWebSocketUrl(courseId: string) {
  const baseUrl = API_BASE || window.location.origin
  const normalizedBaseUrl = baseUrl.replace(/^http/, 'ws')
  return `${normalizedBaseUrl}/ws/courses/${courseId}`
}
