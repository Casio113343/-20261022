import type { CourseChatMessage } from '@/microservices/course/api/responses/CourseChatMessage'

export function resolveUnreadChatCount(
  messages: CourseChatMessage[],
  currentUserId: string,
  hiddenMessageIds: string[],
  seenTimestamp: string | null,
) {
  const seenTime = seenTimestamp ? new Date(seenTimestamp).getTime() : 0
  const hiddenIds = new Set(hiddenMessageIds)

  return messages.filter((message) => (
    message.sender.id !== currentUserId &&
    !message.revokedAt &&
    !hiddenIds.has(message.id) &&
    new Date(message.sentAt).getTime() > seenTime
  )).length
}

export function resolveUnreadChatCountFromLatestTimestamp(
  latestChatSentAt: string | null,
  seenTimestamp: string | null,
) {
  if (!latestChatSentAt) return 0
  const seenTime = seenTimestamp ? new Date(seenTimestamp).getTime() : 0
  return new Date(latestChatSentAt).getTime() > seenTime ? 1 : 0
}
