import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseChatMessageInput } from '@/microservices/course/api/requests/CourseChatMessageInput'
import type { CourseChatMessage } from '@/microservices/course/api/responses/CourseChatMessage'

export class CreateCourseChatMessageAPIMessage extends APIMessage<CourseChatMessage> {
  readonly courseId: string
  readonly userId: string
  readonly input: CourseChatMessageInput

  constructor(courseId: string, userId: string, input: CourseChatMessageInput) {
    super()
    this.courseId = courseId
    this.userId = userId
    this.input = input
  }}

