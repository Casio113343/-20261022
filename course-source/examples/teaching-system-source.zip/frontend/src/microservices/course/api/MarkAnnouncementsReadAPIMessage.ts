import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { UserDashboardResponse } from '@/microservices/dashboard/api/responses/UserDashboardResponse'

export class MarkAnnouncementsReadAPIMessage extends APIMessage<UserDashboardResponse> {
  readonly courseId: string
  readonly userId: string

  constructor(courseId: string, userId: string) {
    super()
    this.courseId = courseId
    this.userId = userId
  }}

