import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseChatMessage } from '@/microservices/course/api/responses/CourseChatMessage'

export class RevokeCourseChatMessageAPIMessage extends APIMessage<CourseChatMessage> {
  readonly courseId: string
  readonly messageId: string
  readonly userId: string

  constructor(courseId: string, messageId: string, userId: string) {
    super()
    this.courseId = courseId
    this.messageId = messageId
    this.userId = userId
  }}

