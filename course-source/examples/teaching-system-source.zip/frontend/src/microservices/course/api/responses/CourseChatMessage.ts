import type { Attachment } from '@/infrastructure/storage/Attachment'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class CourseChatMessage {
  constructor(
    public id: string,
    public courseId: string,
    public sender: PublicUser,
    public content: string,
    public images: Attachment[],
    public attachments: Attachment[],
    public sentAt: string,
    public canRevoke: boolean,
    public revokedAt: string | null = null,
    public revokedByUserId: string | null = null,
  ) {}
}
