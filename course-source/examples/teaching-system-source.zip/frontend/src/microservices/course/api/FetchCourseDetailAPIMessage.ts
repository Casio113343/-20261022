import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class FetchCourseDetailAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly userId: string

  constructor(courseId: string, userId: string) {
    super()
    this.courseId = courseId
    this.userId = userId
  }}

