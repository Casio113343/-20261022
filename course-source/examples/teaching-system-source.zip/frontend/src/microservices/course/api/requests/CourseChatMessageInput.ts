import type { Attachment } from '@/infrastructure/storage/Attachment'

export class CourseChatMessageInput {
  constructor(
    public content: string,
    public images: Attachment[],
    public attachments: Attachment[],
  ) {}
}
