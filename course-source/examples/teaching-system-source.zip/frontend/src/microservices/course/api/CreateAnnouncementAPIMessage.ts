import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseAnnouncementInput } from '@/microservices/course/api/requests/CourseAnnouncementInput'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class CreateAnnouncementAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly userId: string
  readonly input: CourseAnnouncementInput

  constructor(courseId: string, userId: string, input: CourseAnnouncementInput) {
    super()
    this.courseId = courseId
    this.userId = userId
    this.input = input
  }}

