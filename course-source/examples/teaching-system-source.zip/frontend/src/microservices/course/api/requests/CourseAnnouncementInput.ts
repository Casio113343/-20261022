import type { Attachment } from '@/infrastructure/storage/Attachment'

export class CourseAnnouncementInput {
  constructor(
    public title: string,
    public content: string,
    public attachment: Attachment | null | undefined = null,
  ) {}
}
