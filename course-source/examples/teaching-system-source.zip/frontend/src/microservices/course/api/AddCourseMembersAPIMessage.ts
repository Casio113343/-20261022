import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { AddCourseMembersInput } from '@/microservices/course/api/requests/AddCourseMembersInput'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class AddCourseMembersAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly userId: string
  readonly input: AddCourseMembersInput

  constructor(courseId: string, userId: string, input: AddCourseMembersInput) {
    super()
    this.courseId = courseId
    this.userId = userId
    this.input = input
  }}

