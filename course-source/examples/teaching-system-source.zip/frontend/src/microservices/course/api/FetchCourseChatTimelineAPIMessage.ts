import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseChatTimelinePage } from '@/microservices/course/api/responses/CourseChatTimelinePage'

export class FetchCourseChatTimelineAPIMessage extends APIMessage<CourseChatTimelinePage> {
  readonly courseId: string
  readonly userId: string
  readonly limit: number
  readonly beforeSentAt: string | null | undefined
  readonly beforeRowIndex: number | null | undefined

  constructor(courseId: string, userId: string, limit = 50, beforeSentAt?: string | null, beforeRowIndex?: number | null) {
    super()
    this.courseId = courseId
    this.userId = userId
    this.limit = limit
    this.beforeSentAt = beforeSentAt
    this.beforeRowIndex = beforeRowIndex
  }}

