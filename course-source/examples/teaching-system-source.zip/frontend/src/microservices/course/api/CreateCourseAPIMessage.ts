import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CreateCourseInput } from '@/microservices/course/api/requests/CreateCourseInput'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class CreateCourseAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly userId: string
  readonly input: CreateCourseInput

  constructor(userId: string, input: CreateCourseInput) {
    super()
    this.userId = userId
    this.input = input
  }}

