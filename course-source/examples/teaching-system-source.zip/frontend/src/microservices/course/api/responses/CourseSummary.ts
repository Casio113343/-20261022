import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class CourseSummary {
  constructor(
    public id: string,
    public title: string,
    public description: string,
    public teachers: PublicUser[],
    public students: PublicUser[],
    public createdAt: string,
  ) {}
}
