import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseDetailResponse } from './responses/CourseDetailResponse'

export class FetchAnnouncementCourseDetailAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly announcementId: string
  readonly userId: string

  constructor(announcementId: string, userId: string) {
    super()
    this.announcementId = announcementId
    this.userId = userId
  }}

