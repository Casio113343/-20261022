export class CreateCourseInput {
  constructor(
    public title: string,
    public description: string,
  ) {}
}
