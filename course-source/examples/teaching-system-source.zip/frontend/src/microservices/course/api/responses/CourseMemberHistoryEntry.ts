import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class CourseMemberHistoryEntry {
  constructor(
    public user: PublicUser,
    public role: string,
    public action: string,
    public occurredAt: string,
  ) {}
}
