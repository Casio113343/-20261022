import type { Assignment } from '@/microservices/assignment/objects/Assignment'
import type { AssignmentSubmission } from '@/microservices/assignment/objects/AssignmentSubmission'
import type { SubmissionReview } from '@/microservices/assignment/objects/SubmissionReview'
import type { ExamSummary } from '@/microservices/exam/api/responses/ExamSummary'

import type { CourseAnnouncement } from './CourseAnnouncement'
import type { CourseChatMessage } from './CourseChatMessage'
import type { CourseMemberHistoryEntry } from './CourseMemberHistoryEntry'
import type { CourseSummary } from './CourseSummary'

export class CourseDetailResponse {
  constructor(
    public course: CourseSummary,
    public announcements: CourseAnnouncement[],
    public assignments: Assignment[],
    public submissions: AssignmentSubmission[],
    public reviews: SubmissionReview[],
    public exams: ExamSummary[],
    public chatMessages: CourseChatMessage[],
    public memberHistory: CourseMemberHistoryEntry[],
  ) {}
}
