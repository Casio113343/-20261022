import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class DeleteAnnouncementAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly announcementId: string
  readonly userId: string

  constructor(courseId: string, announcementId: string, userId: string) {
    super()
    this.courseId = courseId
    this.announcementId = announcementId
    this.userId = userId
  }}

