import type { CourseChatMessage } from './CourseChatMessage'

export class CourseChatTimelinePage {
  constructor(
    public messages: CourseChatMessage[],
    public nextCursorSentAt: string | null = null,
    public nextCursorRowIndex: number | null = null,
  ) {}
}
