import { APIMessage } from '@/infrastructure/api/APIMessage'
import type { CourseAnnouncementInput } from '@/microservices/course/api/requests/CourseAnnouncementInput'
import type { CourseDetailResponse } from '@/microservices/course/api/responses/CourseDetailResponse'

export class UpdateAnnouncementAPIMessage extends APIMessage<CourseDetailResponse> {
  readonly courseId: string
  readonly announcementId: string
  readonly userId: string
  readonly input: CourseAnnouncementInput

  constructor(courseId: string, announcementId: string, userId: string, input: CourseAnnouncementInput) {
    super()
    this.courseId = courseId
    this.announcementId = announcementId
    this.userId = userId
    this.input = input
  }}

