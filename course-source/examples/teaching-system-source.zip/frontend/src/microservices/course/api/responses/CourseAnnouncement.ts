import type { Attachment } from '@/infrastructure/storage/Attachment'
import type { PublicUser } from '@/microservices/auth/objects/PublicUser'

export class CourseAnnouncement {
  constructor(
    public id: string,
    public courseId: string,
    public title: string,
    public content: string,
    public publisher: PublicUser,
    public createdAt: string,
    public attachment: Attachment | null = null,
  ) {}
}
