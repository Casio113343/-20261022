export class AddCourseMembersInput {
  constructor(
    public usernames: string[],
  ) {}
}
