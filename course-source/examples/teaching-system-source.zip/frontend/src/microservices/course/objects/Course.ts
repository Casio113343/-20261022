import { CourseMemberEvent } from './CourseMemberEvent'

export class Course {
  constructor(
    public id: string,
    public title: string,
    public description: string,
    public teachers: string[],
    public students: string[],
    public createdAt: string,
    public memberEvents: CourseMemberEvent[],
  ) {}
}
