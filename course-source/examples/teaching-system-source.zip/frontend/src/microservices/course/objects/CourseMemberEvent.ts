export class CourseMemberEvent {
  constructor(
    public userId: string,
    public role: string,
    public action: string,
    public occurredAt: string,
  ) {}
}
