import type { Attachment } from '@/infrastructure/storage/Attachment'

export class CourseChatMessage {
  constructor(
    public id: string,
    public courseId: string,
    public senderUserId: string,
    public content: string,
    public images: Attachment[],
    public attachments: Attachment[],
    public sentAt: string,
    public revokedAt: string | null,
    public revokedByUserId: string | null,
  ) {}
}
