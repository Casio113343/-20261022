import type { Attachment } from '@/infrastructure/storage/Attachment'

export class CourseAnnouncement {
  constructor(
    public id: string,
    public courseId: string,
    public title: string,
    public content: string,
    public attachment: Attachment | null,
    public publisherTeacherId: string,
    public createdAt: string,
  ) {}
}
