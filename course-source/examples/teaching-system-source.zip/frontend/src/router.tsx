import { Suspense, lazy, type ReactNode } from 'react'
import { createBrowserRouter, Navigate, type RouteObject } from 'react-router-dom'

const LoginPage = lazy(() => import('@/pages/login'))
const RegisterPage = lazy(() => import('@/pages/register'))
const ProfilePage = lazy(() => import('@/pages/profile'))
const DashboardPage = lazy(() => import('@/pages/dashboard'))
const CourseWorkspacePage = lazy(() => import('@/pages/courseWorkspace'))
const AnnouncementDetailPage = lazy(() => import('@/pages/announcementDetail'))
const AnnouncementCreatePage = lazy(() => import('@/pages/announcementCreate'))
const CourseCreatePage = lazy(() => import('@/pages/courseCreate'))
const CourseMembersManagePage = lazy(() => import('@/pages/courseMembersManage'))
const AssignmentDetailPage = lazy(() => import('@/pages/assignmentDetail'))
const AssignmentCreatePage = lazy(() => import('@/pages/assignmentCreate'))
const ReviewBoardPage = lazy(() => import('@/pages/reviewBoard'))
const ReviewDetailPage = lazy(() => import('@/pages/reviewDetail'))
const ExamDetailPage = lazy(() => import('@/pages/examDetail'))
const ExamCreatePage = lazy(() => import('@/pages/examCreate'))
const ExamImportPage = lazy(() => import('@/pages/examImport'))
const ExamProgressPage = lazy(() => import('@/pages/examProgress'))
const ExamReviewBoardPage = lazy(() => import('@/pages/examReviewBoard'))
const ExamQuestionDetailPage = lazy(() => import('@/pages/examQuestionDetail'))
const ExamTeacherQuestionDetailPage = lazy(() => import('@/pages/examTeacherQuestionDetail'))
const QuestionnaireCreatePage = lazy(() => import('@/pages/questionnaireCreate'))
const QuestionnaireDetailPage = lazy(() => import('@/pages/questionnaireDetail'))
const QuestionnaireTextAnswersPage = lazy(() => import('@/pages/questionnaireTextAnswers'))

function page(element: ReactNode) {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[linear-gradient(180deg,#ecfeff_0%,#eefcf6_100%)] p-8 text-sm text-slate-500">页面加载中...</div>}>
      {element}
    </Suspense>
  )
}

const routes: RouteObject[] = [
  {
    path: '/',
    element: <Navigate replace to="/login" />,
  },
  {
    path: '/login',
    element: page(<LoginPage />),
  },
  {
    path: '/register',
    element: page(<RegisterPage />),
  },
  {
    path: '/profile',
    element: page(<ProfilePage />),
  },
  {
    path: '/dashboard',
    element: page(<DashboardPage />),
  },
  {
    path: '/courses/:courseId',
    element: page(<CourseWorkspacePage />),
  },
  {
    path: '/announcements/:announcementId',
    element: page(<AnnouncementDetailPage />),
  },
  {
    path: '/courses/:courseId/announcements/new',
    element: page(<AnnouncementCreatePage />),
  },
  {
    path: '/courses/:courseId/announcements/:announcementId/edit',
    element: page(<AnnouncementCreatePage />),
  },
  {
    path: '/courses/new',
    element: page(<CourseCreatePage />),
  },
  {
    path: '/courses/:courseId/members/manage',
    element: page(<CourseMembersManagePage />),
  },
  {
    path: '/assignments/:assignmentId',
    element: page(<AssignmentDetailPage />),
  },
  {
    path: '/courses/:courseId/assignments/new',
    element: page(<AssignmentCreatePage />),
  },
  {
    path: '/courses/:courseId/assignments/:assignmentId/edit',
    element: page(<AssignmentCreatePage />),
  },
  {
    path: '/reviews/:assignmentId',
    element: page(<ReviewBoardPage />),
  },
  {
    path: '/reviews/:assignmentId/submissions/:submissionId',
    element: page(<ReviewDetailPage />),
  },
  {
    path: '/exams/:examId',
    element: page(<ExamDetailPage />),
  },
  {
    path: '/courses/:courseId/exams/new',
    element: page(<ExamCreatePage />),
  },
  {
    path: '/courses/:courseId/exams/:examId/edit',
    element: page(<ExamCreatePage />),
  },
  {
    path: '/exams/:examId/import',
    element: page(<ExamImportPage />),
  },
  {
    path: '/exams/:examId/progress',
    element: page(<ExamProgressPage />),
  },
  {
    path: '/exams/:examId/questions/:questionId/review',
    element: page(<ExamReviewBoardPage />),
  },
  {
    path: '/exams/:examId/questions/:questionId',
    element: page(<ExamQuestionDetailPage />),
  },
  {
    path: '/exams/:examId/students/:studentId/questions/:questionId',
    element: page(<ExamTeacherQuestionDetailPage />),
  },
  {
    path: '/courses/:courseId/questionnaires/new',
    element: page(<QuestionnaireCreatePage />),
  },
  {
    path: '/questionnaires/:questionnaireId',
    element: page(<QuestionnaireDetailPage />),
  },
  {
    path: '/questionnaires/:questionnaireId/questions/:questionId/answers',
    element: page(<QuestionnaireTextAnswersPage />),
  },
  {
    path: '*',
    element: <Navigate replace to="/login" />,
  },
]

export const router = createBrowserRouter(routes)
