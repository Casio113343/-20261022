# Backend

教学系统后端，技术栈为 `Scala 3 + Cats Effect IO + http4s + Circe + PostgreSQL + HikariCP`。

当前后端的核心结构原则：

- HTTP 接口统一走 `/api/<ApiName>`
- `routes/` 负责 HTTP 解析，`infrastructure/api/` 负责通用 API 协议
- 微服务按 `auth / dashboard / course / assignment / exam / questionnaire` 组织

## 启动入口

- `src/main/scala/Main.scala`
  后端启动入口。
  负责：
  - 初始化数据库连接池
  - 初始化数据库表和 seed
  - 组装 Kafka / Redis / MinIO 等资源
  - 启动 outbox processor、Kafka consumer
  - 启动 HTTP 服务

## 顶层目录

- `src/main/scala/infrastructure/`
  与教学业务无关的基础设施。
- `src/main/scala/routes/`
  HTTP 路由入口和通用 HTTP 支持。
- `src/main/scala/microservices/`
  教学业务微服务，按业务边界组织。
- `src/main/scala/shared/`
  跨微服务共享代码。

## `infrastructure/` 目录说明

- `api/`
  通用 API message、API router 和错误对象。

- `cache/`
  Redis 配置。

- `database/`
  数据库配置、连接池、事务会话。
  重点文件：
  - `DatabaseConfig.scala`
  - `DatabaseSession.scala`

- `events/`
  领域事件基础设施与 Kafka 实现。

- `http/`
  HTTP 公共支持。
  重点文件：
  - `HttpSupport.scala`
  - `HealthRouter.scala`
  - `ServiceRouteSupport.scala`

- `outbox/`
  事务 outbox。
  分为：
  - `model/`
  - `persistence/`
  - `processor/`

- `realtime/`
  当前主要是课程聊天实时链路。

- `storage/`
  对象存储抽象与 MinIO 实现。

## 微服务目录结构

每个微服务通常只保留真正需要的目录，不再强行凑齐分层。常见目录有：

- `api/`
  接口编排与请求/响应对象。
- `objects/`
  业务对象定义。
- `routes/`
  HTTP 路由。
- `tables/`
  数据表 schema / writes / projection writes。
- `support/`
  只保留确实被同一微服务多个位置复用的支持代码。

已经删除的典型冗余层：

- `TeachingMicroservices`
- 多数微服务里的 `service/`
- 多数只被单点调用的 `domain/` / `*ApiSupport`

## 当前主要微服务定位

- `auth/`
  用户登录、注册、资料、阅读标记。

- `asset/`
  文件上传与资产内容读取。

- `dashboard/`
  dashboard summary、review queue、projection rebuild consumer。

- `course/`
  课程、公告、成员、聊天、workspace、chat timeline。

- `assignment/`
  作业、提交、批改与相关读取。

- `exam/`
  考试、答题卡、批改、仲裁、申诉与相关读取。

- `questionnaire/`
  问卷、作答
