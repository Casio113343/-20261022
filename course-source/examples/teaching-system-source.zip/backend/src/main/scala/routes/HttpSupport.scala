package routes

import cats.effect.IO
import org.http4s.{EntityDecoder, EntityEncoder, Response}
import org.http4s.circe.{jsonEncoderOf, jsonOf}
import org.http4s.circe.CirceEntityEncoder.*
import org.typelevel.log4cats.Logger
import org.http4s.dsl.io.*
import infrastructure.api.ApiError
import org.http4s.Request
import scala.util.Try

object HttpSupport:

  inline def jsonDecoder[A: io.circe.Decoder]: EntityDecoder[IO, A] = jsonOf

  inline def jsonEncoder[A: io.circe.Encoder]: EntityEncoder[IO, A] = jsonEncoderOf

  def handleResult[A: io.circe.Encoder](result: Either[String, A]): IO[Response[IO]] =
    result match
      case Right(value) => Ok(value)
      case Left(error) => BadRequest(ApiError(error))

  def execute[Output: io.circe.Encoder](apiName: String, path: String)(plan: IO[Either[String, Output]])(using logger: Logger[IO]): IO[Response[IO]] =
    for
      _ <- logger.info(s"$apiName $path")
      result <- plan
      response <- handleResult(result)
    yield response

  def executeWithBody[Input: io.circe.Decoder, Output: io.circe.Encoder](request: org.http4s.Request[IO], apiName: String, path: String)(
    plan: Input => IO[Either[String, Output]]
  )(using logger: Logger[IO]): IO[Response[IO]] =
    given EntityDecoder[IO, Input] = jsonDecoder[Input]
    for
      payload <- request.as[Input]
      response <- execute(apiName, path)(plan(payload))
    yield response

  def requiredQueryParam(request: Request[IO], name: String): IO[String] =
    IO.fromEither(
      request.params
        .get(name)
        .map(_.trim)
        .filter(_.nonEmpty)
        .toRight(new IllegalArgumentException(s"缺少参数: $name"))
    )

  def optionalQueryParam(request: Request[IO], name: String): Option[String] =
    request.params.get(name).map(_.trim).filter(_.nonEmpty)

  def optionalIntQueryParam(request: Request[IO], name: String): IO[Option[Int]] =
    optionalQueryParam(request, name) match
      case None => IO.pure(None)
      case Some(value) =>
        IO.fromEither(
          Try(value.toInt).toEither.left.map(_ => new IllegalArgumentException(s"参数 $name 必须是整数")).map(Some(_))
        )
