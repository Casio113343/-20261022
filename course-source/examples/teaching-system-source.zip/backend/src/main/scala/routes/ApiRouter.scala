package routes

import cats.effect.IO
import cats.syntax.semigroupk.*
import org.http4s.HttpApp
import org.http4s.implicits.*
import infrastructure.api.APIMessageRouter
import infrastructure.realtime.CourseRealtimeHub
import infrastructure.storage.AssetObjectStore
import microservices.assignment.routes.AssignmentRoutes
import microservices.auth.routes.AuthRoutes
import microservices.course.routes.CourseRoutes
import microservices.dashboard.routes.DashboardRoutes
import microservices.exam.routes.ExamRoutes
import microservices.questionnaire.routes.QuestionnaireRoutes

object ApiRouter:
  private val apiMessages =
    AuthRoutes.apiMessages ++
      DashboardRoutes.apiMessages ++
      CourseRoutes.apiMessages ++
      AssignmentRoutes.apiMessages ++
      ExamRoutes.apiMessages ++
      QuestionnaireRoutes.apiMessages

  def httpApp(
      assetObjectStore: AssetObjectStore,
      courseRealtimeHub: CourseRealtimeHub
  ): HttpApp[IO] =
    (
      HealthRoutes.routes <+>
        AssetRoutes.routes(assetObjectStore) <+>
        CourseRealtimeRoutes.routes(courseRealtimeHub) <+>
        APIMessageRouter.routes(apiMessages)
    ).orNotFound
