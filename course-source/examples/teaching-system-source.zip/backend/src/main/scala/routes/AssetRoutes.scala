package routes

import cats.effect.IO
import cats.syntax.semigroupk.*
import infrastructure.api.ApiError
import infrastructure.storage.{AssetObjectStore, AssetStorageService}
import org.http4s.{Header, HttpRoutes, MediaType, MessageBodyFailure, Response, Status}
import org.http4s.dsl.io.*
import org.http4s.multipart.Multipart
import org.typelevel.ci.CIStringSyntax
import org.typelevel.log4cats.slf4j.Slf4jLogger

object AssetRoutes:
  def routes(assetObjectStore: AssetObjectStore): HttpRoutes[IO] =
    uploadRoutes(assetObjectStore) <+> fetchContentRoutes(assetObjectStore) <+> legacyUploadRoutes(assetObjectStore) <+> legacyFetchContentRoutes(assetObjectStore)

  private def uploadRoutes(assetObjectStore: AssetObjectStore): HttpRoutes[IO] =
    given org.typelevel.log4cats.Logger[IO] = Slf4jLogger.getLogger[IO]
    given org.http4s.EntityEncoder[IO, infrastructure.storage.Attachment] = HttpSupport.jsonEncoder
    given org.http4s.EntityEncoder[IO, ApiError] = HttpSupport.jsonEncoder

    HttpRoutes.of[IO] {
      case request @ POST -> Root / "assets" =>
        HttpSupport.requiredQueryParam(request, "userId").flatMap(userId =>
          handleUpload(request, assetObjectStore, userId)
        )
    }

  private def fetchContentRoutes(assetObjectStore: AssetObjectStore): HttpRoutes[IO] =
    given org.typelevel.log4cats.Logger[IO] = Slf4jLogger.getLogger[IO]
    given org.http4s.EntityEncoder[IO, ApiError] = HttpSupport.jsonEncoder

    HttpRoutes.of[IO] {
      case GET -> Root / "assets" / assetId / "content" =>
        for
          _ <- summon[org.typelevel.log4cats.Logger[IO]].info(s"GET /assets/$assetId/content")
          result <- AssetStorageService.fetch(assetObjectStore, assetId)
          response <- result match
            case Left(error) => BadRequest(ApiError(error))
            case Right(asset) => IO.pure(buildAssetResponse(asset.asset.fileName, asset.asset.contentType, asset.content))
        yield response
    }

  private def legacyUploadRoutes(assetObjectStore: AssetObjectStore): HttpRoutes[IO] =
    given org.typelevel.log4cats.Logger[IO] = Slf4jLogger.getLogger[IO]
    given org.http4s.EntityEncoder[IO, infrastructure.storage.Attachment] = HttpSupport.jsonEncoder
    given org.http4s.EntityEncoder[IO, ApiError] = HttpSupport.jsonEncoder

    HttpRoutes.of[IO] {
      case request @ POST -> Root / "api" / apiName if normalize(apiName) == "uploadassetapi" =>
        HttpSupport.requiredQueryParam(request, "userId").flatMap(userId =>
          handleUpload(request, assetObjectStore, userId)
        )
    }

  private def legacyFetchContentRoutes(assetObjectStore: AssetObjectStore): HttpRoutes[IO] =
    given org.typelevel.log4cats.Logger[IO] = Slf4jLogger.getLogger[IO]
    given org.http4s.EntityEncoder[IO, ApiError] = HttpSupport.jsonEncoder

    HttpRoutes.of[IO] {
      case request @ GET -> Root / "api" / apiName if normalize(apiName) == "fetchassetcontentapi" =>
        for
          assetId <- HttpSupport.requiredQueryParam(request, "assetId")
          _ <- summon[org.typelevel.log4cats.Logger[IO]].info(s"GET /api/FetchAssetContentApi?assetId=$assetId")
          result <- AssetStorageService.fetch(assetObjectStore, assetId)
          response <- result match
            case Left(error) => BadRequest(ApiError(error))
            case Right(asset) => IO.pure(buildAssetResponse(asset.asset.fileName, asset.asset.contentType, asset.content))
        yield response
    }

  private def handleUpload(
      request: org.http4s.Request[IO],
      assetObjectStore: AssetObjectStore,
      userId: String
  )(using logger: org.typelevel.log4cats.Logger[IO], apiErrorEncoder: org.http4s.EntityEncoder[IO, ApiError]): IO[Response[IO]] =
    val upload = for
      _ <- logger.info(s"POST /assets?userId=$userId")
      multipart <- request.as[Multipart[IO]]
      result <- AssetStorageService.upload(assetObjectStore, userId, multipart)
      response <- HttpSupport.handleResult(result)
    yield response

    upload.handleErrorWith {
      case error: MessageBodyFailure =>
        logger.warn(error)(s"Asset upload multipart parse failed for user $userId") *>
          BadRequest(ApiError(Option(error.getMessage).filter(_.nonEmpty).getOrElse("上传内容解析失败，请重新选择文件后再试")))
      case error =>
        logger.error(error)(s"Asset upload failed for user $userId") *>
          InternalServerError(ApiError("上传失败，请稍后重试"))
    }

  private def buildAssetResponse(fileName: String, contentType: String, content: Array[Byte]): Response[IO] =
    val mediaType = MediaType.parse(contentType).toOption.getOrElse(MediaType.application.`octet-stream`)
    val contentDisposition = s"inline; filename=\"${escapeHeaderValue(fileName)}\""
    Response[IO](status = Status.Ok)
      .withEntity(content)
      .withContentType(org.http4s.headers.`Content-Type`(mediaType))
      .putHeaders(Header.Raw(ci"Content-Disposition", contentDisposition))

  private def escapeHeaderValue(value: String): String =
    value.replace("\\", "_").replace("\"", "_")

  private def normalize(apiName: String): String =
    apiName.trim.toLowerCase
