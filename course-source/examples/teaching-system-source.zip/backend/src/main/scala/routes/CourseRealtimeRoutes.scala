package routes

import cats.effect.IO
import infrastructure.realtime.CourseRealtimeHub
import org.http4s.HttpRoutes
import org.http4s.dsl.io.*
import org.http4s.server.websocket.WebSocketBuilder2

object CourseRealtimeRoutes:
  def routes(courseRealtimeHub: CourseRealtimeHub): HttpRoutes[IO] =
    HttpRoutes.of[IO] {
      case GET -> Root / "ws" / "courses" / courseId =>
        WebSocketBuilder2[IO].flatMap(_.build(courseRealtimeHub.stream(courseId), _.drain))
    }
