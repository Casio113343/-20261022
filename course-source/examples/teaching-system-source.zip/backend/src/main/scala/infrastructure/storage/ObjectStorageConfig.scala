package infrastructure.storage

final case class ObjectStorageConfig(
    endpoint: String,
    accessKey: String,
    secretKey: String,
    bucketName: String,
    region: Option[String]
)

object ObjectStorageConfig:
  def load: Option[ObjectStorageConfig] =
    val endpoint = sys.env
      .get("MINIO_ENDPOINT")
      .map(_.trim)
      .filter(_.nonEmpty)
      .map(normalizeEndpoint)
    val accessKey = sys.env.get("MINIO_ROOT_USER").map(_.trim).filter(_.nonEmpty)
    val secretKey = sys.env.get("MINIO_ROOT_PASSWORD").map(_.trim).filter(_.nonEmpty)
    val bucketName = sys.env.get("MINIO_BUCKET").map(_.trim).filter(_.nonEmpty)
    val region = sys.env.get("MINIO_REGION").map(_.trim).filter(_.nonEmpty)

    (endpoint, accessKey, secretKey, bucketName) match
      case (Some(currentEndpoint), Some(currentAccessKey), Some(currentSecretKey), Some(currentBucketName)) =>
        Some(ObjectStorageConfig(currentEndpoint, currentAccessKey, currentSecretKey, currentBucketName, region))
      case _ => None

  private def normalizeEndpoint(endpoint: String): String =
    endpoint.stripSuffix("/")
