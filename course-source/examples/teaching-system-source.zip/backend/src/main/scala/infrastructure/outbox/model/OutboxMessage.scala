package infrastructure.outbox

import io.circe.Codec
import io.circe.Json
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

import java.time.Instant

final case class OutboxMessage(
    id: String,
    eventType: String,
    payload: Json,
    createdAt: Instant
)

object OutboxMessage:
  given Codec[OutboxMessage] = deriveCodec
