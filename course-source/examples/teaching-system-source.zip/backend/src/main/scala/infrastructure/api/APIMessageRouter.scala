package infrastructure.api

import cats.effect.IO
import infrastructure.api.ApiError
import io.circe.Json
import io.circe.syntax.*
import org.http4s.{HttpRoutes, InvalidMessageBodyFailure, Response}
import org.http4s.circe.CirceEntityCodec.*
import org.http4s.circe.CirceEntityEncoder.*
import org.http4s.dsl.io.*

object APIMessageRouter:

  def routes(apiMessages: List[RegisteredAPIMessage]): HttpRoutes[IO] =
    val apiMessagesByName = apiMessages.map(apiMessage => normalize(apiMessage.apiName) -> apiMessage).toMap

    HttpRoutes.of[IO] {
      case req @ POST -> Root / "api" / apiName =>
        handleErrors {
          for
            apiMessage <- IO.fromOption(apiMessagesByName.get(normalize(apiName)))(
              APIMessageError.BadRequest(s"不支持的 API：$apiName")
            )
            payload <- req.as[Json]
            response <- apiMessage.planJson(payload)
            httpResponse <- Ok(response)
          yield httpResponse
        }
    }

  private def normalize(apiName: String): String =
    apiName.trim.toLowerCase

  private def handleErrors(action: IO[Response[IO]]): IO[Response[IO]] =
    action.handleErrorWith {
      case error: InvalidMessageBodyFailure =>
        BadRequest(ApiError(error.getMessage).asJson)
      case error: APIMessageError.BadRequest =>
        BadRequest(ApiError(error.getMessage).asJson)
      case error: IllegalArgumentException =>
        BadRequest(ApiError(error.getMessage).asJson)
      case error =>
        InternalServerError(ApiError(Option(error.getMessage).getOrElse("服务器内部错误")).asJson)
    }
