package infrastructure.realtime

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.course.api.responses.CourseChatMessage
import shared.model.SharedCodecs.given

final case class CourseRealtimeEvent(
    eventType: String,
    courseId: String,
    chatMessage: Option[CourseChatMessage]
)

object CourseRealtimeEvent:
  given Codec[CourseRealtimeEvent] = deriveCodec
