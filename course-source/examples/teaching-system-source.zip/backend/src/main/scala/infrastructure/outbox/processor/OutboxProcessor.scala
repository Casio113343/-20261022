package infrastructure.outbox

import cats.effect.IO
import infrastructure.database.DatabaseSession
import infrastructure.events.{DomainEvent, EventPublisher}
import infrastructure.realtime.{CourseRealtimeBroadcaster, CourseRealtimeEvent}
import io.circe.Decoder
import io.circe.parser.decode
import org.typelevel.log4cats.slf4j.Slf4jLogger

import java.time.Instant
import scala.concurrent.duration.DurationInt

final class OutboxProcessor(
    eventPublisher: EventPublisher,
    courseRealtimeBroadcaster: CourseRealtimeBroadcaster
):
  private val logger = Slf4jLogger.getLogger[IO]

  def runForever: IO[Unit] =
    processNext.foreverM

  private def processNext: IO[Unit] =
    DatabaseSession.withTransactionConnection { connection =>
      OutboxTableReads.claimNext(connection).flatMap {
        case Some(message) =>
          handle(connection, message).attempt.flatMap {
            case Right(_) =>
              OutboxTableReads.markProcessed(connection, message.id, Instant.now()) *>
                logger.info(s"Processed outbox message ${message.id} (${message.eventType})")
            case Left(error) =>
              OutboxTableReads.markFailed(connection, message.id, error.getMessage) *>
                logger.error(error)(s"Failed to process outbox message ${message.id}")
          }
        case None =>
          IO.sleep(500.millis)
      }
    }

  private def handle(connection: java.sql.Connection, message: OutboxMessage): IO[Unit] =
    message.eventType match
      case OutboxSupport.domainEventPublishEventType =>
        IO.fromEither(readPayload[DomainEvent](message.payload.noSpaces, "domain event")).flatMap(eventPublisher.publish)
      case OutboxSupport.courseRealtimePublishEventType =>
        IO.fromEither(readPayload[CourseRealtimeEvent](message.payload.noSpaces, "course realtime event")).flatMap(courseRealtimeBroadcaster.publish)
      case _ =>
        logger.warn(s"Skipping unsupported outbox message type: ${message.eventType}")

  private def readPayload[A: Decoder](payload: String, label: String): Either[IllegalStateException, A] =
    decode[A](payload).left.map(error => IllegalStateException(s"Failed to decode $label: ${error.getMessage}"))
