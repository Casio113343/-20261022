package infrastructure.outbox

object OutboxTableInitializer:
  val initSql: List[String] = List(
    """
      |create table if not exists teaching_outbox_messages (
      |  id text primary key,
      |  event_type text not null,
      |  payload text not null,
      |  created_at timestamptz not null,
      |  processed_at timestamptz,
      |  attempt_count integer not null default 0,
      |  last_error text
      |);
      |create index if not exists teaching_outbox_messages_unprocessed_idx
      |on teaching_outbox_messages (processed_at, created_at);
      |""".stripMargin
  )

  val migrationSql: List[String] = Nil
