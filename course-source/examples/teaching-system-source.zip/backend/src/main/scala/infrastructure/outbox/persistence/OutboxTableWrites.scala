package infrastructure.outbox

import shared.jdbc.JdbcStatementSupport.{setInstant, withPrepared}
import io.circe.syntax.*

import java.sql.Connection

object OutboxTableWrites:
  def insert(connection: Connection, message: OutboxMessage): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_outbox_messages (id, event_type, payload, created_at)
        |values (?, ?, ?, ?)
        |""".stripMargin
    ) { statement =>
      statement.setString(1, message.id)
      statement.setString(2, message.eventType)
      statement.setString(3, message.payload.noSpaces)
      setInstant(statement, 4, message.createdAt)
      statement.executeUpdate()
    }

  def insertAll(connection: Connection, messages: Iterable[OutboxMessage]): Unit =
    messages.foreach(insert(connection, _))
