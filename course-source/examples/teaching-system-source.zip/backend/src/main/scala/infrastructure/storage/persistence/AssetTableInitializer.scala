package infrastructure.storage

object AssetTableInitializer:
  val initSql: List[String] = List(
    """
      |create table if not exists teaching_assets (
      |  id text primary key,
      |  file_name text not null,
      |  content_type text not null,
      |  storage_key text not null,
      |  created_by_user_id text not null,
      |  created_at timestamptz not null
      |);
      |""".stripMargin
  )

  val migrationSql: List[String] = List(
    "alter table teaching_assets add column if not exists storage_key text",
    "update teaching_assets set storage_key = id where storage_key is null"
  )
