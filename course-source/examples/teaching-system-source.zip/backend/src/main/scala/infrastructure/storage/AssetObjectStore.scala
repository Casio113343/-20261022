package infrastructure.storage

import cats.effect.IO
import fs2.Stream

import java.nio.file.Path

trait AssetObjectStore:
  def putObjectStream(objectKey: String, contentType: String, content: Stream[IO, Byte], contentLength: Option[Long]): IO[Unit]
  def getObject(objectKey: String): IO[Either[String, Array[Byte]]]
