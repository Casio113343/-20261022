package infrastructure.storage

import cats.effect.IO
import shared.jdbc.JdbcStatementSupport.setInstant

import java.sql.Connection

object AssetTableAccess:
  def insert(connection: Connection, asset: StoredAsset): IO[Unit] =
    IO.blocking {
      val statement = connection.prepareStatement(
        """
          |insert into teaching_assets (id, file_name, content_type, storage_key, created_by_user_id, created_at)
          |values (?, ?, ?, ?, ?, ?)
          |""".stripMargin
      )
      try
        statement.setString(1, asset.id)
        statement.setString(2, asset.fileName)
        statement.setString(3, asset.contentType)
        statement.setString(4, asset.storageKey)
        statement.setString(5, asset.createdByUserId)
        setInstant(statement, 6, asset.createdAt)
        statement.executeUpdate()
        ()
      finally statement.close()
    }

  def find(connection: Connection, assetId: String): IO[Option[StoredAsset]] =
    IO.blocking {
      val statement = connection.prepareStatement(
        """
          |select id, file_name, content_type, storage_key, created_by_user_id, created_at
          |from teaching_assets
          |where id = ?
          |""".stripMargin
      )
      try
        statement.setString(1, assetId)
        val resultSet = statement.executeQuery()
        try
          if resultSet.next() then
            Some(
              StoredAsset(
                id = resultSet.getString("id"),
                fileName = resultSet.getString("file_name"),
                contentType = resultSet.getString("content_type"),
                storageKey = resultSet.getString("storage_key"),
                createdByUserId = resultSet.getString("created_by_user_id"),
                createdAt = resultSet.getObject("created_at", classOf[java.time.OffsetDateTime]).toInstant
              )
            )
          else None
        finally resultSet.close()
      finally statement.close()
    }
