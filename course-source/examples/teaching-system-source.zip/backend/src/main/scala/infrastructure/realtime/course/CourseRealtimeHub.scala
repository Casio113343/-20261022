package infrastructure.realtime

import cats.effect.{IO, Ref, Resource}
import cats.effect.std.Queue
import cats.syntax.all.*
import fs2.Stream
import io.circe.syntax.*
import org.http4s.websocket.WebSocketFrame

import java.util.UUID

final class CourseRealtimeHub private (subscribersRef: Ref[IO, Map[String, CourseRealtimeHub.Subscriber]]):
  import CourseRealtimeHub.Subscriber

  def publish(event: CourseRealtimeEvent): IO[Unit] =
    subscribersRef.get.flatMap { subscribers =>
      subscribers.values.toList
        .filter(_.courseId == event.courseId)
        .traverse_(_.queue.offer(event))
    }

  def stream(courseId: String): Stream[IO, WebSocketFrame] =
    Stream.resource(subscribe(courseId))
      .flatMap(queue => Stream.fromQueueUnterminated(queue))
      .map(event => WebSocketFrame.Text(event.asJson.noSpaces))

  private def subscribe(courseId: String): Resource[IO, Queue[IO, CourseRealtimeEvent]] =
    Resource.make {
      for
        subscriberId <- IO(UUID.randomUUID().toString)
        queue <- Queue.unbounded[IO, CourseRealtimeEvent]
        _ <- subscribersRef.update(_.updated(subscriberId, Subscriber(subscriberId, courseId, queue)))
      yield subscriberId -> queue
    } { case (subscriberId, _) =>
      subscribersRef.update(_ - subscriberId)
    }.map(_._2)

object CourseRealtimeHub:
  private final case class Subscriber(
      id: String,
      courseId: String,
      queue: Queue[IO, CourseRealtimeEvent]
  )

  def create: IO[CourseRealtimeHub] =
    Ref.of[IO, Map[String, Subscriber]](Map.empty).map(new CourseRealtimeHub(_))
