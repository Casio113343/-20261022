package infrastructure.realtime

import cats.effect.{IO, Resource}
import cats.effect.unsafe.implicits.global
import infrastructure.cache.RedisConfig
import io.circe.{Decoder, Encoder}
import io.circe.parser.decode
import io.circe.syntax.*
import redis.clients.jedis.{Jedis, JedisPubSub}

import java.util.concurrent.Executors
import java.util.UUID

trait CourseRealtimeBackplane:
  def publish(event: CourseRealtimeEvent): IO[Unit]

object CourseRealtimeBackplane:
  val noop: CourseRealtimeBackplane = new CourseRealtimeBackplane:
    override def publish(event: CourseRealtimeEvent): IO[Unit] = IO.unit

  def resource(config: RedisConfig, hub: CourseRealtimeHub): Resource[IO, CourseRealtimeBackplane] =
    Resource.make {
      for
        instanceId <- IO(s"instance-${UUID.randomUUID().toString.take(8)}")
        subscriber <- createSubscriber(config, hub, instanceId)
        executor <- IO(Executors.newSingleThreadExecutor())
        _ <- IO.blocking {
          executor.submit(new Runnable:
            override def run(): Unit =
              val jedis = openJedis(config)
              try subscriber.attach(jedis)
              finally jedis.close()
          )
        }
      yield (subscriber, executor, new RedisCourseRealtimeBackplane(config, instanceId))
    } { case (subscriber, executor, _) =>
      IO.blocking {
        subscriber.unsubscribeAll()
        executor.shutdownNow()
        ()
      }.handleErrorWith(_ => IO.unit)
    }.map(_._3)

  private def createSubscriber(config: RedisConfig, hub: CourseRealtimeHub, instanceId: String): IO[RedisCourseRealtimeSubscriber] =
    IO.pure(new RedisCourseRealtimeSubscriber(channel(config), hub, instanceId))

  private def openJedis(config: RedisConfig): Jedis =
    val jedis = new Jedis(config.host, config.port)
    config.password.filter(_.nonEmpty).foreach(jedis.auth)
    if config.database != 0 then jedis.select(config.database)
    jedis

  private def channel(config: RedisConfig): String =
    s"${config.channelPrefix}course-realtime"

  private final case class RedisEnvelope[A](originInstanceId: String, payload: A)

  private object RedisEnvelope:
    given [A: Encoder]: Encoder[RedisEnvelope[A]] = Encoder.forProduct2("originInstanceId", "payload")(value =>
      (value.originInstanceId, value.payload)
    )
    given [A: Decoder]: Decoder[RedisEnvelope[A]] = Decoder.forProduct2("originInstanceId", "payload")(RedisEnvelope.apply[A])

  private final class RedisCourseRealtimeBackplane(config: RedisConfig, instanceId: String) extends CourseRealtimeBackplane:
    override def publish(event: CourseRealtimeEvent): IO[Unit] =
      IO.blocking {
        val jedis = openJedis(config)
        try jedis.publish(channel(config), RedisEnvelope(instanceId, event).asJson.noSpaces)
        finally jedis.close()
      }.void

  private final class RedisCourseRealtimeSubscriber(topic: String, hub: CourseRealtimeHub, instanceId: String) extends JedisPubSub:
    def attach(jedis: Jedis): Unit =
      jedis.subscribe(this, topic)

    def unsubscribeAll(): Unit =
      try unsubscribe()
      catch case _ : Throwable => ()

    override def onMessage(channel: String, message: String): Unit =
      decode[RedisEnvelope[CourseRealtimeEvent]](message).foreach { envelope =>
        val _ =
          if envelope.originInstanceId != instanceId then hub.publish(envelope.payload).unsafeRunAndForget()
          else IO.unit.unsafeRunAndForget()
      }
