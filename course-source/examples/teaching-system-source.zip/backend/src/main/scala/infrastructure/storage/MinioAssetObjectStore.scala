package infrastructure.storage

import cats.effect.IO
import fs2.Stream
import io.minio.errors.ErrorResponseException
import io.minio.{BucketExistsArgs, GetObjectArgs, MakeBucketArgs, MinioClient, PutObjectArgs}
import org.typelevel.log4cats.slf4j.Slf4jLogger

import java.io.{PipedInputStream, PipedOutputStream}
final class MinioAssetObjectStore private (client: MinioClient, bucketName: String) extends AssetObjectStore:
  private val logger = Slf4jLogger.getLogger[IO]
  private val minioUnknownSizePartBytes = 10L * 1024 * 1024

  override def putObjectStream(objectKey: String, contentType: String, content: Stream[IO, Byte], contentLength: Option[Long]): IO[Unit] =
    IO.blocking {
      val inputStream = PipedInputStream()
      val outputStream = PipedOutputStream(inputStream)
      (inputStream, outputStream)
    }.bracket { case (inputStream, outputStream) =>
      val writeContent =
        content.chunks.evalMap(chunk => IO.blocking(outputStream.write(chunk.toArray))).compile.drain
          .guarantee(IO.blocking(outputStream.close()).handleError(_ => ()))

      writeContent.start.bracket { writerFiber =>
        IO.blocking {
          client.putObject(
            PutObjectArgs.builder()
              .bucket(bucketName)
              .`object`(objectKey)
              .contentType(contentType)
              .stream(inputStream, contentLength.getOrElse(-1L), minioUnknownSizePartBytes)
              .build()
          )
          ()
        }.onError(_ => writerFiber.cancel).guarantee(IO.blocking(inputStream.close()).handleError(_ => ())) *> writerFiber.joinWithNever
      }(writerFiber =>
        writerFiber.cancel *>
          IO.blocking(inputStream.close()).handleError(_ => ()) *>
          IO.blocking(outputStream.close()).handleError(_ => ())
      )
    } { case (inputStream, outputStream) =>
      IO.blocking(inputStream.close()).handleError(_ => ()) *>
        IO.blocking(outputStream.close()).handleError(_ => ())
    }.handleErrorWith { error =>
      logStorageError("putObjectStream", error, Some(objectKey)) *> IO.raiseError(error)
    }

  override def getObject(objectKey: String): IO[Either[String, Array[Byte]]] =
    IO.blocking {
      val stream = client.getObject(
        GetObjectArgs.builder()
          .bucket(bucketName)
          .`object`(objectKey)
          .build()
      )
      try Right(stream.readAllBytes())
      catch
        case _: ErrorResponseException => Left("附件不存在")
      finally stream.close()
    }.handleErrorWith { error =>
      logStorageError("getObject", error, Some(objectKey)) *> IO.raiseError(error)
    }

  private def logStorageError(operation: String, error: Throwable, objectKey: Option[String]): IO[Unit] =
    error match
      case response: ErrorResponseException =>
        val resource = objectKey.getOrElse(bucketName)
        logger.error(response)(
          s"MinIO $operation failed for bucket=$bucketName resource=$resource code=${response.errorResponse().code()} message=${response.errorResponse().message()}"
        )
      case other =>
        val resource = objectKey.getOrElse(bucketName)
        logger.error(other)(s"MinIO $operation failed for bucket=$bucketName resource=$resource")

object MinioAssetObjectStore:
  private val logger = Slf4jLogger.getLogger[IO]

  def create(config: ObjectStorageConfig): IO[AssetObjectStore] =
    val clientBuilder = MinioClient.builder()
      .endpoint(config.endpoint)
      .credentials(config.accessKey, config.secretKey)
    config.region.foreach(clientBuilder.region)
    val client = clientBuilder.build()

    IO.blocking {
      val exists = client.bucketExists(BucketExistsArgs.builder().bucket(config.bucketName).build())
      if !exists then
        client.makeBucket(MakeBucketArgs.builder().bucket(config.bucketName).build())
      new MinioAssetObjectStore(client, config.bucketName): AssetObjectStore
    }.flatTap { _ =>
      logger.info(
        s"MinIO storage enabled endpoint=${config.endpoint} bucket=${config.bucketName} region=${config.region.getOrElse("<auto>")}"
      )
    }.handleErrorWith { error =>
      error match
        case response: ErrorResponseException =>
          logger.error(response)(
            s"MinIO initialization failed for endpoint=${config.endpoint} bucket=${config.bucketName} code=${response.errorResponse().code()} message=${response.errorResponse().message()}"
          ) *> IO.raiseError(error)
        case other =>
          logger.error(other)(
            s"MinIO initialization failed for endpoint=${config.endpoint} bucket=${config.bucketName}"
          ) *> IO.raiseError(error)
    }
