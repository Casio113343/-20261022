package infrastructure.events

import io.circe.Codec
import io.circe.Json
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

import java.time.Instant

final case class DomainEvent(
    eventType: String,
    aggregateType: String,
    aggregateId: String,
    userId: String,
    courseId: Option[String],
    occurredAt: Instant,
    payload: Json
)

object DomainEvent:
  given Codec[DomainEvent] = deriveCodec
