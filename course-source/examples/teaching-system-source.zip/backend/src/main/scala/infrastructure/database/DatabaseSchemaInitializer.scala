package infrastructure.database

import cats.effect.IO
import infrastructure.outbox.OutboxTableInitializer
import infrastructure.storage.AssetTableInitializer
import microservices.assignment.tables.AssignmentTableInitializer
import microservices.auth.tables.AuthTableInitializer
import microservices.course.tables.CourseTableInitializer
import microservices.dashboard.tables.DashboardTableInitializer
import microservices.exam.tables.ExamTableInitializer
import microservices.questionnaire.tables.QuestionnaireTableInitializer

import java.sql.Connection

object DatabaseSchemaInitializer:
  def initialize(connection: Connection): IO[Unit] =
    IO.blocking {
      val statement = connection.createStatement()
      try
        (initSql ++ migrationSql).foreach(statement.execute)
      finally statement.close()
    }

  private val initSql: List[String] =
    AssetTableInitializer.initSql ++
      OutboxTableInitializer.initSql ++
      AuthTableInitializer.initSql ++
      DashboardTableInitializer.initSql ++
      CourseTableInitializer.initSql ++
      AssignmentTableInitializer.initSql ++
      ExamTableInitializer.initSql ++
      QuestionnaireTableInitializer.initSql

  private val migrationSql: List[String] =
    AssetTableInitializer.migrationSql ++
      OutboxTableInitializer.migrationSql ++
      AuthTableInitializer.migrationSql ++
      DashboardTableInitializer.migrationSql ++
      CourseTableInitializer.migrationSql ++
      AssignmentTableInitializer.migrationSql ++
      ExamTableInitializer.migrationSql ++
      QuestionnaireTableInitializer.migrationSql
