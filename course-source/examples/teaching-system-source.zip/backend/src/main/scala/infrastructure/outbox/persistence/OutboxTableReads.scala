package infrastructure.outbox

import cats.effect.IO
import shared.jdbc.JdbcStatementSupport.{setInstant, withPrepared}
import io.circe.Json
import io.circe.parser.parse
import shared.model.SharedCodecs.given

import java.sql.Connection
import java.time.Instant

object OutboxTableReads:
  def claimNext(connection: Connection): IO[Option[OutboxMessage]] =
    IO.blocking {
      withPrepared(
        connection,
        """
          |select id, event_type, payload, created_at
          |from teaching_outbox_messages
          |where processed_at is null
          |order by created_at asc
          |limit 1
          |for update skip locked
          |""".stripMargin
      ) { statement =>
        val resultSet = statement.executeQuery()
        try
          if !resultSet.next() then None
          else
            val payload = parse(resultSet.getString("payload")).getOrElse(Json.obj())
            Some(
              OutboxMessage(
                id = resultSet.getString("id"),
                eventType = resultSet.getString("event_type"),
                payload = payload,
                createdAt = resultSet.getObject("created_at", classOf[java.time.OffsetDateTime]).toInstant
              )
            )
        finally resultSet.close()
      }
    }

  def markProcessed(connection: Connection, messageId: String, processedAt: Instant): IO[Unit] =
    IO.blocking {
      withPrepared(
        connection,
        """
          |update teaching_outbox_messages
          |set processed_at = ?, attempt_count = attempt_count + 1, last_error = null
          |where id = ?
          |""".stripMargin
      ) { statement =>
        setInstant(statement, 1, processedAt)
        statement.setString(2, messageId)
        statement.executeUpdate()
        ()
      }
    }

  def markFailed(connection: Connection, messageId: String, error: String): IO[Unit] =
    IO.blocking {
      withPrepared(
        connection,
        """
          |update teaching_outbox_messages
          |set attempt_count = attempt_count + 1, last_error = ?
          |where id = ?
          |""".stripMargin
      ) { statement =>
        statement.setString(1, error.take(2000))
        statement.setString(2, messageId)
        statement.executeUpdate()
        ()
      }
    }
