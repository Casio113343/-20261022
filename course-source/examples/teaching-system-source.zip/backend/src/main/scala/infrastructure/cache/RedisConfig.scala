package infrastructure.cache

final case class RedisConfig(
    host: String,
    port: Int,
    password: Option[String],
    database: Int,
    channelPrefix: String
)

object RedisConfig:
  def load: Option[RedisConfig] =
    sys.env.get("REDIS_HOST").map(_.trim).filter(_.nonEmpty).map { host =>
      val port = sys.env.get("REDIS_PORT").flatMap(_.trim.toIntOption).getOrElse(6379)
      val password = sys.env.get("REDIS_PASSWORD").map(_.trim).filter(_.nonEmpty)
      val database = sys.env.get("REDIS_DB").flatMap(_.trim.toIntOption).getOrElse(0)
      val channelPrefix = sys.env.get("REDIS_CHANNEL_PREFIX").map(_.trim).filter(_.nonEmpty).getOrElse("teaching")
      RedisConfig(host, port, password, database, channelPrefix)
    }
