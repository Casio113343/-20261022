package infrastructure.realtime

import cats.effect.IO

trait CourseRealtimeBroadcaster:
  def publish(event: CourseRealtimeEvent): IO[Unit]

object CourseRealtimeBroadcaster:
  def local(hub: CourseRealtimeHub): CourseRealtimeBroadcaster = new CourseRealtimeBroadcaster:
    override def publish(event: CourseRealtimeEvent): IO[Unit] = hub.publish(event)

  def composite(hub: CourseRealtimeHub, backplane: CourseRealtimeBackplane): CourseRealtimeBroadcaster = new CourseRealtimeBroadcaster:
    override def publish(event: CourseRealtimeEvent): IO[Unit] =
      hub.publish(event) *> backplane.publish(event)
