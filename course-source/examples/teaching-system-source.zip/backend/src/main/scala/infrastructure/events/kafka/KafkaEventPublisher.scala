package infrastructure.events

import cats.effect.{IO, Resource}
import fs2.kafka.{KafkaProducer, ProducerRecord, ProducerRecords, ProducerSettings}
import io.circe.syntax.*

final class KafkaEventPublisher private (producer: fs2.kafka.KafkaProducer.Metrics[IO, String, String], topic: String) extends EventPublisher:
  override def publish(event: DomainEvent): IO[Unit] =
    producer.produce(ProducerRecords.one(ProducerRecord(topic, event.aggregateId, event.asJson.noSpaces))).flatten.void

object KafkaEventPublisher:
  def resource(config: KafkaConfig): Resource[IO, EventPublisher] =
    val settings = ProducerSettings[IO, String, String]
      .withBootstrapServers(config.bootstrapServers)
    KafkaProducer.resource(settings).map(producer => new KafkaEventPublisher(producer, config.topic): EventPublisher)
