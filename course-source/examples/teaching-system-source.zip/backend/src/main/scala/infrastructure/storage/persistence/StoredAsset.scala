package infrastructure.storage

import java.time.Instant

final case class StoredAsset(
    id: String,
    fileName: String,
    contentType: String,
    storageKey: String,
    createdByUserId: String,
    createdAt: Instant
)
