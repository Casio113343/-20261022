package infrastructure.storage

import cats.effect.IO
import org.http4s.multipart.Multipart

object AssetMultipartSupport:
  def extractFirstFile(multipart: Multipart[IO]): IO[Either[String, (String, String, fs2.Stream[IO, Byte], Option[Long])]] =
    multipart.parts.find(part => part.name.contains("file") || part.filename.nonEmpty).toRight("请上传文件") match
      case Left(error) => IO.pure(Left(error))
      case Right(part) =>
        val fileName = part.filename.map(_.trim).getOrElse("")
        if fileName.isEmpty then IO.pure(Left("文件名不能为空"))
        else
          val contentType = part.headers
            .get[org.http4s.headers.`Content-Type`]
            .map(header => s"${header.mediaType.mainType}/${header.mediaType.subType}")
            .getOrElse("application/octet-stream")
          val contentLength = part.headers.get[org.http4s.headers.`Content-Length`].map(_.length)
          IO.pure(Right((fileName, contentType, part.body, contentLength)))
