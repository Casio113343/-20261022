package infrastructure.events

final case class KafkaConfig(
    bootstrapServers: String,
    topic: String,
    projectorConsumerEnabled: Boolean,
    projectorConsumerGroupId: String
)

object KafkaConfig:
  private def readBoolean(name: String, default: Boolean): Boolean =
    sys.env
      .get(name)
      .map(_.trim.toLowerCase)
      .collect {
        case "true" | "1" | "yes" | "on" => true
        case "false" | "0" | "no" | "off" => false
      }
      .getOrElse(default)

  def load: Option[KafkaConfig] =
    val bootstrapServers = sys.env.get("KAFKA_BOOTSTRAP_SERVERS").map(_.trim).filter(_.nonEmpty)
    val topic = sys.env.get("KAFKA_TOPIC").map(_.trim).filter(_.nonEmpty).orElse(Some("teaching-events"))
    val projectorConsumerEnabled = readBoolean("KAFKA_PROJECTOR_CONSUMER_ENABLED", false)
    val projectorConsumerGroupId = sys.env.get("KAFKA_PROJECTOR_CONSUMER_GROUP_ID").map(_.trim).filter(_.nonEmpty).getOrElse("teaching-projector")

    bootstrapServers.map(currentBootstrapServers =>
      KafkaConfig(
        bootstrapServers = currentBootstrapServers,
        topic = topic.get,
        projectorConsumerEnabled = projectorConsumerEnabled,
        projectorConsumerGroupId = projectorConsumerGroupId
      )
    )
