package infrastructure.outbox

import infrastructure.events.DomainEvent
import infrastructure.realtime.CourseRealtimeEvent
import io.circe.Json
import io.circe.syntax.*

import java.time.Instant
import java.util.UUID

object OutboxSupport:
  val domainEventPublishEventType = "integration.domain-event.publish"
  val courseRealtimePublishEventType = "integration.course-realtime.publish"

  def domainEventPublish(event: DomainEvent): OutboxMessage =
    OutboxMessage(
      id = s"outbox-${UUID.randomUUID().toString.take(8)}",
      eventType = domainEventPublishEventType,
      payload = event.asJson,
      createdAt = event.occurredAt
    )

  def courseRealtimePublish(event: CourseRealtimeEvent, now: Instant): OutboxMessage =
    OutboxMessage(
      id = s"outbox-${UUID.randomUUID().toString.take(8)}",
      eventType = courseRealtimePublishEventType,
      payload = event.asJson,
      createdAt = now
    )
