package infrastructure.storage

object AttachmentSupport:
  def normalizeAttachment(attachment: Option[Attachment]): Option[Attachment] =
    attachment.map(item => Attachment(item.fileName.trim, item.dataUrl.trim)).filter(item => item.fileName.nonEmpty && item.dataUrl.nonEmpty)
