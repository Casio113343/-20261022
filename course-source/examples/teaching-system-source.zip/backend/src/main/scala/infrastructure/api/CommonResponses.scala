package infrastructure.api

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec

final case class ApiError(error: String)
object ApiError:
  given Codec[ApiError] = deriveCodec

final case class ActionResponse(message: String)
object ActionResponse:
  given Codec[ActionResponse] = deriveCodec
