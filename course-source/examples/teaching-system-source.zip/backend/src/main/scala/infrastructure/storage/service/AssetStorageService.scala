package infrastructure.storage

import cats.effect.IO
import fs2.Stream
import infrastructure.database.DatabaseSession
import infrastructure.events.DomainEvent
import infrastructure.outbox.{OutboxSupport, OutboxTableWrites}
import infrastructure.storage.Attachment

import java.time.Instant
import java.util.UUID

object AssetStorageService:
  def upload(
      assetObjectStore: AssetObjectStore,
      userId: String,
      multipart: org.http4s.multipart.Multipart[IO]
  ): IO[Either[String, Attachment]] =
    AssetMultipartSupport.extractFirstFile(multipart).flatMap {
      case Left(error) => IO.pure(Left(error))
      case Right((fileName, contentType, content, contentLength)) =>
        uploadStream(assetObjectStore, userId, fileName, contentType, content, contentLength)
    }

  def fetch(assetObjectStore: AssetObjectStore, assetId: String): IO[Either[String, StoredAssetWithContent]] =
    DatabaseSession.withTransactionConnection(connection => AssetTableAccess.find(connection, assetId)).flatMap {
      case None => IO.pure(Left("附件不存在"))
      case Some(asset) =>
        fetchContent(assetObjectStore, asset).map(_.map(content => StoredAssetWithContent(asset, content)))
    }

  private def fetchContent(assetObjectStore: AssetObjectStore, asset: StoredAsset): IO[Either[String, Array[Byte]]] =
    val fallbackStorageKey = s"assets/${asset.createdByUserId}/${asset.id}"
    assetObjectStore.getObject(asset.storageKey).flatMap {
      case Right(content) => IO.pure(Right(content))
      case Left(_) if asset.storageKey != fallbackStorageKey =>
        assetObjectStore.getObject(fallbackStorageKey)
      case Left(error) =>
        IO.pure(Left(error))
    }

  private def uploadStream(
      assetObjectStore: AssetObjectStore,
      userId: String,
      fileName: String,
      contentType: String,
      content: Stream[IO, Byte],
      contentLength: Option[Long]
  ): IO[Either[String, Attachment]] =
    if fileName.trim.isEmpty then IO.pure(Left("文件名不能为空"))
    else if contentLength.exists(_ <= 0) then IO.pure(Left("文件内容不能为空"))
    else
      val assetId = s"asset-${UUID.randomUUID().toString}"
      val trimmedFileName = fileName.trim
      val normalizedContentType = contentType.trim
      val storageKey = s"assets/$userId/$assetId"
      val now = Instant.now()
      for
        _ <- assetObjectStore.putObjectStream(storageKey, normalizedContentType, content, contentLength)
        saved <- DatabaseSession.withTransactionConnection { connection =>
          val asset = StoredAsset(assetId, trimmedFileName, normalizedContentType, storageKey, userId, now)
          AssetTableAccess.insert(connection, asset) *>
            IO.blocking(
              OutboxTableWrites.insert(connection, OutboxSupport.domainEventPublish(uploadedEvent(assetId, userId, trimmedFileName, now)))
            ).as(Right(Attachment(asset.fileName, s"/assets/${asset.id}/content")))
        }
      yield saved

  private def uploadedEvent(assetId: String, userId: String, fileName: String, occurredAt: Instant): DomainEvent =
    DomainEvent(
      eventType = "asset.uploaded",
      aggregateType = "asset",
      aggregateId = assetId,
      userId = userId,
      courseId = None,
      occurredAt = occurredAt,
      payload = io.circe.Json.obj(
        "fileName" -> io.circe.Json.fromString(fileName),
        "storage" -> io.circe.Json.fromString("minio")
      )
    )

final case class StoredAssetWithContent(
    asset: StoredAsset,
    content: Array[Byte]
)
