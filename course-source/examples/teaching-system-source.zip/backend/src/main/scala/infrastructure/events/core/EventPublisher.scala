package infrastructure.events

import cats.effect.IO

trait EventPublisher:
  def publish(event: DomainEvent): IO[Unit]

object EventPublisher:
  val noop: EventPublisher = new EventPublisher:
    override def publish(event: DomainEvent): IO[Unit] = IO.unit
