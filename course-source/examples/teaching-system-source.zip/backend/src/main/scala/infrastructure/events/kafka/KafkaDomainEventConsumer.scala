package infrastructure.events

import cats.effect.{IO, Resource}
import fs2.kafka.{AutoOffsetReset, ConsumerSettings, KafkaConsumer}
import io.circe.parser.decode
import org.typelevel.log4cats.slf4j.Slf4jLogger

object KafkaDomainEventConsumer:
  private val logger = Slf4jLogger.getLogger[IO]

  def resource(config: KafkaConfig, groupId: String)(handle: DomainEvent => IO[Unit]): Resource[IO, Unit] =
    val settings = ConsumerSettings[IO, String, String]
      .withBootstrapServers(config.bootstrapServers)
      .withGroupId(groupId)
      .withAutoOffsetReset(AutoOffsetReset.Latest)
    KafkaConsumer
      .stream(settings)
      .subscribeTo(config.topic)
      .records
      .evalMap { committable =>
        decode[DomainEvent](committable.record.value) match
          case Right(event) =>
            handle(event).attempt.flatMap {
              case Right(_) => committable.offset.commit
              case Left(error) => logger.error(error)(s"Failed to handle Kafka domain event ${event.eventType} (${event.aggregateId})")
            }
          case Left(error) =>
            logger.error(error)(s"Failed to decode Kafka domain event payload for key ${committable.record.key}") *>
              committable.offset.commit
      }
      .compile
      .drain
      .background
      .map(_ => ())
