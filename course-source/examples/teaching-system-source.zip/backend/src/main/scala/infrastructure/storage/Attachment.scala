package infrastructure.storage

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class Attachment(
    fileName: String,
    dataUrl: String
)

object Attachment:
  given Encoder[Attachment] = deriveEncoder[Attachment]
  given Decoder[Attachment] = deriveDecoder[Attachment]
