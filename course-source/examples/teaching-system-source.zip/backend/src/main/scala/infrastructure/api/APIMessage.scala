package infrastructure.api

import cats.effect.IO
import infrastructure.api.ApiError
import io.circe.{Decoder, Encoder, Json}
import io.circe.syntax.*
import org.http4s.circe.CirceEntityEncoder.*

import scala.reflect.ClassTag

trait APIMessage[Response]:
  def plan: IO[Response]

  protected def resolveEither[A](result: Either[String, A]): IO[A] =
    result match
      case Right(value) => IO.pure(value)
      case Left(error) => IO.raiseError(APIMessageError.BadRequest(error))

  protected def resolve[A](result: IO[Either[String, A]]): IO[A] =
    result.flatMap(resolveEither)

final case class RegisteredAPIMessage(
    apiName: String,
    planJson: Json => IO[Json]
)

sealed abstract class APIMessageError(message: String) extends RuntimeException(message)

object APIMessageError:
  final case class BadRequest(override val getMessage: String) extends APIMessageError(getMessage)

object APIMessage:

  private[api] def apiNameFromClassName(className: String): String =
    val objectName = className.stripSuffix("$")
    val baseName = objectName.stripSuffix("APIMessage")
    s"${baseName}Api".toLowerCase

object RegisteredAPIMessage:

  def api[Message <: APIMessage[Response], Response](using
      decoder: Decoder[Message],
      encoder: Encoder[Response],
      classTag: ClassTag[Message]
  ): RegisteredAPIMessage =
    RegisteredAPIMessage(
      apiName = nameOf[Message],
      planJson = payload =>
        for
          message <- IO.fromEither(
            payload.as[Message].left.map(error => APIMessageError.BadRequest(s"请求体格式错误：${error.getMessage}"))
          )
          response <- message.plan
          json <- IO.pure(response.asJson)
        yield json
    )

  private def nameOf[Message](using classTag: ClassTag[Message]): String =
    APIMessage.apiNameFromClassName(classTag.runtimeClass.getSimpleName)
