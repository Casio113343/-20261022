import cats.effect.{IO, IOApp, Resource}
import cats.syntax.parallel.*
import com.comcast.ip4s.{host, port}
import infrastructure.cache.RedisConfig
import infrastructure.database.{DatabaseSchemaInitializer, DatabaseSession}
import infrastructure.events.{EventPublisher, KafkaConfig, KafkaEventPublisher}
import infrastructure.outbox.OutboxProcessor
import infrastructure.realtime.{CourseRealtimeBackplane, CourseRealtimeBroadcaster, CourseRealtimeHub}
import routes.ApiRouter
import infrastructure.storage.{AssetObjectStore, MinioAssetObjectStore, ObjectStorageConfig}
import org.http4s.ember.server.EmberServerBuilder
import org.http4s.server.middleware.CORS
import org.http4s.server.middleware.Logger
import org.typelevel.log4cats.slf4j.Slf4jLogger

object Main extends IOApp.Simple:

  private val logger = Slf4jLogger.getLogger[IO]

  override def run: IO[Unit] =
    DatabaseSession.initialize.use { _ =>
      val kafkaConfig = KafkaConfig.load
      buildEventPublisher(kafkaConfig).use { eventPublisher =>
        for
          assetObjectStore <- buildAssetObjectStore
          courseRealtimeHub <- CourseRealtimeHub.create
          _ <- buildCourseRealtimeBackplane(courseRealtimeHub).use { courseRealtimeBackplane =>
            val courseRealtimeBroadcaster = CourseRealtimeBroadcaster.composite(courseRealtimeHub, courseRealtimeBackplane)
            val outboxProcessor = new OutboxProcessor(
              eventPublisher,
              courseRealtimeBroadcaster
            )
            for
              _ <- DatabaseSession.withTransactionConnection(DatabaseSchemaInitializer.initialize)
              _ <- runBackgroundProcesses(outboxProcessor).use { _ =>
                val httpApp = Logger.httpApp(logHeaders = true, logBody = false)(
                  CORS.policy.withAllowOriginAll(ApiRouter.httpApp(assetObjectStore, courseRealtimeHub))
                )

                for
                  _ <- logger.info("Starting backend-sample on http://0.0.0.0:8080")
                  _ <- EmberServerBuilder
                    .default[IO]
                    .withHost(host"0.0.0.0")
                    .withPort(port"8080")
                    .withHttpApp(httpApp)
                    .build
                    .useForever
                yield ()
              }
            yield ()
          }
        yield ()
      }
    }

  private def buildAssetObjectStore: IO[AssetObjectStore] =
    ObjectStorageConfig.load match
      case Some(config) => MinioAssetObjectStore.create(config)
      case None => IO.raiseError(IllegalStateException("对象存储未配置，必须提供 MinIO 配置后才能启动后端"))

  private def buildEventPublisher(kafkaConfig: Option[KafkaConfig]): Resource[IO, EventPublisher] =
    kafkaConfig.map(KafkaEventPublisher.resource).getOrElse(Resource.pure(EventPublisher.noop))

  private def runBackgroundProcesses(outboxProcessor: OutboxProcessor): Resource[IO, Unit] =
    outboxProcessor.runForever.background.map(_ => ())

  private def buildCourseRealtimeBackplane(courseRealtimeHub: CourseRealtimeHub): Resource[IO, CourseRealtimeBackplane] =
    RedisConfig.load match
      case Some(config) => CourseRealtimeBackplane.resource(config, courseRealtimeHub)
      case None => Resource.pure(CourseRealtimeBackplane.noop)
