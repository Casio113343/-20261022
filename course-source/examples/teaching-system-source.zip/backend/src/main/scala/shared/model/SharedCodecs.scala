package shared.model

import io.circe.{Decoder, Encoder}

import java.time.Instant

object SharedCodecs:
  given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
  given Decoder[Instant] = Decoder.decodeString.emap { value =>
    scala.util.Try(Instant.parse(value)).toEither.left.map(_.getMessage)
  }
