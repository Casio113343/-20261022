package shared.jdbc

import io.circe.Decoder
import io.circe.parser.decode

import java.sql.{Connection, PreparedStatement, ResultSet}
import java.time.Instant
import scala.collection.mutable.ListBuffer

object JdbcReadSupport:
  def withPrepared[A](connection: Connection, sql: String)(use: PreparedStatement => A): A =
    val statement = connection.prepareStatement(sql)
    try use(statement)
    finally statement.close()

  def withInPrepared[A](connection: Connection, sql: String, values: List[String])(use: PreparedStatement => A): A =
    val statement = connection.prepareStatement(sql.replace(":ids", values.map(_ => "?").mkString(", ")))
    try
      values.zipWithIndex.foreach { case (value, index) => statement.setString(index + 1, value) }
      use(statement)
    finally statement.close()

  def decodeJson[A: Decoder](value: String, label: String): Either[String, A] =
    decode[A](value).left.map(error => s"Failed to decode $label: ${error.getMessage}")

  def readStringOpt(resultSet: ResultSet, column: String): Option[String] =
    Option(resultSet.getString(column))

  def readInstant(resultSet: ResultSet, column: String): Instant =
    resultSet.getObject(column, classOf[java.time.OffsetDateTime]).toInstant

  def readInstantOpt(resultSet: ResultSet, column: String): Option[Instant] =
    Option(resultSet.getObject(column, classOf[java.time.OffsetDateTime])).map(_.toInstant)

  def collectRows[A](resultSet: ResultSet)(read: ResultSet => A): List[A] =
    val buffer = ListBuffer.empty[A]
    while resultSet.next() do
      buffer += read(resultSet)
    buffer.toList
