package shared.jdbc

import io.circe.Encoder
import io.circe.syntax.*

import java.sql.{PreparedStatement, Types}
import java.time.Instant

object JdbcStatementSupport:
  def withPrepared[A](connection: java.sql.Connection, sql: String)(use: PreparedStatement => A): A =
    val statement = connection.prepareStatement(sql)
    try use(statement)
    finally statement.close()

  def setStringOpt(statement: PreparedStatement, index: Int, value: Option[String]): Unit =
    value match
      case Some(current) => statement.setString(index, current)
      case None => statement.setNull(index, Types.VARCHAR)

  def setIntOpt(statement: PreparedStatement, index: Int, value: Option[Int]): Unit =
    value match
      case Some(current) => statement.setInt(index, current)
      case None => statement.setNull(index, Types.INTEGER)

  def setInstant(statement: PreparedStatement, index: Int, value: Instant): Unit =
    statement.setObject(index, java.time.OffsetDateTime.ofInstant(value, java.time.ZoneOffset.UTC))

  def setInstantOpt(statement: PreparedStatement, index: Int, value: Option[Instant]): Unit =
    value match
      case Some(current) => setInstant(statement, index, current)
      case None => statement.setNull(index, Types.TIMESTAMP_WITH_TIMEZONE)

  def setJsonbOpt[A: Encoder](statement: PreparedStatement, index: Int, value: Option[A]): Unit =
    value match
      case Some(current) => statement.setString(index, current.asJson.noSpaces)
      case None => statement.setNull(index, Types.OTHER)
