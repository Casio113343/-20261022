package shared.id

import java.util.UUID

object IdGenerator:
  def nextId(prefix: String): String =
    s"$prefix-${UUID.randomUUID().toString.take(8)}"
