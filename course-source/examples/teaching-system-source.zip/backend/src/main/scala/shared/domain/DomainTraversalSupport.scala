package shared.domain

object DomainTraversalSupport:
  def traverseList[A, B](items: List[A])(build: A => Either[String, B]): Either[String, List[B]] =
    items.foldLeft[Either[String, List[B]]](Right(List.empty)) { (accEither, item) =>
      for
        acc <- accEither
        built <- build(item)
      yield acc :+ built
    }
