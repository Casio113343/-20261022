package shared.jdbc

import io.circe.{Decoder, parser}
import microservices.auth.objects.{StudentProfile, TeacherProfile, UserRole}

object JdbcDecodingSupport:

  def decodeRole(value: String, label: String): Either[String, UserRole] =
    val trimmed = Option(value).map(_.trim).getOrElse("")
    parser.decode[UserRole](trimmed) match
      case Right(role) => Right(role)
      case Left(_) =>
        trimmed.toLowerCase match
          case "teacher" => Right(UserRole.Teacher)
          case "student" => Right(UserRole.Student)
          case other => Left(s"Failed to decode $label: unsupported value '$other'")

  def decodeOptionalJson[A: Decoder](value: Option[String], label: String): Either[String, Option[A]] =
    value match
      case Some(current) => JdbcReadSupport.decodeJson[A](current, label).map(Some(_))
      case None => Right(None)

  def sequenceById[A <: Product](values: List[Either[String, A]]): Either[String, Map[String, A]] =
    values.foldLeft[Either[String, Map[String, A]]](Right(Map.empty)) { (accumulator, current) =>
      for
        mapped <- accumulator
        value <- current
        id <- value.productElement(0) match
          case currentId: String => Right(currentId)
          case _ => Left("Read model row id must be a string")
      yield mapped.updated(id, value)
    }
