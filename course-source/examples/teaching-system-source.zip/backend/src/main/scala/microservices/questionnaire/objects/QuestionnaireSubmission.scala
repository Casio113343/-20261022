package microservices.questionnaire.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class QuestionnaireSubmission(
    id: String,
    questionnaireId: String,
    studentId: String,
    answers: List[QuestionnaireAnswer],
    submittedAt: Instant
)

object QuestionnaireSubmission:
  given Encoder[QuestionnaireSubmission] = deriveEncoder
  given Decoder[QuestionnaireSubmission] = deriveDecoder
