package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.api.requests.AddCourseMembersInput
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.objects.{CourseMemberAction, CourseMemberEvent}
import microservices.course.support.CourseAccessSupport.isCurrentCourseMember
import microservices.course.tables.{CourseTableReads, CourseTableWrites}
import microservices.dashboard.objects.SystemNotification
import microservices.dashboard.tables.DashboardTableWrites
import shared.id.IdGenerator

import java.time.Instant

final case class AddCourseMembersAPIMessage(courseId: String, userId: String, input: AddCourseMembersInput) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        val normalizedUsernames = input.usernames.map(_.trim).filter(_.nonEmpty).distinct
        for
          operatorEither <- AuthTableReads.loadUserById(connection, userId)
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          usersEither <- AuthTableReads.loadUsersByUsernames(connection, normalizedUsernames)
          validationEither = for
            operator <- operatorEither
            course <- courseEither
            usersById <- usersEither
            _ <- Either.cond(operator.role == UserRole.Teacher && course.teachers.contains(operator.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(normalizedUsernames.nonEmpty, (), "请至少输入一个账号")
            usersByUsername = usersById.values.map(user => user.username -> user).toMap
            missingUsernames = normalizedUsernames.filterNot(usersByUsername.contains)
            resolvedUsers = normalizedUsernames.flatMap(usersByUsername.get)
            alreadyJoinedUsernames = resolvedUsers.collect { case user if isCurrentCourseMember(course, user.id) => user.username }
            _ <- Either.cond(
              missingUsernames.isEmpty && alreadyJoinedUsernames.isEmpty,
              (),
              List(
                Option.when(missingUsernames.nonEmpty)(s"账号${missingUsernames.mkString("、")}不存在"),
                Option.when(alreadyJoinedUsernames.nonEmpty)(s"账号${alreadyJoinedUsernames.mkString("、")}已在课程中")
              ).flatten.mkString("\n")
            )
          yield
            val nextCourse = resolvedUsers.foldLeft(course) { (current, user) =>
              val joinedEvent = CourseMemberEvent(user.id, user.role, CourseMemberAction.Joined, now)
              user.role match
                case UserRole.Teacher => current.copy(teachers = current.teachers :+ user.id, memberEvents = current.memberEvents :+ joinedEvent)
                case UserRole.Student => current.copy(students = current.students :+ user.id, memberEvents = current.memberEvents :+ joinedEvent)
            }
            val notifications = resolvedUsers.map(user =>
              SystemNotification(IdGenerator.nextId("system-notification"), user.id, s"${operator.displayName} 邀请你加入课程　${course.title}", now)
            )
            nextCourse -> notifications
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((nextCourse, notifications)) =>
              for
                _ <- IO.blocking {
                  CourseTableWrites.replaceCourse(connection, nextCourse)
                }
                notificationsPublished <- IO.blocking(notifications.foreach(DashboardTableWrites.upsertSystemNotification(connection, _))).as(Right(()): Either[String, Unit])
                detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, nextCourse.id, userId)
              yield for
                _ <- notificationsPublished
                detail <- detailEither
              yield detail
        yield result
      }
      response <- resolveEither(result)
    yield response

object AddCourseMembersAPIMessage:
  given Codec.AsObject[AddCourseMembersAPIMessage] = deriveCodec
