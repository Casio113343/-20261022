package microservices.exam.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class OfflineExamQuestion(
    id: String,
    examId: String,
    title: String,
    position: Int,
    scoring: ExamQuestionScoring
)

object OfflineExamQuestion:
  given Encoder[OfflineExamQuestion] = deriveEncoder[OfflineExamQuestion]
  given Decoder[OfflineExamQuestion] = deriveDecoder[OfflineExamQuestion]
