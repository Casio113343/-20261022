package microservices.auth.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}

final case class ClearDeletedCourseReadMarkersAPIMessage(
    userIds: List[String],
    announcementIds: List[String],
    assignmentIds: List[String],
    examIds: List[String]
) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val announcementIdSet = announcementIds.toSet
        val assignmentIdSet = assignmentIds.toSet
        val examIdSet = examIds.toSet
        for
          usersEither <- AuthTableReads.loadUsersByIds(connection, userIds)
          result <- usersEither match
            case Left(error) => IO.pure(Left(error))
            case Right(users) =>
              val updatedUsers = users.values.toList
                .map(user =>
                  user.copy(
                    readAnnouncementIds = user.readAnnouncementIds.filterNot(announcementIdSet.contains),
                    readReviewedAssignmentIds = user.readReviewedAssignmentIds.filterNot(assignmentIdSet.contains),
                    readPublishedExamIds = user.readPublishedExamIds.filterNot(examIdSet.contains),
                  )
                )
                .filter(user =>
                  val previous = users(user.id)
                  previous.readAnnouncementIds != user.readAnnouncementIds ||
                    previous.readReviewedAssignmentIds != user.readReviewedAssignmentIds ||
                    previous.readPublishedExamIds != user.readPublishedExamIds
                )
              IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理删除课程的已读标记")

object ClearDeletedCourseReadMarkersAPIMessage:
  given Codec.AsObject[ClearDeletedCourseReadMarkersAPIMessage] = deriveCodec
