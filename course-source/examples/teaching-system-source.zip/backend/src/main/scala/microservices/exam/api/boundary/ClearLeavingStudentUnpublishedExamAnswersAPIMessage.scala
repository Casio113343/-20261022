package microservices.exam.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.exam.tables.ExamTableWrites

final case class ClearLeavingStudentUnpublishedExamAnswersAPIMessage(answerSheetIds: List[String], appealQuestionIds: List[String]) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val answerSheetIdSet = answerSheetIds.toSet
        val appealQuestionIdSet = appealQuestionIds.toSet
        IO.blocking {
          ExamTableWrites.deleteQuestionGradingsByAnswerSheetIds(connection, answerSheetIdSet)
          ExamTableWrites.deleteQuestionArbitrationsByAnswerSheetIds(connection, answerSheetIdSet)
          ExamTableWrites.deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection, answerSheetIdSet, appealQuestionIdSet)
          answerSheetIdSet.foreach(ExamTableWrites.deleteExamAnswerSheet(connection, _))
        }.as(Right(()): Either[String, Unit])
      }
      _ <- resolveEither(result)
    yield ActionResponse("离课学生的未发布考试答卷已清理")

object ClearLeavingStudentUnpublishedExamAnswersAPIMessage:
  given Codec.AsObject[ClearLeavingStudentUnpublishedExamAnswersAPIMessage] = deriveCodec
