package microservices.auth.support

import microservices.auth.objects.{StudentProfile, TeacherProfile, UserAccount, UserRole}

object AuthUserAccountFactorySupport:

  def teacherAccount(
      id: String,
      username: String,
      password: String,
      displayName: String,
      avatarDataUrl: Option[String],
      profile: TeacherProfile
  ): UserAccount =
    UserAccount(
      id = id,
      username = username,
      password = password,
      displayName = displayName,
      role = UserRole.Teacher,
      avatarDataUrl = avatarDataUrl,
      readAnnouncementIds = Nil,
      readSystemNotificationIds = Nil,
      readReviewedAssignmentIds = Nil,
      readPublishedExamIds = Nil,
      readQuestionnaireIds = Nil,
      teacherProfile = Some(profile),
      studentProfile = None
    )

  def studentAccount(
      id: String,
      username: String,
      password: String,
      displayName: String,
      avatarDataUrl: Option[String],
      profile: StudentProfile
  ): UserAccount =
    UserAccount(
      id = id,
      username = username,
      password = password,
      displayName = displayName,
      role = UserRole.Student,
      avatarDataUrl = avatarDataUrl,
      readAnnouncementIds = Nil,
      readSystemNotificationIds = Nil,
      readReviewedAssignmentIds = Nil,
      readPublishedExamIds = Nil,
      readQuestionnaireIds = Nil,
      teacherProfile = None,
      studentProfile = Some(profile)
    )
