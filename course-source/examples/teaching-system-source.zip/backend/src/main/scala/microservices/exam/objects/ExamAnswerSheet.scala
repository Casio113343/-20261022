package microservices.exam.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import infrastructure.storage.Attachment

final case class ExamAnswerSheet(
    id: String,
    examId: String,
    questionId: String,
    studentId: String,
    images: List[Attachment]
)

object ExamAnswerSheet:
  given Encoder[ExamAnswerSheet] = deriveEncoder[ExamAnswerSheet]
  given Decoder[ExamAnswerSheet] = deriveDecoder[ExamAnswerSheet]
