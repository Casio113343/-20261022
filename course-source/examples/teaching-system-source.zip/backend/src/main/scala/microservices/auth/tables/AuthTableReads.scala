package microservices.auth.tables

import cats.effect.IO
import io.circe.Decoder
import microservices.auth.objects.{StudentProfile, TeacherProfile, UserAccount}
import shared.jdbc.{JdbcDecodingSupport, JdbcReadSupport}

import java.sql.Connection

object AuthTableReads:
  def loadUserById(connection: Connection, userId: String): IO[Either[String, UserAccount]] =
    loadSingleUser(connection, "where id = ?", userId).map(_.flatMap(_.toRight("用户不存在")))

  def loadUserByUsername(connection: Connection, username: String): IO[Either[String, UserAccount]] =
    loadSingleUser(connection, "where username = ?", username).map(_.flatMap(_.toRight("用户不存在")))

  def findUserByUsername(connection: Connection, username: String): IO[Either[String, Option[UserAccount]]] =
    loadSingleUser(connection, "where username = ?", username)

  def loadUsersByIds(connection: Connection, userIds: Iterable[String]): IO[Either[String, Map[String, UserAccount]]] =
    import JdbcReadSupport.*
    val ids = userIds.toList.distinct
    given Decoder[List[String]] = Decoder.decodeList(Decoder.decodeString)
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          """
            |select id, username, password, display_name, role, avatar_data_url,
            |       read_announcement_ids, read_system_notification_ids,
            |       read_reviewed_assignment_ids, read_published_exam_ids,
            |       read_questionnaire_ids,
            |       teacher_profile, student_profile
            |from teaching_users
            |where id in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet)(decodeUser)
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadUsersByUsernames(connection: Connection, usernames: Iterable[String]): IO[Either[String, Map[String, UserAccount]]] =
    import JdbcReadSupport.*
    val normalizedUsernames = usernames.toList.map(_.trim).filter(_.nonEmpty).distinct
    given Decoder[List[String]] = Decoder.decodeList(Decoder.decodeString)
    if normalizedUsernames.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          """
            |select id, username, password, display_name, role, avatar_data_url,
            |       read_announcement_ids, read_system_notification_ids,
            |       read_reviewed_assignment_ids, read_published_exam_ids,
            |       read_questionnaire_ids,
            |       teacher_profile, student_profile
            |from teaching_users
            |where username in (:ids)
            |""".stripMargin,
          normalizedUsernames
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet)(decodeUser)
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  private def loadSingleUser(connection: Connection, whereClause: String, value: String): IO[Either[String, Option[UserAccount]]] =
    import JdbcReadSupport.*
    given Decoder[List[String]] = Decoder.decodeList(Decoder.decodeString)
    IO.blocking {
      withPrepared(
        connection,
        s"""
           |select id, username, password, display_name, role, avatar_data_url,
           |       read_announcement_ids, read_system_notification_ids,
           |       read_reviewed_assignment_ids, read_published_exam_ids,
           |       read_questionnaire_ids,
           |       teacher_profile, student_profile
           |from teaching_users
           |$whereClause
           |""".stripMargin
      ) { statement =>
        statement.setString(1, value)
        val resultSet = statement.executeQuery()
        try
          if resultSet.next() then decodeUser(resultSet).map(Some(_))
          else Right(None)
        finally resultSet.close()
      }
    }

  private def decodeUser(resultSet: java.sql.ResultSet)(using Decoder[List[String]]): Either[String, UserAccount] =
    import JdbcReadSupport.*
    for
      role <- JdbcDecodingSupport.decodeRole(resultSet.getString("role"), "user role")
      readAnnouncementIds <- decodeJson[List[String]](resultSet.getString("read_announcement_ids"), "read announcement ids")
      readSystemNotificationIds <- decodeJson[List[String]](resultSet.getString("read_system_notification_ids"), "read system notification ids")
      readReviewedAssignmentIds <- decodeJson[List[String]](resultSet.getString("read_reviewed_assignment_ids"), "read reviewed assignment ids")
      readPublishedExamIds <- decodeJson[List[String]](resultSet.getString("read_published_exam_ids"), "read published exam ids")
      readQuestionnaireIds <- decodeJson[List[String]](resultSet.getString("read_questionnaire_ids"), "read questionnaire ids")
      teacherProfile <- JdbcDecodingSupport.decodeOptionalJson[TeacherProfile](readStringOpt(resultSet, "teacher_profile"), "teacher profile")
      studentProfile <- JdbcDecodingSupport.decodeOptionalJson[StudentProfile](readStringOpt(resultSet, "student_profile"), "student profile")
    yield UserAccount(
      id = resultSet.getString("id"),
      username = resultSet.getString("username"),
      password = resultSet.getString("password"),
      displayName = resultSet.getString("display_name"),
      role = role,
      avatarDataUrl = readStringOpt(resultSet, "avatar_data_url"),
      readAnnouncementIds = readAnnouncementIds,
      readSystemNotificationIds = readSystemNotificationIds,
      readReviewedAssignmentIds = readReviewedAssignmentIds,
      readPublishedExamIds = readPublishedExamIds,
      readQuestionnaireIds = readQuestionnaireIds,
      teacherProfile = teacherProfile,
      studentProfile = studentProfile
    )
