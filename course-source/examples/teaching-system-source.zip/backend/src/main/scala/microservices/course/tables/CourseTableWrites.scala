package microservices.course.tables

import io.circe.syntax.*
import microservices.course.objects.{Course, CourseAnnouncement, CourseChatMessage}
import shared.jdbc.JdbcStatementSupport.{setInstant, setInstantOpt, setJsonbOpt, setStringOpt, withPrepared}

import java.sql.Connection

object CourseTableWrites:
  def saveCourses(
    connection: Connection,
    courses: Iterable[Course],
    announcements: Iterable[CourseAnnouncement],
    chatMessages: Iterable[CourseChatMessage]
  ): Unit =
    courses.foreach { course =>
      upsertCourse(connection, course)
      course.teachers.zipWithIndex.foreach { case (teacherId, index) => insertCourseMember(connection, "teaching_course_teachers", course.id, teacherId, index + 1) }
      course.students.zipWithIndex.foreach { case (studentId, index) => insertCourseMember(connection, "teaching_course_students", course.id, studentId, index + 1) }
    }
    announcements.foreach(insertAnnouncement(connection, _))
    chatMessages.foreach(insertChatMessage(connection, _))

  def upsertAnnouncement(connection: Connection, announcement: CourseAnnouncement): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_announcements (id, course_id, title, content, attachment, publisher_teacher_id, created_at)
        |values (?, ?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set course_id = excluded.course_id,
        |    title = excluded.title,
        |    content = excluded.content,
        |    attachment = excluded.attachment,
        |    publisher_teacher_id = excluded.publisher_teacher_id,
        |    created_at = excluded.created_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, announcement.id)
      statement.setString(2, announcement.courseId)
      statement.setString(3, announcement.title)
      statement.setString(4, announcement.content)
      setJsonbOpt(statement, 5, announcement.attachment)
      statement.setString(6, announcement.publisherTeacherId)
      setInstant(statement, 7, announcement.createdAt)
      statement.executeUpdate()
    }

  def replaceCourse(connection: Connection, course: Course): Unit =
    upsertCourse(connection, course)
    deleteCourseMembers(connection, "teaching_course_teachers", course.id)
    deleteCourseMembers(connection, "teaching_course_students", course.id)
    course.teachers.zipWithIndex.foreach { case (teacherId, index) => insertCourseMember(connection, "teaching_course_teachers", course.id, teacherId, index + 1) }
    course.students.zipWithIndex.foreach { case (studentId, index) => insertCourseMember(connection, "teaching_course_students", course.id, studentId, index + 1) }

  def deleteCourse(connection: Connection, courseId: String): Unit =
    deleteCourseMembers(connection, "teaching_course_teachers", courseId)
    deleteCourseMembers(connection, "teaching_course_students", courseId)
    withPrepared(connection, "delete from teaching_courses where id = ?") { statement =>
      statement.setString(1, courseId)
      statement.executeUpdate()
    }

  def deleteAnnouncement(connection: Connection, announcementId: String): Unit =
    withPrepared(connection, "delete from teaching_announcements where id = ?") { statement =>
      statement.setString(1, announcementId)
      statement.executeUpdate()
    }

  def upsertChatMessage(connection: Connection, message: CourseChatMessage): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_course_chat_messages (id, course_id, sender_user_id, content, images, attachments, sent_at, revoked_at, revoked_by_user_id)
        |values (?, ?, ?, ?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set course_id = excluded.course_id,
        |    sender_user_id = excluded.sender_user_id,
        |    content = excluded.content,
        |    images = excluded.images,
        |    attachments = excluded.attachments,
        |    sent_at = excluded.sent_at,
        |    revoked_at = excluded.revoked_at,
        |    revoked_by_user_id = excluded.revoked_by_user_id
        |""".stripMargin
    ) { statement =>
      statement.setString(1, message.id)
      statement.setString(2, message.courseId)
      statement.setString(3, message.senderUserId)
      statement.setString(4, message.content)
      statement.setString(5, message.images.asJson.noSpaces)
      statement.setString(6, message.attachments.asJson.noSpaces)
      setInstant(statement, 7, message.sentAt)
      setInstantOpt(statement, 8, message.revokedAt)
      setStringOpt(statement, 9, message.revokedByUserId)
      statement.executeUpdate()
    }

  def deleteChatMessage(connection: Connection, messageId: String): Unit =
    withPrepared(connection, "delete from teaching_course_chat_messages where id = ?") { statement =>
      statement.setString(1, messageId)
      statement.executeUpdate()
    }

  private def upsertCourse(connection: Connection, course: Course): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_courses (id, title, description, member_events, created_at)
        |values (?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set title = excluded.title,
        |    description = excluded.description,
        |    member_events = excluded.member_events,
        |    created_at = excluded.created_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, course.id)
      statement.setString(2, course.title)
      statement.setString(3, course.description)
      statement.setString(4, course.memberEvents.asJson.noSpaces)
      setInstant(statement, 5, course.createdAt)
      statement.executeUpdate()
    }

  private def insertCourseMember(connection: Connection, tableName: String, courseId: String, userId: String, position: Int): Unit =
    withPrepared(connection, s"insert into $tableName values (?, ?, ?)") { statement =>
      statement.setString(1, courseId)
      statement.setString(2, userId)
      statement.setInt(3, position)
      statement.executeUpdate()
    }

  private def deleteCourseMembers(connection: Connection, tableName: String, courseId: String): Unit =
    withPrepared(connection, s"delete from $tableName where course_id = ?") { statement =>
      statement.setString(1, courseId)
      statement.executeUpdate()
    }

  private def insertAnnouncement(connection: Connection, announcement: CourseAnnouncement): Unit =
    upsertAnnouncement(connection, announcement)

  private def insertChatMessage(connection: Connection, message: CourseChatMessage): Unit =
    upsertChatMessage(connection, message)
