package microservices.course.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import infrastructure.storage.Attachment
import shared.model.SharedCodecs.given

import java.time.Instant

final case class CourseAnnouncement(
    id: String,
    courseId: String,
    title: String,
    content: String,
    attachment: Option[Attachment],
    publisher: PublicUser,
    createdAt: Instant
)
object CourseAnnouncement:
  given Codec[CourseAnnouncement] = deriveCodec
