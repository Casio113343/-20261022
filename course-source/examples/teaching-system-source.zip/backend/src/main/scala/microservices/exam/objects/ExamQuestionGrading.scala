package microservices.exam.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class ExamQuestionGrading(
    id: String,
    answerSheetId: String,
    graderTeacherId: String,
    score: Int,
    gradedAt: Instant
)

object ExamQuestionGrading:
  given Encoder[ExamQuestionGrading] = deriveEncoder[ExamQuestionGrading]
  given Decoder[ExamQuestionGrading] = deriveDecoder[ExamQuestionGrading]
