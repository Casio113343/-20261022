package microservices.course.objects

import io.circe.{Decoder, Encoder}

enum CourseMemberAction(val value: String):
  case Joined extends CourseMemberAction("joined")
  case Left extends CourseMemberAction("left")

object CourseMemberAction:
  def fromString(value: String): Either[String, CourseMemberAction] =
    value match
      case Joined.value => Right(Joined)
      case Left.value => Right(Left)
      case _ => scala.Left(s"未知课程成员事件: $value")

  given Encoder[CourseMemberAction] = Encoder.encodeString.contramap(_.value)
  given Decoder[CourseMemberAction] = Decoder.decodeString.emap(fromString)
