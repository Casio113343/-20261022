package microservices.assignment.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.tables.AssignmentTableWrites

final case class ClearDeletedCourseAssignmentsAPIMessage(reviewIds: List[String], submissionIds: List[String], assignmentIds: List[String]) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        IO.blocking {
          reviewIds.foreach(AssignmentTableWrites.deleteReview(connection, _))
          submissionIds.foreach(AssignmentTableWrites.deleteSubmission(connection, _))
          assignmentIds.foreach(AssignmentTableWrites.deleteAssignment(connection, _))
        }.as(Right(()): Either[String, Unit])
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理删除课程的作业数据")

object ClearDeletedCourseAssignmentsAPIMessage:
  given Codec.AsObject[ClearDeletedCourseAssignmentsAPIMessage] = deriveCodec
