package microservices.questionnaire.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser

final case class QuestionnaireChoiceOptionResult(
    option: String,
    selectedCount: Int,
    students: Option[List[PublicUser]]
)

object QuestionnaireChoiceOptionResult:
  given Codec.AsObject[QuestionnaireChoiceOptionResult] = deriveCodec
