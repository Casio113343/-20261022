package microservices.dashboard.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.dashboard.tables.DashboardTableReads

final case class FetchDashboardAPIMessage(userId: String) extends APIMessage[UserDashboardResponse]:
  override def plan: IO[UserDashboardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection(connection => DashboardTableReads.loadDashboardFromTables(connection, userId))
      response <- resolveEither(result)
    yield response

object FetchDashboardAPIMessage:
  given Codec.AsObject[FetchDashboardAPIMessage] = deriveCodec
