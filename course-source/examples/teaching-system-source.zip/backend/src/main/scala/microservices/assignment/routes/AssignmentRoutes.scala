package microservices.assignment.routes

import infrastructure.api.ActionResponse
import infrastructure.api.RegisteredAPIMessage
import microservices.assignment.api.*
import microservices.assignment.api.boundary.*

object AssignmentRoutes:
  val apiMessages: List[RegisteredAPIMessage] = List(
    RegisteredAPIMessage.api[CreateAssignmentAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[UpdateAssignmentAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[DeleteAssignmentAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[FetchAssignmentCourseDetailAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[CreateSubmissionAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[ReviewSubmissionAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[MarkReviewedAssignmentReadAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse],
    RegisteredAPIMessage.api[ClearDeletedCourseAssignmentsAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[ReleaseLeavingTeacherAssignmentReviewResponsibilitiesAPIMessage, ActionResponse]
  )
