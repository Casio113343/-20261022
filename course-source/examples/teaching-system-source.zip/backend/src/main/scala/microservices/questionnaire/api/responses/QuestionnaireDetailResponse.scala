package microservices.questionnaire.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import microservices.course.api.responses.CourseSummary
import microservices.questionnaire.objects.{Questionnaire, QuestionnaireSubmission}

final case class QuestionnaireDetailResponse(
    questionnaire: Questionnaire,
    course: CourseSummary,
    currentUserSubmission: Option[QuestionnaireSubmission],
    filledCount: Int,
    unfilledCount: Int,
    results: Option[List[QuestionnaireQuestionResult]]
)

object QuestionnaireDetailResponse:
  given Codec.AsObject[QuestionnaireDetailResponse] = deriveCodec
