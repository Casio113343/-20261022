package microservices.exam.support

import microservices.course.objects.Course
import microservices.course.support.CourseAccessSupport.{isContentVisibleToUser, isCurrentTeacher}
import microservices.exam.api.requests.{ExamInput, ExamQuestionInput}
import microservices.exam.objects.ExamQuestionScoring

import java.time.Instant

object ExamValidationSupport:
  final case class ValidatedExamQuestion(title: String, scoring: ExamQuestionScoring)

  def validateExam(course: Course, request: ExamInput): Either[String, List[ValidatedExamQuestion]] =
    if request.title.trim.isEmpty then Left("考试名称不能为空")
    else if request.questions.isEmpty then Left("至少需要添加一道题目")
    else request.questions.zipWithIndex.foldLeft[Either[String, List[ValidatedExamQuestion]]](Right(List.empty)) {
      case (Right(acc), (question, index)) => validateExamQuestion(course, question, index + 1).map(acc :+ _)
      case (left @ Left(_), _) => left
    }.flatMap { validated =>
      val appealEnabled = validated.exists(_.scoring.appealEnabled)
      if appealEnabled && request.appealDueAt.isEmpty then Left("存在允许申诉的题目时，必须设置申诉截止时间")
      else if !appealEnabled && request.appealDueAt.nonEmpty then Left("没有题目允许申诉时，无需设置申诉截止时间")
      else Right(validated)
    }

  def validateExamQuestion(course: Course, request: ExamQuestionInput, position: Int): Either[String, ValidatedExamQuestion] =
    val title = request.title.trim
    val normalizedGraders = request.graderTeacherIds.map(_.trim).filter(_.nonEmpty)
    val graderTeacherIds = normalizedGraders.distinct
    if request.fullScore <= 0 then Left(s"第 $position 题满分必须大于 0")
    else if normalizedGraders.length != graderTeacherIds.length then Left(s"第 $position 题批改教师不能重复")
    else if graderTeacherIds.isEmpty || graderTeacherIds.length > 2 then Left(s"第 $position 题批改教师只能设置 1 到 2 人")
    else if graderTeacherIds.exists(id => !course.teachers.contains(id)) then Left(s"第 $position 题批改教师必须属于当前课程")
    else
      val scoringEither =
        if graderTeacherIds.length == 1 || !request.arbitrationEnabled then Right(ExamQuestionScoring(request.fullScore, graderTeacherIds, false, None, None, request.appealEnabled, request.appealTeacherId.map(_.trim).filter(_.nonEmpty)))
        else
          val threshold = request.arbitrationScoreDiffThreshold.getOrElse(-1)
          val arbitrationTeacherId = request.arbitrationTeacherId.map(_.trim).filter(_.nonEmpty)
          if threshold < 0 then Left(s"第 $position 题开启仲裁时必须设置非负分差阈值")
          else if arbitrationTeacherId.isEmpty then Left(s"第 $position 题开启仲裁时必须设置仲裁教师")
          else if !course.teachers.contains(arbitrationTeacherId.get) then Left(s"第 $position 题仲裁教师必须属于当前课程")
          else if graderTeacherIds.contains(arbitrationTeacherId.get) then Left(s"第 $position 题仲裁教师不能与批改教师重复")
          else Right(ExamQuestionScoring(request.fullScore, graderTeacherIds, true, Some(threshold), arbitrationTeacherId, request.appealEnabled, request.appealTeacherId.map(_.trim).filter(_.nonEmpty)))
      scoringEither.flatMap { scoring =>
        if !request.appealEnabled then Right(scoring.copy(appealEnabled = false, appealTeacherId = None))
        else
          val appealTeacherId = request.appealTeacherId.map(_.trim).filter(_.nonEmpty)
          if appealTeacherId.isEmpty then Left(s"第 $position 题开启申诉时必须设置申诉处理教师")
          else if !course.teachers.contains(appealTeacherId.get) then Left(s"第 $position 题申诉处理教师必须属于当前课程")
          else Right(scoring.copy(appealEnabled = true, appealTeacherId = appealTeacherId))
      }.map(scoring => ValidatedExamQuestion(title, scoring))

  def validateAppealDueAt(validatedQuestions: List[ValidatedExamQuestion], appealDueAt: Option[Instant], now: Instant): Either[String, Unit] =
    if validatedQuestions.exists(_.scoring.appealEnabled) then
      appealDueAt match
        case Some(value) if value.isAfter(now) => Right(())
        case Some(_) => Left("申诉截止时间必须晚于当前时间")
        case None => Left("存在允许申诉的题目时，必须设置申诉截止时间")
    else Right(())

  def validateHistoricalTeacherEligibility(course: Course, createdAt: Instant, validatedQuestions: List[ValidatedExamQuestion]): Either[String, Unit] =
    val teacherIds = validatedQuestions.flatMap(question =>
      question.scoring.graderTeacherIds ++ question.scoring.arbitrationTeacherId.toList ++ question.scoring.appealTeacherId.toList
    ).distinct
    teacherIds.find(teacherId => !isCurrentTeacher(course, teacherId) || !isContentVisibleToUser(course, teacherId, createdAt)) match
      case Some(_) => Left("考试创建后加入课程的老师不能接手这场旧考试的批改、仲裁或申诉")
      case None => Right(())
