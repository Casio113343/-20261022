package microservices.questionnaire.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.questionnaire.objects.QuestionnaireAnswer

final case class QuestionnaireSubmissionInput(answers: List[QuestionnaireAnswer])

object QuestionnaireSubmissionInput:
  given Codec.AsObject[QuestionnaireSubmissionInput] = deriveCodec
