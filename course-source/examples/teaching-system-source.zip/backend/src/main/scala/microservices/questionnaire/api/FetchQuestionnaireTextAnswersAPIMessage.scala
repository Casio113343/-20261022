package microservices.questionnaire.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.support.AuthUserViewSupport.toPublicUser
import microservices.auth.tables.AuthTableReads
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.tables.CourseTableReads
import microservices.questionnaire.api.responses.QuestionnaireTextAnswer
import microservices.questionnaire.objects.QuestionnaireQuestionType
import microservices.questionnaire.tables.QuestionnaireTableReads

final case class FetchQuestionnaireTextAnswersAPIMessage(questionnaireId: String, questionId: String, userId: String) extends APIMessage[List[QuestionnaireTextAnswer]]:
  def plan: IO[List[QuestionnaireTextAnswer]] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          questionnaireEither <- QuestionnaireTableReads.loadQuestionnaireById(connection, questionnaireId)
          courseEither <- questionnaireEither match
            case Left(error) => IO.pure(Left(error))
            case Right(questionnaire) => CourseTableReads.loadCourseById(connection, questionnaire.courseId)
          submissionsEither <- QuestionnaireTableReads.loadSubmissionsByQuestionnaireIds(connection, List(questionnaireId))
          usersEither <- submissionsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(submissions) => AuthTableReads.loadUsersByIds(connection, submissions.valuesIterator.map(_.studentId).toSet)
        yield for
          user <- userEither
          questionnaire <- questionnaireEither
          course <- courseEither
          submissions <- submissionsEither
          users <- usersEither
          _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以查看问卷结果")
          question <- questionnaire.questions.find(_.id == questionId).toRight("问卷题目不存在")
          _ <- Either.cond(question.questionType == QuestionnaireQuestionType.Text, (), "只有简答题可以查看回答列表")
        yield submissions.values.toList.flatMap { submission =>
          submission.answers.find(_.questionId == question.id).flatMap(_.text.map(_.trim).filter(_.nonEmpty)).map { text =>
            QuestionnaireTextAnswer(
              submissionId = submission.id,
              student = Option.when(!questionnaire.anonymous)(users.get(submission.studentId).map(toPublicUser)).flatten,
              text = text
            )
          }
        }
      }
      response <- resolveEither(result)
    yield response

object FetchQuestionnaireTextAnswersAPIMessage:
  given Codec.AsObject[FetchQuestionnaireTextAnswersAPIMessage] = deriveCodec
