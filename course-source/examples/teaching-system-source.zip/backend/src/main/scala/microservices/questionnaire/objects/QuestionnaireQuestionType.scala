package microservices.questionnaire.objects

import io.circe.{Decoder, Encoder}

enum QuestionnaireQuestionType(val value: String):
  case SingleChoice extends QuestionnaireQuestionType("single-choice")
  case MultipleChoice extends QuestionnaireQuestionType("multiple-choice")
  case Text extends QuestionnaireQuestionType("text")

object QuestionnaireQuestionType:
  def fromString(value: String): Either[String, QuestionnaireQuestionType] =
    value match
      case SingleChoice.value => Right(SingleChoice)
      case MultipleChoice.value => Right(MultipleChoice)
      case Text.value => Right(Text)
      case _ => Left("未知问卷题目类型")

  given Encoder[QuestionnaireQuestionType] = Encoder.encodeString.contramap(_.value)
  given Decoder[QuestionnaireQuestionType] = Decoder.decodeString.emap(fromString)
