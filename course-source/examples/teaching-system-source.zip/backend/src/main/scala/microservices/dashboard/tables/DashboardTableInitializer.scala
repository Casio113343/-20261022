package microservices.dashboard.tables

object DashboardTableInitializer:
  val initSql: List[String] = List(
    """
      |create table if not exists teaching_system_notifications (
      |  id text primary key,
      |  user_id text not null,
      |  message text not null,
      |  created_at timestamptz not null
      |);
      |""".stripMargin
  )

  val migrationSql: List[String] = Nil

  val tableNames: List[String] = List("teaching_system_notifications")
