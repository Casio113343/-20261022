package microservices.course.tables

import cats.effect.IO
import io.circe.Decoder
import microservices.assignment.tables.AssignmentTableReads
import microservices.auth.objects.UserAccount
import microservices.auth.support.AuthUserViewSupport.toPublicUser
import microservices.auth.tables.AuthTableReads
import microservices.course.api.responses.{CourseAnnouncement as CourseAnnouncementResponse, CourseChatMessage as CourseChatMessageResponse, CourseChatTimelinePage, CourseDetailResponse, CourseMemberHistoryEntry, CourseSummary}
import microservices.course.objects.{Course, CourseAnnouncement, CourseChatMessage, CourseMemberEvent}
import microservices.course.support.CourseAccessSupport.{firstJoinedAt, isContentVisibleToUser, isCurrentCourseMember}
import microservices.exam.api.responses.ExamSummary
import microservices.exam.tables.ExamTableReads
import infrastructure.storage.Attachment
import shared.jdbc.{JdbcDecodingSupport, JdbcReadSupport}

import java.sql.Connection
import java.time.Instant

object CourseTableReads:
  private val defaultChatTimelinePageSize = 20

  val courseIdByAnnouncementIdSql: String =
    "select course_id from teaching_announcements where id = ?"

  def loadCourseDetailFromTables(connection: Connection, courseId: String, userId: String): IO[Either[String, CourseDetailResponse]] =
    for
      courseEither <- loadCourseById(connection, courseId)
      announcementsEither <- loadAnnouncementsByCourseId(connection, courseId)
      chatMessagesEither <- loadChatMessagesByCourseId(connection, courseId)
      assignmentsEither <- AssignmentTableReads.loadAssignmentsByCourseIds(connection, List(courseId))
      submissionsEither <- assignmentsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(assignments) => AssignmentTableReads.loadSubmissionsByAssignmentIds(connection, assignments.keys)
      reviewsEither <- submissionsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(submissions) => AssignmentTableReads.loadReviewsBySubmissionIds(connection, submissions.keys)
      examsEither <- ExamTableReads.loadExamsByCourseIds(connection, List(courseId))
      usersEither <- (courseEither, announcementsEither, chatMessagesEither, examsEither) match
        case (Right(course), Right(announcements), Right(chatMessages), Right(exams)) =>
          AuthTableReads.loadUsersByIds(
            connection,
            (course.teachers ++ course.students ++ course.memberEvents.map(_.userId)).toSet ++
              announcements.valuesIterator.map(_.publisherTeacherId).toSet ++
              chatMessages.valuesIterator.flatMap(message => message.revokedByUserId.toList :+ message.senderUserId).toSet ++
              exams.valuesIterator.map(_.createdByTeacherId).toSet
          )
        case (Left(error), _, _, _) => IO.pure(Left(error))
        case (_, Left(error), _, _) => IO.pure(Left(error))
        case (_, _, Left(error), _) => IO.pure(Left(error))
        case (_, _, _, Left(error)) => IO.pure(Left(error))
      latestChatEither <- (courseEither, chatMessagesEither, usersEither) match
        case (Right(course), Right(chatMessages), Right(users)) =>
          IO.pure(buildChatTimelinePage(course, userId, chatMessages.values.toList, users, defaultChatTimelinePageSize, None, None))
        case (Left(error), _, _) => IO.pure(Left(error))
        case (_, Left(error), _) => IO.pure(Left(error))
        case (_, _, Left(error)) => IO.pure(Left(error))
    yield for
      course <- courseEither
      _ <- Either.cond(isCurrentCourseMember(course, userId), (), "当前用户不可访问该课程")
      announcements <- announcementsEither
      assignments <- assignmentsEither
      submissions <- submissionsEither
      reviews <- reviewsEither
      exams <- examsEither
      users <- usersEither
      latestChat <- latestChatEither
      summary <- buildCourseSummary(course, users)
      announcementViews <- buildAnnouncementViews(course, userId, announcements.values.toList, users)
      examSummaries <- buildExamSummaries(course, userId, exams.values.toList, users)
      memberHistory <- buildMemberHistory(course, userId, users)
    yield
      val visibleAssignments = assignments.values.toList
        .filter(item => item.courseId == course.id && isContentVisibleToUser(course, userId, item.createdAt))
        .sortBy(_.createdAt)(Ordering[Instant].reverse)
      val visibleAssignmentIds = visibleAssignments.map(_.id).toSet
      val visibleSubmissions = submissions.values.toList
        .filter(submission => visibleAssignmentIds.contains(submission.assignmentId))
        .sortBy(_.submittedAt)(Ordering[Instant].reverse)
      val visibleSubmissionIds = visibleSubmissions.map(_.id).toSet
      val visibleReviews = reviews.values.toList
        .filter(review => visibleSubmissionIds.contains(review.submissionId))
        .sortBy(_.reviewedAt)(Ordering[Instant].reverse)
      CourseDetailResponse(summary, announcementViews, visibleAssignments, visibleSubmissions, visibleReviews, examSummaries, latestChat.messages, memberHistory)

  def loadAnnouncementCourseDetailFromTables(connection: Connection, announcementId: String, userId: String): IO[Either[String, CourseDetailResponse]] =
    lookupCourseId(connection, courseIdByAnnouncementIdSql, announcementId).flatMap {
      case Some(courseId) =>
        for
          announcementEither <- loadAnnouncementById(connection, announcementId)
          detailEither <- loadCourseDetailFromTables(connection, courseId, userId)
        yield for
          announcement <- announcementEither
          detail <- detailEither
          _ <- Either.cond(announcement.courseId == detail.course.id, (), "通知所属课程不存在")
        yield detail
      case None => IO.pure(Left("通知不存在"))
    }

  def loadCourseChatTimelineFromTables(
      connection: Connection,
      courseId: String,
      userId: String,
      limit: Int,
      beforeSentAt: Option[String],
      beforeRowIndex: Option[Int]
  ): IO[Either[String, CourseChatTimelinePage]] =
    for
      courseEither <- loadCourseById(connection, courseId)
      messagesEither <- loadChatMessagesByCourseId(connection, courseId)
      usersEither <- (courseEither, messagesEither) match
        case (Right(course), Right(messages)) =>
          AuthTableReads.loadUsersByIds(connection, (course.teachers ++ course.students ++ messages.valuesIterator.flatMap(message => message.revokedByUserId.toList :+ message.senderUserId)).toSet)
        case (Left(error), _) => IO.pure(Left(error))
        case (_, Left(error)) => IO.pure(Left(error))
    yield for
      course <- courseEither
      _ <- Either.cond(isCurrentCourseMember(course, userId), (), "当前用户不可访问该课程")
      messages <- messagesEither
      users <- usersEither
      page <- buildChatTimelinePage(course, userId, messages.values.toList, users, limit, beforeSentAt, beforeRowIndex)
    yield page

  def lookupCourseId(connection: Connection, sql: String, aggregateId: String): IO[Option[String]] =
    IO.blocking {
      JdbcReadSupport.withPrepared(connection, sql) { statement =>
        statement.setString(1, aggregateId)
        val resultSet = statement.executeQuery()
        try Option.when(resultSet.next())(resultSet.getString("course_id"))
        finally resultSet.close()
      }
    }

  def loadCourseById(connection: Connection, courseId: String): IO[Either[String, Course]] =
    loadCoursesByIds(connection, List(courseId)).map(_.flatMap(_.get(courseId).toRight("课程不存在")))

  def courseTitleExists(connection: Connection, title: String): IO[Either[String, Boolean]] =
    import JdbcReadSupport.*
    IO.blocking {
      withPrepared(
        connection,
        """
          |select 1
          |from teaching_courses
          |where lower(trim(title)) = lower(trim(?))
          |limit 1
          |""".stripMargin
      ) { statement =>
        statement.setString(1, title)
        val resultSet = statement.executeQuery()
        try Right(resultSet.next())
        finally resultSet.close()
      }
    }

  def loadCourseIdsForUser(connection: Connection, userId: String): IO[Either[String, List[String]]] =
    import JdbcReadSupport.*
    IO.blocking {
      withPrepared(
        connection,
        """
          |select course_id
          |from teaching_course_teachers
          |where teacher_id = ?
          |union
          |select course_id
          |from teaching_course_students
          |where student_id = ?
          |""".stripMargin
      ) { statement =>
        statement.setString(1, userId)
        statement.setString(2, userId)
        val resultSet = statement.executeQuery()
        try Right(collectRows(resultSet)(_.getString("course_id")))
        finally resultSet.close()
      }
    }

  def loadCoursesByIds(connection: Connection, courseIds: Iterable[String]): IO[Either[String, Map[String, Course]]] =
    import JdbcReadSupport.*
    val ids = courseIds.toList.distinct
    given Decoder[List[CourseMemberEvent]] = Decoder.decodeList(summon[Decoder[CourseMemberEvent]])
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      for
        teachers <- loadCourseMembers(connection, "teaching_course_teachers", "teacher_id", ids)
        students <- loadCourseMembers(connection, "teaching_course_students", "student_id", ids)
        rows <- IO.blocking {
          withInPrepared(
            connection,
            """
              |select id, title, description, member_events, created_at
              |from teaching_courses
              |where id in (:ids)
              |""".stripMargin,
            ids
          ) { statement =>
            val resultSet = statement.executeQuery()
            try
              collectRows(resultSet) { row =>
                decodeJson[List[CourseMemberEvent]](row.getString("member_events"), "course member events").map { memberEvents =>
                  Course(
                    id = row.getString("id"),
                    title = row.getString("title"),
                    description = row.getString("description"),
                    teachers = teachers.getOrElse(row.getString("id"), Nil),
                    students = students.getOrElse(row.getString("id"), Nil),
                    createdAt = readInstant(row, "created_at"),
                    memberEvents = memberEvents
                  )
                }
              }
            finally resultSet.close()
          }
        }
      yield JdbcDecodingSupport.sequenceById(rows)

  def loadAnnouncementsByCourseId(connection: Connection, courseId: String): IO[Either[String, Map[String, CourseAnnouncement]]] =
    loadAnnouncementsByCourseIds(connection, List(courseId))

  def loadAnnouncementById(connection: Connection, announcementId: String): IO[Either[String, CourseAnnouncement]] =
    loadAnnouncementsByIds(connection, List(announcementId)).map(_.flatMap(_.get(announcementId).toRight("通知不存在")))

  def loadAnnouncementsByIds(connection: Connection, announcementIds: Iterable[String]): IO[Either[String, Map[String, CourseAnnouncement]]] =
    loadAnnouncements(connection, "id", announcementIds)

  def loadAnnouncementsByCourseIds(connection: Connection, courseIds: Iterable[String]): IO[Either[String, Map[String, CourseAnnouncement]]] =
    loadAnnouncements(connection, "course_id", courseIds)

  private def loadAnnouncements(connection: Connection, filterColumn: String, filterIds: Iterable[String]): IO[Either[String, Map[String, CourseAnnouncement]]] =
    import JdbcReadSupport.*
    val ids = filterIds.toList.distinct
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          s"""
            |select id, course_id, title, content, attachment, publisher_teacher_id, created_at
            |from teaching_announcements
            |where $filterColumn in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              JdbcDecodingSupport.decodeOptionalJson[Attachment](readStringOpt(row, "attachment"), "announcement attachment").map { attachment =>
                CourseAnnouncement(
                  id = row.getString("id"),
                  courseId = row.getString("course_id"),
                  title = row.getString("title"),
                  content = row.getString("content"),
                  attachment = attachment,
                  publisherTeacherId = row.getString("publisher_teacher_id"),
                  createdAt = readInstant(row, "created_at")
                )
              }
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadChatMessagesByCourseId(connection: Connection, courseId: String): IO[Either[String, Map[String, CourseChatMessage]]] =
    loadChatMessagesByCourseIds(connection, List(courseId))

  def loadChatMessageById(connection: Connection, messageId: String): IO[Either[String, CourseChatMessage]] =
    loadChatMessagesByIds(connection, List(messageId)).map(_.flatMap(_.get(messageId).toRight("消息不存在")))

  def loadChatMessagesByIds(connection: Connection, messageIds: Iterable[String]): IO[Either[String, Map[String, CourseChatMessage]]] =
    loadChatMessages(connection, "id", messageIds)

  def loadChatMessagesByCourseIds(connection: Connection, courseIds: Iterable[String]): IO[Either[String, Map[String, CourseChatMessage]]] =
    loadChatMessages(connection, "course_id", courseIds)

  private def loadChatMessages(connection: Connection, filterColumn: String, filterIds: Iterable[String]): IO[Either[String, Map[String, CourseChatMessage]]] =
    import JdbcReadSupport.*
    val ids = filterIds.toList.distinct
    given Decoder[List[Attachment]] = Decoder.decodeList(summon[Decoder[Attachment]])
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          s"""
            |select id, course_id, sender_user_id, content, images, attachments, sent_at, revoked_at, revoked_by_user_id
            |from teaching_course_chat_messages
            |where $filterColumn in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              for
                images <- decodeJson[List[Attachment]](row.getString("images"), "chat images")
                attachments <- decodeJson[List[Attachment]](row.getString("attachments"), "chat attachments")
              yield CourseChatMessage(
                id = row.getString("id"),
                courseId = row.getString("course_id"),
                senderUserId = row.getString("sender_user_id"),
                content = row.getString("content"),
                images = images,
                attachments = attachments,
                sentAt = readInstant(row, "sent_at"),
                revokedAt = readInstantOpt(row, "revoked_at"),
                revokedByUserId = readStringOpt(row, "revoked_by_user_id")
              )
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  private def loadCourseMembers(connection: Connection, tableName: String, memberColumn: String, courseIds: List[String]): IO[Map[String, List[String]]] =
    import JdbcReadSupport.*
    if courseIds.isEmpty then IO.pure(Map.empty)
    else
      IO.blocking {
        withInPrepared(
          connection,
          s"""
             |select course_id, $memberColumn
             |from $tableName
             |where course_id in (:ids)
             |order by course_id, position
             |""".stripMargin,
          courseIds
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet)(row => row.getString("course_id") -> row.getString(memberColumn))
              .groupBy(_._1)
              .view
              .mapValues(_.map(_._2))
              .toMap
          finally resultSet.close()
        }
      }

  private def buildCourseSummary(course: Course, users: Map[String, UserAccount]): Either[String, CourseSummary] =
    Right(CourseSummary(course.id, course.title, course.description, course.teachers.flatMap(users.get).map(toPublicUser), course.students.flatMap(users.get).map(toPublicUser), course.createdAt))

  private def buildAnnouncementViews(course: Course, userId: String, announcements: List[CourseAnnouncement], users: Map[String, UserAccount]): Either[String, List[CourseAnnouncementResponse]] =
    sequence(
      announcements
        .filter(item => item.courseId == course.id && isContentVisibleToUser(course, userId, item.createdAt))
        .sortBy(_.createdAt)(Ordering[Instant].reverse)
        .map { announcement =>
          users.get(announcement.publisherTeacherId).toRight("通知发布教师不存在").map { publisher =>
            CourseAnnouncementResponse(announcement.id, announcement.courseId, announcement.title, announcement.content, announcement.attachment, toPublicUser(publisher), announcement.createdAt)
          }
        }
    )

  private def buildExamSummaries(course: Course, userId: String, exams: List[microservices.exam.objects.OfflineExam], users: Map[String, UserAccount]): Either[String, List[ExamSummary]] =
    sequence(
      exams
        .filter(item => item.courseId == course.id && isContentVisibleToUser(course, userId, item.createdAt))
        .sortBy(_.createdAt)(Ordering[Instant].reverse)
        .map { exam =>
          users.get(exam.createdByTeacherId).toRight("考试创建者不存在").map { creator =>
            ExamSummary(exam.id, exam.courseId, exam.title, toPublicUser(creator), exam.createdAt, exam.publishedAt, exam.questionIds.length, exam.appealDueAt)
          }
        }
    )

  private def buildMemberHistory(course: Course, userId: String, users: Map[String, UserAccount]): Either[String, List[CourseMemberHistoryEntry]] =
    val visibleFrom = firstJoinedAt(course, userId).getOrElse(course.createdAt)
    sequence(
      course.memberEvents
        .filterNot(_.occurredAt.isBefore(visibleFrom))
        .sortBy(_.occurredAt)(Ordering[Instant].reverse)
        .map { event =>
          users.get(event.userId).toRight("课程成员历史关联的用户不存在").map { account =>
            CourseMemberHistoryEntry(toPublicUser(account), account.role.toString.toLowerCase, event.action.value, event.occurredAt)
          }
        }
    )

  def buildChatMessageView(message: CourseChatMessage, users: Map[String, UserAccount], operatorUserId: String): Either[String, CourseChatMessageResponse] =
    users.get(message.senderUserId).toRight("课程消息发送者不存在").map { sender =>
      CourseChatMessageResponse(message.id, message.courseId, toPublicUser(sender), message.content, message.images, message.attachments, message.sentAt, message.revokedAt, message.revokedByUserId, message.revokedAt.isEmpty && message.senderUserId == operatorUserId)
    }

  private def buildChatTimelinePage(
      course: Course,
      userId: String,
      messages: List[CourseChatMessage],
      users: Map[String, UserAccount],
      limit: Int,
      beforeSentAt: Option[String],
      beforeRowIndex: Option[Int]
  ): Either[String, CourseChatTimelinePage] =
    val normalizedLimit = limit.max(1).min(100)
    val cursorInstantEither: Either[String, Option[Instant]] = beforeSentAt match
      case Some(value) => scala.util.Try(Instant.parse(value)).toEither.left.map(_ => "Invalid beforeSentAt cursor").map(Some(_))
      case None => Right(None)
    for
      cursorInstant <- cursorInstantEither
      visibleMessages <- sequence(
        messages
          .filter(item => item.courseId == course.id && isContentVisibleToUser(course, userId, item.sentAt))
          .sortBy(_.sentAt)
          .zipWithIndex
          .filter { case (message, rowIndex) =>
            cursorInstant.forall(cursor => message.sentAt.isBefore(cursor) || (message.sentAt == cursor && rowIndex < beforeRowIndex.getOrElse(Int.MaxValue)))
          }
          .sortBy { case (message, rowIndex) => (message.sentAt, rowIndex) }(Ordering.Tuple2(Ordering[Instant], Ordering[Int]).reverse)
          .take(normalizedLimit)
          .map { case (message, rowIndex) => buildChatMessageView(message, users, userId).map((_, message.sentAt, rowIndex)) }
      )
    yield
      val ascendingMessages = visibleMessages.reverse.map(_._1)
      val nextCursor = visibleMessages.lastOption.map { case (_, sentAt, rowIndex) => (sentAt.toString, rowIndex) }
      CourseChatTimelinePage(ascendingMessages, nextCursor.map(_._1), nextCursor.map(_._2))

  private def sequence[A](values: List[Either[String, A]]): Either[String, List[A]] =
    values.foldLeft[Either[String, List[A]]](Right(Nil)) { (accumulator, current) =>
      for
        items <- accumulator
        item <- current
      yield items :+ item
    }
