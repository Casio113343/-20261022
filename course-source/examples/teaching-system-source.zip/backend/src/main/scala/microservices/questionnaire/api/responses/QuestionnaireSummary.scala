package microservices.questionnaire.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

import java.time.Instant

final case class QuestionnaireSummary(
    id: String,
    courseId: String,
    title: String,
    overview: Option[String],
    anonymous: Boolean,
    questionCount: Int,
    dueAt: Instant,
    createdAt: Instant,
    submitted: Boolean,
    filledCount: Int,
    unfilledCount: Int
)

object QuestionnaireSummary:
  given Codec.AsObject[QuestionnaireSummary] = deriveCodec
