package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import infrastructure.storage.Attachment

final case class ExamAnswerSheet(
    id: String,
    examId: String,
    questionId: String,
    student: PublicUser,
    images: List[Attachment]
)
object ExamAnswerSheet:
  given Codec[ExamAnswerSheet] = deriveCodec
