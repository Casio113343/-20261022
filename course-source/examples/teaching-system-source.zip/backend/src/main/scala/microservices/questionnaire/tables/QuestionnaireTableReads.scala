package microservices.questionnaire.tables

import cats.effect.IO
import io.circe.Decoder
import microservices.auth.objects.{UserAccount, UserRole}
import microservices.auth.support.AuthUserViewSupport.toPublicUser
import microservices.auth.tables.AuthTableReads
import microservices.course.api.responses.CourseSummary
import microservices.course.support.CourseAccessSupport.{courseStudentsAt, isContentVisibleToUser, isCurrentCourseMember, isCurrentStudent, isCurrentTeacher}
import microservices.course.tables.CourseTableReads
import microservices.questionnaire.api.responses.{QuestionnaireChoiceOptionResult, QuestionnaireDetailResponse, QuestionnaireQuestionResult}
import microservices.questionnaire.objects.{Questionnaire, QuestionnaireAnswer, QuestionnaireQuestion, QuestionnaireSubmission}
import shared.jdbc.{JdbcDecodingSupport, JdbcReadSupport}

import java.sql.Connection

object QuestionnaireTableReads:
  def loadQuestionnaireDetailFromTables(connection: Connection, questionnaireId: String, userId: String): IO[Either[String, QuestionnaireDetailResponse]] =
    for
      userEither <- AuthTableReads.loadUserById(connection, userId)
      questionnaireEither <- loadQuestionnaireById(connection, questionnaireId)
      courseEither <- questionnaireEither match
        case Left(error) => IO.pure(Left(error))
        case Right(questionnaire) => CourseTableReads.loadCourseById(connection, questionnaire.courseId)
      submissionsEither <- loadSubmissionsByQuestionnaireIds(connection, List(questionnaireId))
      usersEither <- (courseEither, submissionsEither) match
        case (Right(course), Right(submissions)) =>
          AuthTableReads.loadUsersByIds(connection, (course.teachers ++ course.students ++ submissions.valuesIterator.map(_.studentId)).toSet)
        case (Left(error), _) => IO.pure(Left(error))
        case (_, Left(error)) => IO.pure(Left(error))
    yield for
      user <- userEither
      questionnaire <- questionnaireEither
      course <- courseEither
      submissions <- submissionsEither
      users <- usersEither
      _ <- Either.cond(isCurrentCourseMember(course, user.id) && isContentVisibleToUser(course, user.id, questionnaire.createdAt), (), "当前用户不可访问该问卷")
      courseSummary <- buildCourseSummary(course, users)
    yield
      val eligibleStudents = courseStudentsAt(course, questionnaire.createdAt).filter(isCurrentStudent(course, _))
      val userSubmission = submissions.values.find(_.studentId == user.id)
      val teacherResults =
        Option.when(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id)) {
          buildQuestionResults(questionnaire, submissions.values.toList, users)
        }
      QuestionnaireDetailResponse(
        questionnaire = questionnaire,
        course = courseSummary,
        currentUserSubmission = userSubmission,
        filledCount = submissions.valuesIterator.map(_.studentId).toSet.intersect(eligibleStudents.toSet).size,
        unfilledCount = eligibleStudents.toSet.diff(submissions.valuesIterator.map(_.studentId).toSet).size,
        results = teacherResults
      )

  def loadQuestionnaireById(connection: Connection, questionnaireId: String): IO[Either[String, Questionnaire]] =
    loadQuestionnairesByIds(connection, List(questionnaireId)).map(_.flatMap(_.get(questionnaireId).toRight("问卷不存在")))

  def loadQuestionnairesByIds(connection: Connection, questionnaireIds: Iterable[String]): IO[Either[String, Map[String, Questionnaire]]] =
    loadQuestionnaires(connection, "id", questionnaireIds)

  def loadQuestionnairesByCourseIds(connection: Connection, courseIds: Iterable[String]): IO[Either[String, Map[String, Questionnaire]]] =
    loadQuestionnaires(connection, "course_id", courseIds)

  private def loadQuestionnaires(connection: Connection, filterColumn: String, filterIds: Iterable[String]): IO[Either[String, Map[String, Questionnaire]]] =
    import JdbcReadSupport.*
    val ids = filterIds.toList.distinct
    given Decoder[List[QuestionnaireQuestion]] = Decoder.decodeList(summon[Decoder[QuestionnaireQuestion]])
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          s"""
            |select id, course_id, title, overview, anonymous, questions, due_at, created_by_teacher_id, created_at
            |from teaching_questionnaires
            |where $filterColumn in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              decodeJson[List[QuestionnaireQuestion]](row.getString("questions"), "questionnaire questions").map { questions =>
                Questionnaire(
                  id = row.getString("id"),
                  courseId = row.getString("course_id"),
                  title = row.getString("title"),
                  overview = readStringOpt(row, "overview"),
                  anonymous = row.getBoolean("anonymous"),
                  questions = questions,
                  dueAt = readInstant(row, "due_at"),
                  createdByTeacherId = row.getString("created_by_teacher_id"),
                  createdAt = readInstant(row, "created_at")
                )
              }
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadSubmissionsByQuestionnaireIds(connection: Connection, questionnaireIds: Iterable[String]): IO[Either[String, Map[String, QuestionnaireSubmission]]] =
    import JdbcReadSupport.*
    val ids = questionnaireIds.toList.distinct
    given Decoder[List[QuestionnaireAnswer]] = Decoder.decodeList(summon[Decoder[QuestionnaireAnswer]])
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          """
            |select id, questionnaire_id, student_id, answers, submitted_at
            |from teaching_questionnaire_submissions
            |where questionnaire_id in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              decodeJson[List[QuestionnaireAnswer]](row.getString("answers"), "questionnaire answers").map { answers =>
                QuestionnaireSubmission(
                  id = row.getString("id"),
                  questionnaireId = row.getString("questionnaire_id"),
                  studentId = row.getString("student_id"),
                  answers = answers,
                  submittedAt = readInstant(row, "submitted_at")
                )
              }
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def findSubmissionForStudent(connection: Connection, questionnaireId: String, studentId: String): IO[Either[String, Option[QuestionnaireSubmission]]] =
    loadSubmissionsByQuestionnaireIds(connection, List(questionnaireId)).map(_.map(_.values.find(submission => submission.questionnaireId == questionnaireId && submission.studentId == studentId)))

  private def buildCourseSummary(course: microservices.course.objects.Course, users: Map[String, UserAccount]): Either[String, CourseSummary] =
    Right(CourseSummary(course.id, course.title, course.description, course.teachers.flatMap(users.get).map(toPublicUser), course.students.flatMap(users.get).map(toPublicUser), course.createdAt))

  private def buildQuestionResults(questionnaire: Questionnaire, submissions: List[QuestionnaireSubmission], users: Map[String, UserAccount]): List[QuestionnaireQuestionResult] =
    questionnaire.questions.map { question =>
      val answers = submissions.flatMap(submission => submission.answers.find(_.questionId == question.id).map(submission -> _))
      val optionResults = question.options.map { option =>
        val selectedSubmissions = answers.collect {
          case (submission, answer) if answer.selectedOptions.contains(option) => submission
        }
        QuestionnaireChoiceOptionResult(
          option = option,
          selectedCount = selectedSubmissions.length,
          students = Option.when(!questionnaire.anonymous)(selectedSubmissions.flatMap(submission => users.get(submission.studentId).map(toPublicUser)))
        )
      }
      QuestionnaireQuestionResult(question, optionResults, answers.count { case (_, answer) => answer.text.exists(_.trim.nonEmpty) })
    }
