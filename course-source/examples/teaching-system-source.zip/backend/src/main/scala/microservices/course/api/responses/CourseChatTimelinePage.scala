package microservices.course.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec

final case class CourseChatTimelinePage(
    messages: List[CourseChatMessage],
    nextCursorSentAt: Option[String],
    nextCursorRowIndex: Option[Int]
)

object CourseChatTimelinePage:
  given Codec[CourseChatTimelinePage] = deriveCodec
