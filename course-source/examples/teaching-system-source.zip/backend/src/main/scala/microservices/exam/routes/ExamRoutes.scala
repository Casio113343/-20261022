package microservices.exam.routes

import infrastructure.api.ActionResponse
import infrastructure.api.RegisteredAPIMessage
import microservices.exam.api.*
import microservices.exam.api.boundary.*

object ExamRoutes:
  val apiMessages: List[RegisteredAPIMessage] = List(
    RegisteredAPIMessage.api[CreateExamAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[UpdateExamAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[DeleteExamAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[ExamDetailAPIMessage, microservices.exam.api.responses.ExamDetailResponse],
    RegisteredAPIMessage.api[PublishExamAPIMessage, microservices.exam.api.responses.ExamDetailResponse],
    RegisteredAPIMessage.api[MarkPublishedExamReadAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse],
    RegisteredAPIMessage.api[ExamReviewBoardAPIMessage, microservices.exam.api.responses.ExamReviewBoardResponse],
    RegisteredAPIMessage.api[ReviewExamAnswerAPIMessage, microservices.exam.api.responses.ExamReviewBoardResponse],
    RegisteredAPIMessage.api[SubmitExamAppealAPIMessage, microservices.exam.api.responses.ExamDetailResponse],
    RegisteredAPIMessage.api[UploadExamAnswerImagesAPIMessage, microservices.exam.api.responses.ExamDetailResponse],
    RegisteredAPIMessage.api[ClearDeletedCourseExamsAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[ClearLeavingStudentUnpublishedExamAnswersAPIMessage, ActionResponse]
  )
