package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.support.CourseAccessSupport.{isCurrentStudent, isCurrentTeacher}
import microservices.course.tables.CourseTableReads
import microservices.exam.api.requests.ExamInput
import microservices.exam.objects.{ExamAppealStatus, ExamQuestionAppeal, ExamQuestionArbitration, ExamQuestionGrading, OfflineExamQuestion}
import microservices.exam.support.ExamValidationSupport.{validateAppealDueAt, validateExam, validateHistoricalTeacherEligibility}
import microservices.exam.tables.{ExamTableReads, ExamTableWrites}
import shared.id.IdGenerator

import java.time.Instant

final case class UpdateExamAPIMessage(courseId: String, examId: String, userId: String, input: ExamInput) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          examEither <- ExamTableReads.loadExamById(connection, examId)
          questionsEither <- ExamTableReads.loadExamQuestionsByExamIds(connection, List(examId))
          answerSheetsEither <- ExamTableReads.loadAnswerSheetsByExamIds(connection, List(examId))
          gradingsEither <- answerSheetsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(answerSheets) => ExamTableReads.loadQuestionGradingsByAnswerSheetIds(connection, answerSheets.keys)
          arbitrationsEither <- answerSheetsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(answerSheets) => ExamTableReads.loadQuestionArbitrationsByAnswerSheetIds(connection, answerSheets.keys)
          appealsEither <- (answerSheetsEither, questionsEither) match
            case (Right(answerSheets), Right(questions)) => ExamTableReads.loadQuestionAppeals(connection, answerSheets.keys, questions.keys)
            case (Left(error), _) => IO.pure(Left(error))
            case (_, Left(error)) => IO.pure(Left(error))
          validationEither = for
            user <- userEither
            course <- courseEither
            exam <- examEither
            questions <- questionsEither
            answerSheets <- answerSheetsEither
            gradings <- gradingsEither
            arbitrations <- arbitrationsEither
            appeals <- appealsEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(exam.courseId == course.id, (), "考试不属于当前课程")
            validatedQuestions <- validateExam(course, input)
            _ <- validateAppealDueAt(validatedQuestions, input.appealDueAt, now)
            _ <- validateHistoricalTeacherEligibility(course, exam.createdAt, validatedQuestions)
          yield
            val existingQuestionMap = questions.values.toList.sortBy(_.position).map(question => question.id -> question).toMap
            val questionEntries = input.questions.zip(validatedQuestions).zipWithIndex.map { case ((requestQuestion, validatedQuestion), index) =>
              val questionId = requestQuestion.questionId.filter(existingQuestionMap.contains).getOrElse(IdGenerator.nextId("exam-question"))
              questionId -> OfflineExamQuestion(questionId, exam.id, validatedQuestion.title, index + 1, validatedQuestion.scoring)
            }
            val retainedQuestionIds = questionEntries.map(_._1).toSet
            val removedQuestionIds = exam.questionIds.toSet.diff(retainedQuestionIds)
            val addedQuestionIds = retainedQuestionIds.diff(existingQuestionMap.keySet)
            val scoreChangedQuestionIds = questionEntries.collect {
              case (questionId, question) if existingQuestionMap.get(questionId).exists(_.scoring.fullScore != question.scoring.fullScore) => questionId
            }.toSet
            val nextExam = exam.copy(
              title = input.title.trim,
              publishedAt = if addedQuestionIds.nonEmpty || scoreChangedQuestionIds.nonEmpty then None else exam.publishedAt,
              questionIds = questionEntries.map(_._1),
              appealDueAt = input.appealDueAt,
            )
            val removedAnswerSheetIds = answerSheets.valuesIterator
              .filter(sheet => removedQuestionIds.contains(sheet.questionId))
              .map(_.id)
              .toSet
            val trimmedSheetMap = answerSheets.filterNot { case (_, sheet) => removedQuestionIds.contains(sheet.questionId) }
            val trimmedGradingMap = gradings.filterNot { case (_, grading) => removedAnswerSheetIds.contains(grading.answerSheetId) }
            val trimmedArbitrationMap = arbitrations.filterNot { case (_, arbitration) => removedAnswerSheetIds.contains(arbitration.answerSheetId) }
            val trimmedAppealMap = appeals.filterNot { case (_, appeal) => removedAnswerSheetIds.contains(appeal.answerSheetId) || removedQuestionIds.contains(appeal.questionId) }

            val remapped = questionEntries.toMap.foldLeft((trimmedGradingMap, trimmedArbitrationMap, trimmedAppealMap)) { case ((currentGradings, currentArbitrations, currentAppeals), (questionId, nextQuestion)) =>
              existingQuestionMap.get(questionId) match
                case None => (currentGradings, currentArbitrations, currentAppeals)
                case Some(previousQuestion) =>
                  val affectedAnswerSheetIds = trimmedSheetMap.valuesIterator.filter(_.questionId == questionId).map(_.id).toSet
                  val canKeepScores = previousQuestion.scoring.fullScore == nextQuestion.scoring.fullScore
                  val remappedGradings = currentGradings.view.mapValues { grading =>
                    if affectedAnswerSheetIds.contains(grading.answerSheetId) && canKeepScores then
                      val oldIndex = previousQuestion.scoring.graderTeacherIds.indexOf(grading.graderTeacherId)
                      if oldIndex >= 0 && oldIndex < nextQuestion.scoring.graderTeacherIds.length then grading.copy(graderTeacherId = nextQuestion.scoring.graderTeacherIds(oldIndex))
                      else grading
                    else grading
                  }.toMap
                  val remappedArbitrations = currentArbitrations.view.mapValues { arbitration =>
                    if affectedAnswerSheetIds.contains(arbitration.answerSheetId) && canKeepScores then
                      nextQuestion.scoring.arbitrationTeacherId.map(nextTeacherId => arbitration.copy(arbitrationTeacherId = nextTeacherId)).getOrElse(arbitration)
                    else arbitration
                  }.toMap
                  val remappedAppeals = currentAppeals.view.mapValues { appeal =>
                    if (affectedAnswerSheetIds.contains(appeal.answerSheetId) || appeal.questionId == questionId) && canKeepScores && appeal.status == ExamAppealStatus.Pending then
                      nextQuestion.scoring.appealTeacherId.map(nextTeacherId => appeal.copy(appealTeacherId = nextTeacherId, questionId = questionId)).getOrElse(appeal)
                    else appeal
                  }.toMap
                  (remappedGradings, remappedArbitrations, remappedAppeals)
            }

            val affectedScoreChangedSheetIds = trimmedSheetMap.valuesIterator.filter(sheet => scoreChangedQuestionIds.contains(sheet.questionId)).map(_.id).toSet
            val inactiveScoreChangedSheetIds = trimmedSheetMap.valuesIterator
              .filter(sheet => scoreChangedQuestionIds.contains(sheet.questionId) && !isCurrentStudent(course, sheet.studentId))
              .map(_.id)
              .toSet
            val scoreChangedRemovedSheetIds = affectedScoreChangedSheetIds ++ inactiveScoreChangedSheetIds
            val finalGradings = remapped._1.filterNot { case (_, grading) => scoreChangedRemovedSheetIds.contains(grading.answerSheetId) }
            val finalArbitrations = remapped._2.filterNot { case (_, arbitration) => scoreChangedRemovedSheetIds.contains(arbitration.answerSheetId) }
            val finalAppeals = remapped._3.filterNot { case (_, appeal) => scoreChangedRemovedSheetIds.contains(appeal.answerSheetId) || scoreChangedQuestionIds.contains(appeal.questionId) }

            (
              nextExam,
              questionEntries.map(_._2),
              removedQuestionIds,
              removedAnswerSheetIds ++ inactiveScoreChangedSheetIds,
              affectedScoreChangedSheetIds,
              scoreChangedQuestionIds,
              finalGradings.values.toList,
              finalArbitrations.values.toList,
              finalAppeals.values.toList
            )
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((nextExam, nextQuestions, removedQuestionIds, removedSheetIds, scoreChangedSheetIds, scoreChangedQuestionIds, finalGradings, finalArbitrations, finalAppeals)) =>
              for
                _ <- IO.blocking {
                  ExamTableWrites.upsertExam(connection, nextExam)
                  nextQuestions.foreach(ExamTableWrites.upsertExamQuestion(connection, _))
                  removedQuestionIds.foreach(ExamTableWrites.deleteExamQuestion(connection, _))
                  ExamTableWrites.deleteQuestionGradingsByAnswerSheetIds(connection, removedSheetIds ++ scoreChangedSheetIds)
                  ExamTableWrites.deleteQuestionArbitrationsByAnswerSheetIds(connection, removedSheetIds ++ scoreChangedSheetIds)
                  ExamTableWrites.deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection, removedSheetIds ++ scoreChangedSheetIds, removedQuestionIds ++ scoreChangedQuestionIds)
                  removedSheetIds.foreach(ExamTableWrites.deleteExamAnswerSheet(connection, _))
                  finalGradings.foreach(ExamTableWrites.upsertQuestionGrading(connection, _))
                  finalArbitrations.foreach(ExamTableWrites.upsertQuestionArbitration(connection, _))
                  finalAppeals.foreach(ExamTableWrites.upsertQuestionAppeal(connection, _))
                }
                detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, userId)
              yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

object UpdateExamAPIMessage:
  given Codec.AsObject[UpdateExamAPIMessage] = deriveCodec
