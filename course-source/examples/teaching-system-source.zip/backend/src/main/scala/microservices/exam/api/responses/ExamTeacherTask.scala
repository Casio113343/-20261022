package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.exam.api.requests.ExamReviewOperation

final case class ExamTeacherTask(
    examId: String,
    examTitle: String,
    questionId: String,
    questionTitle: String,
    position: Int,
    mode: ExamReviewOperation,
    pendingCount: Int,
    completedCount: Int
)
object ExamTeacherTask:
  given Codec[ExamTeacherTask] = deriveCodec
