package microservices.assignment.tables

object AssignmentTableInitializer:
  val initSql: List[String] = List(
    """
      |create table if not exists teaching_assignments (
      |  id text primary key,
      |  course_id text not null,
      |  title text not null,
      |  content text not null,
      |  attachment text,
      |  allow_late_submission boolean not null,
      |  max_score integer,
      |  grader_teacher_id text not null,
      |  due_at timestamptz not null,
      |  created_by_teacher_id text not null,
      |  created_at timestamptz not null,
      |  answer_attachment text,
      |  answer_published_at timestamptz
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_submissions (
      |  id text primary key,
      |  assignment_id text not null,
      |  student_id text not null,
      |  content text not null,
      |  attachment text,
      |  submitted_at timestamptz not null
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_reviews (
      |  id text primary key,
      |  submission_id text not null,
      |  grader_teacher_id text not null,
      |  score integer,
      |  comment text,
      |  reviewed_at timestamptz not null
      |);
      |""".stripMargin
  )

  val migrationSql: List[String] = List(
    "alter table teaching_assignments alter column attachment type text using attachment::text",
    "alter table teaching_submissions alter column attachment type text using attachment::text",
    "alter table teaching_assignments add column if not exists answer_attachment text",
    "alter table teaching_assignments add column if not exists answer_published_at timestamptz"
  )

  val tableNames: List[String] = List(
    "teaching_reviews",
    "teaching_submissions",
    "teaching_assignments"
  )
