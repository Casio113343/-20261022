package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import shared.model.SharedCodecs.given

final case class ExamQuestionScoring(
    fullScore: Int,
    graders: List[PublicUser],
    arbitrationEnabled: Boolean,
    arbitrationScoreDiffThreshold: Option[Int],
    arbitrationTeacher: Option[PublicUser],
    appealEnabled: Boolean,
    appealTeacher: Option[PublicUser]
)
object ExamQuestionScoring:
  given Codec[ExamQuestionScoring] = deriveCodec
