package microservices.exam.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.deriveEncoder

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class OfflineExam(
    id: String,
    courseId: String,
    title: String,
    createdByTeacherId: String,
    createdAt: Instant,
    publishedAt: Option[Instant],
    questionIds: List[String],
    appealDueAt: Option[Instant]
)

object OfflineExam:
  private val encoder = deriveEncoder[OfflineExam]
  private val decoder = Decoder.instance { cursor =>
    for
      id <- cursor.get[String]("id")
      courseId <- cursor.get[String]("courseId")
      title <- cursor.get[String]("title")
      createdByTeacherId <- cursor.get[String]("createdByTeacherId")
      createdAt <- cursor.get[Instant]("createdAt")
      publishedAt <- cursor.get[Option[Instant]]("publishedAt")
      questionIds <- cursor.get[List[String]]("questionIds")
      appealDueAt <- cursor.get[Option[Instant]]("appealDueAt")
    yield OfflineExam(id, courseId, title, createdByTeacherId, createdAt, publishedAt, questionIds, appealDueAt)
  }
  given Encoder[OfflineExam] = encoder
  given Decoder[OfflineExam] = decoder
