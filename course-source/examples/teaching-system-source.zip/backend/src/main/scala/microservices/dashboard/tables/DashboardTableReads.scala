package microservices.dashboard.tables

import cats.effect.IO
import microservices.assignment.objects.{Assignment, AssignmentSubmission, SubmissionReview}
import microservices.assignment.tables.AssignmentTableReads
import microservices.auth.objects.{UserAccount, UserRole}
import microservices.auth.support.AuthUserViewSupport.toPublicUser
import microservices.auth.tables.AuthTableReads
import microservices.course.api.responses.CourseSummary
import microservices.course.objects.{Course, CourseAnnouncement, CourseChatMessage}
import microservices.course.support.CourseAccessSupport.{isContentVisibleToUser, isCurrentCourseMember, isCurrentStudent, isCurrentTeacher}
import microservices.course.tables.CourseTableReads
import microservices.dashboard.api.responses.{AssignmentReviewTask, DashboardCourseSummary, SystemNotificationSummary, UserDashboardResponse}
import microservices.dashboard.objects.SystemNotification
import microservices.exam.api.requests.ExamReviewOperation
import microservices.exam.api.responses.ExamTeacherTask
import microservices.exam.objects.{ExamAnswerSheet, ExamAppealStatus, ExamQuestionAppeal, ExamQuestionArbitration, ExamQuestionGrading, OfflineExam, OfflineExamQuestion}
import microservices.exam.tables.ExamTableReads
import microservices.questionnaire.objects.{Questionnaire, QuestionnaireSubmission}
import microservices.questionnaire.tables.QuestionnaireTableReads
import shared.jdbc.JdbcReadSupport.*
import shared.jdbc.JdbcDecodingSupport

import java.sql.Connection
import java.time.Instant

object DashboardTableReads:
  def loadDashboardFromTables(connection: Connection, userId: String): IO[Either[String, UserDashboardResponse]] =
    for
      userEither <- AuthTableReads.loadUserById(connection, userId)
      courseIdsEither <- CourseTableReads.loadCourseIdsForUser(connection, userId)
      coursesEither <- courseIdsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(courseIds) => CourseTableReads.loadCoursesByIds(connection, courseIds)
      usersEither <- coursesEither match
        case Left(error) => IO.pure(Left(error))
        case Right(courses) => AuthTableReads.loadUsersByIds(connection, courses.valuesIterator.flatMap(course => course.teachers ++ course.students).toSet + userId)
      announcementsEither <- courseIdsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(courseIds) => CourseTableReads.loadAnnouncementsByCourseIds(connection, courseIds)
      chatMessagesEither <- courseIdsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(courseIds) => CourseTableReads.loadChatMessagesByCourseIds(connection, courseIds)
      assignmentsEither <- courseIdsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(courseIds) => AssignmentTableReads.loadAssignmentsByCourseIds(connection, courseIds)
      submissionsEither <- assignmentsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(assignments) => AssignmentTableReads.loadSubmissionsByAssignmentIds(connection, assignments.keys)
      reviewsEither <- submissionsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(submissions) => AssignmentTableReads.loadReviewsBySubmissionIds(connection, submissions.keys)
      examsEither <- courseIdsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(courseIds) => ExamTableReads.loadExamsByCourseIds(connection, courseIds)
      questionsEither <- examsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(exams) => ExamTableReads.loadExamQuestionsByExamIds(connection, exams.keys)
      answerSheetsEither <- examsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(exams) => ExamTableReads.loadAnswerSheetsByExamIds(connection, exams.keys)
      questionGradingsEither <- answerSheetsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(answerSheets) => ExamTableReads.loadQuestionGradingsByAnswerSheetIds(connection, answerSheets.keys)
      arbitrationsEither <- answerSheetsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(answerSheets) => ExamTableReads.loadQuestionArbitrationsByAnswerSheetIds(connection, answerSheets.keys)
      appealsEither <- (answerSheetsEither, questionsEither) match
        case (Right(answerSheets), Right(questions)) => ExamTableReads.loadQuestionAppeals(connection, answerSheets.keys, questions.keys)
        case (Left(error), _) => IO.pure(Left(error))
        case (_, Left(error)) => IO.pure(Left(error))
      questionnairesEither <- courseIdsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(courseIds) => QuestionnaireTableReads.loadQuestionnairesByCourseIds(connection, courseIds)
      questionnaireSubmissionsEither <- questionnairesEither match
        case Left(error) => IO.pure(Left(error))
        case Right(questionnaires) => QuestionnaireTableReads.loadSubmissionsByQuestionnaireIds(connection, questionnaires.keys)
      notificationsEither <- loadSystemNotificationSummariesForUser(connection, userId)
    yield for
      user <- userEither
      courses <- coursesEither
      users <- usersEither
      announcements <- announcementsEither
      chatMessages <- chatMessagesEither
      assignments <- assignmentsEither
      submissions <- submissionsEither
      reviews <- reviewsEither
      exams <- examsEither
      questions <- questionsEither
      answerSheets <- answerSheetsEither
      questionGradings <- questionGradingsEither
      arbitrations <- arbitrationsEither
      appeals <- appealsEither
      questionnaires <- questionnairesEither
      questionnaireSubmissions <- questionnaireSubmissionsEither
      notifications <- notificationsEither
    yield
      val courseList = courses.values.toList.filter(course => isCurrentCourseMember(course, user.id)).sortBy(_.createdAt)(Ordering[Instant].reverse)
      val assignmentTasks = buildAssignmentReviewTasks(user, courseList, users, assignments.values.toList, submissions.values.toList, reviews.values.toList)
      val examTasks = buildExamTeacherTasks(user, exams.values.toList, questions.values.toList, answerSheets.values.toList, questionGradings.values.toList, arbitrations.values.toList, appeals.values.toList)
      val examTasksByExamId = examTasks.groupBy(_.examId)
      val summaries = courseList.map { course =>
        buildDashboardCourseSummary(
          user,
          course,
          users,
          announcements.values.toList,
          chatMessages.values.toList,
          assignments.values.toList,
          submissions.values.toList,
          reviews.values.toList,
          exams.values.toList,
          examTasksByExamId,
          questionnaires.values.toList,
          questionnaireSubmissions.values.toList
        )
      }
      UserDashboardResponse(
        currentUser = toPublicUser(user),
        courseSummaries = summaries,
        reviewTasks = assignmentTasks,
        examReviewTasks = examTasks,
        systemNotifications = notifications
      )

  def loadSystemNotificationIdsForUser(connection: Connection, userId: String): IO[Either[String, List[String]]] =
    IO.blocking {
      withPrepared(
        connection,
        """
          |select id
          |from teaching_system_notifications
          |where user_id = ?
          |order by created_at desc
          |""".stripMargin
      ) { statement =>
        statement.setString(1, userId)
        val resultSet = statement.executeQuery()
        try
          Right(collectRows(resultSet)(_.getString("id")))
        finally resultSet.close()
      }
    }

  def loadSystemNotificationsForUser(connection: Connection, userId: String): IO[Either[String, Map[String, SystemNotification]]] =
    IO.blocking {
      withPrepared(
        connection,
        """
          |select id, user_id, message, created_at
          |from teaching_system_notifications
          |where user_id = ?
          |""".stripMargin
      ) { statement =>
        statement.setString(1, userId)
        val resultSet = statement.executeQuery()
        try
          collectRows(resultSet) { row =>
            Right(SystemNotification(row.getString("id"), row.getString("user_id"), row.getString("message"), readInstant(row, "created_at")))
          }
        finally resultSet.close()
      }
    }.map(JdbcDecodingSupport.sequenceById)

  def loadSystemNotificationSummariesForUser(connection: Connection, userId: String): IO[Either[String, List[SystemNotificationSummary]]] =
    IO.blocking {
      withPrepared(
        connection,
        """
          |select id, message, created_at
          |from teaching_system_notifications
          |where user_id = ?
          |order by created_at desc
          |""".stripMargin
      ) { statement =>
        statement.setString(1, userId)
        val resultSet = statement.executeQuery()
        try
          Right(collectRows(resultSet)(row => SystemNotificationSummary(row.getString("id"), row.getString("message"), readInstant(row, "created_at"))))
        finally resultSet.close()
      }
    }

  private def buildDashboardCourseSummary(
      user: UserAccount,
      course: Course,
      users: Map[String, UserAccount],
      announcements: List[CourseAnnouncement],
      chatMessages: List[CourseChatMessage],
      assignments: List[Assignment],
      submissions: List[AssignmentSubmission],
      reviews: List[SubmissionReview],
      exams: List[OfflineExam],
      examTasksByExamId: Map[String, List[ExamTeacherTask]],
      questionnaires: List[Questionnaire],
      questionnaireSubmissions: List[QuestionnaireSubmission]
  ): DashboardCourseSummary =
    val summary = CourseSummary(
      id = course.id,
      title = course.title,
      description = course.description,
      teachers = course.teachers.flatMap(users.get).map(toPublicUser),
      students = course.students.flatMap(users.get).map(toPublicUser),
      createdAt = course.createdAt
    )
    val visibleAssignments = assignments.filter(item => item.courseId == course.id && isContentVisibleToUser(course, user.id, item.createdAt))
    val visibleAssignmentIds = visibleAssignments.map(_.id).toSet
    val visibleSubmissions = submissions.filter(submission => visibleAssignmentIds.contains(submission.assignmentId))
    val visibleSubmissionIds = visibleSubmissions.map(_.id).toSet
    val visibleReviews = reviews.filter(review => visibleSubmissionIds.contains(review.submissionId))
    val courseExams = exams.filter(exam => exam.courseId == course.id && isContentVisibleToUser(course, user.id, exam.createdAt))
    val visibleQuestionnaires = questionnaires.filter(questionnaire => questionnaire.courseId == course.id && isContentVisibleToUser(course, user.id, questionnaire.createdAt))
    val visibleQuestionnaireIds = visibleQuestionnaires.map(_.id).toSet
    val visibleQuestionnaireSubmissions = questionnaireSubmissions.filter(submission => visibleQuestionnaireIds.contains(submission.questionnaireId))
    DashboardCourseSummary(
      course = summary,
      unreadAnnouncementCount = announcements.count(item =>
        item.courseId == course.id &&
          item.publisherTeacherId != user.id &&
          isContentVisibleToUser(course, user.id, item.createdAt) &&
          !user.readAnnouncementIds.contains(item.id)
      ),
      pendingAssignmentCount =
        if user.role == UserRole.Student then
          visibleAssignments.count(assignment =>
            (assignment.dueAt.isAfter(Instant.now()) || assignment.allowLateSubmission) &&
              !visibleSubmissions.exists(submission => submission.assignmentId == assignment.id && submission.studentId == user.id)
          )
        else 0,
      unreadReviewedAssignmentCount =
        if user.role == UserRole.Student then
          visibleAssignments.count { assignment =>
            val submission = visibleSubmissions.find(item => item.assignmentId == assignment.id && item.studentId == user.id)
            submission.nonEmpty && visibleReviews.exists(_.submissionId == submission.get.id) && !user.readReviewedAssignmentIds.contains(assignment.id)
          }
        else 0,
      unreadPublishedExamCount =
        if user.role == UserRole.Student then
          courseExams.count(exam => exam.publishedAt.nonEmpty && !user.readPublishedExamIds.contains(exam.id))
        else 0,
      pendingReviewCount =
        if user.role == UserRole.Teacher then
          visibleAssignments.count { assignment =>
            assignment.graderTeacherId == user.id &&
              visibleSubmissions.exists(submission =>
                submission.assignmentId == assignment.id &&
                  visibleReviews.forall(_.submissionId != submission.id)
              ) &&
              isCurrentTeacher(course, user.id)
          }
        else 0,
      pendingExamReviewCount = courseExams.flatMap(exam => examTasksByExamId.getOrElse(exam.id, Nil)).map(_.pendingCount).sum,
      pendingExamTaskCount =
        if user.role == UserRole.Teacher then courseExams.flatMap(exam => examTasksByExamId.getOrElse(exam.id, Nil)).count(_.pendingCount > 0)
        else 0,
      pendingQuestionnaireCount =
        if user.role == UserRole.Student then
          visibleQuestionnaires.count(questionnaire =>
            questionnaire.dueAt.isAfter(Instant.now()) &&
              visibleQuestionnaireSubmissions.forall(submission => submission.questionnaireId != questionnaire.id || submission.studentId != user.id)
          )
        else if user.role == UserRole.Teacher then
          visibleQuestionnaires.count(questionnaire =>
            isCurrentTeacher(course, user.id) &&
              questionnaire.createdByTeacherId != user.id &&
              !user.readQuestionnaireIds.contains(questionnaire.id)
          )
        else 0,
      latestChatSentAt = chatMessages
        .filter(item => item.courseId == course.id && isContentVisibleToUser(course, user.id, item.sentAt))
        .map(_.sentAt)
        .sorted(Ordering[Instant].reverse)
        .headOption
    )

  private def buildAssignmentReviewTasks(
      user: UserAccount,
      courses: List[Course],
      users: Map[String, UserAccount],
      assignments: List[Assignment],
      submissions: List[AssignmentSubmission],
      reviews: List[SubmissionReview]
  ): List[AssignmentReviewTask] =
    if user.role != UserRole.Teacher then Nil
    else
      courses.flatMap { course =>
        val courseSummary = CourseSummary(course.id, course.title, course.description, course.teachers.flatMap(users.get).map(toPublicUser), course.students.flatMap(users.get).map(toPublicUser), course.createdAt)
        submissions.flatMap { submission =>
          assignments.find(_.id == submission.assignmentId).flatMap { assignment =>
            Option.when(
              assignment.courseId == course.id &&
                assignment.graderTeacherId == user.id &&
                reviews.forall(_.submissionId != submission.id) &&
                isCurrentTeacher(course, user.id) &&
                isCurrentStudent(course, submission.studentId)
            )(AssignmentReviewTask(submission, assignment, courseSummary))
          }
        }
      }.sortBy(_.submission.submittedAt)(Ordering[Instant].reverse)

  private def buildExamTeacherTasks(
      user: UserAccount,
      exams: List[OfflineExam],
      questions: List[OfflineExamQuestion],
      answerSheets: List[ExamAnswerSheet],
      gradings: List[ExamQuestionGrading],
      arbitrations: List[ExamQuestionArbitration],
      appeals: List[ExamQuestionAppeal]
  ): List[ExamTeacherTask] =
    if user.role != UserRole.Teacher then Nil
    else
      exams.flatMap { exam =>
        questions.filter(_.examId == exam.id).sortBy(_.position).flatMap { question =>
          val sheets = answerSheets.filter(sheet => sheet.examId == exam.id && sheet.questionId == question.id)
          val gradingTask = Option.when(question.scoring.graderTeacherIds.contains(user.id)) {
            ExamTeacherTask(exam.id, exam.title, question.id, question.title, question.position, ExamReviewOperation.Grading, sheets.count(sheet => gradings.forall(grading => grading.answerSheetId != sheet.id || grading.graderTeacherId != user.id)), sheets.count(sheet => gradings.exists(grading => grading.answerSheetId == sheet.id && grading.graderTeacherId == user.id)))
          }
          val arbitrationTask = Option.when(question.scoring.arbitrationTeacherId.contains(user.id)) {
            val arbitrationSheets = sheets.filter(sheet => needsArbitration(question, sheet, gradings))
            ExamTeacherTask(exam.id, exam.title, question.id, question.title, question.position, ExamReviewOperation.Arbitration, arbitrationSheets.count(sheet => arbitrations.forall(_.answerSheetId != sheet.id)), arbitrationSheets.count(sheet => arbitrations.exists(_.answerSheetId == sheet.id)))
          }
          val appealTask = Option.when(question.scoring.appealTeacherId.contains(user.id)) {
            val questionAppeals = appeals.filter(appeal => appeal.questionId == question.id && appeal.appealTeacherId == user.id)
            ExamTeacherTask(exam.id, exam.title, question.id, question.title, question.position, ExamReviewOperation.Appeal, questionAppeals.count(_.status == ExamAppealStatus.Pending), questionAppeals.count(_.status == ExamAppealStatus.Resolved))
          }
          List(gradingTask, arbitrationTask, appealTask).flatten.filter(_.pendingCount > 0)
        }
      }.sortBy(task => (task.examTitle, task.position, task.mode.value))

  private def needsArbitration(question: OfflineExamQuestion, sheet: ExamAnswerSheet, gradings: List[ExamQuestionGrading]): Boolean =
    if !question.scoring.arbitrationEnabled then false
    else
      val scores = question.scoring.graderTeacherIds.flatMap(teacherId => gradings.find(grading => grading.answerSheetId == sheet.id && grading.graderTeacherId == teacherId).map(_.score))
      scores.length == 2 && (scores(0) - scores(1)).abs > question.scoring.arbitrationScoreDiffThreshold.getOrElse(Int.MaxValue)
