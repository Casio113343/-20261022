package microservices.dashboard.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

import java.time.Instant

final case class SystemNotificationSummary(
    id: String,
    message: String,
    createdAt: Instant
)

object SystemNotificationSummary:
  given Codec[SystemNotificationSummary] = deriveCodec
