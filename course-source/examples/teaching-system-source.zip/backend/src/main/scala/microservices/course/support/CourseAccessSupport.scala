package microservices.course.support

import microservices.auth.objects.UserRole
import microservices.course.objects.{Course, CourseMemberAction}

import java.time.Instant

object CourseAccessSupport:

  private def memberEventsFor(course: Course, userId: String) =
    course.memberEvents.filter(_.userId == userId).sortBy(_.occurredAt)

  def firstJoinedAt(course: Course, userId: String): Option[Instant] =
    memberEventsFor(course, userId).find(_.action == CourseMemberAction.Joined).map(_.occurredAt).orElse {
      Option.when(course.teachers.contains(userId) || course.students.contains(userId))(course.createdAt)
    }

  def isMemberAt(course: Course, userId: String, at: Instant): Boolean =
    val events = memberEventsFor(course, userId).filterNot(_.occurredAt.isAfter(at))
    if events.isEmpty then (course.teachers.contains(userId) || course.students.contains(userId)) && !at.isBefore(course.createdAt)
    else
      events.foldLeft(false) { case (_, event) =>
        event.action match
          case CourseMemberAction.Joined => true
          case CourseMemberAction.Left => false
      }

  def isCurrentTeacher(course: Course, userId: String): Boolean =
    course.teachers.contains(userId)

  def isCurrentStudent(course: Course, userId: String): Boolean =
    course.students.contains(userId)

  def isCurrentCourseMember(course: Course, userId: String): Boolean =
    isCurrentTeacher(course, userId) || isCurrentStudent(course, userId)

  def isContentVisibleToUser(course: Course, userId: String, createdAt: Instant): Boolean =
    isMemberAt(course, userId, createdAt)

  def courseStudentsAt(course: Course, at: Instant): List[String] =
    course.memberEvents
      .filter(_.role == UserRole.Student)
      .map(_.userId)
      .distinct
      .filter(userId => isMemberAt(course, userId, at))
      .sortBy(userId => course.memberEvents.find(event => event.userId == userId && event.action == CourseMemberAction.Joined).map(_.occurredAt).getOrElse(course.createdAt))
