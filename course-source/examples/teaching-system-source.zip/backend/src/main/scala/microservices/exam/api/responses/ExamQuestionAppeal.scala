package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import microservices.exam.objects.ExamAppealStatus
import shared.model.SharedCodecs.given

import java.time.Instant

final case class ExamQuestionAppeal(
    id: String,
    questionId: String,
    answerSheetId: String,
    student: PublicUser,
    appealTeacher: PublicUser,
    expectedScore: Int,
    reason: String,
    status: ExamAppealStatus,
    submittedAt: Instant,
    resolvedAt: Option[Instant],
    resolvedScore: Option[Int]
)
object ExamQuestionAppeal:
  given Codec[ExamQuestionAppeal] = deriveCodec
