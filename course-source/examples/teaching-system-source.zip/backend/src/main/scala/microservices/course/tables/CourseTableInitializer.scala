package microservices.course.tables

object CourseTableInitializer:
  val initSql: List[String] = List(
    """
      |create table if not exists teaching_courses (
      |  id text primary key,
      |  title text not null,
      |  description text not null,
      |  member_events text not null,
      |  created_at timestamptz not null
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_course_teachers (
      |  course_id text not null,
      |  teacher_id text not null,
      |  position integer not null,
      |  primary key (course_id, teacher_id)
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_course_students (
      |  course_id text not null,
      |  student_id text not null,
      |  position integer not null,
      |  primary key (course_id, student_id)
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_announcements (
      |  id text primary key,
      |  course_id text not null,
      |  title text not null,
      |  content text not null,
      |  attachment text,
      |  publisher_teacher_id text not null,
      |  created_at timestamptz not null
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_course_chat_messages (
      |  id text primary key,
      |  course_id text not null,
      |  sender_user_id text not null,
      |  content text not null,
      |  images text not null,
      |  attachments text not null,
      |  sent_at timestamptz not null,
      |  revoked_at timestamptz,
      |  revoked_by_user_id text
      |);
      |""".stripMargin
  )

  val migrationSql: List[String] = List(
    "alter table teaching_courses add column if not exists member_events text not null default '[]'",
    "alter table teaching_announcements alter column attachment type text using attachment::text",
    "alter table teaching_course_chat_messages alter column images type text using images::text",
    "alter table teaching_course_chat_messages alter column attachments type text using attachments::text"
  )

  val tableNames: List[String] = List(
    "teaching_course_chat_messages",
    "teaching_announcements",
    "teaching_course_students",
    "teaching_course_teachers",
    "teaching_courses"
  )
