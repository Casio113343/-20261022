package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import microservices.course.api.responses.CourseSummary
import shared.model.SharedCodecs.given

final case class ExamDetailResponse(
    exam: ExamSummary,
    course: CourseSummary,
    questions: List[ExamQuestion],
    answerSheets: List[ExamAnswerSheet],
    participantStudents: List[PublicUser],
    teacherTasks: List[ExamTeacherTask],
    gradingProgress: List[ExamQuestionGradingProgress],
    scoreRows: List[ExamTeacherScoreRow],
    appeals: List[ExamQuestionAppeal],
    studentResult: Option[ExamStudentResult],
    canPublish: Boolean
)
object ExamDetailResponse:
  given Codec[ExamDetailResponse] = deriveCodec
