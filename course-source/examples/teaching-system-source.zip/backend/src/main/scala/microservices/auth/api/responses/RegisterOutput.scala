package microservices.auth.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser

final case class RegisterOutput(
    user: PublicUser
)

object RegisterOutput:
  given Codec[RegisterOutput] = deriveCodec
