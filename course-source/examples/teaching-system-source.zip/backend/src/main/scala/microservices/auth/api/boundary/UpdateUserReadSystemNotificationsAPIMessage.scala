package microservices.auth.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}

final case class UpdateUserReadSystemNotificationsAPIMessage(userId: String, notificationIds: List[String]) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          result <- userEither match
            case Left(error) => IO.pure(Left(error))
            case Right(user) =>
              val nextUser = user.copy(readSystemNotificationIds = (user.readSystemNotificationIds ++ notificationIds).distinct)
              IO.blocking(AuthTableWrites.upsertUser(connection, nextUser)).as(Right(()): Either[String, Unit])
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("系统通知已标记为已读")

object UpdateUserReadSystemNotificationsAPIMessage:
  given Codec.AsObject[UpdateUserReadSystemNotificationsAPIMessage] = deriveCodec
