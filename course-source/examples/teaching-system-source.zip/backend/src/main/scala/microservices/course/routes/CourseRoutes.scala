package microservices.course.routes

import infrastructure.api.RegisteredAPIMessage
import microservices.course.api.*

object CourseRoutes:
  val apiMessages: List[RegisteredAPIMessage] = List(
    RegisteredAPIMessage.api[CreateCourseAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[FetchCourseDetailAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[CreateAnnouncementAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[UpdateAnnouncementAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[DeleteAnnouncementAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[FetchAnnouncementCourseDetailAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[AddCourseMembersAPIMessage, microservices.course.api.responses.CourseDetailResponse],
    RegisteredAPIMessage.api[CreateCourseChatMessageAPIMessage, microservices.course.api.responses.CourseChatMessage],
    RegisteredAPIMessage.api[RevokeCourseChatMessageAPIMessage, microservices.course.api.responses.CourseChatMessage],
    RegisteredAPIMessage.api[FetchCourseChatTimelineAPIMessage, microservices.course.api.responses.CourseChatTimelinePage],
    RegisteredAPIMessage.api[MarkAnnouncementsReadAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse],
    RegisteredAPIMessage.api[LeaveCourseAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse],
    RegisteredAPIMessage.api[DeleteCourseAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse]
  )
