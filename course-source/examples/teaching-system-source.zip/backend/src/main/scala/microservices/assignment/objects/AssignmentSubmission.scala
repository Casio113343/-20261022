package microservices.assignment.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import infrastructure.storage.Attachment

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class AssignmentSubmission(
    id: String,
    assignmentId: String,
    studentId: String,
    content: String,
    attachment: Option[Attachment],
    submittedAt: Instant
)

object AssignmentSubmission:
  given Encoder[AssignmentSubmission] = deriveEncoder[AssignmentSubmission]
  given Decoder[AssignmentSubmission] = deriveDecoder[AssignmentSubmission]
