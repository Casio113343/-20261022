package microservices.assignment.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.tables.{AssignmentTableReads, AssignmentTableWrites}

final case class ClearDeletedAccountAssignmentsAPIMessage(accountId: String, courseIds: List[String], deletedCourseIds: List[String]) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          assignmentsEither <- AssignmentTableReads.loadAssignmentsByCourseIds(connection, courseIds)
          submissionsEither <- assignmentsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(assignments) => AssignmentTableReads.loadSubmissionsByAssignmentIds(connection, assignments.keys)
          reviewsEither <- submissionsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(submissions) => AssignmentTableReads.loadReviewsBySubmissionIds(connection, submissions.keys)
          result <- (assignmentsEither, submissionsEither, reviewsEither) match
            case (Right(assignments), Right(submissions), Right(reviews)) =>
              IO.blocking {
                val deletedCourseIdSet = deletedCourseIds.toSet
                val deletedAssignmentIds = assignments.valuesIterator
                  .filter(assignment => deletedCourseIdSet.contains(assignment.courseId) || assignment.createdByTeacherId == accountId || assignment.graderTeacherId == accountId)
                  .map(_.id)
                  .toSet
                val deletedSubmissionIds = submissions.valuesIterator
                  .filter(submission => deletedAssignmentIds.contains(submission.assignmentId) || submission.studentId == accountId)
                  .map(_.id)
                  .toSet
                val deletedReviewIds = reviews.valuesIterator
                  .filter(review => deletedSubmissionIds.contains(review.submissionId) || review.graderTeacherId == accountId)
                  .map(_.id)
                  .toSet

                deletedReviewIds.foreach(AssignmentTableWrites.deleteReview(connection, _))
                deletedSubmissionIds.foreach(AssignmentTableWrites.deleteSubmission(connection, _))
                deletedAssignmentIds.foreach(AssignmentTableWrites.deleteAssignment(connection, _))
                Right(())
              }
            case (Left(error), _, _) => IO.pure(Left(error))
            case (_, Left(error), _) => IO.pure(Left(error))
            case (_, _, Left(error)) => IO.pure(Left(error))
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理注销账号相关作业数据")

object ClearDeletedAccountAssignmentsAPIMessage:
  given Codec.AsObject[ClearDeletedAccountAssignmentsAPIMessage] = deriveCodec
