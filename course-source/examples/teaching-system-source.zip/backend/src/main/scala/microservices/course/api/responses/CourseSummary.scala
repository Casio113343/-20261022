package microservices.course.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import shared.model.SharedCodecs.given

import java.time.Instant

final case class CourseSummary(
    id: String,
    title: String,
    description: String,
    teachers: List[PublicUser],
    students: List[PublicUser],
    createdAt: Instant
)
object CourseSummary:
  given Codec[CourseSummary] = deriveCodec
