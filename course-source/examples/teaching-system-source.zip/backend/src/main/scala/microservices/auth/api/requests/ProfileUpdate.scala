package microservices.auth.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.{StudentProfile, TeacherProfile}

final case class ProfileUpdate(
    displayName: Option[String],
    currentPassword: Option[String],
    newPassword: Option[String],
    avatarDataUrl: Option[String],
    clearAvatar: Boolean,
    teacherProfile: Option[TeacherProfile],
    studentProfile: Option[StudentProfile]
)

object ProfileUpdate:
  given Codec[ProfileUpdate] = deriveCodec
