package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.tables.{AssignmentTableReads, AssignmentTableWrites}
import microservices.auth.objects.UserRole
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.tables.{CourseTableReads, CourseTableWrites}
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.dashboard.objects.SystemNotification
import microservices.dashboard.tables.{DashboardTableReads, DashboardTableWrites}
import microservices.exam.tables.{ExamTableReads, ExamTableWrites}
import microservices.questionnaire.tables.{QuestionnaireTableReads, QuestionnaireTableWrites}
import shared.id.IdGenerator

import java.time.Instant

final case class DeleteCourseAPIMessage(courseId: String, userId: String) extends APIMessage[UserDashboardResponse]:
  def plan: IO[UserDashboardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        for
          operatorEither <- AuthTableReads.loadUserById(connection, userId)
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          announcementsEither <- CourseTableReads.loadAnnouncementsByCourseId(connection, courseId)
          chatMessagesEither <- CourseTableReads.loadChatMessagesByCourseId(connection, courseId)
          assignmentsEither <- AssignmentTableReads.loadAssignmentsByCourseIds(connection, List(courseId))
          submissionsEither <- assignmentsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(assignments) => AssignmentTableReads.loadSubmissionsByAssignmentIds(connection, assignments.keys)
          reviewsEither <- submissionsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(submissions) => AssignmentTableReads.loadReviewsBySubmissionIds(connection, submissions.keys)
          examsEither <- ExamTableReads.loadExamsByCourseIds(connection, List(courseId))
          questionsEither <- examsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(exams) => ExamTableReads.loadExamQuestionsByExamIds(connection, exams.keys)
          answerSheetsEither <- examsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(exams) => ExamTableReads.loadAnswerSheetsByExamIds(connection, exams.keys)
          questionnairesEither <- QuestionnaireTableReads.loadQuestionnairesByCourseIds(connection, List(courseId))
          validationEither = for
            operator <- operatorEither
            course <- courseEither
            announcements <- announcementsEither
            chatMessages <- chatMessagesEither
            assignments <- assignmentsEither
            submissions <- submissionsEither
            reviews <- reviewsEither
            exams <- examsEither
            questions <- questionsEither
            answerSheets <- answerSheetsEither
            questionnaires <- questionnairesEither
            _ <- Either.cond(operator.role == UserRole.Teacher && isCurrentTeacher(course, operator.id), (), "只有本课程老师可以执行该操作")
          yield
            val memberIds = (course.teachers ++ course.students).distinct
            val assignmentIds = assignments.keySet
            val submissionIds = submissions.keySet
            val examIds = exams.keySet
            val questionIds = questions.keySet
            val answerSheetIds = answerSheets.keySet
            val questionnaireIds = questionnaires.keySet
            val notifications =
              SystemNotification(IdGenerator.nextId("system-notification"), operator.id, s"你删除了课程　${course.title}", now) ::
                memberIds.filterNot(_ == operator.id).flatMap { memberId =>
                  Some(SystemNotification(IdGenerator.nextId("system-notification"), memberId, s"${operator.displayName} 删除了你所在的课程　${course.title}", now))
                }
            (
              memberIds,
              announcements.keys.toList,
              chatMessages.keys.toList,
              assignmentIds.toList,
              submissionIds.toList,
              reviews.keys.toList,
              examIds.toList,
              questionIds.toList,
              answerSheetIds.toList,
              questionnaireIds.toList,
              notifications
            )
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((memberIds, announcementIds, chatMessageIds, assignmentIds, submissionIds, reviewIds, examIds, questionIds, answerSheetIds, questionnaireIds, notifications)) =>
              for
                usersEither <- AuthTableReads.loadUsersByIds(connection, memberIds :+ userId)
                userReadMarkersCleared <- usersEither match
                  case Left(error) => IO.pure(Left(error))
                  case Right(users) =>
                    val announcementIdSet = announcementIds.toSet
                    val assignmentIdSet = assignmentIds.toSet
                    val examIdSet = examIds.toSet
                    val questionnaireIdSet = questionnaireIds.toSet
                    val updatedUsers = users.values.toList
                      .map(user =>
                        user.copy(
                          readAnnouncementIds = user.readAnnouncementIds.filterNot(announcementIdSet.contains),
                          readReviewedAssignmentIds = user.readReviewedAssignmentIds.filterNot(assignmentIdSet.contains),
                          readPublishedExamIds = user.readPublishedExamIds.filterNot(examIdSet.contains),
                          readQuestionnaireIds = user.readQuestionnaireIds.filterNot(questionnaireIdSet.contains),
                        )
                      )
                      .filter(user =>
                        val previous = users(user.id)
                        previous.readAnnouncementIds != user.readAnnouncementIds ||
                          previous.readReviewedAssignmentIds != user.readReviewedAssignmentIds ||
                          previous.readPublishedExamIds != user.readPublishedExamIds ||
                          previous.readQuestionnaireIds != user.readQuestionnaireIds
                      )
                    IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
                notificationsPublished <- IO.blocking(notifications.foreach(DashboardTableWrites.upsertSystemNotification(connection, _))).as(Right(()): Either[String, Unit])
                assignmentDataCleared <- IO.blocking {
                  reviewIds.foreach(AssignmentTableWrites.deleteReview(connection, _))
                  submissionIds.foreach(AssignmentTableWrites.deleteSubmission(connection, _))
                  assignmentIds.foreach(AssignmentTableWrites.deleteAssignment(connection, _))
                }.as(Right(()): Either[String, Unit])
                examDataCleared <- IO.blocking {
                  ExamTableWrites.deleteQuestionGradingsByAnswerSheetIds(connection, answerSheetIds.toSet)
                  ExamTableWrites.deleteQuestionArbitrationsByAnswerSheetIds(connection, answerSheetIds.toSet)
                  ExamTableWrites.deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection, answerSheetIds.toSet, questionIds.toSet)
                  examIds.foreach { examId =>
                    ExamTableWrites.deleteAnswerSheetsByExamId(connection, examId)
                    ExamTableWrites.deleteExamQuestionsByExamId(connection, examId)
                    ExamTableWrites.deleteExam(connection, examId)
                  }
                }.as(Right(()): Either[String, Unit])
                questionnaireDataCleared <- IO.blocking(questionnaireIds.foreach(QuestionnaireTableWrites.deleteQuestionnaire(connection, _))).as(Right(()): Either[String, Unit])
                _ <- IO.blocking {
                  announcementIds.foreach(CourseTableWrites.deleteAnnouncement(connection, _))
                  chatMessageIds.foreach(CourseTableWrites.deleteChatMessage(connection, _))
                  CourseTableWrites.deleteCourse(connection, courseId)
                }
                dashboardEither <- DashboardTableReads.loadDashboardFromTables(connection, userId)
              yield for
                _ <- userReadMarkersCleared
                _ <- notificationsPublished
                _ <- assignmentDataCleared
                _ <- examDataCleared
                _ <- questionnaireDataCleared
                dashboard <- dashboardEither
              yield dashboard
        yield result
      }
      response <- resolveEither(result)
    yield response

object DeleteCourseAPIMessage:
  given Codec.AsObject[DeleteCourseAPIMessage] = deriveCodec
