package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.AuthTableReads
import microservices.auth.objects.UserRole
import microservices.course.api.requests.CreateCourseInput
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.objects.{Course, CourseMemberAction, CourseMemberEvent}
import microservices.course.tables.{CourseTableReads, CourseTableWrites}
import microservices.dashboard.objects.SystemNotification
import microservices.dashboard.tables.DashboardTableWrites
import shared.id.IdGenerator

import java.time.Instant

final case class CreateCourseAPIMessage(userId: String, input: CreateCourseInput) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        val normalizedTitle = input.title.trim
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          titleExistsEither <- CourseTableReads.courseTitleExists(connection, normalizedTitle)
          validationEither = for
            user <- userEither
            titleExists <- titleExistsEither
            _ <- Either.cond(user.role == UserRole.Teacher, (), "只有老师可以创建课程")
            _ <- Either.cond(normalizedTitle.nonEmpty, (), "课程名称不能为空")
            _ <- Either.cond(!titleExists, (), "课程名称不能重复")
          yield
            val course = Course(
              id = IdGenerator.nextId("course"),
              title = normalizedTitle,
              description = input.description.trim,
              teachers = List(user.id),
              students = List.empty,
              createdAt = now,
              memberEvents = List(CourseMemberEvent(user.id, UserRole.Teacher, CourseMemberAction.Joined, now)),
            )
            val notification = SystemNotification(IdGenerator.nextId("system-notification"), user.id, s"你创建了课程　${course.title}", now)
            (course, notification)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((course, notification)) =>
              for
                _ <- IO.blocking {
                  CourseTableWrites.replaceCourse(connection, course)
                }
                notificationsPublished <- IO.blocking(DashboardTableWrites.upsertSystemNotification(connection, notification)).as(Right(()): Either[String, Unit])
                detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, course.id, userId)
              yield for
                _ <- notificationsPublished
                detail <- detailEither
              yield detail
        yield result
      }
      response <- resolveEither(result)
    yield response

object CreateCourseAPIMessage:
  given Codec.AsObject[CreateCourseAPIMessage] = deriveCodec
