package microservices.auth.support

import microservices.auth.objects.{PublicUser, UserAccount}

object AuthUserViewSupport:

  def toPublicUser(account: UserAccount): PublicUser =
    PublicUser(
      id = account.id,
      username = account.username,
      displayName = account.displayName,
      role = account.role,
      avatarDataUrl = account.avatarDataUrl,
      readAnnouncementIds = account.readAnnouncementIds,
      readSystemNotificationIds = account.readSystemNotificationIds,
      readReviewedAssignmentIds = account.readReviewedAssignmentIds,
      readPublishedExamIds = account.readPublishedExamIds,
      readQuestionnaireIds = account.readQuestionnaireIds,
      teacherProfile = account.teacherProfile,
      studentProfile = account.studentProfile
    )
