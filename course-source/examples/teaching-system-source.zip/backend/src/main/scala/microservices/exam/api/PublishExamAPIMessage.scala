package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.exam.api.responses.ExamDetailResponse
import microservices.exam.tables.{ExamTableWrites, ExamWorkspaceReads}

import java.time.Instant

final case class PublishExamAPIMessage(examId: String, userId: String) extends APIMessage[ExamDetailResponse]:
  def plan: IO[ExamDetailResponse] =
    for
      now <- IO.delay(Instant.now())
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          workspaceEither <- ExamWorkspaceReads.loadWorkspace(connection, examId)
          validationEither = workspaceEither.flatMap { workspace =>
            for
              currentUser <- ExamWorkspaceReads.validateAccessibleExam(workspace, userId)
              _ <- Either.cond(currentUser.role == UserRole.Teacher, (), "只有老师可以发布考试")
              _ <- Either.cond(workspace.exam.publishedAt.isEmpty, (), "考试已经发布")
              _ <- Either.cond(ExamWorkspaceReads.canPublishExam(workspace), (), "仍有题目未导入或未完成批改，不能发布")
            yield
              val nextExam = workspace.exam.copy(publishedAt = Some(now))
              (currentUser, workspace.copy(exam = nextExam), nextExam)
          }
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((currentUser, nextWorkspace, nextExam)) =>
              for
                _ <- IO.blocking(ExamTableWrites.upsertExam(connection, nextExam))
                detailEither = ExamWorkspaceReads.buildExamDetailForUser(nextWorkspace, currentUser)
              yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

object PublishExamAPIMessage:
  given Codec.AsObject[PublishExamAPIMessage] = deriveCodec
