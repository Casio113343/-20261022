package microservices.questionnaire.api

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.tables.CourseTableReads
import microservices.questionnaire.tables.{QuestionnaireTableReads, QuestionnaireTableWrites}

final case class DeleteQuestionnaireAPIMessage(questionnaireId: String, userId: String) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          questionnaireEither <- QuestionnaireTableReads.loadQuestionnaireById(connection, questionnaireId)
          courseEither <- questionnaireEither match
            case Left(error) => IO.pure(Left(error))
            case Right(questionnaire) => CourseTableReads.loadCourseById(connection, questionnaire.courseId)
          validationEither = for
            user <- userEither
            questionnaire <- questionnaireEither
            course <- courseEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以删除问卷")
          yield course.teachers
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(teacherIds) =>
              for
                usersEither <- AuthTableReads.loadUsersByIds(connection, teacherIds)
                userReadMarkersCleared <- usersEither match
                  case Left(error) => IO.pure(Left(error))
                  case Right(users) =>
                    val updatedUsers = users.values.toList
                      .map(user => user.copy(readQuestionnaireIds = user.readQuestionnaireIds.filterNot(_ == questionnaireId)))
                      .filter(user => users(user.id).readQuestionnaireIds != user.readQuestionnaireIds)
                    IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
                questionnaireDeleted <- IO.blocking(QuestionnaireTableWrites.deleteQuestionnaire(connection, questionnaireId)).as(Right(ActionResponse("问卷已删除")): Either[String, ActionResponse])
              yield for
                _ <- userReadMarkersCleared
                response <- questionnaireDeleted
              yield response
        yield result
      }
      response <- resolveEither(result)
    yield response

object DeleteQuestionnaireAPIMessage:
  given Codec.AsObject[DeleteQuestionnaireAPIMessage] = deriveCodec
