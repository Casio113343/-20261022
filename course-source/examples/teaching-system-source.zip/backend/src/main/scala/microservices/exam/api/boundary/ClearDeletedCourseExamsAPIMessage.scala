package microservices.exam.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.exam.tables.ExamTableWrites

final case class ClearDeletedCourseExamsAPIMessage(answerSheetIds: List[String], questionIds: List[String], examIds: List[String]) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val answerSheetIdSet = answerSheetIds.toSet
        val questionIdSet = questionIds.toSet
        IO.blocking {
          ExamTableWrites.deleteQuestionGradingsByAnswerSheetIds(connection, answerSheetIdSet)
          ExamTableWrites.deleteQuestionArbitrationsByAnswerSheetIds(connection, answerSheetIdSet)
          ExamTableWrites.deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection, answerSheetIdSet, questionIdSet)
          examIds.foreach { examId =>
            ExamTableWrites.deleteAnswerSheetsByExamId(connection, examId)
            ExamTableWrites.deleteExamQuestionsByExamId(connection, examId)
            ExamTableWrites.deleteExam(connection, examId)
          }
        }.as(Right(()): Either[String, Unit])
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理删除课程的考试数据")

object ClearDeletedCourseExamsAPIMessage:
  given Codec.AsObject[ClearDeletedCourseExamsAPIMessage] = deriveCodec
