package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.tables.CourseTableReads

final case class FetchAnnouncementCourseDetailAPIMessage(announcementId: String, userId: String) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection(connection =>
        CourseTableReads.loadAnnouncementCourseDetailFromTables(connection, announcementId, userId)
      )
      response <- resolveEither(result)
    yield response

object FetchAnnouncementCourseDetailAPIMessage:
  given Codec.AsObject[FetchAnnouncementCourseDetailAPIMessage] = deriveCodec
