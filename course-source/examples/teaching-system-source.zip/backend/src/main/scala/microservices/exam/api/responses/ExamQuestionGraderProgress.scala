package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser

final case class ExamQuestionGraderProgress(
    grader: PublicUser,
    gradedCount: Int,
    pendingGradingCount: Int,
    missingImportCount: Int
)

object ExamQuestionGraderProgress:
  given Codec[ExamQuestionGraderProgress] = deriveCodec
