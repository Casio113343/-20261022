package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.exam.api.responses.ExamDetailResponse
import microservices.exam.tables.ExamWorkspaceReads

final case class ExamDetailAPIMessage(examId: String, userId: String) extends APIMessage[ExamDetailResponse]:
  def plan: IO[ExamDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        ExamWorkspaceReads.loadWorkspace(connection, examId).map {
          _.flatMap { workspace =>
            for
              currentUser <- ExamWorkspaceReads.validateAccessibleExam(workspace, userId)
              detail <- ExamWorkspaceReads.buildExamDetailForUser(workspace, currentUser)
            yield detail
          }
        }
      }
      response <- resolveEither(result)
    yield response

object ExamDetailAPIMessage:
  given Codec.AsObject[ExamDetailAPIMessage] = deriveCodec
