package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import infrastructure.events.DomainEvent
import infrastructure.outbox.OutboxSupport
import infrastructure.outbox.OutboxTableWrites
import infrastructure.realtime.CourseRealtimeEvent
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.AuthTableReads
import microservices.course.api.responses.CourseChatMessage
import microservices.course.support.CourseAccessSupport.isCurrentCourseMember
import microservices.course.tables.{CourseTableReads, CourseTableWrites}

import java.time.Instant

final case class RevokeCourseChatMessageAPIMessage(courseId: String, messageId: String, userId: String) extends APIMessage[CourseChatMessage]:
  def plan: IO[CourseChatMessage] =
    for
      occurredAt <- IO.delay(Instant.now())
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          messageEither <- CourseTableReads.loadChatMessageById(connection, messageId)
          validationEither = for
            course <- courseEither
            user <- userEither
            message <- messageEither
            _ <- Either.cond(isCurrentCourseMember(course, user.id), (), "当前用户不可访问该课程")
            _ <- Either.cond(message.courseId == course.id, (), "消息不属于当前课程")
            _ <- Either.cond(message.revokedAt.isEmpty, (), "消息已撤回")
            _ <- Either.cond(message.senderUserId == user.id, (), "只能撤回自己发送的消息")
            nextMessage = message.copy(revokedAt = Some(occurredAt), revokedByUserId = Some(user.id))
            view <- CourseTableReads.buildChatMessageView(nextMessage, Map(user.id -> user), user.id)
          yield
            val outboxMessages = List(
              OutboxSupport.courseRealtimePublish(CourseRealtimeEvent("chat.message.revoked", courseId, Some(view)), occurredAt),
              OutboxSupport.domainEventPublish(
                DomainEvent(
                  eventType = "chat.message.revoked",
                  aggregateType = "course-chat",
                  aggregateId = view.id,
                  userId = userId,
                  courseId = Some(courseId),
                  occurredAt = occurredAt,
                  payload = io.circe.Json.obj(
                    "courseId" -> io.circe.Json.fromString(courseId),
                    "messageId" -> io.circe.Json.fromString(view.id)
                  )
                )
              )
            )
            (nextMessage, view, outboxMessages)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((nextMessage, view, outboxMessages)) =>
              for
                _ <- IO.blocking {
                  CourseTableWrites.upsertChatMessage(connection, nextMessage)
                  OutboxTableWrites.insertAll(connection, outboxMessages)
                }
              yield Right(view)
        yield result
      }
      response <- resolveEither(result)
    yield response

object RevokeCourseChatMessageAPIMessage:
  given Codec.AsObject[RevokeCourseChatMessageAPIMessage] = deriveCodec
