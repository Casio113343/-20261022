package microservices.course.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.course.tables.{CourseTableReads, CourseTableWrites}

final case class ClearDeletedAccountCourseDataAPIMessage(accountId: String) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseIdsEither <- CourseTableReads.loadCourseIdsForUser(connection, accountId)
          coursesEither <- courseIdsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseIds) => CourseTableReads.loadCoursesByIds(connection, courseIds)
          announcementsEither <- courseIdsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseIds) => CourseTableReads.loadAnnouncementsByCourseIds(connection, courseIds)
          chatMessagesEither <- courseIdsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseIds) => CourseTableReads.loadChatMessagesByCourseIds(connection, courseIds)
          result <- (coursesEither, announcementsEither, chatMessagesEither) match
            case (Right(courses), Right(announcements), Right(chatMessages)) =>
              IO.blocking {
                val nextCourses = courses.values.toList.map(course =>
                  course.copy(
                    teachers = course.teachers.filterNot(_ == accountId),
                    students = course.students.filterNot(_ == accountId)
                  )
                )
                val deletedCourseIds = nextCourses.filter(_.teachers.isEmpty).map(_.id).toSet
                val keptCourses = nextCourses.filterNot(course => deletedCourseIds.contains(course.id))
                val deletedAnnouncementIds = announcements.valuesIterator
                  .filter(announcement => deletedCourseIds.contains(announcement.courseId) || announcement.publisherTeacherId == accountId)
                  .map(_.id)
                  .toSet
                val deletedChatMessageIds = chatMessages.valuesIterator
                  .filter(message => deletedCourseIds.contains(message.courseId) || message.senderUserId == accountId || message.revokedByUserId.contains(accountId))
                  .map(_.id)
                  .toSet

                keptCourses.foreach(CourseTableWrites.replaceCourse(connection, _))
                deletedAnnouncementIds.foreach(CourseTableWrites.deleteAnnouncement(connection, _))
                deletedChatMessageIds.foreach(CourseTableWrites.deleteChatMessage(connection, _))
                deletedCourseIds.foreach { courseId =>
                  CourseTableWrites.deleteCourse(connection, courseId)
                }
                Right(())
              }
            case (Left(error), _, _) => IO.pure(Left(error))
            case (_, Left(error), _) => IO.pure(Left(error))
            case (_, _, Left(error)) => IO.pure(Left(error))
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理注销账号相关课程数据")

object ClearDeletedAccountCourseDataAPIMessage:
  given Codec.AsObject[ClearDeletedAccountCourseDataAPIMessage] = deriveCodec
