package microservices.auth.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.deriveEncoder

final case class UserAccount(
    id: String,
    username: String,
    password: String,
    displayName: String,
    role: UserRole,
    avatarDataUrl: Option[String],
    readAnnouncementIds: List[String],
    readSystemNotificationIds: List[String],
    readReviewedAssignmentIds: List[String],
    readPublishedExamIds: List[String],
    readQuestionnaireIds: List[String],
    teacherProfile: Option[TeacherProfile],
    studentProfile: Option[StudentProfile]
)

object UserAccount:
  given Encoder.AsObject[UserAccount] = deriveEncoder
  given Decoder[UserAccount] = Decoder.instance { cursor =>
    for
      id <- cursor.get[String]("id")
      username <- cursor.get[String]("username")
      password <- cursor.get[String]("password")
      displayName <- cursor.get[String]("displayName")
      role <- cursor.get[UserRole]("role")
      avatarDataUrl <- cursor.get[Option[String]]("avatarDataUrl")
      readAnnouncementIds <- cursor.getOrElse[List[String]]("readAnnouncementIds")(Nil)
      readSystemNotificationIds <- cursor.getOrElse[List[String]]("readSystemNotificationIds")(Nil)
      readReviewedAssignmentIds <- cursor.getOrElse[List[String]]("readReviewedAssignmentIds")(Nil)
      readPublishedExamIds <- cursor.getOrElse[List[String]]("readPublishedExamIds")(Nil)
      readQuestionnaireIds <- cursor.getOrElse[List[String]]("readQuestionnaireIds")(Nil)
      teacherProfile <- cursor.get[Option[TeacherProfile]]("teacherProfile")
      studentProfile <- cursor.get[Option[StudentProfile]]("studentProfile")
    yield UserAccount(
      id,
      username,
      password,
      displayName,
      role,
      avatarDataUrl,
      readAnnouncementIds,
      readSystemNotificationIds,
      readReviewedAssignmentIds,
      readPublishedExamIds,
      readQuestionnaireIds,
      teacherProfile,
      studentProfile,
    )
  }
