package microservices.exam.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec

final case class SubmitExamAppealInput(
    expectedScore: Int,
    reason: String
)
object SubmitExamAppealInput:
  given Codec[SubmitExamAppealInput] = deriveCodec
