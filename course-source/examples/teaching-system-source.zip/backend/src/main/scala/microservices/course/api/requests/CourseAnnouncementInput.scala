package microservices.course.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.storage.Attachment
import shared.model.SharedCodecs.given

final case class CourseAnnouncementInput(
    title: String,
    content: String,
    attachment: Option[Attachment]
)
object CourseAnnouncementInput:
  given Codec[CourseAnnouncementInput] = deriveCodec
