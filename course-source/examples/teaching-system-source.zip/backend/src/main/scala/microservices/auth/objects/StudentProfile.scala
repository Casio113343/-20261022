package microservices.auth.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.deriveEncoder
import microservices.auth.support.AuthProfileCodecSupport.decodeFlexibleProfile

final case class StudentProfile(
    grade: Option[String],
    major: Option[String]
)

object StudentProfile:
  given Encoder.AsObject[StudentProfile] = deriveEncoder
  given Decoder[StudentProfile] = Decoder.instance { cursor =>
    decodeFlexibleProfile(cursor, "grade", "major")(StudentProfile.apply)
  }
