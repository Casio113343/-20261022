package microservices.dashboard.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.course.api.responses.CourseSummary
import shared.model.SharedCodecs.given

import java.time.Instant

final case class DashboardCourseSummary(
    course: CourseSummary,
    unreadAnnouncementCount: Int,
    pendingAssignmentCount: Int,
    unreadReviewedAssignmentCount: Int,
    unreadPublishedExamCount: Int,
    pendingReviewCount: Int,
    pendingExamReviewCount: Int,
    pendingExamTaskCount: Int,
    pendingQuestionnaireCount: Int,
    latestChatSentAt: Option[Instant]
)

object DashboardCourseSummary:
  given Codec[DashboardCourseSummary] = deriveCodec
