package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.storage.Attachment

final case class ExamReviewItem(
    answerSheetId: String,
    label: String,
    status: ExamReviewItemStatus,
    score: Option[Int],
    images: List[Attachment],
    appeal: Option[ExamQuestionAppeal],
    graderScores: List[Int]
)
object ExamReviewItem:
  given Codec[ExamReviewItem] = deriveCodec
