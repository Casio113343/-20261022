package microservices.questionnaire.tables

object QuestionnaireTableInitializer:
  val initSql: List[String] = List(
    """
      |create table if not exists teaching_questionnaires (
      |  id text primary key,
      |  course_id text not null,
      |  title text not null,
      |  overview text,
      |  anonymous boolean not null,
      |  questions jsonb not null,
      |  due_at timestamptz not null,
      |  created_by_teacher_id text not null,
      |  created_at timestamptz not null
      |)
      |""".stripMargin,
    """
      |create table if not exists teaching_questionnaire_submissions (
      |  id text primary key,
      |  questionnaire_id text not null,
      |  student_id text not null,
      |  answers jsonb not null,
      |  submitted_at timestamptz not null,
      |  unique(questionnaire_id, student_id)
      |)
      |""".stripMargin
  )

  val migrationSql: List[String] = Nil
