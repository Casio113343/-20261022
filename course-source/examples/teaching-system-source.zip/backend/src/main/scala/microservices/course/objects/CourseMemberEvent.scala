package microservices.course.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import microservices.auth.objects.UserRole

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class CourseMemberEvent(
    userId: String,
    role: UserRole,
    action: CourseMemberAction,
    occurredAt: Instant
)

object CourseMemberEvent:
  given Encoder[CourseMemberEvent] = deriveEncoder[CourseMemberEvent]
  given Decoder[CourseMemberEvent] = deriveDecoder[CourseMemberEvent]
