package microservices.course.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.storage.Attachment
import shared.model.SharedCodecs.given

final case class CourseChatMessageInput(
    content: String,
    images: List[Attachment],
    attachments: List[Attachment]
)
object CourseChatMessageInput:
  given Codec[CourseChatMessageInput] = deriveCodec
