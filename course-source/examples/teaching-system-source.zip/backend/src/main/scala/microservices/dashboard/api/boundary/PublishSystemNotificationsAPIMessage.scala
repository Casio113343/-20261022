package microservices.dashboard.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.dashboard.objects.SystemNotification
import microservices.dashboard.tables.DashboardTableWrites

final case class PublishSystemNotificationsAPIMessage(notifications: List[SystemNotification]) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        IO.blocking(notifications.foreach(DashboardTableWrites.upsertSystemNotification(connection, _))).as(Right(()): Either[String, Unit])
      }
      _ <- resolveEither(result)
    yield ActionResponse("系统通知已发布")

object PublishSystemNotificationsAPIMessage:
  given Codec.AsObject[PublishSystemNotificationsAPIMessage] = deriveCodec
