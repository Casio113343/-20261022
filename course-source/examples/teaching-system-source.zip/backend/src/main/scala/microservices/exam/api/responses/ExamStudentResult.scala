package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

final case class ExamStudentResult(
    published: Boolean,
    totalFullScore: Int,
    totalScore: Option[BigDecimal],
    questions: List[ExamQuestionResult]
)
object ExamStudentResult:
  given Codec[ExamStudentResult] = deriveCodec
