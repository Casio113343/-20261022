package microservices.course.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import infrastructure.storage.Attachment
import shared.model.SharedCodecs.given

import java.time.Instant

final case class CourseChatMessage(
    id: String,
    courseId: String,
    sender: PublicUser,
    content: String,
    images: List[Attachment],
    attachments: List[Attachment],
    sentAt: Instant,
    revokedAt: Option[Instant],
    revokedByUserId: Option[String],
    canRevoke: Boolean
)
object CourseChatMessage:
  given Codec[CourseChatMessage] = deriveCodec
