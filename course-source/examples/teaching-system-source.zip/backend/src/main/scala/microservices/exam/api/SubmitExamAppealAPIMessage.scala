package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.course.support.CourseAccessSupport.{isContentVisibleToUser, isCurrentStudent}
import microservices.exam.api.requests.SubmitExamAppealInput
import microservices.exam.api.responses.ExamDetailResponse
import microservices.exam.objects.{ExamAppealStatus, ExamQuestionAppeal}
import microservices.exam.tables.{ExamTableWrites, ExamWorkspaceReads}
import shared.id.IdGenerator

import java.time.Instant

final case class SubmitExamAppealAPIMessage(examId: String, questionId: String, userId: String, input: SubmitExamAppealInput) extends APIMessage[ExamDetailResponse]:
  def plan: IO[ExamDetailResponse] =
    for
      now <- IO.delay(Instant.now())
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          workspaceEither <- ExamWorkspaceReads.loadWorkspace(connection, examId)
          validationEither = workspaceEither.flatMap { workspace =>
            for
              student <- workspace.users.get(userId).filter(_.role == UserRole.Student).toRight("只有本课程学生可以对该题申诉")
              question <- workspace.questions.get(questionId).toRight("考试题目不存在")
              _ <- Either.cond(question.examId == workspace.exam.id, (), "考试题目不存在")
              _ <- Either.cond(isCurrentStudent(workspace.course, student.id) && isContentVisibleToUser(workspace.course, student.id, workspace.exam.createdAt), (), "只有本课程学生可以对该题申诉")
              answerSheet <- ExamWorkspaceReads.sheetForQuestionStudent(workspace, question.id, student.id).toRight("只有本课程学生可以对该题申诉")
              _ <- Either.cond(workspace.exam.publishedAt.nonEmpty, (), "成绩发布后才能申诉")
              _ <- Either.cond(!workspace.exam.appealDueAt.exists(now.isAfter), (), "申诉截止时间已过，不能再提交申诉")
              _ <- Either.cond(question.scoring.appealEnabled, (), "该题不允许申诉")
              _ <- Either.cond(input.expectedScore >= 0 && input.expectedScore <= question.scoring.fullScore, (), s"申诉得分必须在 0 到 ${question.scoring.fullScore} 之间")
              _ <- Either.cond(input.reason.trim.nonEmpty, (), "申诉理由不能为空")
              outcome <- ExamWorkspaceReads.resolvedQuestionOutcome(workspace, question, answerSheet).toRight("当前题目还没有最终成绩")
              finalScore <- outcome.finalScore.toRight("当前题目还没有最终成绩")
              _ <- Either.cond(finalScore != BigDecimal(question.scoring.fullScore), (), "满分题目不能申诉")
              _ <- Either.cond(!ExamWorkspaceReads.pendingAppealExists(workspace, answerSheet.id), (), "该题已有申诉正在处理中")
              appealTeacherId <- question.scoring.appealTeacherId.toRight("该题未配置申诉处理教师")
            yield
              val appeal = ExamQuestionAppeal(IdGenerator.nextId("exam-appeal"), answerSheet.id, question.id, student.id, appealTeacherId, input.expectedScore, input.reason.trim, ExamAppealStatus.Pending, now, None, None)
              val nextWorkspace = workspace.copy(appeals = workspace.appeals.updated(appeal.id, appeal))
              (appeal, nextWorkspace, student)
          }
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((appeal, nextWorkspace, student)) =>
              IO.blocking(ExamTableWrites.upsertQuestionAppeal(connection, appeal))
                .as(ExamWorkspaceReads.buildExamDetailForUser(nextWorkspace, student))
        yield result
      }
      response <- resolveEither(result)
    yield response

object SubmitExamAppealAPIMessage:
  given Codec.AsObject[SubmitExamAppealAPIMessage] = deriveCodec
