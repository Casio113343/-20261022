package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.exam.tables.ExamTableReads
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.auth.objects.UserRole
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.support.CourseAccessSupport.{isContentVisibleToUser, isCurrentStudent}
import microservices.course.tables.CourseTableReads
import microservices.dashboard.tables.DashboardTableReads

final case class MarkPublishedExamReadAPIMessage(examId: String, userId: String) extends APIMessage[UserDashboardResponse]:
  def plan: IO[UserDashboardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        CourseTableReads.lookupCourseId(connection, ExamTableReads.courseIdByExamIdSql, examId).flatMap {
          case None => IO.pure(Left("考试不存在"))
          case Some(courseId) =>
            for
              courseEither <- CourseTableReads.loadCourseById(connection, courseId)
              userEither <- AuthTableReads.loadUserById(connection, userId)
              examEither <- ExamTableReads.loadExamById(connection, examId)
              validationEither = for
                course <- courseEither
                user <- userEither
                exam <- examEither
                _ <- Either.cond(user.role == UserRole.Student && isCurrentStudent(course, user.id) && isContentVisibleToUser(course, user.id, exam.createdAt), (), "当前用户不可访问该考试")
                _ <- Either.cond(exam.publishedAt.nonEmpty, (), "当前考试尚未发布")
              yield (user, exam.id)
              result <- validationEither match
                case Left(error) => IO.pure(Left(error))
                case Right((user, readExamId)) =>
                  for
                    userReadUpdate <- IO.blocking {
                      AuthTableWrites.upsertUser(connection, user.copy(readPublishedExamIds = (user.readPublishedExamIds :+ readExamId).distinct))
                    }.as(Right(()): Either[String, Unit])
                    dashboardEither <- DashboardTableReads.loadDashboardFromTables(connection, userId)
                  yield for
                    _ <- userReadUpdate
                    dashboard <- dashboardEither
                  yield dashboard
            yield result
        }
      }
      response <- resolveEither(result)
    yield response

object MarkPublishedExamReadAPIMessage:
  given Codec.AsObject[MarkPublishedExamReadAPIMessage] = deriveCodec
