package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.api.requests.CourseAnnouncementInput
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.objects.CourseAnnouncement
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.tables.{CourseTableReads, CourseTableWrites}
import shared.id.IdGenerator
import infrastructure.storage.AttachmentSupport.normalizeAttachment

import java.time.Instant

final case class CreateAnnouncementAPIMessage(courseId: String, userId: String, input: CourseAnnouncementInput) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          validationEither = for
            course <- courseEither
            user <- userEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(input.title.trim.nonEmpty, (), "通知标题不能为空")
            _ <- Either.cond(input.content.trim.nonEmpty, (), "通知内容不能为空")
          yield CourseAnnouncement(IdGenerator.nextId("announcement"), course.id, input.title.trim, input.content.trim, normalizeAttachment(input.attachment), user.id, now)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(announcement) =>
              for
                _ <- IO.blocking(CourseTableWrites.upsertAnnouncement(connection, announcement))
                detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, userId)
              yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

object CreateAnnouncementAPIMessage:
  given Codec.AsObject[CreateAnnouncementAPIMessage] = deriveCodec
