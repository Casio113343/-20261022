package microservices.questionnaire.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.tables.CourseTableReads
import microservices.questionnaire.api.requests.QuestionnaireInput
import microservices.questionnaire.api.responses.QuestionnaireDetailResponse
import microservices.questionnaire.objects.{Questionnaire, QuestionnaireQuestionType}
import microservices.questionnaire.tables.{QuestionnaireTableReads, QuestionnaireTableWrites}
import shared.id.IdGenerator

import java.time.Instant

final case class CreateQuestionnaireAPIMessage(courseId: String, userId: String, input: QuestionnaireInput) extends APIMessage[QuestionnaireDetailResponse]:
  def plan: IO[QuestionnaireDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          validationEither = for
            user <- userEither
            course <- courseEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以创建问卷")
            _ <- Either.cond(input.title.trim.nonEmpty, (), "问卷标题不能为空")
            _ <- Either.cond(input.questions.nonEmpty, (), "问卷至少需要一道题")
            _ <- Either.cond(input.dueAt.isAfter(now), (), "问卷截止时间必须晚于当前时间")
            normalizedQuestions <- validateQuestions(input)
          yield Questionnaire(
            id = IdGenerator.nextId("questionnaire"),
            courseId = course.id,
            title = input.title.trim,
            overview = input.overview.map(_.trim).filter(_.nonEmpty),
            anonymous = input.anonymous,
            questions = normalizedQuestions,
            dueAt = input.dueAt,
            createdByTeacherId = user.id,
            createdAt = now
          )
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(questionnaire) =>
              for
                _ <- IO.blocking(QuestionnaireTableWrites.upsertQuestionnaire(connection, questionnaire))
                detailEither <- QuestionnaireTableReads.loadQuestionnaireDetailFromTables(connection, questionnaire.id, userId)
              yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

  private def validateQuestions(input: QuestionnaireInput): Either[String, List[microservices.questionnaire.objects.QuestionnaireQuestion]] =
    input.questions.zipWithIndex.foldLeft[Either[String, List[microservices.questionnaire.objects.QuestionnaireQuestion]]](Right(Nil)) { case (accumulator, (question, index)) =>
      for
        values <- accumulator
        _ <- Either.cond(question.title.trim.nonEmpty, (), s"第 ${index + 1} 题标题不能为空")
        normalizedOptions = question.options.map(_.trim).filter(_.nonEmpty).distinct
        _ <- question.questionType match
          case QuestionnaireQuestionType.SingleChoice | QuestionnaireQuestionType.MultipleChoice => Either.cond(normalizedOptions.length >= 2, (), s"第 ${index + 1} 题至少需要两个选项")
          case QuestionnaireQuestionType.Text => Right(())
        questionId = question.id.trim match
          case "" => IdGenerator.nextId("questionnaire-question")
          case value => value
      yield values :+ question.copy(
        id = questionId,
        title = question.title.trim,
        options = if question.questionType == QuestionnaireQuestionType.Text then Nil else normalizedOptions
      )
    }

object CreateQuestionnaireAPIMessage:
  given Codec.AsObject[CreateQuestionnaireAPIMessage] = deriveCodec
