package microservices.exam.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.storage.Attachment
import shared.model.SharedCodecs.given

final case class UploadExamAnswerImagesInput(
    studentId: String,
    images: List[Attachment]
)
object UploadExamAnswerImagesInput:
  given Codec[UploadExamAnswerImagesInput] = deriveCodec
