package microservices.questionnaire.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class QuestionnaireQuestion(
    id: String,
    title: String,
    questionType: QuestionnaireQuestionType,
    required: Boolean,
    options: List[String]
)

object QuestionnaireQuestion:
  given Encoder[QuestionnaireQuestion] = deriveEncoder
  given Decoder[QuestionnaireQuestion] = deriveDecoder
