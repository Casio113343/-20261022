package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import shared.model.SharedCodecs.given

import java.time.Instant

final case class ExamSummary(
    id: String,
    courseId: String,
    title: String,
    createdBy: PublicUser,
    createdAt: Instant,
    publishedAt: Option[Instant],
    questionCount: Int,
    appealDueAt: Option[Instant]
)
object ExamSummary:
  given Codec[ExamSummary] = deriveCodec
