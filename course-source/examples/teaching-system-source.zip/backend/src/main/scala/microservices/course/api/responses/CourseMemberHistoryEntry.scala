package microservices.course.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import shared.model.SharedCodecs.given

import java.time.Instant

final case class CourseMemberHistoryEntry(
    user: PublicUser,
    role: String,
    action: String,
    occurredAt: Instant
)
object CourseMemberHistoryEntry:
  given Codec[CourseMemberHistoryEntry] = deriveCodec
