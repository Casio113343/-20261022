package microservices.dashboard.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class SystemNotification(
    id: String,
    userId: String,
    message: String,
    createdAt: Instant
)
object SystemNotification:
  given Encoder[SystemNotification] = deriveEncoder[SystemNotification]
  given Decoder[SystemNotification] = deriveDecoder[SystemNotification]
