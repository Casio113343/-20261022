package microservices.course.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.assignment.objects.{Assignment, AssignmentSubmission, SubmissionReview}
import microservices.exam.api.responses.ExamSummary
import shared.model.SharedCodecs.given

final case class CourseDetailResponse(
    course: CourseSummary,
    announcements: List[CourseAnnouncement],
    assignments: List[Assignment],
    submissions: List[AssignmentSubmission],
    reviews: List[SubmissionReview],
    exams: List[ExamSummary],
    chatMessages: List[CourseChatMessage],
    memberHistory: List[CourseMemberHistoryEntry]
)
object CourseDetailResponse:
  given Codec[CourseDetailResponse] = deriveCodec
