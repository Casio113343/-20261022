package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.support.CourseAccessSupport.isCurrentCourseMember
import microservices.course.tables.CourseTableReads
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.dashboard.tables.DashboardTableReads

final case class MarkAnnouncementsReadAPIMessage(courseId: String, userId: String) extends APIMessage[UserDashboardResponse]:
  def plan: IO[UserDashboardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          announcementsEither <- CourseTableReads.loadAnnouncementsByCourseId(connection, courseId)
          validationEither = for
            course <- courseEither
            user <- userEither
            announcements <- announcementsEither
            _ <- Either.cond(isCurrentCourseMember(course, user.id), (), "当前用户不可访问该课程")
          yield (user, announcements.keys.toList)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((user, announcementIds)) =>
              for
                userReadUpdate <- IO.blocking {
                  AuthTableWrites.upsertUser(connection, user.copy(readAnnouncementIds = (user.readAnnouncementIds ++ announcementIds).distinct))
                }.as(Right(()): Either[String, Unit])
                dashboardEither <- DashboardTableReads.loadDashboardFromTables(connection, userId)
              yield for
                _ <- userReadUpdate
                dashboard <- dashboardEither
              yield dashboard
        yield result
      }
      response <- resolveEither(result)
    yield response

object MarkAnnouncementsReadAPIMessage:
  given Codec.AsObject[MarkAnnouncementsReadAPIMessage] = deriveCodec
