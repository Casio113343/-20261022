package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.tables.CourseTableReads
import microservices.exam.api.requests.ExamInput
import microservices.exam.objects.{OfflineExam, OfflineExamQuestion}
import microservices.exam.support.ExamValidationSupport.{validateAppealDueAt, validateExam}
import microservices.exam.tables.ExamTableWrites
import shared.id.IdGenerator

import java.time.Instant

final case class CreateExamAPIMessage(courseId: String, userId: String, input: ExamInput) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          validationEither = for
            course <- courseEither
            user <- userEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以执行该操作")
            validatedQuestions <- validateExam(course, input)
            _ <- validateAppealDueAt(validatedQuestions, input.appealDueAt, now)
          yield
            val newExamId = IdGenerator.nextId("exam")
            val questions = validatedQuestions.zipWithIndex.map { case (question, index) =>
              val newQuestionId = IdGenerator.nextId("exam-question")
              OfflineExamQuestion(newQuestionId, newExamId, question.title, index + 1, question.scoring)
            }
            val exam = OfflineExam(newExamId, course.id, input.title.trim, user.id, now, None, questions.map(_.id), input.appealDueAt)
            (exam, questions)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((exam, questions)) =>
              for
                _ <- IO.blocking {
                  ExamTableWrites.upsertExam(connection, exam)
                  questions.foreach(ExamTableWrites.upsertExamQuestion(connection, _))
                }
                detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, userId)
              yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

object CreateExamAPIMessage:
  given Codec.AsObject[CreateExamAPIMessage] = deriveCodec
