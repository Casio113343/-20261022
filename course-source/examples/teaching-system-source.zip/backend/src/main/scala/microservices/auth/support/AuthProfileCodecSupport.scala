package microservices.auth.support

import io.circe.{Decoder, HCursor}

object AuthProfileCodecSupport:

  def decodeFlexibleProfile[A](
      cursor: HCursor,
      firstField: String,
      secondField: String
  )(
      build: (Option[String], Option[String]) => A
  ): Decoder.Result[A] =
    def readField(fieldName: String): Decoder.Result[Option[String]] =
      cursor.value.hcursor.downField(fieldName).focus match
        case None => Right(None)
        case Some(json) if json.isNull => Right(None)
        case Some(_) =>
          cursor.get[String](fieldName).map(value => Option(value.trim).filter(_.nonEmpty))

    for
      first <- readField(firstField)
      second <- readField(secondField)
    yield build(first, second)
