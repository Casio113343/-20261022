package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec

final case class ExamQuestionGradingProgress(
    questionId: String,
    title: String,
    position: Int,
    graders: List[ExamQuestionGraderProgress]
)

object ExamQuestionGradingProgress:
  given Codec[ExamQuestionGradingProgress] = deriveCodec
