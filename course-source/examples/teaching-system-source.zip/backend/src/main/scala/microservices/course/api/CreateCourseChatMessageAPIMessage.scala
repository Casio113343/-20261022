package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import infrastructure.events.DomainEvent
import infrastructure.outbox.OutboxTableWrites
import infrastructure.outbox.OutboxSupport
import infrastructure.realtime.CourseRealtimeEvent
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.AuthTableReads
import microservices.course.api.requests.CourseChatMessageInput
import microservices.course.api.responses.CourseChatMessage
import microservices.course.objects.CourseChatMessage as CourseChatMessageModel
import microservices.course.support.CourseAccessSupport.isCurrentCourseMember
import microservices.course.tables.{CourseTableReads, CourseTableWrites}
import shared.id.IdGenerator
import infrastructure.storage.AttachmentSupport.normalizeAttachment

import java.time.Instant

final case class CreateCourseChatMessageAPIMessage(courseId: String, userId: String, input: CourseChatMessageInput) extends APIMessage[CourseChatMessage]:
  def plan: IO[CourseChatMessage] =
    for
      occurredAt <- IO.delay(Instant.now())
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          validationEither = for
            course <- courseEither
            user <- userEither
            _ <- Either.cond(isCurrentCourseMember(course, user.id), (), "当前用户不可访问该课程")
            content = input.content.trim
            images = input.images.flatMap(image => normalizeAttachment(Some(image)))
            attachments = input.attachments.flatMap(attachment => normalizeAttachment(Some(attachment)))
            _ <- Either.cond(content.nonEmpty || images.nonEmpty || attachments.nonEmpty, (), "消息内容、图片和附件不能同时为空")
            message = CourseChatMessageModel(IdGenerator.nextId("chat-message"), course.id, user.id, content, images, attachments, occurredAt, None, None)
            view <- CourseTableReads.buildChatMessageView(message, Map(user.id -> user), user.id)
          yield
            val outboxMessages = List(
              OutboxSupport.courseRealtimePublish(CourseRealtimeEvent("chat.message.created", courseId, Some(view)), occurredAt),
              OutboxSupport.domainEventPublish(
                DomainEvent(
                  eventType = "chat.message.created",
                  aggregateType = "course-chat",
                  aggregateId = view.id,
                  userId = userId,
                  courseId = Some(courseId),
                  occurredAt = occurredAt,
                  payload = io.circe.Json.obj(
                    "courseId" -> io.circe.Json.fromString(courseId),
                    "messageId" -> io.circe.Json.fromString(view.id)
                  )
                )
              )
            )
            (message, view, outboxMessages)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((message, view, outboxMessages)) =>
              for
                _ <- IO.blocking {
                  CourseTableWrites.upsertChatMessage(connection, message)
                  OutboxTableWrites.insertAll(connection, outboxMessages)
                }
              yield Right(view)
        yield result
      }
      response <- resolveEither(result)
    yield response

object CreateCourseChatMessageAPIMessage:
  given Codec.AsObject[CreateCourseChatMessageAPIMessage] = deriveCodec
