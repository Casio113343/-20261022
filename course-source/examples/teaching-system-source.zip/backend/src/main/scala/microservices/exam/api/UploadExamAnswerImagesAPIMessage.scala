package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import infrastructure.events.DomainEvent
import infrastructure.outbox.{OutboxSupport, OutboxTableWrites}
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.course.support.CourseAccessSupport.{courseStudentsAt, isCurrentStudent}
import microservices.exam.api.requests.UploadExamAnswerImagesInput
import microservices.exam.api.responses.ExamDetailResponse
import microservices.exam.objects.ExamAnswerSheet
import microservices.exam.tables.{ExamTableWrites, ExamWorkspaceReads}
import infrastructure.storage.AttachmentSupport.normalizeAttachment
import shared.id.IdGenerator

import java.time.Instant

final case class UploadExamAnswerImagesAPIMessage(examId: String, questionId: String, userId: String, input: UploadExamAnswerImagesInput) extends APIMessage[ExamDetailResponse]:
  def plan: IO[ExamDetailResponse] =
    for
      occurredAt <- IO.delay(Instant.now())
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          workspaceEither <- ExamWorkspaceReads.loadWorkspace(connection, examId)
          validationEither = workspaceEither.flatMap { workspace =>
            for
              question <- ExamWorkspaceReads.validateTeacherQuestion(workspace, questionId, userId)
              operator <- workspace.users.get(userId).toRight("用户不存在")
              _ <- Either.cond(question.examId == workspace.exam.id, (), "考试题目不存在")
              _ <- Either.cond(isCurrentStudent(workspace.course, input.studentId) && courseStudentsAt(workspace.course, workspace.exam.createdAt).contains(input.studentId), (), "只能为本场考试的有效学生导入答题图片")
              images = input.images.flatMap(image => normalizeAttachment(Some(image)))
              _ <- Either.cond(images.nonEmpty, (), "至少需要上传一张答题图片")
            yield
              val sheet = ExamAnswerSheet(IdGenerator.nextId("exam-sheet"), examId, questionId, input.studentId, images)
              val nextWorkspace = workspace.copy(answerSheets = workspace.answerSheets.filterNot { case (_, current) => current.examId == examId && current.questionId == questionId && current.studentId == input.studentId }.updated(sheet.id, sheet))
              val outbox = OutboxSupport.domainEventPublish(
                DomainEvent(
                  eventType = "exam.answer-images.uploaded",
                  aggregateType = "exam",
                  aggregateId = examId,
                  userId = userId,
                  courseId = None,
                  occurredAt = occurredAt,
                  payload = io.circe.Json.obj("relatedId" -> io.circe.Json.fromString(questionId))
                )
              )
              (sheet, operator, nextWorkspace, outbox)
          }
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((sheet, operator, nextWorkspace, outbox)) =>
              IO.blocking {
                ExamTableWrites.deleteAnswerSheetsByQuestionAndStudent(connection, examId, questionId, input.studentId)
                ExamTableWrites.upsertExamAnswerSheet(connection, sheet)
                OutboxTableWrites.insertAll(connection, List(outbox))
              }.as(ExamWorkspaceReads.buildExamDetailForUser(nextWorkspace, operator))
        yield result
      }
      response <- resolveEither(result)
    yield response

object UploadExamAnswerImagesAPIMessage:
  given Codec.AsObject[UploadExamAnswerImagesAPIMessage] = deriveCodec
