package microservices.assignment.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.support.CourseAccessSupport.*
import microservices.assignment.objects.Assignment
import microservices.assignment.tables.AssignmentTableWrites
import microservices.course.api.responses.CourseDetailResponse
import shared.id.IdGenerator
import infrastructure.storage.AttachmentSupport.normalizeAttachment
import microservices.course.tables.CourseTableReads

import java.time.Instant

final case class CreateAssignmentAPIMessage(courseId: String, operatorUserId: String, input: Assignment) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          operatorEither <- AuthTableReads.loadUserById(connection, operatorUserId)
          graderEither <- AuthTableReads.loadUserById(connection, input.graderTeacherId)
          validationEither = for
            course <- courseEither
            operator <- operatorEither
            grader <- graderEither
            _ <- Either.cond(operator.role == UserRole.Teacher && isCurrentTeacher(course, operator.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(grader.role == UserRole.Teacher && isCurrentTeacher(course, grader.id), (), "负责批改的老师必须属于当前课程")
            _ <- Either.cond(input.maxScore.forall(_ > 0), (), "满分必须大于 0")
            _ <- Either.cond(input.title.trim.nonEmpty, (), "作业标题不能为空")
            normalizedAttachment = normalizeAttachment(input.attachment)
            _ <- Either.cond(input.content.trim.nonEmpty || normalizedAttachment.nonEmpty, (), "作业内容和附件至少填写一项")
            _ <- Either.cond(input.dueAt.isAfter(now), (), "截止时间必须晚于当前时间")
            _ <- Either.cond(input.answerPublishedAt.forall(_.isAfter(now)), (), "答案公布时间必须晚于当前时间")
          yield Assignment(IdGenerator.nextId("assignment"), course.id, input.title.trim, input.content.trim, normalizedAttachment, input.allowLateSubmission, input.maxScore, grader.id, input.dueAt, operator.id, now, normalizeAttachment(input.answerAttachment), input.answerPublishedAt)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(assignment) =>
                for
                  _ <- IO.blocking(AssignmentTableWrites.upsertAssignment(connection, assignment))
                  detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, operatorUserId)
                yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

object CreateAssignmentAPIMessage:
  given Codec.AsObject[CreateAssignmentAPIMessage] = deriveCodec
