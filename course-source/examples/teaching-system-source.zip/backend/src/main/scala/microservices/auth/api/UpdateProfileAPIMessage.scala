package microservices.auth.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.api.requests.ProfileUpdate
import microservices.auth.tables.AuthTableReads
import microservices.auth.tables.AuthTableWrites
import microservices.auth.objects.{StudentProfile, TeacherProfile, UserRole}
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.dashboard.tables.DashboardTableReads

final case class UpdateProfileAPIMessage(userId: String, input: ProfileUpdate) extends APIMessage[UserDashboardResponse]:
  override def plan: IO[UserDashboardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          validationEither = userEither.flatMap { currentUser =>
            val nextDisplayName = input.displayName.map(_.trim).filter(_.nonEmpty).getOrElse(currentUser.displayName)
            val nextPasswordEither =
              input.newPassword.map(_.trim).filter(_.nonEmpty) match
                case None => Right(currentUser.password)
                case Some(newPassword) =>
                  if newPassword.length < 6 then Left("新密码至少 6 位")
                  else if input.currentPassword.map(_.trim).filter(_.nonEmpty).contains(currentUser.password) then Right(newPassword)
                  else Left("原密码错误")
            if nextDisplayName.isEmpty then Left("姓名不能为空")
            else nextPasswordEither.map { nextPassword =>
              currentUser.copy(
                displayName = nextDisplayName,
                password = nextPassword,
                avatarDataUrl = if input.clearAvatar then None else input.avatarDataUrl match
                  case Some(value) => Some(value).map(_.trim).filter(_.nonEmpty)
                  case None => currentUser.avatarDataUrl,
                teacherProfile =
                  if currentUser.role == UserRole.Teacher then
                    val mergedProfile = input.teacherProfile match
                      case Some(profile) => Some(TeacherProfile(profile.subject.orElse(currentUser.teacherProfile.flatMap(_.subject)), profile.office.orElse(currentUser.teacherProfile.flatMap(_.office))))
                      case None => currentUser.teacherProfile
                    Some(TeacherProfile(mergedProfile.flatMap(_.subject).map(_.trim).filter(_.nonEmpty), mergedProfile.flatMap(_.office).map(_.trim).filter(_.nonEmpty)))
                  else None,
                studentProfile =
                  if currentUser.role == UserRole.Student then
                    val mergedProfile = input.studentProfile match
                      case Some(profile) => Some(StudentProfile(profile.grade.orElse(currentUser.studentProfile.flatMap(_.grade)), profile.major.orElse(currentUser.studentProfile.flatMap(_.major))))
                      case None => currentUser.studentProfile
                    Some(StudentProfile(mergedProfile.flatMap(_.grade).map(_.trim).filter(_.nonEmpty), mergedProfile.flatMap(_.major).map(_.trim).filter(_.nonEmpty)))
                  else None,
              )
            }
          }
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(nextAccount) =>
              for
                _ <- IO.blocking(AuthTableWrites.upsertUser(connection, nextAccount))
                dashboardEither <- DashboardTableReads.loadDashboardFromTables(connection, userId)
              yield dashboardEither
        yield result
      }
      response <- resolveEither(result)
    yield response

object UpdateProfileAPIMessage:
  given Codec.AsObject[UpdateProfileAPIMessage] = deriveCodec
