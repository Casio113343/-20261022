package microservices.exam.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec

final case class ReviewExamAnswerInput(
    score: Int
)
object ReviewExamAnswerInput:
  given Codec[ReviewExamAnswerInput] = deriveCodec
