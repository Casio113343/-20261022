package microservices.assignment.tables

import cats.effect.IO
import microservices.assignment.objects.{Assignment, AssignmentSubmission, SubmissionReview}
import infrastructure.storage.Attachment
import shared.jdbc.{JdbcDecodingSupport, JdbcReadSupport}

import java.sql.Connection

object AssignmentTableReads:
  val courseIdByAssignmentIdSql: String =
    "select course_id from teaching_assignments where id = ?"

  val courseIdBySubmissionIdSql: String =
    """
      |select a.course_id
      |from teaching_submissions s
      |join teaching_assignments a on a.id = s.assignment_id
      |where s.id = ?
      |""".stripMargin

  def loadAssignmentById(connection: Connection, assignmentId: String): IO[Either[String, Assignment]] =
    loadAssignmentsByIds(connection, List(assignmentId)).map(_.flatMap(_.get(assignmentId).toRight("作业不存在")))

  def loadSubmissionById(connection: Connection, submissionId: String): IO[Either[String, AssignmentSubmission]] =
    loadSubmissionsByIds(connection, List(submissionId)).map(_.flatMap(_.get(submissionId).toRight("提交不存在")))

  def findSubmissionForAssignmentAndStudent(connection: Connection, assignmentId: String, studentId: String): IO[Either[String, Option[AssignmentSubmission]]] =
    loadSubmissionsByAssignmentIds(connection, List(assignmentId)).map(_.map(_.values.find(submission => submission.assignmentId == assignmentId && submission.studentId == studentId)))

  def loadReviewBySubmissionId(connection: Connection, submissionId: String): IO[Either[String, Option[SubmissionReview]]] =
    loadReviewsBySubmissionIds(connection, List(submissionId)).map(_.map(_.values.find(_.submissionId == submissionId)))

  def loadAssignmentsByIds(connection: Connection, assignmentIds: Iterable[String]): IO[Either[String, Map[String, Assignment]]] =
    loadAssignments(connection, "id", assignmentIds)

  def loadAssignmentsByCourseIds(connection: Connection, courseIds: Iterable[String]): IO[Either[String, Map[String, Assignment]]] =
    loadAssignments(connection, "course_id", courseIds)

  private def loadAssignments(connection: Connection, filterColumn: String, filterIds: Iterable[String]): IO[Either[String, Map[String, Assignment]]] =
    import JdbcReadSupport.*
    val ids = filterIds.toList.distinct
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          s"""
            |select id, course_id, title, content, attachment, allow_late_submission, max_score, grader_teacher_id, due_at, created_by_teacher_id, created_at, answer_attachment, answer_published_at
            |from teaching_assignments
            |where $filterColumn in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              for
                attachment <- JdbcDecodingSupport.decodeOptionalJson[Attachment](readStringOpt(row, "attachment"), "assignment attachment")
                answerAttachment <- JdbcDecodingSupport.decodeOptionalJson[Attachment](readStringOpt(row, "answer_attachment"), "assignment answer attachment")
              yield
                Assignment(
                  id = row.getString("id"),
                  courseId = row.getString("course_id"),
                  title = row.getString("title"),
                  content = row.getString("content"),
                  attachment = attachment,
                  allowLateSubmission = row.getBoolean("allow_late_submission"),
                  maxScore = Option(row.getObject("max_score")).map(_ => row.getInt("max_score")),
                  graderTeacherId = row.getString("grader_teacher_id"),
                  dueAt = readInstant(row, "due_at"),
                  createdByTeacherId = row.getString("created_by_teacher_id"),
                  createdAt = readInstant(row, "created_at"),
                  answerAttachment = answerAttachment,
                  answerPublishedAt = Option(row.getTimestamp("answer_published_at")).map(_.toInstant)
                )
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadSubmissionsByIds(connection: Connection, submissionIds: Iterable[String]): IO[Either[String, Map[String, AssignmentSubmission]]] =
    loadSubmissions(connection, "id", submissionIds)

  def loadSubmissionsByAssignmentIds(connection: Connection, assignmentIds: Iterable[String]): IO[Either[String, Map[String, AssignmentSubmission]]] =
    loadSubmissions(connection, "assignment_id", assignmentIds)

  private def loadSubmissions(connection: Connection, filterColumn: String, filterIds: Iterable[String]): IO[Either[String, Map[String, AssignmentSubmission]]] =
    import JdbcReadSupport.*
    val ids = filterIds.toList.distinct
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          s"""
            |select id, assignment_id, student_id, content, attachment, submitted_at
            |from teaching_submissions
            |where $filterColumn in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              JdbcDecodingSupport.decodeOptionalJson[Attachment](readStringOpt(row, "attachment"), "submission attachment").map { attachment =>
                AssignmentSubmission(
                  id = row.getString("id"),
                  assignmentId = row.getString("assignment_id"),
                  studentId = row.getString("student_id"),
                  content = row.getString("content"),
                  attachment = attachment,
                  submittedAt = readInstant(row, "submitted_at")
                )
              }
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadReviewsBySubmissionIds(connection: Connection, submissionIds: Iterable[String]): IO[Either[String, Map[String, SubmissionReview]]] =
    import JdbcReadSupport.*
    val ids = submissionIds.toList.distinct
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          """
            |select id, submission_id, grader_teacher_id, score, comment, reviewed_at
            |from teaching_reviews
            |where submission_id in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              Right(
                SubmissionReview(
                  id = row.getString("id"),
                  submissionId = row.getString("submission_id"),
                  graderTeacherId = row.getString("grader_teacher_id"),
                  score = Option(row.getObject("score")).map(_ => row.getInt("score")),
                  comment = readStringOpt(row, "comment"),
                  reviewedAt = readInstant(row, "reviewed_at")
                )
              )
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)
