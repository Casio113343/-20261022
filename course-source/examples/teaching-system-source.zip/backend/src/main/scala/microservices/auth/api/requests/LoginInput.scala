package microservices.auth.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.UserRole

final case class LoginInput(
    username: String,
    password: String,
    role: UserRole
)

object LoginInput:
  given Codec[LoginInput] = deriveCodec
