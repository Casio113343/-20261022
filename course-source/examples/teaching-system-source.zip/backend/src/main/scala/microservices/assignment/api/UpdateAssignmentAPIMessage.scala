package microservices.assignment.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.assignment.tables.AssignmentTableReads
import microservices.assignment.tables.AssignmentTableWrites
import microservices.course.tables.CourseTableReads
import microservices.course.support.CourseAccessSupport.*
import microservices.assignment.objects.Assignment
import microservices.course.api.responses.CourseDetailResponse
import infrastructure.storage.AttachmentSupport.normalizeAttachment

final case class UpdateAssignmentAPIMessage(courseId: String, assignmentId: String, operatorUserId: String, input: Assignment) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          operatorEither <- AuthTableReads.loadUserById(connection, operatorUserId)
          graderEither <- AuthTableReads.loadUserById(connection, input.graderTeacherId)
          assignmentEither <- AssignmentTableReads.loadAssignmentById(connection, assignmentId)
          submissionsEither <- AssignmentTableReads.loadSubmissionsByAssignmentIds(connection, List(assignmentId))
          reviewsEither <- submissionsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(submissions) => AssignmentTableReads.loadReviewsBySubmissionIds(connection, submissions.keys)
          validationEither = for
            course <- courseEither
            operator <- operatorEither
            grader <- graderEither
            assignment <- assignmentEither
            submissions <- submissionsEither
            reviews <- reviewsEither
            _ <- Either.cond(operator.role == UserRole.Teacher && isCurrentTeacher(course, operator.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(assignment.courseId == course.id, (), "作业不属于当前课程")
            _ <- Either.cond(grader.role == UserRole.Teacher && isCurrentTeacher(course, grader.id) && isContentVisibleToUser(course, grader.id, assignment.createdAt), (), "负责批改的老师必须在作业创建时已属于当前课程")
            _ <- Either.cond(input.maxScore.forall(_ > 0), (), "满分必须大于 0")
            _ <- Either.cond(input.title.trim.nonEmpty, (), "作业标题不能为空")
            normalizedAttachment = normalizeAttachment(input.attachment)
            _ <- Either.cond(input.content.trim.nonEmpty || normalizedAttachment.nonEmpty, (), "作业内容和附件至少填写一项")
          yield
            val nextAssignment = assignment.copy(
              title = input.title.trim,
              content = input.content.trim,
              attachment = normalizedAttachment,
              allowLateSubmission = input.allowLateSubmission,
              maxScore = input.maxScore,
              graderTeacherId = grader.id,
              dueAt = input.dueAt,
              answerAttachment = normalizeAttachment(input.answerAttachment),
              answerPublishedAt = input.answerPublishedAt,
            )
            val allSubmissions = submissions.values.toList
            val submissionIds = allSubmissions.map(_.id).toSet
            val removedSubmissions =
              if assignment.maxScore != input.maxScore then allSubmissions.filterNot(submission => isCurrentStudent(course, submission.studentId))
              else Nil
            val removedReviews =
              if assignment.maxScore != input.maxScore then reviews.values.toList.filter(review => submissionIds.contains(review.submissionId))
              else Nil
            (nextAssignment, removedSubmissions, removedReviews)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((nextAssignment, removedSubmissions, removedReviews)) =>
                for
                  _ <- IO.blocking {
                    AssignmentTableWrites.upsertAssignment(connection, nextAssignment)
                    removedReviews.foreach(review => AssignmentTableWrites.deleteReview(connection, review.id))
                    removedSubmissions.foreach(submission => AssignmentTableWrites.deleteSubmission(connection, submission.id))
                  }
                  detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, operatorUserId)
                yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

object UpdateAssignmentAPIMessage:
  given Codec.AsObject[UpdateAssignmentAPIMessage] = deriveCodec
