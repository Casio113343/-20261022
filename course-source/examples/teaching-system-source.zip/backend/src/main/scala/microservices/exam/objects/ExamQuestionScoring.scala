package microservices.exam.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.deriveEncoder

final case class ExamQuestionScoring(
    fullScore: Int,
    graderTeacherIds: List[String],
    arbitrationEnabled: Boolean,
    arbitrationScoreDiffThreshold: Option[Int],
    arbitrationTeacherId: Option[String],
    appealEnabled: Boolean,
    appealTeacherId: Option[String]
)

object ExamQuestionScoring:
  private val encoder: Encoder.AsObject[ExamQuestionScoring] = deriveEncoder[ExamQuestionScoring]
  private val decoder: Decoder[ExamQuestionScoring] = Decoder.instance { cursor =>
    for
      fullScore <- cursor.get[Int]("fullScore")
      graderTeacherIds <- cursor.get[List[String]]("graderTeacherIds")
      arbitrationEnabled <- cursor.getOrElse[Boolean]("arbitrationEnabled")(false)
      arbitrationScoreDiffThreshold <- cursor.get[Option[Int]]("arbitrationScoreDiffThreshold")
      arbitrationTeacherId <- cursor.get[Option[String]]("arbitrationTeacherId")
      appealEnabled <- cursor.getOrElse[Boolean]("appealEnabled")(false)
      appealTeacherId <- cursor.get[Option[String]]("appealTeacherId")
    yield ExamQuestionScoring(
      fullScore,
      graderTeacherIds,
      arbitrationEnabled,
      arbitrationScoreDiffThreshold,
      arbitrationTeacherId,
      appealEnabled,
      appealTeacherId,
    )
  }
  given Encoder[ExamQuestionScoring] = encoder
  given Decoder[ExamQuestionScoring] = decoder
