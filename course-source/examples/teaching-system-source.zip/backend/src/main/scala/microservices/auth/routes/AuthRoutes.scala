package microservices.auth.routes

import infrastructure.api.ActionResponse
import infrastructure.api.RegisteredAPIMessage
import microservices.auth.api.*
import microservices.auth.api.boundary.*

object AuthRoutes:
  val apiMessages: List[RegisteredAPIMessage] = List(
    RegisteredAPIMessage.api[LoginAPIMessage, microservices.auth.api.responses.LoginOutput],
    RegisteredAPIMessage.api[RegisterAPIMessage, microservices.auth.api.responses.RegisterOutput],
    RegisteredAPIMessage.api[UpdateProfileAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse],
    RegisteredAPIMessage.api[ClearDeletedAnnouncementReadMarkersAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[ClearDeletedAssignmentReviewReadMarkersAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[ClearDeletedCourseReadMarkersAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[ClearDeletedExamResultReadMarkersAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[UpdateUserReadCourseAnnouncementsAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[UpdateUserReadPublishedExamAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[UpdateUserReadReviewedAssignmentAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[UpdateUserReadSystemNotificationsAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[DeleteAccountAPIMessage, ActionResponse]
  )
