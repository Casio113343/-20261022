package microservices.auth.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}

final case class ClearDeletedExamResultReadMarkersAPIMessage(userIds: List[String], examId: String) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          usersEither <- AuthTableReads.loadUsersByIds(connection, userIds)
          result <- usersEither match
            case Left(error) => IO.pure(Left(error))
            case Right(users) =>
              val updatedUsers = users.values.toList
                .map(user => user.copy(readPublishedExamIds = user.readPublishedExamIds.filterNot(_ == examId)))
                .filter(user => users(user.id).readPublishedExamIds != user.readPublishedExamIds)
              IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理删除考试的成绩已读标记")

object ClearDeletedExamResultReadMarkersAPIMessage:
  given Codec.AsObject[ClearDeletedExamResultReadMarkersAPIMessage] = deriveCodec
