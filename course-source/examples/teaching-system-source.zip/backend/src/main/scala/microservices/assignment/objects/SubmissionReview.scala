package microservices.assignment.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class SubmissionReview(
    id: String,
    submissionId: String,
    graderTeacherId: String,
    score: Option[Int],
    comment: Option[String],
    reviewedAt: Instant
)

object SubmissionReview:
  given Encoder[SubmissionReview] = deriveEncoder[SubmissionReview]
  given Decoder[SubmissionReview] = deriveDecoder[SubmissionReview]
