package microservices.assignment.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.assignment.tables.AssignmentTableWrites
import microservices.assignment.tables.AssignmentTableReads
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.tables.CourseTableReads
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.api.responses.CourseDetailResponse

final case class DeleteAssignmentAPIMessage(courseId: String, assignmentId: String, operatorUserId: String) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          operatorEither <- AuthTableReads.loadUserById(connection, operatorUserId)
          assignmentEither <- AssignmentTableReads.loadAssignmentById(connection, assignmentId)
          submissionsEither <- AssignmentTableReads.loadSubmissionsByAssignmentIds(connection, List(assignmentId))
          reviewsEither <- submissionsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(submissions) => AssignmentTableReads.loadReviewsBySubmissionIds(connection, submissions.keys)
          validationEither = for
            course <- courseEither
            operator <- operatorEither
            assignment <- assignmentEither
            submissions <- submissionsEither
            reviews <- reviewsEither
            _ <- Either.cond(operator.role == UserRole.Teacher && isCurrentTeacher(course, operator.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(assignment.courseId == course.id, (), "作业不属于当前课程")
          yield
            val submissionIds = submissions.keys.toSet
            ((course.teachers ++ course.students).distinct, submissions.values.toList, reviews.values.toList.filter(review => submissionIds.contains(review.submissionId)))
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((courseMemberIds, submissions, reviews)) =>
                for
                  _ <- IO.blocking {
                    reviews.foreach(review => AssignmentTableWrites.deleteReview(connection, review.id))
                    submissions.foreach(submission => AssignmentTableWrites.deleteSubmission(connection, submission.id))
                    AssignmentTableWrites.deleteAssignment(connection, assignmentId)
                  }
                  usersEither <- AuthTableReads.loadUsersByIds(connection, courseMemberIds)
                  userReadMarkersCleared <- usersEither match
                    case Left(error) => IO.pure(Left(error))
                    case Right(users) =>
                      val updatedUsers = users.values.toList
                        .map(user => user.copy(readReviewedAssignmentIds = user.readReviewedAssignmentIds.filterNot(_ == assignmentId)))
                        .filter(user => users(user.id).readReviewedAssignmentIds != user.readReviewedAssignmentIds)
                      IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
                  detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, operatorUserId)
                yield for
                  _ <- userReadMarkersCleared
                  detail <- detailEither
                yield detail
        yield result
      }
      response <- resolveEither(result)
    yield response

object DeleteAssignmentAPIMessage:
  given Codec.AsObject[DeleteAssignmentAPIMessage] = deriveCodec
