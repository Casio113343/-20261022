package microservices.course.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.deriveEncoder
import microservices.auth.objects.UserRole

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class Course(
    id: String,
    title: String,
    description: String,
    teachers: List[String],
    students: List[String],
    createdAt: Instant,
    memberEvents: List[CourseMemberEvent]
)

object Course:
  private val encoder = deriveEncoder[Course]
  private val decoder = io.circe.Decoder.instance { cursor =>
    for
      id <- cursor.get[String]("id")
      title <- cursor.get[String]("title")
      description <- cursor.get[String]("description")
      teachers <- cursor.get[List[String]]("teachers")
      students <- cursor.get[List[String]]("students")
      createdAt <- cursor.get[Instant]("createdAt")
      memberEvents <- cursor.get[Option[List[CourseMemberEvent]]]("memberEvents")
    yield Course(
      id = id,
      title = title,
      description = description,
      teachers = teachers,
      students = students,
      createdAt = createdAt,
      memberEvents = memberEvents.getOrElse(
        teachers.map(CourseMemberEvent(_, UserRole.Teacher, CourseMemberAction.Joined, createdAt)) ++
          students.map(CourseMemberEvent(_, UserRole.Student, CourseMemberAction.Joined, createdAt))
      ),
    )
  }
  given Encoder[Course] = encoder
  given Decoder[Course] = decoder
