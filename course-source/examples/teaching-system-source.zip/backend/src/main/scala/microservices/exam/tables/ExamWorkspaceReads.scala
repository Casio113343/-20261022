package microservices.exam.tables

import cats.effect.IO
import microservices.auth.objects.{UserAccount, UserRole}
import microservices.auth.support.AuthUserViewSupport.toPublicUser
import microservices.auth.tables.AuthTableReads
import microservices.course.api.responses.CourseSummary
import microservices.course.objects.Course
import microservices.course.support.CourseAccessSupport.*
import microservices.course.tables.CourseTableReads
import microservices.exam.api.requests.ExamReviewOperation
import microservices.exam.api.responses.{ExamAnswerSheet as ExamAnswerSheetResponse, ExamDetailResponse, ExamQuestion as ExamQuestionResponse, ExamQuestionAppeal as ExamQuestionAppealResponse, ExamQuestionGraderProgress as ExamQuestionGraderProgressResponse, ExamQuestionGradingProgress as ExamQuestionGradingProgressResponse, ExamQuestionResult as ExamQuestionResultResponse, ExamQuestionResultStatus, ExamQuestionScoring as ExamQuestionScoringResponse, ExamReviewBoardResponse, ExamReviewItem as ExamReviewItemResponse, ExamReviewItemStatus, ExamStudentResult as ExamStudentResultResponse, ExamSummary, ExamTeacherScoreCell as ExamTeacherScoreCellResponse, ExamTeacherScoreRow as ExamTeacherScoreRowResponse, ExamTeacherTask as ExamTeacherTaskResponse}
import microservices.exam.objects.*
import microservices.exam.tables.ExamTableReads

import java.sql.Connection
import java.time.Instant
import scala.math.BigDecimal.RoundingMode

object ExamWorkspaceReads:
  final case class Workspace(
      exam: OfflineExam,
      course: Course,
      questions: Map[String, OfflineExamQuestion],
      answerSheets: Map[String, ExamAnswerSheet],
      gradings: Map[String, ExamQuestionGrading],
      arbitrations: Map[String, ExamQuestionArbitration],
      appeals: Map[String, ExamQuestionAppeal],
      users: Map[String, UserAccount]
  )

  final case class ResolvedQuestionOutcome(status: ExamQuestionResultStatus, finalScore: Option[BigDecimal])

  def loadWorkspace(connection: Connection, examId: String): IO[Either[String, Workspace]] =
    for
      examEither <- ExamTableReads.loadExamById(connection, examId)
      courseEither <- examEither match
        case Left(error) => IO.pure(Left(error))
        case Right(exam) => CourseTableReads.loadCourseById(connection, exam.courseId)
      questionsEither <- ExamTableReads.loadExamQuestionsByExamIds(connection, List(examId))
      answerSheetsEither <- ExamTableReads.loadAnswerSheetsByExamIds(connection, List(examId))
      gradingsEither <- answerSheetsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(answerSheets) => ExamTableReads.loadQuestionGradingsByAnswerSheetIds(connection, answerSheets.keys)
      arbitrationsEither <- answerSheetsEither match
        case Left(error) => IO.pure(Left(error))
        case Right(answerSheets) => ExamTableReads.loadQuestionArbitrationsByAnswerSheetIds(connection, answerSheets.keys)
      appealsEither <- (answerSheetsEither, questionsEither) match
        case (Right(answerSheets), Right(questions)) => ExamTableReads.loadQuestionAppeals(connection, answerSheets.keys, questions.keys)
        case (Left(error), _) => IO.pure(Left(error))
        case (_, Left(error)) => IO.pure(Left(error))
      usersEither <- (examEither, courseEither, questionsEither, answerSheetsEither, gradingsEither, arbitrationsEither, appealsEither) match
        case (Right(exam), Right(course), Right(questions), Right(answerSheets), Right(gradings), Right(arbitrations), Right(appeals)) =>
          val userIds =
            (course.teachers ++ course.students ++ course.memberEvents.map(_.userId)).toSet +
              exam.createdByTeacherId ++
              questions.valuesIterator.flatMap(question => question.scoring.graderTeacherIds ++ question.scoring.arbitrationTeacherId.toList ++ question.scoring.appealTeacherId.toList).toSet ++
              answerSheets.valuesIterator.map(_.studentId).toSet ++
              gradings.valuesIterator.map(_.graderTeacherId).toSet ++
              arbitrations.valuesIterator.map(_.arbitrationTeacherId).toSet ++
              appeals.valuesIterator.flatMap(appeal => List(appeal.studentId, appeal.appealTeacherId)).toSet
          AuthTableReads.loadUsersByIds(connection, userIds)
        case (Left(error), _, _, _, _, _, _) => IO.pure(Left(error))
        case (_, Left(error), _, _, _, _, _) => IO.pure(Left(error))
        case (_, _, Left(error), _, _, _, _) => IO.pure(Left(error))
        case (_, _, _, Left(error), _, _, _) => IO.pure(Left(error))
        case (_, _, _, _, Left(error), _, _) => IO.pure(Left(error))
        case (_, _, _, _, _, Left(error), _) => IO.pure(Left(error))
        case (_, _, _, _, _, _, Left(error)) => IO.pure(Left(error))
    yield for
      exam <- examEither
      course <- courseEither
      questions <- questionsEither
      answerSheets <- answerSheetsEither
      gradings <- gradingsEither
      arbitrations <- arbitrationsEither
      appeals <- appealsEither
      users <- usersEither
    yield Workspace(exam, course, questions, answerSheets, gradings, arbitrations, appeals, users)

  def buildExamDetailForUser(workspace: Workspace, currentUser: UserAccount): Either[String, ExamDetailResponse] =
    for
      answerSheets <- buildAnswerSheets(workspace).map { sheets =>
        if currentUser.role == UserRole.Teacher then sheets
        else if workspace.exam.publishedAt.nonEmpty then sheets.filter(_.student.id == currentUser.id)
        else Nil
      }
      participantStudents <- traverse(courseStudentsAt(workspace.course, workspace.exam.createdAt).filter(isCurrentStudent(workspace.course, _))) { studentId =>
        workspace.users.get(studentId).toRight("考试参与学生不存在").map(toPublicUser)
      }
      summary <- buildExamSummary(workspace)
      courseSummary <- buildCourseSummary(workspace.course, workspace.users)
      questions <- buildExamQuestions(workspace)
      appeals <- buildAppeals(workspace).map(allAppeals => if currentUser.role == UserRole.Teacher then allAppeals else allAppeals.filter(_.student.id == currentUser.id))
      studentResult <- if currentUser.role == UserRole.Student then buildStudentResult(workspace, currentUser.id).map(Some(_)) else Right(None)
      scoreRows <- if currentUser.role == UserRole.Teacher then buildTeacherScoreRows(workspace) else Right(Nil)
      gradingProgress <- if currentUser.role == UserRole.Teacher then buildGradingProgress(workspace) else Right(Nil)
    yield ExamDetailResponse(
      summary,
      courseSummary,
      questions,
      answerSheets,
      participantStudents,
      if currentUser.role == UserRole.Teacher then buildTeacherTasks(workspace, currentUser.id) else Nil,
      gradingProgress,
      scoreRows,
      appeals,
      studentResult,
      currentUser.role == UserRole.Teacher && canPublishExam(workspace)
    )

  def buildReviewBoard(workspace: Workspace, question: OfflineExamQuestion, mode: ExamReviewOperation, operatorUserId: String): Either[String, ExamReviewBoardResponse] =
    for
      items <- traverse(sheetsForQuestion(workspace, question.id).zipWithIndex) { case (sheet, index) =>
        val graderScores = question.scoring.graderTeacherIds.flatMap(teacherId => gradingForTeacher(workspace, sheet.id, teacherId).map(_.score))
        val currentScore = mode match
          case ExamReviewOperation.Grading => gradingForTeacher(workspace, sheet.id, operatorUserId).map(_.score)
          case ExamReviewOperation.Arbitration => arbitrationForSheet(workspace, sheet.id).map(_.decidedScore)
          case ExamReviewOperation.Appeal => appealForTeacher(workspace, sheet.id, operatorUserId).flatMap(_.resolvedScore)
        val appealEither = appealForTeacher(workspace, sheet.id, operatorUserId) match
          case Some(appeal) => buildAppeal(workspace, appeal).map(Some(_))
          case None => Right(None)
        appealEither.map { appeal =>
          val status =
            if mode == ExamReviewOperation.Arbitration then if needsArbitration(workspace, question, sheet) then currentScore.map(_ => ExamReviewItemStatus.Completed).getOrElse(ExamReviewItemStatus.Pending) else ExamReviewItemStatus.NotNeeded
            else if mode == ExamReviewOperation.Appeal then appeal.map(current => if current.status == ExamAppealStatus.Resolved then ExamReviewItemStatus.Completed else ExamReviewItemStatus.Pending).getOrElse(ExamReviewItemStatus.NotNeeded)
            else currentScore.map(_ => ExamReviewItemStatus.Completed).getOrElse(ExamReviewItemStatus.Pending)
          ExamReviewItemResponse(sheet.id, s"答卷 ${index + 1}", status, currentScore, sheet.images, appeal, graderScores)
        }
      }
      summary <- buildExamSummary(workspace)
      courseSummary <- buildCourseSummary(workspace.course, workspace.users)
      scoring <- buildQuestionScoring(workspace, question.scoring)
      visibleItems = if mode == ExamReviewOperation.Arbitration || mode == ExamReviewOperation.Appeal then items.filter(_.status != ExamReviewItemStatus.NotNeeded) else items
      pendingItems = visibleItems.filter(_.status == ExamReviewItemStatus.Pending)
      completedItems = visibleItems.filter(_.status == ExamReviewItemStatus.Completed)
    yield ExamReviewBoardResponse(summary, courseSummary, ExamQuestionResponse(question.id, question.examId, question.title, question.position, scoring), mode, pendingItems, completedItems, pendingItems.headOption.orElse(completedItems.headOption))

  def validateAccessibleExam(workspace: Workspace, operatorUserId: String): Either[String, UserAccount] =
    workspace.users.get(operatorUserId).filter(user => isCurrentCourseMember(workspace.course, user.id) && isContentVisibleToUser(workspace.course, user.id, workspace.exam.createdAt)).toRight("当前用户不可访问该考试")

  def validateTeacherQuestion(workspace: Workspace, questionId: String, operatorUserId: String): Either[String, OfflineExamQuestion] =
    for
      user <- workspace.users.get(operatorUserId).filter(_.role == UserRole.Teacher).toRight("只有本课程老师可以导入考试答题图片")
      question <- workspace.questions.get(questionId).toRight("考试题目不存在")
      _ <- Either.cond(question.examId == workspace.exam.id && isCurrentTeacher(workspace.course, user.id) && isContentVisibleToUser(workspace.course, user.id, workspace.exam.createdAt), (), "只有本课程老师可以导入考试答题图片")
    yield question

  def validateReviewModeAccess(question: OfflineExamQuestion, mode: ExamReviewOperation, operatorUserId: String): Either[String, Unit] =
    mode match
      case ExamReviewOperation.Grading => Either.cond(question.scoring.graderTeacherIds.contains(operatorUserId), (), "当前老师无权批改这道题")
      case ExamReviewOperation.Arbitration => Either.cond(question.scoring.arbitrationTeacherId.contains(operatorUserId), (), "当前老师无权仲裁这道题")
      case ExamReviewOperation.Appeal => Either.cond(question.scoring.appealTeacherId.contains(operatorUserId), (), "当前老师无权处理这道题的申诉")

  def sheetForQuestionStudent(workspace: Workspace, questionId: String, studentId: String): Option[ExamAnswerSheet] =
    workspace.answerSheets.values.find(sheet => sheet.questionId == questionId && sheet.studentId == studentId)

  def pendingAppealExists(workspace: Workspace, answerSheetId: String): Boolean =
    appealsForSheet(workspace, answerSheetId).exists(_.status == ExamAppealStatus.Pending)

  def resolvedQuestionOutcome(workspace: Workspace, question: OfflineExamQuestion, answerSheet: ExamAnswerSheet): Option[ResolvedQuestionOutcome] =
    latestAppealForSheet(workspace, answerSheet.id) match
      case Some(appeal) if appeal.status == ExamAppealStatus.Resolved && appeal.resolvedScore.nonEmpty => Some(ResolvedQuestionOutcome(ExamQuestionResultStatus.AppealResolved, appeal.resolvedScore.map(BigDecimal(_))))
      case Some(appeal) if appeal.status == ExamAppealStatus.Pending => baseQuestionOutcome(workspace, question, answerSheet).map(outcome => outcome.copy(status = ExamQuestionResultStatus.AppealPending))
      case _ => baseQuestionOutcome(workspace, question, answerSheet)

  def canPublishExam(workspace: Workspace): Boolean =
    val questions = sortedQuestions(workspace)
    val eligibleStudents = courseStudentsAt(workspace.course, workspace.exam.createdAt).filter(isCurrentStudent(workspace.course, _))
    eligibleStudents.nonEmpty && questions.nonEmpty && eligibleStudents.forall { studentId =>
      questions.forall { question =>
        sheetForQuestionStudent(workspace, question.id, studentId).flatMap(sheet => resolvedQuestionOutcome(workspace, question, sheet).flatMap(_.finalScore)).nonEmpty
      }
    }

  def needsArbitration(workspace: Workspace, question: OfflineExamQuestion, answerSheet: ExamAnswerSheet): Boolean =
    if !question.scoring.arbitrationEnabled then false
    else
      val gradings = question.scoring.graderTeacherIds.flatMap(teacherId => gradingForTeacher(workspace, answerSheet.id, teacherId))
      gradings.length == 2 && (gradings(0).score - gradings(1).score).abs > question.scoring.arbitrationScoreDiffThreshold.getOrElse(Int.MaxValue)

  def appealForTeacher(workspace: Workspace, answerSheetId: String, teacherId: String): Option[ExamQuestionAppeal] =
    appealsForSheet(workspace, answerSheetId).find(_.appealTeacherId == teacherId)

  private def buildExamSummary(workspace: Workspace): Either[String, ExamSummary] =
    workspace.users.get(workspace.exam.createdByTeacherId).toRight("考试创建者不存在").map { creator =>
      ExamSummary(workspace.exam.id, workspace.exam.courseId, workspace.exam.title, toPublicUser(creator), workspace.exam.createdAt, workspace.exam.publishedAt, workspace.exam.questionIds.length, workspace.exam.appealDueAt)
    }

  private def buildCourseSummary(course: Course, users: Map[String, UserAccount]): Either[String, CourseSummary] =
    Right(CourseSummary(course.id, course.title, course.description, course.teachers.flatMap(users.get).map(toPublicUser), course.students.flatMap(users.get).map(toPublicUser), course.createdAt))

  private def buildExamQuestions(workspace: Workspace): Either[String, List[ExamQuestionResponse]] =
    traverse(sortedQuestions(workspace))(question => buildQuestionScoring(workspace, question.scoring).map(scoring => ExamQuestionResponse(question.id, question.examId, question.title, question.position, scoring)))

  private def buildQuestionScoring(workspace: Workspace, scoring: ExamQuestionScoring): Either[String, ExamQuestionScoringResponse] =
    for
      graders <- traverse(scoring.graderTeacherIds)(teacherId => workspace.users.get(teacherId).toRight("考试批改教师不存在").map(toPublicUser))
      arbitrationTeacher <- scoring.arbitrationTeacherId match
        case Some(teacherId) => workspace.users.get(teacherId).toRight("考试仲裁教师不存在").map(user => Some(toPublicUser(user)))
        case None => Right(None)
      appealTeacher <- scoring.appealTeacherId match
        case Some(teacherId) => workspace.users.get(teacherId).toRight("考试申诉处理教师不存在").map(user => Some(toPublicUser(user)))
        case None => Right(None)
    yield ExamQuestionScoringResponse(scoring.fullScore, graders, scoring.arbitrationEnabled, scoring.arbitrationScoreDiffThreshold, arbitrationTeacher, scoring.appealEnabled, appealTeacher)

  private def buildAnswerSheets(workspace: Workspace): Either[String, List[ExamAnswerSheetResponse]] =
    traverse(workspace.answerSheets.values.toList.sortBy(_.studentId)) { sheet =>
      workspace.users.get(sheet.studentId).toRight("答卷关联的学生不存在").map { student =>
        ExamAnswerSheetResponse(sheet.id, sheet.examId, sheet.questionId, toPublicUser(student), sheet.images)
      }
    }

  private def buildTeacherTasks(workspace: Workspace, teacherId: String): List[ExamTeacherTaskResponse] =
    sortedQuestions(workspace).flatMap { question =>
      val sheets = sheetsForQuestion(workspace, question.id)
      val gradingTask = Option.when(question.scoring.graderTeacherIds.contains(teacherId))(ExamTeacherTaskResponse(workspace.exam.id, workspace.exam.title, question.id, question.title, question.position, ExamReviewOperation.Grading, sheets.count(sheet => gradingForTeacher(workspace, sheet.id, teacherId).isEmpty), sheets.count(sheet => gradingForTeacher(workspace, sheet.id, teacherId).nonEmpty)))
      val arbitrationTask = Option.when(question.scoring.arbitrationTeacherId.contains(teacherId))(ExamTeacherTaskResponse(workspace.exam.id, workspace.exam.title, question.id, question.title, question.position, ExamReviewOperation.Arbitration, sheets.count(sheet => needsArbitration(workspace, question, sheet) && arbitrationForSheet(workspace, sheet.id).isEmpty), sheets.count(sheet => arbitrationForSheet(workspace, sheet.id).nonEmpty)))
      val appealTask = Option.when(question.scoring.appealTeacherId.contains(teacherId))(ExamTeacherTaskResponse(workspace.exam.id, workspace.exam.title, question.id, question.title, question.position, ExamReviewOperation.Appeal, sheets.count(sheet => appealForTeacher(workspace, sheet.id, teacherId).exists(_.status == ExamAppealStatus.Pending)), sheets.count(sheet => appealForTeacher(workspace, sheet.id, teacherId).exists(_.status == ExamAppealStatus.Resolved))))
      List(gradingTask, arbitrationTask, appealTask).flatten
    }.filter(task => task.pendingCount > 0 || task.completedCount > 0)

  private def buildGradingProgress(workspace: Workspace): Either[String, List[ExamQuestionGradingProgressResponse]] =
    traverse(sortedQuestions(workspace)) { question =>
      traverse(question.scoring.graderTeacherIds) { teacherId =>
        workspace.users.get(teacherId).toRight("考试批改教师不存在").map { teacher =>
          val sheets = sheetsForQuestion(workspace, question.id)
          val gradedCount = sheets.count(sheet => gradingForTeacher(workspace, sheet.id, teacherId).nonEmpty)
          ExamQuestionGraderProgressResponse(
            grader = toPublicUser(teacher),
            gradedCount = gradedCount,
            pendingGradingCount = Math.max(0, sheets.length - gradedCount),
            missingImportCount = Math.max(0, courseStudentsAt(workspace.course, workspace.exam.createdAt).count(isCurrentStudent(workspace.course, _)) - sheets.length)
          )
        }
      }.map { graderProgress =>
        ExamQuestionGradingProgressResponse(question.id, question.title, question.position, graderProgress)
      }
    }

  private def buildStudentResult(workspace: Workspace, studentId: String): Either[String, ExamStudentResultResponse] =
    val questions = sortedQuestions(workspace)
    traverse(questions) { question =>
      val sheet = sheetForQuestionStudent(workspace, question.id, studentId)
      val outcome = sheet.flatMap(currentSheet => resolvedQuestionOutcome(workspace, question, currentSheet))
      val appealEither = sheet.flatMap(currentSheet => latestAppealForSheet(workspace, currentSheet.id)) match
        case Some(appeal) => buildAppeal(workspace, appeal).map(Some(_))
        case None => Right(None)
      appealEither.map { appeal =>
        ExamQuestionResultResponse(question.id, question.title, question.position, question.scoring.fullScore, if workspace.exam.publishedAt.nonEmpty then outcome.flatMap(_.finalScore) else None, outcome.map(_.status).getOrElse(ExamQuestionResultStatus.Missing), appeal, canStudentAppealQuestion(workspace.exam, question, outcome, appeal, Instant.now()))
      }
    }.map { questionResults =>
      ExamStudentResultResponse(workspace.exam.publishedAt.nonEmpty, questions.map(_.scoring.fullScore).sum, Option.when(workspace.exam.publishedAt.nonEmpty && questionResults.forall(_.score.nonEmpty))(questionResults.flatMap(_.score).foldLeft(BigDecimal(0))(_ + _)), questionResults)
    }

  private def buildTeacherScoreRows(workspace: Workspace): Either[String, List[ExamTeacherScoreRowResponse]] =
    val questions = sortedQuestions(workspace)
    traverse(courseStudentsAt(workspace.course, workspace.exam.createdAt).filter(isCurrentStudent(workspace.course, _))) { studentId =>
      workspace.users.get(studentId).toRight("考试成绩表中的学生不存在").map { student =>
        val cells = questions.map { question =>
          val outcome = sheetForQuestionStudent(workspace, question.id, student.id).flatMap(sheet => resolvedQuestionOutcome(workspace, question, sheet))
          ExamTeacherScoreCellResponse(question.id, question.title, question.position, question.scoring.fullScore, outcome.flatMap(_.finalScore), outcome.map(_.status).getOrElse(ExamQuestionResultStatus.Missing))
        }
        val totalScore = Option.when(workspace.exam.publishedAt.nonEmpty && cells.forall(_.score.nonEmpty))(cells.flatMap(_.score).foldLeft(BigDecimal(0))(_ + _))
        ExamTeacherScoreRowResponse(toPublicUser(student), totalScore, cells)
      }
    }.map(_.sortBy(_.totalScore.getOrElse(BigDecimal(-1)))(Ordering[BigDecimal].reverse))

  private def buildAppeals(workspace: Workspace): Either[String, List[ExamQuestionAppealResponse]] =
    traverse(workspace.appeals.values.toList.sortBy(_.submittedAt)(Ordering[Instant].reverse))(buildAppeal(workspace, _))

  private def buildAppeal(workspace: Workspace, appeal: ExamQuestionAppeal): Either[String, ExamQuestionAppealResponse] =
    for
      student <- workspace.users.get(appeal.studentId).toRight("申诉关联的学生不存在")
      appealTeacher <- workspace.users.get(appeal.appealTeacherId).toRight("申诉处理教师不存在")
    yield ExamQuestionAppealResponse(appeal.id, appeal.questionId, appeal.answerSheetId, toPublicUser(student), toPublicUser(appealTeacher), appeal.expectedScore, appeal.reason, appeal.status, appeal.submittedAt, appeal.resolvedAt, appeal.resolvedScore)

  private def baseQuestionOutcome(workspace: Workspace, question: OfflineExamQuestion, answerSheet: ExamAnswerSheet): Option[ResolvedQuestionOutcome] =
    val gradings = gradingsForSheet(workspace, answerSheet.id)
    val graderScores = question.scoring.graderTeacherIds.flatMap(teacherId => gradings.find(_.graderTeacherId == teacherId))
    if graderScores.isEmpty then Some(ResolvedQuestionOutcome(ExamQuestionResultStatus.Pending, None))
    else if question.scoring.graderTeacherIds.length == 1 then graderScores.headOption.map(grading => ResolvedQuestionOutcome(ExamQuestionResultStatus.Graded, Some(BigDecimal(grading.score))))
    else if graderScores.length < 2 then Some(ResolvedQuestionOutcome(ExamQuestionResultStatus.Pending, None))
    else
      val diff = (graderScores(0).score - graderScores(1).score).abs
      if !question.scoring.arbitrationEnabled || diff <= question.scoring.arbitrationScoreDiffThreshold.getOrElse(Int.MaxValue) then
        Some(ResolvedQuestionOutcome(ExamQuestionResultStatus.Graded, Some(((BigDecimal(graderScores(0).score) + BigDecimal(graderScores(1).score)) / BigDecimal(2)).setScale(1, RoundingMode.HALF_UP))))
      else arbitrationForSheet(workspace, answerSheet.id).map(arbitration => ResolvedQuestionOutcome(ExamQuestionResultStatus.Arbitrated, Some(BigDecimal(arbitration.decidedScore)))).orElse(Some(ResolvedQuestionOutcome(ExamQuestionResultStatus.WaitingArbitration, None)))

  private def canStudentAppealQuestion(exam: OfflineExam, question: OfflineExamQuestion, outcome: Option[ResolvedQuestionOutcome], appeal: Option[ExamQuestionAppealResponse], now: Instant): Boolean =
    exam.publishedAt.nonEmpty && exam.appealDueAt.exists(!now.isAfter(_)) && question.scoring.appealEnabled && outcome.flatMap(_.finalScore).exists(_ < BigDecimal(question.scoring.fullScore)) && appeal.forall(_.status != ExamAppealStatus.Pending)

  private def sortedQuestions(workspace: Workspace): List[OfflineExamQuestion] =
    workspace.exam.questionIds.flatMap(workspace.questions.get).sortBy(_.position)

  private def sheetsForQuestion(workspace: Workspace, questionId: String): List[ExamAnswerSheet] =
    workspace.answerSheets.values.toList.filter(_.questionId == questionId).sortBy(_.studentId)

  private def gradingForTeacher(workspace: Workspace, answerSheetId: String, teacherId: String): Option[ExamQuestionGrading] =
    workspace.gradings.values.find(grading => grading.answerSheetId == answerSheetId && grading.graderTeacherId == teacherId)

  private def gradingsForSheet(workspace: Workspace, answerSheetId: String): List[ExamQuestionGrading] =
    workspace.gradings.values.toList.filter(_.answerSheetId == answerSheetId)

  private def arbitrationForSheet(workspace: Workspace, answerSheetId: String): Option[ExamQuestionArbitration] =
    workspace.arbitrations.values.find(_.answerSheetId == answerSheetId)

  private def appealsForSheet(workspace: Workspace, answerSheetId: String): List[ExamQuestionAppeal] =
    workspace.appeals.values.toList.filter(_.answerSheetId == answerSheetId).sortBy(_.submittedAt)(Ordering[Instant].reverse)

  private def latestAppealForSheet(workspace: Workspace, answerSheetId: String): Option[ExamQuestionAppeal] =
    appealsForSheet(workspace, answerSheetId).headOption

  private def traverse[A, B](items: Iterable[A])(f: A => Either[String, B]): Either[String, List[B]] =
    items.foldLeft[Either[String, List[B]]](Right(Nil)) { (accumulator, item) =>
      for
        values <- accumulator
        value <- f(item)
      yield values :+ value
    }
