package microservices.exam.tables

object ExamTableInitializer:
  val initSql: List[String] = List(
    """
      |create table if not exists teaching_exams (
      |  id text primary key,
      |  course_id text not null,
      |  title text not null,
      |  description text not null,
      |  created_by_teacher_id text not null,
      |  created_at timestamptz not null,
      |  published_at timestamptz,
      |  question_ids text not null,
      |  appeal_due_at timestamptz
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_exam_questions (
      |  id text primary key,
      |  exam_id text not null,
      |  title text not null,
      |  position integer not null,
      |  scoring text not null
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_exam_answer_sheets (
      |  id text primary key,
      |  exam_id text not null,
      |  question_id text not null,
      |  student_id text not null,
      |  images text not null,
      |  uploaded_by_teacher_id text,
      |  uploaded_at timestamptz
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_exam_question_reviews (
      |  id text primary key,
      |  answer_sheet_id text not null,
      |  grader_teacher_id text not null,
      |  score integer not null,
      |  comment text,
      |  reviewed_at timestamptz not null
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_exam_question_arbitrations (
      |  id text primary key,
      |  answer_sheet_id text not null,
      |  arbitration_teacher_id text not null,
      |  decided_score integer not null,
      |  comment text,
      |  decided_at timestamptz not null
      |);
      |""".stripMargin,
    """
      |create table if not exists teaching_exam_question_appeals (
      |  id text primary key,
      |  answer_sheet_id text not null,
      |  question_id text not null,
      |  student_id text not null,
      |  appeal_teacher_id text not null,
      |  expected_score integer not null,
      |  reason text not null,
      |  status text not null,
      |  submitted_at timestamptz not null,
      |  resolved_at timestamptz,
      |  resolved_score integer,
      |  resolution_comment text
      |);
      |""".stripMargin
  )

  val migrationSql: List[String] = List(
    "alter table teaching_exams alter column question_ids type text using question_ids::text",
    "alter table teaching_exams add column if not exists appeal_due_at timestamptz",
    "alter table teaching_exam_questions alter column scoring type text using scoring::text",
    "alter table teaching_exam_answer_sheets alter column images type text using images::text",
    "alter table teaching_exam_answer_sheets alter column uploaded_by_teacher_id drop not null",
    "alter table teaching_exam_answer_sheets alter column uploaded_at drop not null"
  )

  val tableNames: List[String] = List(
    "teaching_exam_question_appeals",
    "teaching_exam_question_arbitrations",
    "teaching_exam_question_reviews",
    "teaching_exam_answer_sheets",
    "teaching_exam_questions",
    "teaching_exams"
  )
