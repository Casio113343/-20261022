package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.exam.api.requests.ExamReviewOperation
import microservices.exam.api.responses.ExamReviewBoardResponse
import microservices.exam.tables.ExamWorkspaceReads

final case class ExamReviewBoardAPIMessage(examId: String, questionId: String, userId: String, mode: ExamReviewOperation) extends APIMessage[ExamReviewBoardResponse]:
  def plan: IO[ExamReviewBoardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        ExamWorkspaceReads.loadWorkspace(connection, examId).map {
          _.flatMap { workspace =>
            for
              question <- ExamWorkspaceReads.validateTeacherQuestion(workspace, questionId, userId)
              _ <- ExamWorkspaceReads.validateReviewModeAccess(question, mode, userId)
              board <- ExamWorkspaceReads.buildReviewBoard(workspace, question, mode, userId)
            yield board
          }
        }
      }
      response <- resolveEither(result)
    yield response

object ExamReviewBoardAPIMessage:
  given Codec.AsObject[ExamReviewBoardAPIMessage] = deriveCodec
