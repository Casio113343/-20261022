package microservices.exam.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class ExamQuestionAppeal(
    id: String,
    answerSheetId: String,
    questionId: String,
    studentId: String,
    appealTeacherId: String,
    expectedScore: Int,
    reason: String,
    status: ExamAppealStatus,
    submittedAt: Instant,
    resolvedAt: Option[Instant],
    resolvedScore: Option[Int]
)

object ExamQuestionAppeal:
  given Encoder[ExamQuestionAppeal] = deriveEncoder[ExamQuestionAppeal]
  given Decoder[ExamQuestionAppeal] = deriveDecoder[ExamQuestionAppeal]
