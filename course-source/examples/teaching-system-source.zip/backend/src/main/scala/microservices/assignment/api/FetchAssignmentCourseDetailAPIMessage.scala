package microservices.assignment.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.tables.AssignmentTableReads
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.support.CourseAccessSupport.isCurrentCourseMember
import microservices.course.tables.CourseTableReads

final case class FetchAssignmentCourseDetailAPIMessage(assignmentId: String, userId: String) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        CourseTableReads.lookupCourseId(connection, AssignmentTableReads.courseIdByAssignmentIdSql, assignmentId).flatMap {
          case Some(courseId) =>
            for
              assignmentEither <- AssignmentTableReads.loadAssignmentById(connection, assignmentId)
              courseEither <- CourseTableReads.loadCourseById(connection, courseId)
              detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, userId)
            yield for
              assignment <- assignmentEither
              course <- courseEither
              _ <- Either.cond(assignment.courseId == course.id, (), "作业所属课程不存在")
              _ <- Either.cond(isCurrentCourseMember(course, userId), (), "当前用户不可访问该作业")
              detail <- detailEither
            yield detail
          case None => IO.pure(Left("作业不存在"))
        }
      }
      response <- resolveEither(result)
    yield response

object FetchAssignmentCourseDetailAPIMessage:
  given Codec.AsObject[FetchAssignmentCourseDetailAPIMessage] = deriveCodec
