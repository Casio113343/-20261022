package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.course.api.responses.CourseDetailResponse
import microservices.auth.objects.UserRole
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.tables.{CourseTableReads, CourseTableWrites}

final case class DeleteAnnouncementAPIMessage(courseId: String, announcementId: String, userId: String) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          announcementEither <- CourseTableReads.loadAnnouncementById(connection, announcementId)
          validationEither = for
            course <- courseEither
            user <- userEither
            announcement <- announcementEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(announcement.courseId == course.id, (), "通知不属于当前课程")
          yield (course.teachers ++ course.students).distinct
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseMemberIds) =>
              for
                _ <- IO.blocking {
                  CourseTableWrites.deleteAnnouncement(connection, announcementId)
                }
                usersEither <- AuthTableReads.loadUsersByIds(connection, courseMemberIds)
                userReadMarkersCleared <- usersEither match
                  case Left(error) => IO.pure(Left(error))
                  case Right(users) =>
                    val updatedUsers = users.values.toList
                      .map(user => user.copy(readAnnouncementIds = user.readAnnouncementIds.filterNot(_ == announcementId)))
                      .filter(user => users(user.id).readAnnouncementIds != user.readAnnouncementIds)
                    IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
                detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, userId)
              yield for
                _ <- userReadMarkersCleared
                detail <- detailEither
              yield detail
        yield result
      }
      response <- resolveEither(result)
    yield response

object DeleteAnnouncementAPIMessage:
  given Codec.AsObject[DeleteAnnouncementAPIMessage] = deriveCodec
