package microservices.dashboard.tables

import shared.jdbc.JdbcStatementSupport.{setInstant, withPrepared}
import microservices.dashboard.objects.SystemNotification

import java.sql.Connection

object DashboardTableWrites:
  def saveSystemNotifications(connection: Connection, notifications: Iterable[SystemNotification]): Unit =
    notifications.foreach(insertSystemNotification(connection, _))

  def upsertSystemNotification(connection: Connection, notification: SystemNotification): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_system_notifications (id, user_id, message, created_at)
        |values (?, ?, ?, ?)
        |on conflict (id) do update
        |set user_id = excluded.user_id,
        |    message = excluded.message,
        |    created_at = excluded.created_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, notification.id)
      statement.setString(2, notification.userId)
      statement.setString(3, notification.message)
      setInstant(statement, 4, notification.createdAt)
      statement.executeUpdate()
    }

  def deleteSystemNotification(connection: Connection, notificationId: String): Unit =
    withPrepared(connection, "delete from teaching_system_notifications where id = ?") { statement =>
      statement.setString(1, notificationId)
      statement.executeUpdate()
    }

  private def insertSystemNotification(connection: Connection, notification: SystemNotification): Unit =
    upsertSystemNotification(connection, notification)
