package microservices.questionnaire.tables

import io.circe.syntax.*
import microservices.questionnaire.objects.{Questionnaire, QuestionnaireSubmission}
import shared.jdbc.JdbcStatementSupport.{setInstant, setStringOpt, withPrepared}

import java.sql.Connection

object QuestionnaireTableWrites:
  def upsertQuestionnaire(connection: Connection, questionnaire: Questionnaire): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_questionnaires (id, course_id, title, overview, anonymous, questions, due_at, created_by_teacher_id, created_at)
        |values (?, ?, ?, ?, ?, ?::jsonb, ?, ?, ?)
        |on conflict (id) do update
        |set course_id = excluded.course_id,
        |    title = excluded.title,
        |    overview = excluded.overview,
        |    anonymous = excluded.anonymous,
        |    questions = excluded.questions,
        |    due_at = excluded.due_at,
        |    created_by_teacher_id = excluded.created_by_teacher_id,
        |    created_at = excluded.created_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, questionnaire.id)
      statement.setString(2, questionnaire.courseId)
      statement.setString(3, questionnaire.title)
      setStringOpt(statement, 4, questionnaire.overview)
      statement.setBoolean(5, questionnaire.anonymous)
      statement.setString(6, questionnaire.questions.asJson.noSpaces)
      setInstant(statement, 7, questionnaire.dueAt)
      statement.setString(8, questionnaire.createdByTeacherId)
      setInstant(statement, 9, questionnaire.createdAt)
      statement.executeUpdate()
    }

  def insertSubmission(connection: Connection, submission: QuestionnaireSubmission): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_questionnaire_submissions (id, questionnaire_id, student_id, answers, submitted_at)
        |values (?, ?, ?, ?::jsonb, ?)
        |""".stripMargin
    ) { statement =>
      statement.setString(1, submission.id)
      statement.setString(2, submission.questionnaireId)
      statement.setString(3, submission.studentId)
      statement.setString(4, submission.answers.asJson.noSpaces)
      setInstant(statement, 5, submission.submittedAt)
      statement.executeUpdate()
    }

  def deleteQuestionnaire(connection: Connection, questionnaireId: String): Unit =
    withPrepared(connection, "delete from teaching_questionnaire_submissions where questionnaire_id = ?") { statement =>
      statement.setString(1, questionnaireId)
      statement.executeUpdate()
    }
    withPrepared(connection, "delete from teaching_questionnaires where id = ?") { statement =>
      statement.setString(1, questionnaireId)
      statement.executeUpdate()
    }
