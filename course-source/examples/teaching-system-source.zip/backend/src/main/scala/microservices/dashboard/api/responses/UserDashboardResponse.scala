package microservices.dashboard.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import microservices.exam.api.responses.ExamTeacherTask

final case class UserDashboardResponse(
    currentUser: PublicUser,
    courseSummaries: List[DashboardCourseSummary],
    reviewTasks: List[AssignmentReviewTask],
    examReviewTasks: List[ExamTeacherTask],
    systemNotifications: List[SystemNotificationSummary]
)

object UserDashboardResponse:
  given Codec[UserDashboardResponse] = deriveCodec
