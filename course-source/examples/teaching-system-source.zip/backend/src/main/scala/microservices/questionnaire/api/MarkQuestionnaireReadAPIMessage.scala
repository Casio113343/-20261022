package microservices.questionnaire.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.support.CourseAccessSupport.{isContentVisibleToUser, isCurrentTeacher}
import microservices.course.tables.CourseTableReads
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.dashboard.tables.DashboardTableReads
import microservices.questionnaire.tables.QuestionnaireTableReads

final case class MarkQuestionnaireReadAPIMessage(questionnaireId: String, userId: String) extends APIMessage[UserDashboardResponse]:
  def plan: IO[UserDashboardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          questionnaireEither <- QuestionnaireTableReads.loadQuestionnaireById(connection, questionnaireId)
          courseEither <- questionnaireEither match
            case Left(error) => IO.pure(Left(error))
            case Right(questionnaire) => CourseTableReads.loadCourseById(connection, questionnaire.courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          validationEither = for
            questionnaire <- questionnaireEither
            course <- courseEither
            user <- userEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以标记问卷已读")
            _ <- Either.cond(isContentVisibleToUser(course, user.id, questionnaire.createdAt), (), "当前用户不可访问该问卷")
          yield (user, questionnaire.id)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((user, readQuestionnaireId)) =>
              for
                userReadUpdate <- IO.blocking {
                  AuthTableWrites.upsertUser(connection, user.copy(readQuestionnaireIds = (user.readQuestionnaireIds :+ readQuestionnaireId).distinct))
                }.as(Right(()): Either[String, Unit])
                dashboardEither <- DashboardTableReads.loadDashboardFromTables(connection, userId)
              yield for
                _ <- userReadUpdate
                dashboard <- dashboardEither
              yield dashboard
        yield result
      }
      response <- resolveEither(result)
    yield response

object MarkQuestionnaireReadAPIMessage:
  given Codec.AsObject[MarkQuestionnaireReadAPIMessage] = deriveCodec
