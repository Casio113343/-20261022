package microservices.exam.api.responses

import io.circe.{Decoder, Encoder}

enum ExamReviewItemStatus(val value: String):
  case Pending extends ExamReviewItemStatus("pending")
  case Completed extends ExamReviewItemStatus("completed")
  case NotNeeded extends ExamReviewItemStatus("not-needed")

object ExamReviewItemStatus:
  given Encoder[ExamReviewItemStatus] = Encoder.encodeString.contramap(_.value)
  given Decoder[ExamReviewItemStatus] = Decoder.decodeString.emap {
    case Pending.value => Right(Pending)
    case Completed.value => Right(Completed)
    case NotNeeded.value => Right(NotNeeded)
    case value => Left(s"未知批改条目状态: $value")
  }
