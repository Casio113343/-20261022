package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

final case class ExamTeacherScoreCell(
    questionId: String,
    title: String,
    position: Int,
    fullScore: Int,
    score: Option[BigDecimal],
    status: ExamQuestionResultStatus
)
object ExamTeacherScoreCell:
  given Codec[ExamTeacherScoreCell] = deriveCodec
