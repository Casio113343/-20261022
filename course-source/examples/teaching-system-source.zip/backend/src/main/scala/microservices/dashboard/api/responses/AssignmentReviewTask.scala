package microservices.dashboard.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.assignment.objects.{Assignment, AssignmentSubmission}
import microservices.course.api.responses.CourseSummary

final case class AssignmentReviewTask(
    submission: AssignmentSubmission,
    assignment: Assignment,
    course: CourseSummary
)

object AssignmentReviewTask:
  given Codec[AssignmentReviewTask] = deriveCodec
