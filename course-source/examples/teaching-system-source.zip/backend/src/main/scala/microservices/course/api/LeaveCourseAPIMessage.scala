package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.assignment.tables.{AssignmentTableReads, AssignmentTableWrites}
import microservices.course.objects.{CourseMemberAction, CourseMemberEvent}
import microservices.exam.objects.ExamAppealStatus
import microservices.course.support.CourseAccessSupport.isCurrentCourseMember
import microservices.course.tables.{CourseTableReads, CourseTableWrites}
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.dashboard.objects.SystemNotification
import microservices.dashboard.tables.{DashboardTableReads, DashboardTableWrites}
import microservices.exam.tables.{ExamTableReads, ExamTableWrites}
import shared.id.IdGenerator

import java.time.Instant

final case class LeaveCourseAPIMessage(courseId: String, userId: String) extends APIMessage[UserDashboardResponse]:
  def plan: IO[UserDashboardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          assignmentsEither <- AssignmentTableReads.loadAssignmentsByCourseIds(connection, List(courseId))
          submissionsEither <- assignmentsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(assignments) => AssignmentTableReads.loadSubmissionsByAssignmentIds(connection, assignments.keys)
          reviewsEither <- submissionsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(submissions) => AssignmentTableReads.loadReviewsBySubmissionIds(connection, submissions.keys)
          examsEither <- ExamTableReads.loadExamsByCourseIds(connection, List(courseId))
          questionsEither <- examsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(exams) => ExamTableReads.loadExamQuestionsByExamIds(connection, exams.keys)
          answerSheetsEither <- examsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(exams) => ExamTableReads.loadAnswerSheetsByExamIds(connection, exams.keys)
          appealsEither <- (answerSheetsEither, questionsEither) match
            case (Right(answerSheets), Right(questions)) => ExamTableReads.loadQuestionAppeals(connection, answerSheets.keys, questions.keys)
            case (Left(error), _) => IO.pure(Left(error))
            case (_, Left(error)) => IO.pure(Left(error))
          validationEither = for
            user <- userEither
            course <- courseEither
            assignments <- assignmentsEither
            submissions <- submissionsEither
            reviews <- reviewsEither
            exams <- examsEither
            questions <- questionsEither
            answerSheets <- answerSheetsEither
            appeals <- appealsEither
            _ <- Either.cond(isCurrentCourseMember(course, user.id), (), "当前用户不可访问该课程")
            next <- user.role match
              case UserRole.Student =>
                val nextCourse = course.copy(
                  students = course.students.filterNot(_ == user.id),
                  memberEvents = course.memberEvents :+ CourseMemberEvent(user.id, UserRole.Student, CourseMemberAction.Left, now),
                )
                val unpublishedExamIds = exams.valuesIterator.filter(exam => exam.courseId == course.id && exam.publishedAt.isEmpty).map(_.id).toSet
                val unpublishedQuestionIds = questions.valuesIterator.filter(question => unpublishedExamIds.contains(question.examId)).map(_.id).toSet
                val removedSheetIds = answerSheets.valuesIterator
                  .filter(sheet => unpublishedExamIds.contains(sheet.examId) && sheet.studentId == user.id)
                  .map(_.id)
                  .toSet
                val removedAppealQuestionIds = appeals.valuesIterator
                  .filter(appeal => unpublishedQuestionIds.contains(appeal.questionId) && appeal.studentId == user.id)
                  .map(_.questionId)
                  .toSet
                Right(nextCourse, Nil, removedSheetIds, removedAppealQuestionIds)
              case UserRole.Teacher =>
                val assignmentReasons = assignments.values.toList.collect {
                  case assignment if assignment.courseId == course.id && assignment.graderTeacherId == user.id =>
                    val assignmentSubmissions = submissions.values.toList.filter(_.assignmentId == assignment.id)
                    val hasPendingReviews = assignmentSubmissions.exists(submission => reviews.values.forall(_.submissionId != submission.id))
                    if assignment.dueAt.isAfter(now) || hasPendingReviews then Some(s"仍负责作业《${assignment.title}》的批改，且该作业未到期或仍有未批改提交") else None
                }.flatten
                val examRoleReasons = exams.values.toList.collect {
                  case exam if exam.courseId == course.id && exam.publishedAt.isEmpty =>
                    val examQuestions = questions.values.toList.filter(_.examId == exam.id).sortBy(_.position)
                    if examQuestions.exists(question => question.scoring.graderTeacherIds.contains(user.id) || question.scoring.arbitrationTeacherId.contains(user.id)) then Some(s"仍负责未发布考试《${exam.title}》的批改或仲裁") else None
                }.flatten
                val appealReasons = exams.values.toList.collect {
                  case exam if exam.courseId == course.id =>
                    val examQuestions = questions.values.toList.filter(_.examId == exam.id).sortBy(_.position)
                    val examQuestionIds = examQuestions.map(_.id).toSet
                    val responsible = examQuestions.exists(_.scoring.appealTeacherId.contains(user.id))
                    val pendingAppeals = appeals.values.exists(appeal => appeal.appealTeacherId == user.id && examQuestionIds.contains(appeal.questionId) && appeal.status == ExamAppealStatus.Pending)
                    if responsible && (exam.appealDueAt.exists(!now.isAfter(_)) || pendingAppeals) then Some(s"仍负责考试《${exam.title}》的申诉处理，且申诉未到期或仍有未处理申诉") else None
                }.flatten
                val reasons = assignmentReasons ++ examRoleReasons ++ appealReasons
                if reasons.nonEmpty then Left(reasons.mkString("；"))
                else if course.teachers.length <= 1 then Left("课程至少需要保留一名老师")
                else
                  val nextCourse = course.copy(
                    teachers = course.teachers.filterNot(_ == user.id),
                    memberEvents = course.memberEvents :+ CourseMemberEvent(user.id, UserRole.Teacher, CourseMemberAction.Left, now),
                  )
                  val assignmentsToUpdate = assignments.values.toList.collect {
                    case assignment if assignment.courseId == course.id && assignment.graderTeacherId == user.id => assignment.copy(allowLateSubmission = false)
                  }
                  Right(nextCourse, assignmentsToUpdate, Set.empty[String], Set.empty[String])
          yield
            val notification = SystemNotification(IdGenerator.nextId("system-notification"), user.id, s"你退出了课程　${course.title}", now)
            (next._1, next._2, next._3, next._4, notification)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((nextCourse, assignmentsToUpdate, removedSheetIds, removedAppealQuestionIds, notification)) =>
              for
                _ <- IO.blocking {
                  CourseTableWrites.replaceCourse(connection, nextCourse)
                }
                assignmentResponsibilitiesReleased <- IO.blocking(assignmentsToUpdate.foreach(AssignmentTableWrites.upsertAssignment(connection, _))).as(Right(()): Either[String, Unit])
                examAnswersCleared <- IO.blocking {
                  ExamTableWrites.deleteQuestionGradingsByAnswerSheetIds(connection, removedSheetIds)
                  ExamTableWrites.deleteQuestionArbitrationsByAnswerSheetIds(connection, removedSheetIds)
                  ExamTableWrites.deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection, removedSheetIds, removedAppealQuestionIds)
                  removedSheetIds.foreach(ExamTableWrites.deleteExamAnswerSheet(connection, _))
                }.as(Right(()): Either[String, Unit])
                notificationsPublished <- IO.blocking(DashboardTableWrites.upsertSystemNotification(connection, notification)).as(Right(()): Either[String, Unit])
                dashboardEither <- DashboardTableReads.loadDashboardFromTables(connection, userId)
              yield for
                _ <- assignmentResponsibilitiesReleased
                _ <- examAnswersCleared
                _ <- notificationsPublished
                dashboard <- dashboardEither
              yield dashboard
        yield result
      }
      response <- resolveEither(result)
    yield response

object LeaveCourseAPIMessage:
  given Codec.AsObject[LeaveCourseAPIMessage] = deriveCodec
