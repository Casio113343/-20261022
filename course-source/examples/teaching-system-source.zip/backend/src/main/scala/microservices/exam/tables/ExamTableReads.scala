package microservices.exam.tables

import cats.effect.IO
import io.circe.Decoder
import microservices.exam.objects.{ExamAnswerSheet, ExamAppealStatus, ExamQuestionAppeal, ExamQuestionArbitration, ExamQuestionGrading, ExamQuestionScoring, OfflineExam, OfflineExamQuestion}
import infrastructure.storage.Attachment
import shared.jdbc.{JdbcDecodingSupport, JdbcReadSupport}

import java.sql.Connection

object ExamTableReads:
  val courseIdByExamIdSql: String =
    "select course_id from teaching_exams where id = ?"

  def loadExamById(connection: Connection, examId: String): IO[Either[String, OfflineExam]] =
    loadExamsByIds(connection, List(examId)).map(_.flatMap(_.get(examId).toRight("考试不存在")))

  def loadExamsByIds(connection: Connection, examIds: Iterable[String]): IO[Either[String, Map[String, OfflineExam]]] =
    loadExams(connection, "id", examIds)

  def loadExamsByCourseIds(connection: Connection, courseIds: Iterable[String]): IO[Either[String, Map[String, OfflineExam]]] =
    loadExams(connection, "course_id", courseIds)

  private def loadExams(connection: Connection, filterColumn: String, filterIds: Iterable[String]): IO[Either[String, Map[String, OfflineExam]]] =
    import JdbcReadSupport.*
    val ids = filterIds.toList.distinct
    given Decoder[List[String]] = Decoder.decodeList(Decoder.decodeString)
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          s"""
            |select id, course_id, title, created_by_teacher_id, created_at, published_at, question_ids, appeal_due_at
            |from teaching_exams
            |where $filterColumn in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              decodeJson[List[String]](row.getString("question_ids"), "exam question ids").map { questionIds =>
                OfflineExam(
                  id = row.getString("id"),
                  courseId = row.getString("course_id"),
                  title = row.getString("title"),
                  createdByTeacherId = row.getString("created_by_teacher_id"),
                  createdAt = readInstant(row, "created_at"),
                  publishedAt = readInstantOpt(row, "published_at"),
                  questionIds = questionIds,
                  appealDueAt = readInstantOpt(row, "appeal_due_at")
                )
              }
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadExamQuestionById(connection: Connection, questionId: String): IO[Either[String, OfflineExamQuestion]] =
    loadExamQuestionsByIds(connection, List(questionId)).map(_.flatMap(_.get(questionId).toRight("考试题目不存在")))

  def loadExamQuestionsByIds(connection: Connection, questionIds: Iterable[String]): IO[Either[String, Map[String, OfflineExamQuestion]]] =
    loadExamQuestions(connection, "id", questionIds)

  def loadExamQuestionsByExamIds(connection: Connection, examIds: Iterable[String]): IO[Either[String, Map[String, OfflineExamQuestion]]] =
    loadExamQuestions(connection, "exam_id", examIds)

  private def loadExamQuestions(connection: Connection, filterColumn: String, filterIds: Iterable[String]): IO[Either[String, Map[String, OfflineExamQuestion]]] =
    import JdbcReadSupport.*
    val ids = filterIds.toList.distinct
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          s"""
            |select id, exam_id, title, position, scoring
            |from teaching_exam_questions
            |where $filterColumn in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              decodeJson[ExamQuestionScoring](row.getString("scoring"), "exam question scoring").map { scoring =>
                OfflineExamQuestion(
                  id = row.getString("id"),
                  examId = row.getString("exam_id"),
                  title = row.getString("title"),
                  position = row.getInt("position"),
                  scoring = scoring
                )
              }
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadAnswerSheetsByExamIds(connection: Connection, examIds: Iterable[String]): IO[Either[String, Map[String, ExamAnswerSheet]]] =
    import JdbcReadSupport.*
    val ids = examIds.toList.distinct
    given Decoder[List[Attachment]] = Decoder.decodeList(summon[Decoder[Attachment]])
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          """
            |select id, exam_id, question_id, student_id, images
            |from teaching_exam_answer_sheets
            |where exam_id in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              decodeJson[List[Attachment]](row.getString("images"), "answer sheet images").map { images =>
                ExamAnswerSheet(
                  id = row.getString("id"),
                  examId = row.getString("exam_id"),
                  questionId = row.getString("question_id"),
                  studentId = row.getString("student_id"),
                  images = images
                )
              }
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadQuestionGradingsByAnswerSheetIds(connection: Connection, answerSheetIds: Iterable[String]): IO[Either[String, Map[String, ExamQuestionGrading]]] =
    import JdbcReadSupport.*
    val ids = answerSheetIds.toList.distinct
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          """
            |select id, answer_sheet_id, grader_teacher_id, score, reviewed_at
            |from teaching_exam_question_reviews
            |where answer_sheet_id in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              Right(
                ExamQuestionGrading(
                  id = row.getString("id"),
                  answerSheetId = row.getString("answer_sheet_id"),
                  graderTeacherId = row.getString("grader_teacher_id"),
                  score = row.getInt("score"),
                  gradedAt = readInstant(row, "reviewed_at")
                )
              )
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadQuestionArbitrationsByAnswerSheetIds(connection: Connection, answerSheetIds: Iterable[String]): IO[Either[String, Map[String, ExamQuestionArbitration]]] =
    import JdbcReadSupport.*
    val ids = answerSheetIds.toList.distinct
    if ids.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        withInPrepared(
          connection,
          """
            |select id, answer_sheet_id, arbitration_teacher_id, decided_score, decided_at
            |from teaching_exam_question_arbitrations
            |where answer_sheet_id in (:ids)
            |""".stripMargin,
          ids
        ) { statement =>
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet)(row => Right(ExamQuestionArbitration(row.getString("id"), row.getString("answer_sheet_id"), row.getString("arbitration_teacher_id"), row.getInt("decided_score"), readInstant(row, "decided_at"))))
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)

  def loadQuestionAppeals(connection: Connection, answerSheetIds: Iterable[String], questionIds: Iterable[String]): IO[Either[String, Map[String, ExamQuestionAppeal]]] =
    import JdbcReadSupport.*
    val sheetIds = answerSheetIds.toList.distinct
    val qIds = questionIds.toList.distinct
    if sheetIds.isEmpty && qIds.isEmpty then IO.pure(Right(Map.empty))
    else
      IO.blocking {
        val answerPlaceholders = if sheetIds.nonEmpty then sheetIds.map(_ => "?").mkString(", ") else "null"
        val questionPlaceholders = if qIds.nonEmpty then qIds.map(_ => "?").mkString(", ") else "null"
        val sql =
          s"""
             |select id, answer_sheet_id, question_id, student_id, appeal_teacher_id, expected_score, reason, status, submitted_at, resolved_at, resolved_score
             |from teaching_exam_question_appeals
             |where answer_sheet_id in ($answerPlaceholders) or question_id in ($questionPlaceholders)
             |""".stripMargin
        withPrepared(connection, sql) { statement =>
          (sheetIds ++ qIds).zipWithIndex.foreach { case (value, index) => statement.setString(index + 1, value) }
          val resultSet = statement.executeQuery()
          try
            collectRows(resultSet) { row =>
              for
                status <- ExamAppealStatus.fromString(row.getString("status"))
              yield
                ExamQuestionAppeal(
                  id = row.getString("id"),
                  answerSheetId = row.getString("answer_sheet_id"),
                  questionId = row.getString("question_id"),
                  studentId = row.getString("student_id"),
                  appealTeacherId = row.getString("appeal_teacher_id"),
                  expectedScore = row.getInt("expected_score"),
                  reason = row.getString("reason"),
                  status = status,
                  submittedAt = readInstant(row, "submitted_at"),
                  resolvedAt = readInstantOpt(row, "resolved_at"),
                  resolvedScore = Option(row.getObject("resolved_score")).map(_ => row.getInt("resolved_score"))
                )
            }
          finally resultSet.close()
        }
      }.map(JdbcDecodingSupport.sequenceById)
