package microservices.auth.api

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.tables.{AssignmentTableReads, AssignmentTableWrites}
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.tables.{CourseTableReads, CourseTableWrites}
import microservices.exam.tables.{ExamTableReads, ExamTableWrites}

final case class DeleteAccountAPIMessage(userId: String) extends APIMessage[ActionResponse]:
  override def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          accountEither <- AuthTableReads.loadUserById(connection, userId)
          courseIdsEither <- CourseTableReads.loadCourseIdsForUser(connection, userId)
          coursesEither <- courseIdsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseIds) => CourseTableReads.loadCoursesByIds(connection, courseIds)
          announcementsEither <- courseIdsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseIds) => CourseTableReads.loadAnnouncementsByCourseIds(connection, courseIds)
          chatMessagesEither <- courseIdsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseIds) => CourseTableReads.loadChatMessagesByCourseIds(connection, courseIds)
          assignmentsEither <- courseIdsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseIds) => AssignmentTableReads.loadAssignmentsByCourseIds(connection, courseIds)
          submissionsEither <- assignmentsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(assignments) => AssignmentTableReads.loadSubmissionsByAssignmentIds(connection, assignments.keys)
          reviewsEither <- submissionsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(submissions) => AssignmentTableReads.loadReviewsBySubmissionIds(connection, submissions.keys)
          examsEither <- courseIdsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(courseIds) => ExamTableReads.loadExamsByCourseIds(connection, courseIds)
          questionsEither <- examsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(exams) => ExamTableReads.loadExamQuestionsByExamIds(connection, exams.keys)
          answerSheetsEither <- examsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(exams) => ExamTableReads.loadAnswerSheetsByExamIds(connection, exams.keys)
          validationEither = for
            account <- accountEither
            courses <- coursesEither
            announcements <- announcementsEither
            chatMessages <- chatMessagesEither
            assignments <- assignmentsEither
            submissions <- submissionsEither
            reviews <- reviewsEither
            exams <- examsEither
            questions <- questionsEither
            answerSheets <- answerSheetsEither
          yield
            val nextCourses = courses.values.toList.map(course =>
              course.copy(
                teachers = course.teachers.filterNot(_ == account.id),
                students = course.students.filterNot(_ == account.id)
              )
            )
            val deletedCourseIds = nextCourses.filter(_.teachers.isEmpty).map(_.id).toSet
            val keptCourses = nextCourses.filterNot(course => deletedCourseIds.contains(course.id))
            val keptCourseIds = keptCourses.map(_.id).toSet
            val memberIds = courses.valuesIterator.flatMap(course => course.teachers ++ course.students).toSet
            val deletedAnnouncementIds = announcements.valuesIterator
              .filter(announcement => deletedCourseIds.contains(announcement.courseId) || announcement.publisherTeacherId == account.id)
              .map(_.id)
              .toSet
            val deletedChatMessageIds = chatMessages.valuesIterator
              .filter(message => deletedCourseIds.contains(message.courseId) || message.senderUserId == account.id || message.revokedByUserId.contains(account.id))
              .map(_.id)
              .toSet
            val deletedAssignmentIds = assignments.valuesIterator
              .filter(assignment => deletedCourseIds.contains(assignment.courseId) || assignment.createdByTeacherId == account.id || assignment.graderTeacherId == account.id)
              .map(_.id)
              .toSet
            val deletedSubmissionIds = submissions.valuesIterator
              .filter(submission => deletedAssignmentIds.contains(submission.assignmentId) || submission.studentId == account.id)
              .map(_.id)
              .toSet
            val deletedReviewIds = reviews.valuesIterator
              .filter(review => deletedSubmissionIds.contains(review.submissionId) || review.graderTeacherId == account.id)
              .map(_.id)
              .toSet
            val deletedExamIds = exams.valuesIterator
              .filter(exam => deletedCourseIds.contains(exam.courseId) || exam.createdByTeacherId == account.id)
              .map(_.id)
              .toSet
            val deletedQuestionIds = questions.valuesIterator
              .filter(question => deletedExamIds.contains(question.examId))
              .map(_.id)
              .toSet
            val deletedAnswerSheetIds = answerSheets.valuesIterator
              .filter(sheet => deletedExamIds.contains(sheet.examId) || deletedQuestionIds.contains(sheet.questionId) || sheet.studentId == account.id)
              .map(_.id)
              .toSet
            (
              account.id,
              keptCourses,
              keptCourseIds,
              memberIds,
              deletedCourseIds,
              deletedAnnouncementIds,
              deletedChatMessageIds,
              deletedAssignmentIds,
              deletedSubmissionIds,
              deletedReviewIds,
              deletedExamIds,
              deletedQuestionIds,
              deletedAnswerSheetIds
            )
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((accountId, keptCourses, keptCourseIds, memberIds, deletedCourseIds, deletedAnnouncementIds, deletedChatMessageIds, deletedAssignmentIds, deletedSubmissionIds, deletedReviewIds, deletedExamIds, deletedQuestionIds, deletedAnswerSheetIds)) =>
              for
                writeResult <- IO.blocking {
                  keptCourses.foreach(CourseTableWrites.replaceCourse(connection, _))
                  deletedReviewIds.foreach(AssignmentTableWrites.deleteReview(connection, _))
                  deletedSubmissionIds.foreach(AssignmentTableWrites.deleteSubmission(connection, _))
                  deletedAssignmentIds.foreach(AssignmentTableWrites.deleteAssignment(connection, _))
                  ExamTableWrites.deleteQuestionGradingsByAnswerSheetIds(connection, deletedAnswerSheetIds)
                  ExamTableWrites.deleteQuestionArbitrationsByAnswerSheetIds(connection, deletedAnswerSheetIds)
                  ExamTableWrites.deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection, deletedAnswerSheetIds, deletedQuestionIds)
                  deletedAnswerSheetIds.foreach(ExamTableWrites.deleteExamAnswerSheet(connection, _))
                  deletedExamIds.foreach { examId =>
                    ExamTableWrites.deleteExamQuestionsByExamId(connection, examId)
                    ExamTableWrites.deleteExam(connection, examId)
                  }
                  deletedAnnouncementIds.foreach(CourseTableWrites.deleteAnnouncement(connection, _))
                  deletedChatMessageIds.foreach(CourseTableWrites.deleteChatMessage(connection, _))
                  deletedCourseIds.foreach { courseId =>
                    CourseTableWrites.deleteCourse(connection, courseId)
                  }
                  AuthTableWrites.deleteUser(connection, accountId)
                }.as(Right(()): Either[String, Unit])
              yield List(writeResult).collectFirst { case Left(error) => error } match
                case Some(error) => Left(error)
                case None => Right(ActionResponse("账号已注销"))
        yield result
      }
      response <- resolveEither(result)
    yield response

object DeleteAccountAPIMessage:
  given Codec.AsObject[DeleteAccountAPIMessage] = deriveCodec
