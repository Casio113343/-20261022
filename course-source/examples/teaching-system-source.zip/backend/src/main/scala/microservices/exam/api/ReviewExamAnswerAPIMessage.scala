package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import infrastructure.events.DomainEvent
import infrastructure.outbox.{OutboxSupport, OutboxTableWrites}
import infrastructure.outbox.OutboxMessage
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.exam.api.requests.{ExamReviewOperation, ReviewExamAnswerInput}
import microservices.exam.api.responses.ExamReviewBoardResponse
import microservices.exam.objects.{ExamAppealStatus, ExamQuestionAppeal, ExamQuestionArbitration, ExamQuestionGrading}
import microservices.exam.tables.{ExamTableWrites, ExamWorkspaceReads}
import shared.id.IdGenerator

import java.time.Instant

private final case class ReviewMutation(
    workspace: ExamWorkspaceReads.Workspace,
    grading: Option[ExamQuestionGrading],
    arbitration: Option[ExamQuestionArbitration],
    appeal: Option[ExamQuestionAppeal],
    outbox: OutboxMessage
)

final case class ReviewExamAnswerAPIMessage(
    examId: String,
    questionId: String,
    answerSheetId: String,
    userId: String,
    mode: ExamReviewOperation,
    input: ReviewExamAnswerInput
) extends APIMessage[ExamReviewBoardResponse]:
  def plan: IO[ExamReviewBoardResponse] =
    for
      occurredAt <- IO.delay(Instant.now())
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          workspaceEither <- ExamWorkspaceReads.loadWorkspace(connection, examId)
          validationEither = workspaceEither.flatMap { workspace =>
            for
              question <- ExamWorkspaceReads.validateTeacherQuestion(workspace, questionId, userId)
              answerSheet <- workspace.answerSheets.get(answerSheetId).toRight("答卷不存在")
              _ <- Either.cond(answerSheet.questionId == question.id && answerSheet.examId == workspace.exam.id, (), "答卷与考试题目不匹配")
              _ <- ExamWorkspaceReads.validateReviewModeAccess(question, mode, userId)
              _ <- Either.cond(mode != ExamReviewOperation.Arbitration || ExamWorkspaceReads.needsArbitration(workspace, question, answerSheet), (), "当前答卷不需要仲裁")
              _ <- Either.cond(mode != ExamReviewOperation.Arbitration || workspace.arbitrations.values.forall(_.answerSheetId != answerSheet.id), (), "当前答卷已经完成仲裁")
              _ <- Either.cond(workspace.exam.publishedAt.isEmpty || mode == ExamReviewOperation.Appeal, (), "考试已经发布，不能继续批改或仲裁")
              _ <- Either.cond(mode != ExamReviewOperation.Appeal || ExamWorkspaceReads.appealForTeacher(workspace, answerSheet.id, userId).forall(_.status == ExamAppealStatus.Pending), (), "当前申诉已经处理")
              _ <- Either.cond(input.score >= 0 && input.score <= question.scoring.fullScore, (), s"分数必须在 0 到 ${question.scoring.fullScore} 之间")
            yield
              val outbox = OutboxSupport.domainEventPublish(
                DomainEvent(
                  eventType = "exam.answer.reviewed",
                  aggregateType = "exam",
                  aggregateId = examId,
                  userId = userId,
                  courseId = None,
                  occurredAt = occurredAt,
                  payload = io.circe.Json.obj("relatedId" -> io.circe.Json.fromString(answerSheetId))
                )
              )
              mode match
                case ExamReviewOperation.Grading =>
                  val grading = ExamQuestionGrading(IdGenerator.nextId("exam-grading"), answerSheetId, userId, input.score, occurredAt)
                  val nextWorkspace = workspace.copy(gradings = workspace.gradings.filterNot { case (_, current) => current.answerSheetId == answerSheetId && current.graderTeacherId == userId }.updated(grading.id, grading))
                  Right(ReviewMutation(nextWorkspace, Some(grading), None, None, outbox))
                case ExamReviewOperation.Arbitration =>
                  val arbitration = ExamQuestionArbitration(IdGenerator.nextId("exam-arbitration"), answerSheetId, userId, input.score, occurredAt)
                  val nextWorkspace = workspace.copy(arbitrations = workspace.arbitrations.filterNot { case (_, current) => current.answerSheetId == answerSheetId }.updated(arbitration.id, arbitration))
                  Right(ReviewMutation(nextWorkspace, None, Some(arbitration), None, outbox))
                case ExamReviewOperation.Appeal =>
                  val appeal = ExamWorkspaceReads.appealForTeacher(workspace, answerSheetId, userId).toRight("当前没有待处理申诉").map(_.copy(status = ExamAppealStatus.Resolved, resolvedAt = Some(occurredAt), resolvedScore = Some(input.score)))
                  appeal.map { resolvedAppeal =>
                    val nextWorkspace = workspace.copy(appeals = workspace.appeals.updated(resolvedAppeal.id, resolvedAppeal))
                    ReviewMutation(nextWorkspace, None, None, Some(resolvedAppeal), outbox)
                  }
          }.flatten
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(mutation) =>
              IO.blocking {
                mutation.grading.foreach(ExamTableWrites.replaceQuestionGrading(connection, _))
                mutation.arbitration.foreach(ExamTableWrites.replaceQuestionArbitration(connection, _))
                mutation.appeal.foreach(ExamTableWrites.upsertQuestionAppeal(connection, _))
                OutboxTableWrites.insertAll(connection, List(mutation.outbox))
              }.as(
                mutation.workspace.questions.get(questionId).toRight("考试题目不存在").flatMap { question =>
                  ExamWorkspaceReads.buildReviewBoard(mutation.workspace, question, mode, userId)
                }
              )
        yield result
      }
      response <- resolveEither(result)
    yield response

object ReviewExamAnswerAPIMessage:
  given Codec.AsObject[ReviewExamAnswerAPIMessage] = deriveCodec
