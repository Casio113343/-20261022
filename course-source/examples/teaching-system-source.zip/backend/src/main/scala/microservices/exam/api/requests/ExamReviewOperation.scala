package microservices.exam.api.requests

import io.circe.{Decoder, Encoder}

enum ExamReviewOperation(val value: String):
  case Grading extends ExamReviewOperation("grading")
  case Arbitration extends ExamReviewOperation("arbitration")
  case Appeal extends ExamReviewOperation("appeal")

object ExamReviewOperation:
  def fromString(value: String): Either[String, ExamReviewOperation] =
    value match
      case Grading.value => Right(Grading)
      case Arbitration.value => Right(Arbitration)
      case Appeal.value => Right(Appeal)
      case _ => Left("未知批改模式")

  given Encoder[ExamReviewOperation] = Encoder.encodeString.contramap(_.value)
  given Decoder[ExamReviewOperation] = Decoder.decodeString.emap(fromString)
