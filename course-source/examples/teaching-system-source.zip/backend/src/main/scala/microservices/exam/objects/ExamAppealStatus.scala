package microservices.exam.objects

import io.circe.{Decoder, Encoder}

enum ExamAppealStatus(val value: String):
  case Pending extends ExamAppealStatus("pending")
  case Resolved extends ExamAppealStatus("resolved")

object ExamAppealStatus:
  def fromString(value: String): Either[String, ExamAppealStatus] =
    value match
      case Pending.value => Right(Pending)
      case Resolved.value => Right(Resolved)
      case _ => Left(s"未知申诉状态: $value")

  given Encoder[ExamAppealStatus] = Encoder.encodeString.contramap(_.value)
  given Decoder[ExamAppealStatus] = Decoder.decodeString.emap(fromString)
