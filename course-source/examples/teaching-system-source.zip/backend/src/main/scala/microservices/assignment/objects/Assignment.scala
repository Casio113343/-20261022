package microservices.assignment.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import infrastructure.storage.Attachment

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class Assignment(
    id: String,
    courseId: String,
    title: String,
    content: String,
    attachment: Option[Attachment],
    allowLateSubmission: Boolean,
    maxScore: Option[Int],
    graderTeacherId: String,
    dueAt: Instant,
    createdByTeacherId: String,
    createdAt: Instant,
    answerAttachment: Option[Attachment],
    answerPublishedAt: Option[Instant]
)

object Assignment:
  given Encoder[Assignment] = deriveEncoder[Assignment]
  given Decoder[Assignment] = deriveDecoder[Assignment]
