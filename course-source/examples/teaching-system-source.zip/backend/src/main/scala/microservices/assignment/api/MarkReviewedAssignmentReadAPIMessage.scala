package microservices.assignment.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.tables.AssignmentTableReads
import microservices.auth.objects.UserRole
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.support.CourseAccessSupport.{isContentVisibleToUser, isCurrentStudent}
import microservices.course.tables.CourseTableReads
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.dashboard.tables.DashboardTableReads

final case class MarkReviewedAssignmentReadAPIMessage(assignmentId: String, userId: String) extends APIMessage[UserDashboardResponse]:
  def plan: IO[UserDashboardResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        CourseTableReads.lookupCourseId(connection, AssignmentTableReads.courseIdByAssignmentIdSql, assignmentId).flatMap {
          case None => IO.pure(Left("作业不存在"))
          case Some(courseId) =>
            for
              courseEither <- CourseTableReads.loadCourseById(connection, courseId)
              studentEither <- AuthTableReads.loadUserById(connection, userId)
              assignmentEither <- AssignmentTableReads.loadAssignmentById(connection, assignmentId)
              submissionEither <- AssignmentTableReads.findSubmissionForAssignmentAndStudent(connection, assignmentId, userId)
              reviewEither <- submissionEither match
                case Left(error) => IO.pure(Left(error))
                case Right(Some(submission)) => AssignmentTableReads.loadReviewBySubmissionId(connection, submission.id)
                case Right(None) => IO.pure(Right(None))
              validationEither = for
                course <- courseEither
                student <- studentEither
                assignment <- assignmentEither
                submission <- submissionEither
                review <- reviewEither
                _ <- Either.cond(assignment.courseId == course.id, (), "作业不属于当前课程")
                _ <- Either.cond(student.role == UserRole.Student && isCurrentStudent(course, student.id) && isContentVisibleToUser(course, student.id, assignment.createdAt), (), "只有本课程学生可以提交该作业")
                _ <- Either.cond(submission.nonEmpty && review.nonEmpty, (), "当前作业还没有可标记的批改结果")
              yield (student, assignment.id)
              result <- validationEither match
                case Left(error) => IO.pure(Left(error))
                case Right((student, readAssignmentId)) =>
                  for
                    userReadUpdate <- IO.blocking {
                      AuthTableWrites.upsertUser(connection, student.copy(readReviewedAssignmentIds = (student.readReviewedAssignmentIds :+ readAssignmentId).distinct))
                    }.as(Right(()): Either[String, Unit])
                    dashboardEither <- DashboardTableReads.loadDashboardFromTables(connection, userId)
                  yield for
                    _ <- userReadUpdate
                    dashboard <- dashboardEither
                  yield dashboard
            yield result
        }
      }
      response <- resolveEither(result)
    yield response

object MarkReviewedAssignmentReadAPIMessage:
  given Codec.AsObject[MarkReviewedAssignmentReadAPIMessage] = deriveCodec
