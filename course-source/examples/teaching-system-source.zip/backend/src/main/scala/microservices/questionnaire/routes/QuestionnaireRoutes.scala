package microservices.questionnaire.routes

import infrastructure.api.ActionResponse
import infrastructure.api.RegisteredAPIMessage
import microservices.questionnaire.api.*

object QuestionnaireRoutes:
  val apiMessages: List[RegisteredAPIMessage] = List(
    RegisteredAPIMessage.api[CreateQuestionnaireAPIMessage, microservices.questionnaire.api.responses.QuestionnaireDetailResponse],
    RegisteredAPIMessage.api[DeleteQuestionnaireAPIMessage, ActionResponse],
    RegisteredAPIMessage.api[FetchCourseQuestionnairesAPIMessage, List[microservices.questionnaire.api.responses.QuestionnaireSummary]],
    RegisteredAPIMessage.api[FetchQuestionnaireDetailAPIMessage, microservices.questionnaire.api.responses.QuestionnaireDetailResponse],
    RegisteredAPIMessage.api[MarkQuestionnaireReadAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse],
    RegisteredAPIMessage.api[SubmitQuestionnaireAnswersAPIMessage, microservices.questionnaire.api.responses.QuestionnaireDetailResponse],
    RegisteredAPIMessage.api[FetchQuestionnaireTextAnswersAPIMessage, List[microservices.questionnaire.api.responses.QuestionnaireTextAnswer]]
  )
