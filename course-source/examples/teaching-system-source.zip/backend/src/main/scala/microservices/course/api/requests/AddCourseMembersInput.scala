package microservices.course.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec

final case class AddCourseMembersInput(
    usernames: List[String]
)
object AddCourseMembersInput:
  given Codec[AddCourseMembersInput] = deriveCodec
