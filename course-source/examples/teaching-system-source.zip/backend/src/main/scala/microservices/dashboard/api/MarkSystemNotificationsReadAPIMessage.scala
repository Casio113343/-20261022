package microservices.dashboard.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.dashboard.api.responses.UserDashboardResponse
import microservices.dashboard.tables.DashboardTableReads

final case class MarkSystemNotificationsReadAPIMessage(userId: String) extends APIMessage[UserDashboardResponse]:
  override def plan: IO[UserDashboardResponse] =
    for
      updateResult <- DatabaseSession.withTransactionConnection { connection =>
        for
          notificationIdsEither <- DashboardTableReads.loadSystemNotificationIdsForUser(connection, userId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          result <- (notificationIdsEither, userEither) match
            case (Right(notificationIds), Right(user)) =>
              IO.blocking {
                AuthTableWrites.upsertUser(connection, user.copy(readSystemNotificationIds = (user.readSystemNotificationIds ++ notificationIds).distinct))
              }.as(Right(()): Either[String, Unit])
            case (Left(error), _) => IO.pure(Left(error))
            case (_, Left(error)) => IO.pure(Left(error))
        yield result
      }
      _ <- resolveEither(updateResult)
      dashboardResult <- DatabaseSession.withTransactionConnection(connection => DashboardTableReads.loadDashboardFromTables(connection, userId))
      response <- resolveEither(dashboardResult)
    yield response

object MarkSystemNotificationsReadAPIMessage:
  given Codec.AsObject[MarkSystemNotificationsReadAPIMessage] = deriveCodec
