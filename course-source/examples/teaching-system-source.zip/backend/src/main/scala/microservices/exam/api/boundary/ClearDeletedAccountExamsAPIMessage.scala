package microservices.exam.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.exam.tables.{ExamTableReads, ExamTableWrites}

final case class ClearDeletedAccountExamsAPIMessage(accountId: String, courseIds: List[String], deletedCourseIds: List[String]) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          examsEither <- ExamTableReads.loadExamsByCourseIds(connection, courseIds)
          questionsEither <- examsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(exams) => ExamTableReads.loadExamQuestionsByExamIds(connection, exams.keys)
          answerSheetsEither <- examsEither match
            case Left(error) => IO.pure(Left(error))
            case Right(exams) => ExamTableReads.loadAnswerSheetsByExamIds(connection, exams.keys)
          result <- (examsEither, questionsEither, answerSheetsEither) match
            case (Right(exams), Right(questions), Right(answerSheets)) =>
              IO.blocking {
                val deletedCourseIdSet = deletedCourseIds.toSet
                val deletedExamIds = exams.valuesIterator
                  .filter(exam => deletedCourseIdSet.contains(exam.courseId) || exam.createdByTeacherId == accountId)
                  .map(_.id)
                  .toSet
                val deletedQuestionIds = questions.valuesIterator
                  .filter(question => deletedExamIds.contains(question.examId))
                  .map(_.id)
                  .toSet
                val deletedAnswerSheetIds = answerSheets.valuesIterator
                  .filter(sheet => deletedExamIds.contains(sheet.examId) || deletedQuestionIds.contains(sheet.questionId) || sheet.studentId == accountId)
                  .map(_.id)
                  .toSet

                ExamTableWrites.deleteQuestionGradingsByAnswerSheetIds(connection, deletedAnswerSheetIds)
                ExamTableWrites.deleteQuestionArbitrationsByAnswerSheetIds(connection, deletedAnswerSheetIds)
                ExamTableWrites.deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection, deletedAnswerSheetIds, deletedQuestionIds)
                deletedAnswerSheetIds.foreach(ExamTableWrites.deleteExamAnswerSheet(connection, _))
                deletedExamIds.foreach { examId =>
                  ExamTableWrites.deleteExamQuestionsByExamId(connection, examId)
                  ExamTableWrites.deleteExam(connection, examId)
                }
                Right(())
              }
            case (Left(error), _, _) => IO.pure(Left(error))
            case (_, Left(error), _) => IO.pure(Left(error))
            case (_, _, Left(error)) => IO.pure(Left(error))
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理注销账号相关考试数据")

object ClearDeletedAccountExamsAPIMessage:
  given Codec.AsObject[ClearDeletedAccountExamsAPIMessage] = deriveCodec
