package microservices.auth.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}

final case class UpdateUserReadReviewedAssignmentAPIMessage(userId: String, assignmentId: String) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          result <- userEither match
            case Left(error) => IO.pure(Left(error))
            case Right(user) =>
              val nextUser = user.copy(readReviewedAssignmentIds = (user.readReviewedAssignmentIds :+ assignmentId).distinct)
              IO.blocking(AuthTableWrites.upsertUser(connection, nextUser)).as(Right(()): Either[String, Unit])
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("作业批改结果已标记为已读")

object UpdateUserReadReviewedAssignmentAPIMessage:
  given Codec.AsObject[UpdateUserReadReviewedAssignmentAPIMessage] = deriveCodec
