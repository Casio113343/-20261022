package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.course.api.responses.CourseChatTimelinePage
import microservices.course.tables.CourseTableReads

final case class FetchCourseChatTimelineAPIMessage(
    courseId: String,
    userId: String,
    limit: Int = 50,
    beforeSentAt: Option[String] = None,
    beforeRowIndex: Option[Int] = None
) extends APIMessage[CourseChatTimelinePage]:
  def plan: IO[CourseChatTimelinePage] =
    for
      result <- DatabaseSession.withTransactionConnection(connection =>
        CourseTableReads.loadCourseChatTimelineFromTables(
          connection,
          courseId,
          userId,
          limit,
          beforeSentAt,
          beforeRowIndex
        )
      )
      response <- resolveEither(result)
    yield response

object FetchCourseChatTimelineAPIMessage:
  given Codec.AsObject[FetchCourseChatTimelineAPIMessage] = deriveCodec
