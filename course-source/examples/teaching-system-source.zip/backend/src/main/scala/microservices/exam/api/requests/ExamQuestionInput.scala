package microservices.exam.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec

final case class ExamQuestionInput(
    questionId: Option[String],
    title: String,
    fullScore: Int,
    graderTeacherIds: List[String],
    arbitrationEnabled: Boolean,
    arbitrationScoreDiffThreshold: Option[Int],
    arbitrationTeacherId: Option[String],
    appealEnabled: Boolean,
    appealTeacherId: Option[String]
)
object ExamQuestionInput:
  given Codec[ExamQuestionInput] = deriveCodec
