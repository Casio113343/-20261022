package microservices.auth.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.api.requests.RegisterInput
import microservices.auth.api.responses.RegisterOutput
import microservices.auth.objects.{StudentProfile, TeacherProfile, UserRole}
import microservices.auth.support.AuthUserAccountFactorySupport.{studentAccount, teacherAccount}
import microservices.auth.support.AuthUserViewSupport.toPublicUser
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}

import java.util.UUID

final case class RegisterAPIMessage(input: RegisterInput) extends APIMessage[RegisterOutput]:
  override def plan: IO[RegisterOutput] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val numericUsernamePattern = raw"\d+".r
        val username = input.username.trim
        val password = input.password.trim
        val displayName = input.displayName.trim
        if username.isEmpty then IO.pure(Left("账号不能为空"))
        else if numericUsernamePattern.matches(username).unary_! then IO.pure(Left("账号必须为纯数字，且注册后不可修改"))
        else if displayName.isEmpty then IO.pure(Left("姓名不能为空"))
        else if password.length < 6 then IO.pure(Left("密码至少 6 位"))
        else
          AuthTableReads.findUserByUsername(connection, username).flatMap {
            case Left(error) => IO.pure(Left(error))
            case Right(Some(_)) => IO.pure(Left("账号已存在"))
            case Right(None) =>
              val account =
                input.role match
                  case UserRole.Teacher =>
                    teacherAccount(
                      s"teacher-${UUID.randomUUID().toString.take(8)}",
                      username,
                      password,
                      displayName,
                      None,
                      TeacherProfile(input.teacherProfile.flatMap(_.subject).map(_.trim).filter(_.nonEmpty), input.teacherProfile.flatMap(_.office).map(_.trim).filter(_.nonEmpty))
                    )
                  case UserRole.Student =>
                    studentAccount(
                      s"student-${UUID.randomUUID().toString.take(8)}",
                      username,
                      password,
                      displayName,
                      None,
                      StudentProfile(input.studentProfile.flatMap(_.grade).map(_.trim).filter(_.nonEmpty), input.studentProfile.flatMap(_.major).map(_.trim).filter(_.nonEmpty))
                    )
              IO.blocking(AuthTableWrites.upsertUser(connection, account)).as(Right(RegisterOutput(toPublicUser(account))))
          }
      }
      response <- resolveEither(result)
    yield response

object RegisterAPIMessage:
  given Codec.AsObject[RegisterAPIMessage] = deriveCodec
