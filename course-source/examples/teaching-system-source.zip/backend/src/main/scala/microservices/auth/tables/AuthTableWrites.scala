package microservices.auth.tables

import io.circe.syntax.*
import shared.jdbc.JdbcStatementSupport.{setJsonbOpt, setStringOpt, withPrepared}
import microservices.auth.objects.UserAccount
import shared.model.SharedCodecs

import java.sql.Connection

object AuthTableWrites:
  import SharedCodecs.given

  def saveUsers(connection: Connection, users: Iterable[UserAccount]): Unit =
    users.foreach(insertUser(connection, _))

  def upsertUser(connection: Connection, user: UserAccount): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_users (
        |  id,
        |  username,
        |  password,
        |  display_name,
        |  role,
        |  avatar_data_url,
        |  read_announcement_ids,
        |  read_system_notification_ids,
        |  read_reviewed_assignment_ids,
        |  read_published_exam_ids,
        |  read_questionnaire_ids,
        |  teacher_profile,
        |  student_profile
        |)
        |values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set username = excluded.username,
        |    password = excluded.password,
        |    display_name = excluded.display_name,
        |    role = excluded.role,
        |    avatar_data_url = excluded.avatar_data_url,
        |    read_announcement_ids = excluded.read_announcement_ids,
        |    read_system_notification_ids = excluded.read_system_notification_ids,
        |    read_reviewed_assignment_ids = excluded.read_reviewed_assignment_ids,
        |    read_published_exam_ids = excluded.read_published_exam_ids,
        |    read_questionnaire_ids = excluded.read_questionnaire_ids,
        |    teacher_profile = excluded.teacher_profile,
        |    student_profile = excluded.student_profile
        |""".stripMargin
    ) { statement =>
      statement.setString(1, user.id)
      statement.setString(2, user.username)
      statement.setString(3, user.password)
      statement.setString(4, user.displayName)
      statement.setString(5, user.role.toString.toLowerCase)
      setStringOpt(statement, 6, user.avatarDataUrl)
      statement.setString(7, user.readAnnouncementIds.asJson.noSpaces)
      statement.setString(8, user.readSystemNotificationIds.asJson.noSpaces)
      statement.setString(9, user.readReviewedAssignmentIds.asJson.noSpaces)
      statement.setString(10, user.readPublishedExamIds.asJson.noSpaces)
      statement.setString(11, user.readQuestionnaireIds.asJson.noSpaces)
      setJsonbOpt(statement, 12, user.teacherProfile)
      setJsonbOpt(statement, 13, user.studentProfile)
      statement.executeUpdate()
    }

  def deleteUser(connection: Connection, userId: String): Unit =
    withPrepared(connection, "delete from teaching_users where id = ?") { statement =>
      statement.setString(1, userId)
      statement.executeUpdate()
    }

  private def insertUser(connection: Connection, user: UserAccount): Unit =
    upsertUser(connection, user)
