package microservices.auth.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class PublicUser(
    id: String,
    username: String,
    displayName: String,
    role: UserRole,
    avatarDataUrl: Option[String],
    readAnnouncementIds: List[String],
    readSystemNotificationIds: List[String],
    readReviewedAssignmentIds: List[String],
    readPublishedExamIds: List[String],
    readQuestionnaireIds: List[String],
    teacherProfile: Option[TeacherProfile],
    studentProfile: Option[StudentProfile]
)

object PublicUser:
  given Encoder[PublicUser] = deriveEncoder[PublicUser]
  given Decoder[PublicUser] = deriveDecoder[PublicUser]
