package microservices.exam.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class ExamQuestionArbitration(
    id: String,
    answerSheetId: String,
    arbitrationTeacherId: String,
    decidedScore: Int,
    decidedAt: Instant
)

object ExamQuestionArbitration:
  given Encoder[ExamQuestionArbitration] = deriveEncoder[ExamQuestionArbitration]
  given Decoder[ExamQuestionArbitration] = deriveDecoder[ExamQuestionArbitration]
