package microservices.auth.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}

final case class ClearDeletedAnnouncementReadMarkersAPIMessage(userIds: List[String], announcementId: String) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          usersEither <- AuthTableReads.loadUsersByIds(connection, userIds)
          result <- usersEither match
            case Left(error) => IO.pure(Left(error))
            case Right(users) =>
              val updatedUsers = users.values.toList
                .map(user => user.copy(readAnnouncementIds = user.readAnnouncementIds.filterNot(_ == announcementId)))
                .filter(user => users(user.id).readAnnouncementIds != user.readAnnouncementIds)
              IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理删除通知的已读标记")

object ClearDeletedAnnouncementReadMarkersAPIMessage:
  given Codec.AsObject[ClearDeletedAnnouncementReadMarkersAPIMessage] = deriveCodec
