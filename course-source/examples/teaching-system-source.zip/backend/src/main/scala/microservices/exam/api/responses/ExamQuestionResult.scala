package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

final case class ExamQuestionResult(
    questionId: String,
    title: String,
    position: Int,
    fullScore: Int,
    score: Option[BigDecimal],
    status: ExamQuestionResultStatus,
    appeal: Option[ExamQuestionAppeal],
    canAppeal: Boolean
)
object ExamQuestionResult:
  given Codec[ExamQuestionResult] = deriveCodec
