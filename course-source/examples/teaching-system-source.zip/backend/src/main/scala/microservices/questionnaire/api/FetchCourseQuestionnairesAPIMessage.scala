package microservices.questionnaire.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.AuthTableReads
import microservices.course.support.CourseAccessSupport.{courseStudentsAt, isContentVisibleToUser, isCurrentCourseMember, isCurrentStudent}
import microservices.course.tables.CourseTableReads
import microservices.questionnaire.api.responses.QuestionnaireSummary
import microservices.questionnaire.tables.QuestionnaireTableReads

final case class FetchCourseQuestionnairesAPIMessage(courseId: String, userId: String) extends APIMessage[List[QuestionnaireSummary]]:
  def plan: IO[List[QuestionnaireSummary]] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          questionnairesEither <- QuestionnaireTableReads.loadQuestionnairesByCourseIds(connection, List(courseId))
          submissionsEither <- questionnairesEither match
            case Left(error) => IO.pure(Left(error))
            case Right(questionnaires) => QuestionnaireTableReads.loadSubmissionsByQuestionnaireIds(connection, questionnaires.keys)
        yield for
          user <- userEither
          course <- courseEither
          questionnaires <- questionnairesEither
          submissions <- submissionsEither
          _ <- Either.cond(isCurrentCourseMember(course, user.id), (), "当前用户不可访问该课程")
        yield questionnaires.values.toList
          .filter(questionnaire => isContentVisibleToUser(course, user.id, questionnaire.createdAt))
          .sortBy(_.createdAt)(Ordering[java.time.Instant].reverse)
          .map { questionnaire =>
            val eligibleStudents = courseStudentsAt(course, questionnaire.createdAt).filter(isCurrentStudent(course, _)).toSet
            val questionnaireSubmissions = submissions.values.toList.filter(_.questionnaireId == questionnaire.id)
            val filledStudentIds = questionnaireSubmissions.map(_.studentId).toSet.intersect(eligibleStudents)
            QuestionnaireSummary(
              id = questionnaire.id,
              courseId = questionnaire.courseId,
              title = questionnaire.title,
              overview = questionnaire.overview,
              anonymous = questionnaire.anonymous,
              questionCount = questionnaire.questions.length,
              dueAt = questionnaire.dueAt,
              createdAt = questionnaire.createdAt,
              submitted = questionnaireSubmissions.exists(_.studentId == user.id),
              filledCount = filledStudentIds.size,
              unfilledCount = eligibleStudents.diff(filledStudentIds).size
            )
          }
      }
      response <- resolveEither(result)
    yield response

object FetchCourseQuestionnairesAPIMessage:
  given Codec.AsObject[FetchCourseQuestionnairesAPIMessage] = deriveCodec
