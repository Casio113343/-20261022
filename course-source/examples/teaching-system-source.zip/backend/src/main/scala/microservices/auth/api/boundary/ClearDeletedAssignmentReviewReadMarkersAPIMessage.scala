package microservices.auth.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}

final case class ClearDeletedAssignmentReviewReadMarkersAPIMessage(userIds: List[String], assignmentId: String) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          usersEither <- AuthTableReads.loadUsersByIds(connection, userIds)
          result <- usersEither match
            case Left(error) => IO.pure(Left(error))
            case Right(users) =>
              val updatedUsers = users.values.toList
                .map(user => user.copy(readReviewedAssignmentIds = user.readReviewedAssignmentIds.filterNot(_ == assignmentId)))
                .filter(user => users(user.id).readReviewedAssignmentIds != user.readReviewedAssignmentIds)
              IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
        yield result
      }
      _ <- resolveEither(result)
    yield ActionResponse("已清理删除作业的批改已读标记")

object ClearDeletedAssignmentReviewReadMarkersAPIMessage:
  given Codec.AsObject[ClearDeletedAssignmentReviewReadMarkersAPIMessage] = deriveCodec
