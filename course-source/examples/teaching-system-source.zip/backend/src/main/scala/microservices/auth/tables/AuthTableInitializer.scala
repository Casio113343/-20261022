package microservices.auth.tables

object AuthTableInitializer:
  val initSql: List[String] = List(
    """
      |create table if not exists teaching_users (
      |  id text primary key,
      |  username text not null unique,
      |  password text not null,
      |  display_name text not null,
      |  role text not null,
      |  avatar_data_url text,
      |  read_announcement_ids text not null,
      |  read_system_notification_ids text not null default '[]',
      |  read_reviewed_assignment_ids text not null default '[]',
      |  read_published_exam_ids text not null default '[]',
      |  read_questionnaire_ids text not null default '[]',
      |  teacher_profile text,
      |  student_profile text
      |);
      |""".stripMargin
  )

  val migrationSql: List[String] = List(
    "alter table teaching_users alter column read_announcement_ids type text using read_announcement_ids::text",
    "update teaching_users set role = lower(role) where role <> lower(role)",
    "alter table teaching_users add column if not exists read_system_notification_ids text not null default '[]'",
    "alter table teaching_users add column if not exists read_reviewed_assignment_ids text not null default '[]'",
    "alter table teaching_users add column if not exists read_published_exam_ids text not null default '[]'",
    "alter table teaching_users add column if not exists read_questionnaire_ids text not null default '[]'",
    "alter table teaching_users alter column read_system_notification_ids type text using read_system_notification_ids::text",
    "alter table teaching_users alter column read_reviewed_assignment_ids type text using read_reviewed_assignment_ids::text",
    "alter table teaching_users alter column read_published_exam_ids type text using read_published_exam_ids::text",
    "alter table teaching_users alter column read_questionnaire_ids type text using read_questionnaire_ids::text",
    "alter table teaching_users alter column teacher_profile type text using teacher_profile::text",
    "alter table teaching_users alter column student_profile type text using student_profile::text"
  )

  val tableNames: List[String] = List("teaching_users")
