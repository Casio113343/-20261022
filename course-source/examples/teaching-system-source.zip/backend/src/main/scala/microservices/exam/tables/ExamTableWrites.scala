package microservices.exam.tables

import io.circe.syntax.*
import microservices.exam.objects.{ExamAnswerSheet, ExamQuestionAppeal, ExamQuestionArbitration, ExamQuestionGrading, OfflineExam, OfflineExamQuestion}
import shared.jdbc.JdbcStatementSupport.{setInstant, setInstantOpt, setIntOpt, setStringOpt, withPrepared}

import java.sql.Connection

object ExamTableWrites:
  def saveExams(
    connection: Connection,
    exams: Iterable[OfflineExam],
    questions: Iterable[OfflineExamQuestion],
    answerSheets: Iterable[ExamAnswerSheet],
    gradings: Iterable[ExamQuestionGrading],
    arbitrations: Iterable[ExamQuestionArbitration],
    appeals: Iterable[ExamQuestionAppeal]
  ): Unit =
    exams.foreach(insertExam(connection, _))
    questions.foreach(insertExamQuestion(connection, _))
    answerSheets.foreach(insertExamAnswerSheet(connection, _))
    gradings.foreach(insertExamQuestionGrading(connection, _))
    arbitrations.foreach(insertExamQuestionArbitration(connection, _))
    appeals.foreach(insertExamQuestionAppeal(connection, _))

  def upsertExamAnswerSheet(connection: Connection, sheet: ExamAnswerSheet): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_exam_answer_sheets (id, exam_id, question_id, student_id, images)
        |values (?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set exam_id = excluded.exam_id,
        |    question_id = excluded.question_id,
        |    student_id = excluded.student_id,
        |    images = excluded.images
        |""".stripMargin
    ) { statement =>
      statement.setString(1, sheet.id)
      statement.setString(2, sheet.examId)
      statement.setString(3, sheet.questionId)
      statement.setString(4, sheet.studentId)
      statement.setString(5, sheet.images.asJson.noSpaces)
      statement.executeUpdate()
    }

  def upsertExam(connection: Connection, exam: OfflineExam): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_exams (id, course_id, title, description, created_by_teacher_id, created_at, published_at, question_ids, appeal_due_at)
        |values (?, ?, ?, ?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set course_id = excluded.course_id,
        |    title = excluded.title,
        |    description = excluded.description,
        |    created_by_teacher_id = excluded.created_by_teacher_id,
        |    created_at = excluded.created_at,
        |    published_at = excluded.published_at,
        |    question_ids = excluded.question_ids,
        |    appeal_due_at = excluded.appeal_due_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, exam.id)
      statement.setString(2, exam.courseId)
      statement.setString(3, exam.title)
      statement.setString(4, "")
      statement.setString(5, exam.createdByTeacherId)
      setInstant(statement, 6, exam.createdAt)
      setInstantOpt(statement, 7, exam.publishedAt)
      statement.setString(8, exam.questionIds.asJson.noSpaces)
      setInstantOpt(statement, 9, exam.appealDueAt)
      statement.executeUpdate()
    }

  def deleteExam(connection: Connection, examId: String): Unit =
    withPrepared(connection, "delete from teaching_exams where id = ?") { statement =>
      statement.setString(1, examId)
      statement.executeUpdate()
    }

  def deleteExamQuestionsByExamId(connection: Connection, examId: String): Unit =
    withPrepared(connection, "delete from teaching_exam_questions where exam_id = ?") { statement =>
      statement.setString(1, examId)
      statement.executeUpdate()
    }

  def deleteAnswerSheetsByExamId(connection: Connection, examId: String): Unit =
    withPrepared(connection, "delete from teaching_exam_answer_sheets where exam_id = ?") { statement =>
      statement.setString(1, examId)
      statement.executeUpdate()
    }

  def deleteQuestionGradingsByAnswerSheetIds(connection: Connection, answerSheetIds: Iterable[String]): Unit =
    deleteByIds(connection, "teaching_exam_question_reviews", "answer_sheet_id", answerSheetIds)

  def deleteQuestionArbitrationsByAnswerSheetIds(connection: Connection, answerSheetIds: Iterable[String]): Unit =
    deleteByIds(connection, "teaching_exam_question_arbitrations", "answer_sheet_id", answerSheetIds)

  def deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection: Connection, answerSheetIds: Iterable[String], questionIds: Iterable[String]): Unit =
    val sheetIds = answerSheetIds.toList.distinct
    val qIds = questionIds.toList.distinct
    if sheetIds.nonEmpty || qIds.nonEmpty then
      val sheetPlaceholders = if sheetIds.nonEmpty then sheetIds.map(_ => "?").mkString(", ") else "null"
      val questionPlaceholders = if qIds.nonEmpty then qIds.map(_ => "?").mkString(", ") else "null"
      withPrepared(
        connection,
        s"""
           |delete from teaching_exam_question_appeals
           |where answer_sheet_id in ($sheetPlaceholders) or question_id in ($questionPlaceholders)
           |""".stripMargin
      ) { statement =>
        (sheetIds ++ qIds).zipWithIndex.foreach { case (id, index) => statement.setString(index + 1, id) }
        statement.executeUpdate()
      }

  def upsertExamQuestion(connection: Connection, question: OfflineExamQuestion): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_exam_questions (id, exam_id, title, position, scoring)
        |values (?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set exam_id = excluded.exam_id,
        |    title = excluded.title,
        |    position = excluded.position,
        |    scoring = excluded.scoring
        |""".stripMargin
    ) { statement =>
      statement.setString(1, question.id)
      statement.setString(2, question.examId)
      statement.setString(3, question.title)
      statement.setInt(4, question.position)
      statement.setString(5, question.scoring.asJson.noSpaces)
      statement.executeUpdate()
    }

  def deleteExamQuestion(connection: Connection, questionId: String): Unit =
    withPrepared(connection, "delete from teaching_exam_questions where id = ?") { statement =>
      statement.setString(1, questionId)
      statement.executeUpdate()
    }

  def deleteAnswerSheetsByQuestionAndStudent(connection: Connection, examId: String, questionId: String, studentId: String): Unit =
    withPrepared(
      connection,
      """
        |delete from teaching_exam_answer_sheets
        |where exam_id = ? and question_id = ? and student_id = ?
        |""".stripMargin
    ) { statement =>
      statement.setString(1, examId)
      statement.setString(2, questionId)
      statement.setString(3, studentId)
      statement.executeUpdate()
    }

  def deleteExamAnswerSheet(connection: Connection, sheetId: String): Unit =
    withPrepared(connection, "delete from teaching_exam_answer_sheets where id = ?") { statement =>
      statement.setString(1, sheetId)
      statement.executeUpdate()
    }

  def replaceQuestionGrading(connection: Connection, grading: ExamQuestionGrading): Unit =
    withPrepared(
      connection,
      """
        |delete from teaching_exam_question_reviews
        |where answer_sheet_id = ? and grader_teacher_id = ?
        |""".stripMargin
    ) { statement =>
      statement.setString(1, grading.answerSheetId)
      statement.setString(2, grading.graderTeacherId)
      statement.executeUpdate()
    }
    insertExamQuestionGrading(connection, grading)

  def upsertQuestionGrading(connection: Connection, grading: ExamQuestionGrading): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_exam_question_reviews (id, answer_sheet_id, grader_teacher_id, score, comment, reviewed_at)
        |values (?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set answer_sheet_id = excluded.answer_sheet_id,
        |    grader_teacher_id = excluded.grader_teacher_id,
        |    score = excluded.score,
        |    comment = excluded.comment,
        |    reviewed_at = excluded.reviewed_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, grading.id)
      statement.setString(2, grading.answerSheetId)
      statement.setString(3, grading.graderTeacherId)
      statement.setInt(4, grading.score)
      setStringOpt(statement, 5, None)
      setInstant(statement, 6, grading.gradedAt)
      statement.executeUpdate()
    }

  def deleteQuestionGrading(connection: Connection, reviewId: String): Unit =
    withPrepared(connection, "delete from teaching_exam_question_reviews where id = ?") { statement =>
      statement.setString(1, reviewId)
      statement.executeUpdate()
    }

  def replaceQuestionArbitration(connection: Connection, arbitration: ExamQuestionArbitration): Unit =
    withPrepared(
      connection,
      """
        |delete from teaching_exam_question_arbitrations
        |where answer_sheet_id = ?
        |""".stripMargin
    ) { statement =>
      statement.setString(1, arbitration.answerSheetId)
      statement.executeUpdate()
    }
    insertExamQuestionArbitration(connection, arbitration)

  def upsertQuestionArbitration(connection: Connection, arbitration: ExamQuestionArbitration): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_exam_question_arbitrations (id, answer_sheet_id, arbitration_teacher_id, decided_score, comment, decided_at)
        |values (?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set answer_sheet_id = excluded.answer_sheet_id,
        |    arbitration_teacher_id = excluded.arbitration_teacher_id,
        |    decided_score = excluded.decided_score,
        |    comment = excluded.comment,
        |    decided_at = excluded.decided_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, arbitration.id)
      statement.setString(2, arbitration.answerSheetId)
      statement.setString(3, arbitration.arbitrationTeacherId)
      statement.setInt(4, arbitration.decidedScore)
      setStringOpt(statement, 5, None)
      setInstant(statement, 6, arbitration.decidedAt)
      statement.executeUpdate()
    }

  def deleteQuestionArbitration(connection: Connection, arbitrationId: String): Unit =
    withPrepared(connection, "delete from teaching_exam_question_arbitrations where id = ?") { statement =>
      statement.setString(1, arbitrationId)
      statement.executeUpdate()
    }

  def upsertQuestionAppeal(connection: Connection, appeal: ExamQuestionAppeal): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_exam_question_appeals (id, answer_sheet_id, question_id, student_id, appeal_teacher_id, expected_score, reason, status, submitted_at, resolved_at, resolved_score, resolution_comment)
        |values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set answer_sheet_id = excluded.answer_sheet_id,
        |    question_id = excluded.question_id,
        |    student_id = excluded.student_id,
        |    appeal_teacher_id = excluded.appeal_teacher_id,
        |    expected_score = excluded.expected_score,
        |    reason = excluded.reason,
        |    status = excluded.status,
        |    submitted_at = excluded.submitted_at,
        |    resolved_at = excluded.resolved_at,
        |    resolved_score = excluded.resolved_score,
        |    resolution_comment = excluded.resolution_comment
        |""".stripMargin
    ) { statement =>
      statement.setString(1, appeal.id)
      statement.setString(2, appeal.answerSheetId)
      statement.setString(3, appeal.questionId)
      statement.setString(4, appeal.studentId)
      statement.setString(5, appeal.appealTeacherId)
      statement.setInt(6, appeal.expectedScore)
      statement.setString(7, appeal.reason)
      statement.setString(8, appeal.status.value)
      setInstant(statement, 9, appeal.submittedAt)
      setInstantOpt(statement, 10, appeal.resolvedAt)
      setIntOpt(statement, 11, appeal.resolvedScore)
      setStringOpt(statement, 12, None)
      statement.executeUpdate()
    }

  def deleteQuestionAppeal(connection: Connection, appealId: String): Unit =
    withPrepared(connection, "delete from teaching_exam_question_appeals where id = ?") { statement =>
      statement.setString(1, appealId)
      statement.executeUpdate()
    }

  private def insertExam(connection: Connection, exam: OfflineExam): Unit =
    upsertExam(connection, exam)

  private def insertExamQuestion(connection: Connection, question: OfflineExamQuestion): Unit =
    upsertExamQuestion(connection, question)

  private def insertExamAnswerSheet(connection: Connection, sheet: ExamAnswerSheet): Unit =
    upsertExamAnswerSheet(connection, sheet)

  private def insertExamQuestionGrading(connection: Connection, grading: ExamQuestionGrading): Unit =
    withPrepared(connection, "insert into teaching_exam_question_reviews (id, answer_sheet_id, grader_teacher_id, score, comment, reviewed_at) values (?, ?, ?, ?, ?, ?)") { statement =>
      statement.setString(1, grading.id)
      statement.setString(2, grading.answerSheetId)
      statement.setString(3, grading.graderTeacherId)
      statement.setInt(4, grading.score)
      setStringOpt(statement, 5, None)
      setInstant(statement, 6, grading.gradedAt)
      statement.executeUpdate()
    }

  private def insertExamQuestionArbitration(connection: Connection, arbitration: ExamQuestionArbitration): Unit =
    withPrepared(connection, "insert into teaching_exam_question_arbitrations (id, answer_sheet_id, arbitration_teacher_id, decided_score, comment, decided_at) values (?, ?, ?, ?, ?, ?)") { statement =>
      statement.setString(1, arbitration.id)
      statement.setString(2, arbitration.answerSheetId)
      statement.setString(3, arbitration.arbitrationTeacherId)
      statement.setInt(4, arbitration.decidedScore)
      setStringOpt(statement, 5, None)
      setInstant(statement, 6, arbitration.decidedAt)
      statement.executeUpdate()
    }

  private def insertExamQuestionAppeal(connection: Connection, appeal: ExamQuestionAppeal): Unit =
    upsertQuestionAppeal(connection, appeal)

  private def deleteByIds(connection: Connection, tableName: String, columnName: String, ids: Iterable[String]): Unit =
    val distinctIds = ids.toList.distinct
    if distinctIds.nonEmpty then
      val placeholders = distinctIds.map(_ => "?").mkString(", ")
      withPrepared(connection, s"delete from $tableName where $columnName in ($placeholders)") { statement =>
        distinctIds.zipWithIndex.foreach { case (id, index) => statement.setString(index + 1, id) }
        statement.executeUpdate()
      }
