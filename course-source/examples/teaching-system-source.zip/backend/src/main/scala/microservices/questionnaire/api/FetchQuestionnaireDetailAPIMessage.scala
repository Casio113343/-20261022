package microservices.questionnaire.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.questionnaire.api.responses.QuestionnaireDetailResponse
import microservices.questionnaire.tables.QuestionnaireTableReads

final case class FetchQuestionnaireDetailAPIMessage(questionnaireId: String, userId: String) extends APIMessage[QuestionnaireDetailResponse]:
  def plan: IO[QuestionnaireDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection(QuestionnaireTableReads.loadQuestionnaireDetailFromTables(_, questionnaireId, userId))
      response <- resolveEither(result)
    yield response

object FetchQuestionnaireDetailAPIMessage:
  given Codec.AsObject[FetchQuestionnaireDetailAPIMessage] = deriveCodec
