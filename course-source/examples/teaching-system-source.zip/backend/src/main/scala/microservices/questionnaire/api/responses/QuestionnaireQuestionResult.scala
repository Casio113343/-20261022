package microservices.questionnaire.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.questionnaire.objects.QuestionnaireQuestion

final case class QuestionnaireQuestionResult(
    question: QuestionnaireQuestion,
    options: List[QuestionnaireChoiceOptionResult],
    textAnswerCount: Int
)

object QuestionnaireQuestionResult:
  given Codec.AsObject[QuestionnaireQuestionResult] = deriveCodec
