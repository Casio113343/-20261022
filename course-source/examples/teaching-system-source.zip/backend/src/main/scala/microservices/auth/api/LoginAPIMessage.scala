package microservices.auth.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.api.requests.LoginInput
import microservices.auth.api.responses.LoginOutput
import microservices.auth.objects.UserRole
import microservices.auth.support.AuthUserViewSupport.toPublicUser
import microservices.auth.tables.AuthTableReads

final case class LoginAPIMessage(input: LoginInput) extends APIMessage[LoginOutput]:
  override def plan: IO[LoginOutput] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        AuthTableReads.loadUserByUsername(connection, input.username.trim).map {
          case Left(error) => Left(error)
          case Right(account) =>
            if account.password != input.password.trim then Left("密码错误")
            else if account.role != input.role then
              input.role match
                case UserRole.Teacher => Left("当前选择的是教师端，请使用教师账号登录")
                case UserRole.Student => Left("当前选择的是学生端，请使用学生账号登录")
            else Right(LoginOutput(toPublicUser(account)))
        }
      }
      response <- resolveEither(result)
    yield response

object LoginAPIMessage:
  given Codec.AsObject[LoginAPIMessage] = deriveCodec
