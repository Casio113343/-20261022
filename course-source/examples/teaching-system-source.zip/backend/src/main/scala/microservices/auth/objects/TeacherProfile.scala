package microservices.auth.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.deriveEncoder
import microservices.auth.support.AuthProfileCodecSupport.decodeFlexibleProfile

final case class TeacherProfile(
    subject: Option[String],
    office: Option[String]
)

object TeacherProfile:
  given Encoder.AsObject[TeacherProfile] = deriveEncoder
  given Decoder[TeacherProfile] = Decoder.instance { cursor =>
    decodeFlexibleProfile(cursor, "subject", "office")(TeacherProfile.apply)
  }
