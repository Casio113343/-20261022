package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

final case class ExamQuestion(
    id: String,
    examId: String,
    title: String,
    position: Int,
    scoring: ExamQuestionScoring
)
object ExamQuestion:
  given Codec[ExamQuestion] = deriveCodec
