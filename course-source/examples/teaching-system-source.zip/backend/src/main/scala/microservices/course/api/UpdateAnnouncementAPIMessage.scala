package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.api.requests.CourseAnnouncementInput
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.tables.{CourseTableReads, CourseTableWrites}
import infrastructure.storage.AttachmentSupport.normalizeAttachment

final case class UpdateAnnouncementAPIMessage(courseId: String, announcementId: String, userId: String, input: CourseAnnouncementInput) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          announcementEither <- CourseTableReads.loadAnnouncementById(connection, announcementId)
          validationEither = for
            course <- courseEither
            user <- userEither
            announcement <- announcementEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(announcement.courseId == course.id, (), "通知不属于当前课程")
            _ <- Either.cond(input.title.trim.nonEmpty, (), "通知标题不能为空")
            _ <- Either.cond(input.content.trim.nonEmpty, (), "通知内容不能为空")
          yield announcement.copy(title = input.title.trim, content = input.content.trim, attachment = normalizeAttachment(input.attachment))
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(nextAnnouncement) =>
              for
                _ <- IO.blocking(CourseTableWrites.upsertAnnouncement(connection, nextAnnouncement))
                detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, userId)
              yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

object UpdateAnnouncementAPIMessage:
  given Codec.AsObject[UpdateAnnouncementAPIMessage] = deriveCodec
