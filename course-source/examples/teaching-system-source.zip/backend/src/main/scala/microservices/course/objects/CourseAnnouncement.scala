package microservices.course.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import infrastructure.storage.Attachment

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class CourseAnnouncement(
    id: String,
    courseId: String,
    title: String,
    content: String,
    attachment: Option[Attachment],
    publisherTeacherId: String,
    createdAt: Instant
)

object CourseAnnouncement:
  given Encoder[CourseAnnouncement] = deriveEncoder[CourseAnnouncement]
  given Decoder[CourseAnnouncement] = deriveDecoder[CourseAnnouncement]
