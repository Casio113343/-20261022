package microservices.course.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}
import infrastructure.storage.Attachment

import java.time.Instant
import scala.util.Try

private given Encoder[Instant] = Encoder.encodeString.contramap(_.toString)
private given Decoder[Instant] = Decoder.decodeString.emap(value => Try(Instant.parse(value)).toEither.left.map(_.getMessage))

final case class CourseChatMessage(
    id: String,
    courseId: String,
    senderUserId: String,
    content: String,
    images: List[Attachment],
    attachments: List[Attachment],
    sentAt: Instant,
    revokedAt: Option[Instant],
    revokedByUserId: Option[String]
)

object CourseChatMessage:
  given Encoder[CourseChatMessage] = deriveEncoder[CourseChatMessage]
  given Decoder[CourseChatMessage] = deriveDecoder[CourseChatMessage]
