package microservices.dashboard.routes

import infrastructure.api.ActionResponse
import infrastructure.api.RegisteredAPIMessage
import microservices.dashboard.api.*
import microservices.dashboard.api.boundary.*

object DashboardRoutes:
  val apiMessages: List[RegisteredAPIMessage] = List(
    RegisteredAPIMessage.api[FetchDashboardAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse],
    RegisteredAPIMessage.api[MarkSystemNotificationsReadAPIMessage, microservices.dashboard.api.responses.UserDashboardResponse],
    RegisteredAPIMessage.api[PublishSystemNotificationsAPIMessage, ActionResponse]
  )
