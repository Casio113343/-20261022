package microservices.questionnaire.objects

import io.circe.{Decoder, Encoder}
import io.circe.generic.semiauto.{deriveDecoder, deriveEncoder}

final case class QuestionnaireAnswer(
    questionId: String,
    selectedOptions: List[String],
    text: Option[String]
)

object QuestionnaireAnswer:
  given Encoder[QuestionnaireAnswer] = deriveEncoder
  given Decoder[QuestionnaireAnswer] = deriveDecoder
