package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.course.api.responses.CourseSummary
import microservices.exam.api.requests.ExamReviewOperation
import shared.model.SharedCodecs.given

final case class ExamReviewBoardResponse(
    exam: ExamSummary,
    course: CourseSummary,
    question: ExamQuestion,
    mode: ExamReviewOperation,
    pendingItems: List[ExamReviewItem],
    completedItems: List[ExamReviewItem],
    currentItem: Option[ExamReviewItem]
)
object ExamReviewBoardResponse:
  given Codec[ExamReviewBoardResponse] = deriveCodec
