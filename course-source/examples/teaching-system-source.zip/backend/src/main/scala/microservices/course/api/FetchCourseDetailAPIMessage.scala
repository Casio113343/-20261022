package microservices.course.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.tables.CourseTableReads

final case class FetchCourseDetailAPIMessage(courseId: String, userId: String) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection(connection =>
        CourseTableReads.loadCourseDetailFromTables(connection, courseId, userId)
      )
      response <- resolveEither(result)
    yield response

object FetchCourseDetailAPIMessage:
  given Codec.AsObject[FetchCourseDetailAPIMessage] = deriveCodec
