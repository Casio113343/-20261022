package microservices.questionnaire.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser

final case class QuestionnaireTextAnswer(
    submissionId: String,
    student: Option[PublicUser],
    text: String
)

object QuestionnaireTextAnswer:
  given Codec.AsObject[QuestionnaireTextAnswer] = deriveCodec
