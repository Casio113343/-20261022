package microservices.auth.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.{StudentProfile, TeacherProfile, UserRole}

final case class RegisterInput(
    username: String,
    password: String,
    displayName: String,
    role: UserRole,
    teacherProfile: Option[TeacherProfile],
    studentProfile: Option[StudentProfile]
)

object RegisterInput:
  given Codec[RegisterInput] = deriveCodec
