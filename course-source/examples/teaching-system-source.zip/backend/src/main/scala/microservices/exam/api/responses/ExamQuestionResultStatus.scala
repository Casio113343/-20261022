package microservices.exam.api.responses

import io.circe.{Decoder, Encoder}

enum ExamQuestionResultStatus(val value: String):
  case Pending extends ExamQuestionResultStatus("pending")
  case Missing extends ExamQuestionResultStatus("missing")
  case Graded extends ExamQuestionResultStatus("graded")
  case Arbitrated extends ExamQuestionResultStatus("arbitrated")
  case WaitingArbitration extends ExamQuestionResultStatus("waiting-arbitration")
  case AppealPending extends ExamQuestionResultStatus("appeal-pending")
  case AppealResolved extends ExamQuestionResultStatus("appeal-resolved")

object ExamQuestionResultStatus:
  given Encoder[ExamQuestionResultStatus] = Encoder.encodeString.contramap(_.value)
  given Decoder[ExamQuestionResultStatus] = Decoder.decodeString.emap {
    case Pending.value => Right(Pending)
    case Missing.value => Right(Missing)
    case Graded.value => Right(Graded)
    case Arbitrated.value => Right(Arbitrated)
    case WaitingArbitration.value => Right(WaitingArbitration)
    case AppealPending.value => Right(AppealPending)
    case AppealResolved.value => Right(AppealResolved)
    case value => Left(s"未知考试结果状态: $value")
  }
