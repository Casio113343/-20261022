package microservices.assignment.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.tables.AssignmentTableReads
import microservices.course.api.responses.CourseDetailResponse
import microservices.assignment.objects.AssignmentSubmission
import microservices.assignment.tables.AssignmentTableWrites
import microservices.course.tables.CourseTableReads
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.support.CourseAccessSupport.{isContentVisibleToUser, isCurrentStudent}
import shared.id.IdGenerator
import infrastructure.storage.AttachmentSupport.normalizeAttachment

import java.time.Instant

final case class CreateSubmissionAPIMessage(assignmentId: String, operatorUserId: String, input: AssignmentSubmission) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        CourseTableReads.lookupCourseId(connection, AssignmentTableReads.courseIdByAssignmentIdSql, assignmentId).flatMap {
          case None => IO.pure(Left("作业不存在"))
          case Some(courseId) =>
            val now = Instant.now()
            for
              courseEither <- CourseTableReads.loadCourseById(connection, courseId)
              studentEither <- AuthTableReads.loadUserById(connection, operatorUserId)
              assignmentEither <- AssignmentTableReads.loadAssignmentById(connection, assignmentId)
              existingSubmissionEither <- AssignmentTableReads.findSubmissionForAssignmentAndStudent(connection, assignmentId, operatorUserId)
              validationEither = for
                course <- courseEither
                student <- studentEither
                assignment <- assignmentEither
                existingSubmission <- existingSubmissionEither
                _ <- Either.cond(assignment.courseId == course.id, (), "作业不属于当前课程")
                _ <- Either.cond(student.role == UserRole.Student && isCurrentStudent(course, student.id) && isContentVisibleToUser(course, student.id, assignment.createdAt), (), "只有本课程学生可以提交该作业")
                normalizedContent = input.content.trim
                normalizedAttachment = normalizeAttachment(input.attachment)
                _ <- Either.cond(existingSubmission.isEmpty, (), "该作业已经提交，不能再次提交")
                _ <- Either.cond(normalizedContent.nonEmpty || normalizedAttachment.nonEmpty, (), "提交文本和附件至少填写一项")
                _ <- Either.cond(!now.isAfter(assignment.dueAt) || assignment.allowLateSubmission, (), "作业已截止，当前不允许补交")
              yield AssignmentSubmission(IdGenerator.nextId("submission"), assignment.id, student.id, normalizedContent, normalizedAttachment, now)
              result <- validationEither match
                case Left(error) => IO.pure(Left(error))
                case Right(submission) =>
                  for
                    _ <- IO.blocking(AssignmentTableWrites.upsertSubmission(connection, submission))
                    detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, operatorUserId)
                  yield detailEither
            yield result
        }
      }
      response <- resolveEither(result)
    yield response

object CreateSubmissionAPIMessage:
  given Codec.AsObject[CreateSubmissionAPIMessage] = deriveCodec
