package microservices.assignment.api.boundary

import cats.effect.IO
import infrastructure.api.ActionResponse
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.objects.Assignment
import microservices.assignment.tables.AssignmentTableWrites

final case class ReleaseLeavingTeacherAssignmentReviewResponsibilitiesAPIMessage(assignments: List[Assignment]) extends APIMessage[ActionResponse]:
  def plan: IO[ActionResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        IO.blocking(assignments.foreach(AssignmentTableWrites.upsertAssignment(connection, _))).as(Right(()): Either[String, Unit])
      }
      _ <- resolveEither(result)
    yield ActionResponse("离课教师的作业批改关系已处理")

object ReleaseLeavingTeacherAssignmentReviewResponsibilitiesAPIMessage:
  given Codec.AsObject[ReleaseLeavingTeacherAssignmentReviewResponsibilitiesAPIMessage] = deriveCodec
