package microservices.exam.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser
import shared.model.SharedCodecs.given

final case class ExamTeacherScoreRow(
    student: PublicUser,
    totalScore: Option[BigDecimal],
    questions: List[ExamTeacherScoreCell]
)
object ExamTeacherScoreRow:
  given Codec[ExamTeacherScoreRow] = deriveCodec
