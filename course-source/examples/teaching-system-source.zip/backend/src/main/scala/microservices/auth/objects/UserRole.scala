package microservices.auth.objects

import io.circe.{Decoder, Encoder}

enum UserRole:
  case Teacher, Student

object UserRole:
  given Encoder[UserRole] = Encoder.encodeString.contramap(_.toString.toLowerCase)
  given Decoder[UserRole] = Decoder.decodeString.emap {
    case "teacher" => Right(UserRole.Teacher)
    case "student" => Right(UserRole.Student)
    case other => Left(s"Unsupported user role: $other")
  }
