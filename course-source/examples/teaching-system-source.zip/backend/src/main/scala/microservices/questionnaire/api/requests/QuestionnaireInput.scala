package microservices.questionnaire.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.questionnaire.objects.QuestionnaireQuestion
import shared.model.SharedCodecs.given

import java.time.Instant

final case class QuestionnaireInput(
    title: String,
    overview: Option[String],
    anonymous: Boolean,
    questions: List[QuestionnaireQuestion],
    dueAt: Instant
)

object QuestionnaireInput:
  given Codec.AsObject[QuestionnaireInput] = deriveCodec
