package microservices.assignment.tables

import microservices.assignment.objects.{Assignment, AssignmentSubmission, SubmissionReview}
import shared.jdbc.JdbcStatementSupport.{setInstant, setIntOpt, setJsonbOpt, setStringOpt, withPrepared}

import java.sql.Connection

object AssignmentTableWrites:
  def saveAssignments(
    connection: Connection,
    assignments: Iterable[Assignment],
    submissions: Iterable[AssignmentSubmission],
    reviews: Iterable[SubmissionReview]
  ): Unit =
    assignments.foreach(insertAssignment(connection, _))
    submissions.foreach(insertSubmission(connection, _))
    reviews.foreach(insertReview(connection, _))

  def upsertSubmission(connection: Connection, submission: AssignmentSubmission): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_submissions (id, assignment_id, student_id, content, attachment, submitted_at)
        |values (?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set assignment_id = excluded.assignment_id,
        |    student_id = excluded.student_id,
        |    content = excluded.content,
        |    attachment = excluded.attachment,
        |    submitted_at = excluded.submitted_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, submission.id)
      statement.setString(2, submission.assignmentId)
      statement.setString(3, submission.studentId)
      statement.setString(4, submission.content)
      setJsonbOpt(statement, 5, submission.attachment)
      setInstant(statement, 6, submission.submittedAt)
      statement.executeUpdate()
    }

  def upsertAssignment(connection: Connection, assignment: Assignment): Unit =
    withPrepared(
      connection,
      """
        |insert into teaching_assignments (id, course_id, title, content, attachment, allow_late_submission, max_score, grader_teacher_id, due_at, created_by_teacher_id, created_at, answer_attachment, answer_published_at)
        |values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        |on conflict (id) do update
        |set course_id = excluded.course_id,
        |    title = excluded.title,
        |    content = excluded.content,
        |    attachment = excluded.attachment,
        |    allow_late_submission = excluded.allow_late_submission,
        |    max_score = excluded.max_score,
        |    grader_teacher_id = excluded.grader_teacher_id,
        |    due_at = excluded.due_at,
        |    created_by_teacher_id = excluded.created_by_teacher_id,
        |    created_at = excluded.created_at,
        |    answer_attachment = excluded.answer_attachment,
        |    answer_published_at = excluded.answer_published_at
        |""".stripMargin
    ) { statement =>
      statement.setString(1, assignment.id)
      statement.setString(2, assignment.courseId)
      statement.setString(3, assignment.title)
      statement.setString(4, assignment.content)
      setJsonbOpt(statement, 5, assignment.attachment)
      statement.setBoolean(6, assignment.allowLateSubmission)
      setIntOpt(statement, 7, assignment.maxScore)
      statement.setString(8, assignment.graderTeacherId)
      setInstant(statement, 9, assignment.dueAt)
      statement.setString(10, assignment.createdByTeacherId)
      setInstant(statement, 11, assignment.createdAt)
      setJsonbOpt(statement, 12, assignment.answerAttachment)
      assignment.answerPublishedAt match
        case Some(value) => setInstant(statement, 13, value)
        case None => statement.setObject(13, null)
      statement.executeUpdate()
    }

  def deleteAssignment(connection: Connection, assignmentId: String): Unit =
    withPrepared(connection, "delete from teaching_assignments where id = ?") { statement =>
      statement.setString(1, assignmentId)
      statement.executeUpdate()
    }

  def deleteSubmission(connection: Connection, submissionId: String): Unit =
    withPrepared(connection, "delete from teaching_submissions where id = ?") { statement =>
      statement.setString(1, submissionId)
      statement.executeUpdate()
    }

  def deleteReview(connection: Connection, reviewId: String): Unit =
    withPrepared(connection, "delete from teaching_reviews where id = ?") { statement =>
      statement.setString(1, reviewId)
      statement.executeUpdate()
    }

  def replaceReviewForSubmission(connection: Connection, review: SubmissionReview): Unit =
    withPrepared(connection, "delete from teaching_reviews where submission_id = ?") { statement =>
      statement.setString(1, review.submissionId)
      statement.executeUpdate()
    }
    insertReview(connection, review)

  private def insertAssignment(connection: Connection, assignment: Assignment): Unit =
    upsertAssignment(connection, assignment)

  private def insertSubmission(connection: Connection, submission: AssignmentSubmission): Unit =
    upsertSubmission(connection, submission)

  private def insertReview(connection: Connection, review: SubmissionReview): Unit =
    withPrepared(connection, "insert into teaching_reviews (id, submission_id, grader_teacher_id, score, comment, reviewed_at) values (?, ?, ?, ?, ?, ?)") { statement =>
      statement.setString(1, review.id)
      statement.setString(2, review.submissionId)
      statement.setString(3, review.graderTeacherId)
      setIntOpt(statement, 4, review.score)
      setStringOpt(statement, 5, review.comment)
      setInstant(statement, 6, review.reviewedAt)
      statement.executeUpdate()
    }
