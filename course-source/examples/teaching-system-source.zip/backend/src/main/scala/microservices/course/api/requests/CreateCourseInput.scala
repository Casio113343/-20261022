package microservices.course.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec

final case class CreateCourseInput(
    title: String,
    description: String
)
object CreateCourseInput:
  given Codec[CreateCourseInput] = deriveCodec
