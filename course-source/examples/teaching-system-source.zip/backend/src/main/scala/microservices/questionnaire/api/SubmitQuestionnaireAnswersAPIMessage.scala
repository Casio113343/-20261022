package microservices.questionnaire.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.support.CourseAccessSupport.{isCurrentStudent, isContentVisibleToUser}
import microservices.course.tables.CourseTableReads
import microservices.questionnaire.api.requests.QuestionnaireSubmissionInput
import microservices.questionnaire.api.responses.QuestionnaireDetailResponse
import microservices.questionnaire.objects.{QuestionnaireAnswer, QuestionnaireQuestion, QuestionnaireQuestionType, QuestionnaireSubmission}
import microservices.questionnaire.tables.{QuestionnaireTableReads, QuestionnaireTableWrites}
import shared.id.IdGenerator

import java.time.Instant

final case class SubmitQuestionnaireAnswersAPIMessage(questionnaireId: String, userId: String, input: QuestionnaireSubmissionInput) extends APIMessage[QuestionnaireDetailResponse]:
  def plan: IO[QuestionnaireDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        val now = Instant.now()
        for
          userEither <- AuthTableReads.loadUserById(connection, userId)
          questionnaireEither <- QuestionnaireTableReads.loadQuestionnaireById(connection, questionnaireId)
          courseEither <- questionnaireEither match
            case Left(error) => IO.pure(Left(error))
            case Right(questionnaire) => CourseTableReads.loadCourseById(connection, questionnaire.courseId)
          existingSubmissionEither <- QuestionnaireTableReads.findSubmissionForStudent(connection, questionnaireId, userId)
          validationEither = for
            user <- userEither
            questionnaire <- questionnaireEither
            course <- courseEither
            existingSubmission <- existingSubmissionEither
            _ <- Either.cond(user.role == UserRole.Student && isCurrentStudent(course, user.id) && isContentVisibleToUser(course, user.id, questionnaire.createdAt), (), "只有当前课程学生可以填写问卷")
            _ <- Either.cond(now.isBefore(questionnaire.dueAt), (), "问卷已截止")
            _ <- Either.cond(existingSubmission.isEmpty, (), "每人只能填写一次问卷")
            answers <- validateAnswers(questionnaire.questions, input.answers)
          yield QuestionnaireSubmission(IdGenerator.nextId("questionnaire-submission"), questionnaire.id, user.id, answers, now)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right(submission) =>
              for
                _ <- IO.blocking(QuestionnaireTableWrites.insertSubmission(connection, submission))
                detailEither <- QuestionnaireTableReads.loadQuestionnaireDetailFromTables(connection, questionnaireId, userId)
              yield detailEither
        yield result
      }
      response <- resolveEither(result)
    yield response

  private def validateAnswers(questions: List[QuestionnaireQuestion], answers: List[QuestionnaireAnswer]): Either[String, List[QuestionnaireAnswer]] =
    val answerByQuestionId = answers.map(answer => answer.questionId -> answer).toMap
    questions.foldLeft[Either[String, List[QuestionnaireAnswer]]](Right(Nil)) { (accumulator, question) =>
      for
        values <- accumulator
        answer = answerByQuestionId.getOrElse(question.id, QuestionnaireAnswer(question.id, Nil, None))
        normalized <- validateAnswer(question, answer)
      yield values :+ normalized
    }

  private def validateAnswer(question: QuestionnaireQuestion, answer: QuestionnaireAnswer): Either[String, QuestionnaireAnswer] =
    question.questionType match
      case QuestionnaireQuestionType.SingleChoice =>
        val selected = answer.selectedOptions.map(_.trim).filter(_.nonEmpty).distinct
        for
          _ <- Either.cond(!question.required || selected.nonEmpty, (), s"${question.title} 为必填题")
          _ <- Either.cond(selected.length <= 1, (), s"${question.title} 只能选择一个选项")
          _ <- Either.cond(selected.forall(question.options.contains), (), s"${question.title} 包含无效选项")
        yield QuestionnaireAnswer(question.id, selected, None)
      case QuestionnaireQuestionType.MultipleChoice =>
        val selected = answer.selectedOptions.map(_.trim).filter(_.nonEmpty).distinct
        for
          _ <- Either.cond(!question.required || selected.nonEmpty, (), s"${question.title} 为必填题")
          _ <- Either.cond(selected.forall(question.options.contains), (), s"${question.title} 包含无效选项")
        yield QuestionnaireAnswer(question.id, selected, None)
      case QuestionnaireQuestionType.Text =>
        val text = answer.text.map(_.trim).filter(_.nonEmpty)
        Either.cond(!question.required || text.nonEmpty, QuestionnaireAnswer(question.id, Nil, text), s"${question.title} 为必填题")

object SubmitQuestionnaireAnswersAPIMessage:
  given Codec.AsObject[SubmitQuestionnaireAnswersAPIMessage] = deriveCodec
