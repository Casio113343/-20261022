package microservices.assignment.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.assignment.tables.AssignmentTableReads
import microservices.course.api.responses.CourseDetailResponse
import microservices.auth.objects.UserRole
import microservices.auth.tables.AuthTableReads
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.assignment.objects.SubmissionReview
import microservices.assignment.tables.AssignmentTableWrites
import microservices.course.tables.CourseTableReads
import shared.id.IdGenerator

import java.time.Instant

final case class ReviewSubmissionAPIMessage(submissionId: String, operatorUserId: String, input: SubmissionReview) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        CourseTableReads.lookupCourseId(connection, AssignmentTableReads.courseIdBySubmissionIdSql, submissionId).flatMap {
          case None => IO.pure(Left("提交不存在"))
          case Some(courseId) =>
            val now = Instant.now()
            for
              courseEither <- CourseTableReads.loadCourseById(connection, courseId)
              teacherEither <- AuthTableReads.loadUserById(connection, operatorUserId)
              submissionEither <- AssignmentTableReads.loadSubmissionById(connection, submissionId)
              assignmentEither <- submissionEither match
                case Left(error) => IO.pure(Left(error))
                case Right(submission) => AssignmentTableReads.loadAssignmentById(connection, submission.assignmentId)
              validationEither = for
                course <- courseEither
                teacher <- teacherEither
                submission <- submissionEither
                assignment <- assignmentEither
                _ <- Either.cond(assignment.courseId == course.id, (), "作业不属于当前课程")
                _ <- Either.cond(teacher.role == UserRole.Teacher && assignment.graderTeacherId == teacher.id && isCurrentTeacher(course, teacher.id), (), "只有负责批改的老师可以处理该提交")
                score <- assignment.maxScore match
                  case Some(maxScore) =>
                    input.score match
                      case Some(value) if value >= 0 && value <= maxScore => Right(Some(value))
                      case Some(_) => Left(s"评分必须在 0 到 $maxScore 之间")
                      case None => Left("该作业已设置满分，批改时必须给出分数")
                  case None =>
                    input.score match
                      case Some(value) if value >= 0 => Right(Some(value))
                      case Some(_) => Left("评分不能为负数")
                      case None => Right(None)
              yield SubmissionReview(IdGenerator.nextId("review"), submission.id, teacher.id, score, input.comment.map(_.trim).filter(_.nonEmpty), now)
              result <- validationEither match
                case Left(error) => IO.pure(Left(error))
                case Right(review) =>
                  for
                    _ <- IO.blocking(AssignmentTableWrites.replaceReviewForSubmission(connection, review))
                    detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, operatorUserId)
                  yield detailEither
            yield result
        }
      }
      response <- resolveEither(result)
    yield response

object ReviewSubmissionAPIMessage:
  given Codec.AsObject[ReviewSubmissionAPIMessage] = deriveCodec
