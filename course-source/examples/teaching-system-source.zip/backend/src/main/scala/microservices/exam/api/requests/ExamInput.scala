package microservices.exam.api.requests

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import shared.model.SharedCodecs.given

import java.time.Instant

final case class ExamInput(
    title: String,
    questions: List[ExamQuestionInput],
    appealDueAt: Option[Instant]
)
object ExamInput:
  given Codec[ExamInput] = deriveCodec
