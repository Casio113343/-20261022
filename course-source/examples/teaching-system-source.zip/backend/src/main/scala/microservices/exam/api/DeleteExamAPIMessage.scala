package microservices.exam.api

import cats.effect.IO
import infrastructure.database.DatabaseSession
import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import infrastructure.api.APIMessage
import microservices.auth.objects.UserRole
import microservices.auth.tables.{AuthTableReads, AuthTableWrites}
import microservices.course.api.responses.CourseDetailResponse
import microservices.course.support.CourseAccessSupport.isCurrentTeacher
import microservices.course.tables.CourseTableReads
import microservices.exam.tables.{ExamTableReads, ExamTableWrites}

final case class DeleteExamAPIMessage(courseId: String, examId: String, userId: String) extends APIMessage[CourseDetailResponse]:
  def plan: IO[CourseDetailResponse] =
    for
      result <- DatabaseSession.withTransactionConnection { connection =>
        for
          courseEither <- CourseTableReads.loadCourseById(connection, courseId)
          userEither <- AuthTableReads.loadUserById(connection, userId)
          examEither <- ExamTableReads.loadExamById(connection, examId)
          questionsEither <- ExamTableReads.loadExamQuestionsByExamIds(connection, List(examId))
          sheetsEither <- ExamTableReads.loadAnswerSheetsByExamIds(connection, List(examId))
          validationEither = for
            course <- courseEither
            user <- userEither
            exam <- examEither
            questions <- questionsEither
            sheets <- sheetsEither
            _ <- Either.cond(user.role == UserRole.Teacher && isCurrentTeacher(course, user.id), (), "只有本课程老师可以执行该操作")
            _ <- Either.cond(exam.courseId == course.id, (), "考试不属于当前课程")
          yield
            (questions.keys.toSet, sheets.keys.toSet, (course.teachers ++ course.students).distinct)
          result <- validationEither match
            case Left(error) => IO.pure(Left(error))
            case Right((questionIds, answerSheetIds, courseMemberIds)) =>
              for
                _ <- IO.blocking {
                  ExamTableWrites.deleteQuestionAppealsByAnswerSheetOrQuestionIds(connection, answerSheetIds, questionIds)
                  ExamTableWrites.deleteQuestionArbitrationsByAnswerSheetIds(connection, answerSheetIds)
                  ExamTableWrites.deleteQuestionGradingsByAnswerSheetIds(connection, answerSheetIds)
                  ExamTableWrites.deleteAnswerSheetsByExamId(connection, examId)
                  ExamTableWrites.deleteExamQuestionsByExamId(connection, examId)
                  ExamTableWrites.deleteExam(connection, examId)
                }
                usersEither <- AuthTableReads.loadUsersByIds(connection, courseMemberIds)
                userReadMarkersCleared <- usersEither match
                  case Left(error) => IO.pure(Left(error))
                  case Right(users) =>
                    val updatedUsers = users.values.toList
                      .map(user => user.copy(readPublishedExamIds = user.readPublishedExamIds.filterNot(_ == examId)))
                      .filter(user => users(user.id).readPublishedExamIds != user.readPublishedExamIds)
                    IO.blocking(updatedUsers.foreach(AuthTableWrites.upsertUser(connection, _))).as(Right(()): Either[String, Unit])
                detailEither <- CourseTableReads.loadCourseDetailFromTables(connection, courseId, userId)
              yield for
                _ <- userReadMarkersCleared
                detail <- detailEither
              yield detail
        yield result
      }
      response <- resolveEither(result)
    yield response

object DeleteExamAPIMessage:
  given Codec.AsObject[DeleteExamAPIMessage] = deriveCodec
