package microservices.auth.api.responses

import io.circe.Codec
import io.circe.generic.semiauto.deriveCodec
import microservices.auth.objects.PublicUser

final case class LoginOutput(
    user: PublicUser
)

object LoginOutput:
  given Codec[LoginOutput] = deriveCodec
